# Databricks notebook source
# import http
# import requests
# import json
# import os
# import pandas as pd
# import numpy as np
# from pyspark.sql.types import StructType, StructField, StringType, LongType, DoubleType
# from datetime import datetime
# from pyspark.sql.functions import current_timestamp, lit
# from python_wheel import hello

# COMMAND ----------

# MAGIC %run "/Shared/Utilities/utils"

# COMMAND ----------

TrakCareSource = "DM"
TrakURL = "jdbc:IRIS://100.85.26.81:1972/SCR-TRAK"

# COMMAND ----------

etlControlData= read_from_mi_db('ADM_Config',f'select * from etl.control_cds')

# COMMAND ----------

display(etlControlData)

# COMMAND ----------

# table_write_path =  "dbfs:/mnt/devcdpadlsae1/bronze/trakcare_live/cds_bronze_recon"
# results_df.write.format("delta").mode("append").save(table_write_path)

# COMMAND ----------

table_name = "adm_config.control_cds"
etlControlData.write.mode("overwrite").saveAsTable(table_name) 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from adm_config.control_cds;
