# Databricks notebook source
import http
import requests
import json
import os
import pandas as pd
import numpy as np
from pyspark.sql.types import StructType, StructField, StringType, LongType, DoubleType
from datetime import datetime
from pyspark.sql.functions import current_timestamp, lit
from python_wheel import hello

# COMMAND ----------

# %run "/Shared/Utilities/utils"

# COMMAND ----------

TrakCareSource = "DM"
TrakURL = "jdbc:IRIS://100.85.26.81:1972/SCR-TRAK"

# COMMAND ----------

# TRAKProdURL = "http://rpt1.trak.hanz.health.nz:1972/SCR-TRAK"

TRAKProdURL = "jdbc:IRIS://100.84.27.16:1972/SCR-TRAK"

# COMMAND ----------

def get_data_from_trak(query):
    remote_table = spark.read.format("jdbc")\
        .option("url", TRAKProdURL)\
        .option("driver", "com.intersystems.jdbc.IRISDriver")\
        .option("query", query)\
        .option("user", "dw_powerbi_direct")\
        .option("password", dbutils.secrets.get(scope='AzureSecretScope',key='prod-test-UAT-IRIS'))\
        .load() 
    return remote_table 

# COMMAND ----------

tables = [
"pa_adm"
# ,"pa_admtransaction"
# ,"mr_adm"
# ,"mr_diagnos"
# ,"or_anaest_operation"
# ,"or_an_oper_secondaryproc"
# ,"pa_patmas"
# ,"pa_personethnicity"
# ,"rb_reseffdate"
# ,"rb_reseffdatesession"
# ,"rb_reseffdatesessotspec"
# ,"rb_appointment"
# ,"rb_operatingroom"
# ,"or_anaesthesia"
# ,"rb_apptschedule"
# ,"pa_person"
]

# COMMAND ----------

def get_source_table_count(table_name):
    query = f"(SELECT COUNT(1) AS Total_Patients FROM SQLUser.{table_name})"
    result_df = get_data_from_trak(query).collect()[0][0]
    return result_df

# COMMAND ----------

def get_dest_table_count(table_name):
    delta_table_path = f"dbfs:/mnt/devcdpadlsae1/bronze/trakcare_live/tc_{table_name}"
    count = spark.read.format("delta").load(delta_table_path).count()
    return count

# COMMAND ----------

results = []
for table in tables:
    source_count = get_source_table_count(table)
    dest_count = get_dest_table_count(table)
    difference = source_count - dest_count
    if source_count != 0:
        ratio = (dest_count / source_count) * 100.0
    else:
        ratio = 0.0
    results.append((table, source_count, dest_count, difference,ratio))
    


# COMMAND ----------

schema = StructType([
    StructField("TableName", StringType(), True),
    StructField("SourceCount", LongType(), True),
    StructField("DestCount", LongType(), True),
    StructField("Difference", LongType(), True),
    StructField("Ratio", DoubleType(), True)
])

# COMMAND ----------

results_df = spark.createDataFrame(results, schema)

# COMMAND ----------

current_date = datetime.now().replace(microsecond=0)
results_df = results_df.withColumn("DateTime",lit(current_date))

# COMMAND ----------

results_df.show(truncate=False)

# COMMAND ----------

# table_write_path =  "dbfs:/mnt/devcdpadlsae1/bronze/trakcare_live/cds_bronze_recon"
# results_df.write.format("delta").mode("append").save(table_write_path)

# COMMAND ----------

table_name = "bronze_live.cds_bronze_recon"
results_df.write.mode("overwrite").saveAsTable(table_name) 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from bronze_live.cds_bronze_recon;
