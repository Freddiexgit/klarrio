# Databricks notebook source
# MAGIC %md
# MAGIC #### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 6-Apr-2024 | 1      | Siddharth Saravanan    | First draft of CDS Child notebook                 |
# MAGIC
# MAGIC

# COMMAND ----------

dbutils.widgets.text("etlControlID", "","")

# COMMAND ----------

import pandas as pd
import datetime
import pytz
import pyodbc
from pyspark.sql.window import Window
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import SparkSession

# COMMAND ----------

# DBTITLE 1,Reset
# Use the function below if you need to reset the development and start from scratch.  
# reset_table('silver_live', 'trakcare_live/CDS', 'cds_admission', 2193)

# COMMAND ----------

etlControlID=dbutils.widgets.get("etlControlID")
print(etlControlID)

# COMMAND ----------

def merge_delta_tables(input_df, db_name, table_name, merge_condition, matched_additional_condition=None ):
    from delta.tables import DeltaTable
    spark.conf.set("spark.databricks.optimizer.dynamicPartitionPruning", "true")
    
 #   from delta.tables 
    if (spark._jsparkSession.catalog().tableExists(f"{db_name}.{table_name}")):
        #merge
        deltaTable = DeltaTable.forName(spark, f"{db_name}.{table_name}")
        deltaTable.alias("TARGET")\
        .merge(input_df.alias("SOURCE"), merge_condition) \
        .whenMatchedUpdateAll(matched_additional_condition) \
        .whenNotMatchedInsertAll() \
        .execute()
    else:
        # runs the first time and creates the table
        # output_df.write.mode("append").partitionBy('race_id').format("parquet").saveAsTable(f"{db_name}.{table_name}")
        input_df.write.mode("overwrite").format("delta").saveAsTable(f"{db_name}.{table_name}")

# COMMAND ----------

def update_watermark(watermark,etlControlID):
    spark.sql(f"""
    UPDATE bronze_live.etl_control_cds
    SET WaterMarkValue = '{watermark}'
    WHERE ETLControlID = {etlControlID}
    """)

# COMMAND ----------

def datetime_nz():
    return pytz.utc.localize(datetime.datetime.utcnow()).astimezone(pytz.timezone("Pacific/Auckland")).strftime('%Y-%m-%d %H:%M:%S')

# COMMAND ----------

#Get the metadata from the ETLControl table. This is based on a hardwired ETLControlID
qry = f"""
       SELECT 
              ETLControlID
            , SourceSystem
            , SourceSystemType
            , SourceEntityPath
            , SourceTableSchemaName
            , SourceTableName
            , SourceQuery
            , CASE WHEN IncrementalLoad = 1 THEN WaterMarkValue ELSE '1900-01-01 00:00:00' END WaterMarkValue
            , TargetSystemType
            , TargetTableSchemaName
            , TargetTableName
            , StoredProcName
            , IncrementalLoad
            , IsActive
            , TargetEntityPath
            , CustomConfig
        FROM bronze_live.etl_control_cds
        WHERE ETLControlID = {etlControlID}"""


# Convert the DataFrame to a list of Row objects and get the first row
df_control = spark.sql(qry).collect()[0]

# COMMAND ----------

v_watermark_date = df_control["WaterMarkValue"]
v_incremental_load = df_control["IncrementalLoad"]

v_source_system = df_control["SourceSystem"]
v_source_database = df_control["SourceEntityPath"]
v_source_table_name = df_control["SourceTableName"]
v_source_table_schema = df_control["SourceTableSchemaName"]

v_target_system_type = df_control["TargetSystemType"]
v_target_table_name = df_control["TargetTableName"]
v_target_table_schema = df_control["TargetTableSchemaName"]
v_target_mi_database = df_control["TargetEntityPath"]

v_stored_proc = df_control["StoredProcName"]
v_merge_column = df_control["CustomConfig"]
v_source_query = df_control["SourceQuery"]

v_source_view = f'{v_source_table_schema}.{v_source_table_name}'
v_source_mi_view = f'{v_source_database}.{v_source_table_schema}.{v_source_table_name}'
v_target_table = f'{v_target_table_schema}.{v_target_table_name}'

# COMMAND ----------

print(qry)

# COMMAND ----------

print(v_watermark_date)

# COMMAND ----------

print(v_target_system_type)

# COMMAND ----------

# if v_target_system_type == "ADLS":
#     v_new_watermark = (
#         spark.sql(
#             f"SELECT max(watermark_value) AS v_new_watermark_value FROM {v_source_view}"
#         )
#         .select("v_new_watermark_value")
#         .collect()[0][0]
#     )

#     if v_new_watermark is None:
#         dbutils.notebook.exit("Watermark value is empty in bronze table")
#     else:
#         print(v_new_watermark)

# COMMAND ----------

print('Getting the delta records')
df_view = spark.sql(f"SELECT * FROM {v_source_view} WHERE processing_time > '{v_watermark_date}'")
# set the merge condition required for the merge functions
merge_condition = 'TARGET.uid = SOURCE.uid'

# merge the data from df_hashed to target delta table
print(etlControlID)
print('TargetDatabase')
print(v_target_table_schema)
print('TargetTableName')
print(v_target_table_name)
print('merge_condition')
print(merge_condition)
print(df_view)
merge_delta_tables(df_view, v_target_table_schema, v_target_table_name, merge_condition)
print('Data merged to the target table')

#Updating Watermark value
print('value to update to watermark after running the query')
watermark_toUpdate = datetime_nz()
print(watermark_toUpdate)
update_watermark(watermark_toUpdate,etlControlID)
print('watermark updated')


# COMMAND ----------

# if v_target_system_type == "ADLS":
#     print('Running ADLS')

#     if v_watermark_date >= v_new_watermark:
    
#         print('Do not run the query')
#         run_query = False
#         print('Updating the watermark value to current runtime')
#         watermark_toUpdate = datetime_nz()
#         update_watermark(watermark_toUpdate,etlControlID)
#         print('watermark updated')
#         print(watermark_toUpdate)
#         dbutils.notebook.exit("Processing complete")


#     else: 
#         print('Run the query')
#         run_query = True
#         print(run_query)
#         if run_query == True:
#             print('Getting the delta records')
#             df_view = spark.sql(f"SELECT * FROM {v_source_view} WHERE processing_time > '{v_watermark_date}'")
#             # set the merge condition required for the merge functions
#             merge_condition = 'TARGET.uid = SOURCE.uid'

#             # merge the data from df_hashed to target delta table
#             print(etlControlID)
#             print('TargetDatabase')
#             print(v_target_table_schema)
#             print('TargetTableName')
#             print(v_target_table_name)
#             print('merge_condition')
#             print(merge_condition)
#             print(df_view)
#             merge_delta_tables(df_view, v_target_table_schema, v_target_table_name, merge_condition)
#             print('Data merged to the target table')

#             #Updating Watermark value
#             print('value to update to watermark after running the query')
#             watermark_toUpdate = datetime_nz()
#             print(watermark_toUpdate)
#             update_watermark(watermark_toUpdate,etlControlID)
#             print('watermark updated')
  
    
