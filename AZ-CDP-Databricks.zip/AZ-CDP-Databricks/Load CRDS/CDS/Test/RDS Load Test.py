# Databricks notebook source
dbutils.widgets.text("etlControlID", "","")

# COMMAND ----------

dbutils.widgets.text("TrakCareSource", "DM")
TrakCareSource = dbutils.widgets.get("TrakCareSource")
if TrakCareSource == 'DM':
    #TrakURL = 'jdbc:IRIS://100.84.26.81:1972/SCR-TRAK' #New DM2 Endpoint
    TrakURL = 'jdbc:IRIS://100.85.26.81:1972/SCR-TRAK' #New DM2 Endpoint
else :
    #TrakURL = 'jdbc:IRIS://100.84.26.78:1972/SCR-TRAK'
    TrakURL = 'jdbc:IRIS://100.85.26.78:1972/SCR-TRAK'

# COMMAND ----------

import http
import requests
import json
import os
import pytz
import pandas as pd
from pyspark.sql.window import Window
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit
from pyspark.sql.types import StructField
import numpy as np
from datetime import datetime
import datetime


# COMMAND ----------

landing_folder_path = f"/mnt/devcdpadlsae1/landing/"
bronze_folder_path = f"/mnt/devcdpadlsae1/bronze/"
silver_folder_path = f"/mnt/devcdpadlsae1/silver/"
gold_folder_path = f"/mnt/devcdpadlsae1/gold/"

# COMMAND ----------

# MAGIC %md
# MAGIC ###The function gets data from Intersystems Data Migration/Functional server using the Spark JDBC driver

# COMMAND ----------

def get_data_from_trak(query):
    remote_table = spark.read.format("jdbc")\
        .option("url", TrakURL)\
        .option("driver", "com.intersystems.jdbc.IRISDriver")\
        .option("query", query)\
        .option("user", "aukdna")\
        .option("password", dbutils.secrets.get(scope='AzureSecretScope',key='IRIS'))\
        .load() 
    return remote_table 

# COMMAND ----------

def update_watermark(watermark,etlControlID):
    spark.sql(f"""
    UPDATE bronze_live.etl_control_cds
    SET WaterMarkValue = '{watermarkNew}'
    WHERE ETLControlID = {etlControlID}
    """)

# COMMAND ----------

# update_watermark('2024-06-19 10:18:39',2122)

# COMMAND ----------

def datetime_nz():
    return pytz.utc.localize(datetime.datetime.utcnow()).astimezone(pytz.timezone("Pacific/Auckland")).strftime('%Y-%m-%d %H:%M:%S')

# COMMAND ----------

# MAGIC %md
# MAGIC ###The code block below does lands and loads the Delta table without any logging steps. We will rely on alerting to tell us if a process breaks (performance is paramount)
# MAGIC ####1. Work out whether or not the source table is a Trak table or not.
# MAGIC ####2. Work out if the table is an incremental load or a full load
# MAGIC ####3. Merge new or changed data. Do not merge the schema, we don't want new columns added to the Delta target table
# MAGIC
# MAGIC #####Note: Ensure we add the extra columns for file name, processing date and rescued data column so that target and source have identical schema

# COMMAND ----------

etlControlID=dbutils.widgets.get("etlControlID")
print(etlControlID)
#Get the metadata from the ETLControl table. This is based on a hardwired ETLControlID
etlControlData=spark.sql(f"""SELECT * FROM bronze_live.etl_control_cds WHERE etlcontrolID = {etlControlID}""")

# Convert the DataFrame to a list of Row objects and get the first row
etlControlRow = etlControlData.collect()[0]

# Extract the values from the Row object
database_name = etlControlRow["SourceSystem"]
Sourcefilename = etlControlRow["SourceTableName"]
SourceQuery = etlControlRow["SourceQuery"]
WaterMarkQuery = etlControlRow["WaterMarkQuery"] if "WaterMarkQuery" in etlControlRow else None
IncrementalLoadFlag = etlControlRow["IncrementalLoad"]
etlControlID = etlControlRow["ETLControlID"]
SourceQueryWhereClause = etlControlRow["SourceQueryWhereClause"] if "SourceQueryWhereClause" in etlControlRow else None
WaterMarkValue = etlControlRow["WaterMarkValue"] if "WaterMarkValue" in etlControlRow else None
TargetTableSchemaName = f'{etlControlRow["TargetTableSchemaName"]}_live'
TargetTableName = etlControlRow["TargetTableName"].replace('_l_', '_lv_')
IncrementalClauseQuery = etlControlRow["IncrementalClauseQuery"] if "IncrementalClauseQuery" in etlControlRow else None
MergeColumn = None
if "CustomConfig" in etlControlRow and etlControlRow["CustomConfig"]:
    CustomConfig = json.loads(etlControlRow["CustomConfig"])
    MergeColumn = CustomConfig["MergeColumn"]

current_datetime_nz = datetime.datetime.now()
folder_date_YYYYMMDD = current_datetime_nz.strftime("%Y/%m/%d")    
SourceDirectory =f"/{database_name}_live/Archive/{Sourcefilename}/{folder_date_YYYYMMDD}/"

dateNOW = datetime.datetime.strptime(datetime_nz(), '%Y-%m-%d %H:%M:%S').date()
timeNOW = datetime.datetime.strptime(datetime_nz(), '%Y-%m-%d %H:%M:%S').time()
lastWaterMarkDate = datetime.datetime.strptime(WaterMarkValue, '%Y-%m-%d %H:%M:%S').date() #Capture last watermark date from SQL MI
lastWaterMarkTime = datetime.datetime.strptime(WaterMarkValue, '%Y-%m-%d %H:%M:%S').time() #Capture last watermark time from SQL MI

# COMMAND ----------

# Print extracted values (optional)
# print("Database Name:", database_name)
# print("Source Filename:", Sourcefilename)
# print("Source Query:", SourceQuery)
# print("WaterMark Query:", WaterMarkQuery)
# print("Incremental Load Flag:", IncrementalLoadFlag)
# print("ETL Control ID:", etlControlID)
# print("Source Query Where Clause:", SourceQueryWhereClause)
# print("WaterMark Value:", WaterMarkValue)
# print("Target Table Schema Name:", TargetTableSchemaName)
# print("Target Table Name:", TargetTableName)
# print("Incremental Clause Query:", IncrementalClauseQuery)
# print("Merge Column:", MergeColumn)

# print("Current Date:", dateNOW)
# print("Current Time:", timeNOW)
# print("Last WaterMark Date:", lastWaterMarkDate)
# print("Last WaterMark Time:", lastWaterMarkTime)
# print("Source Directory:", SourceDirectory)

# COMMAND ----------

# print( f"{SourceDirectory}{TargetTableName}_{current_YYYYMMDDHHMMSS_nz}/*.parquet")

# COMMAND ----------

try:
    #Set this so we can check if it exists later. It is to solve the problem of checking if a date exists
    watermarkNew = None

    skip_cell = False	
    #Initiate Watermark and Query variables	
    if database_name.lower()=="Trakcare".lower() and  IncrementalLoadFlag==True:		
        print(f"Setting variables")
        print(f"###########################")		
        #Watermark variables
        watermarkDateNew = get_data_from_trak(WaterMarkQuery).collect()[0][0]
        watermarkTimeNew = get_data_from_trak(WaterMarkQuery).collect()[0][1]
        watermarkTimeNew = watermarkTimeNew.time() #Extract Timestamp from returned datetime value
        v_watermarkdt_from_trak = (watermarkDateNew.strftime("%Y-%m-%d") + ' ' + watermarkTimeNew.strftime("%H:%M:%S"))
       
	    #Replace placeholder values in SourceQueryWhereClause
        #If the Last Update DATE in TRAK is greater than the Watermark date in SQL MI, we set the timestamp to look for records from midnight to 23:59:59 to avoid missing records
        if watermarkDateNew > lastWaterMarkDate:
            lastUpdateTime = '00:00:00'
            SourceQueryWhereClauseNew = SourceQueryWhereClause.replace("<LastUpdateDate>", f"'{lastWaterMarkDate}'").replace("<CurrentDate>", f"'{dateNOW}'").replace("<LastUpdateTime>", f"'{lastUpdateTime}'").replace("<CurrentTime>", f"'23:59:59'")
        else:
            lastUpdateTime = lastWaterMarkTime #This is the last update time in TRAK
            SourceQueryWhereClauseNew = SourceQueryWhereClause.replace("<LastUpdateDate>", f"'{watermarkDateNew}'").replace("<CurrentDate>", f"'{dateNOW}'").replace("<LastUpdateTime>", f"'{lastUpdateTime}'").replace("<CurrentTime>", f"'{timeNOW}'")
	
        #The new SQL Query to run against TRAK
        SQLQueryFull=f"{SourceQuery} {SourceQueryWhereClauseNew}"
		
	#IF the Last Update date in TRAK is less than the Watermark date in SQL MI, it essentially means everything is upto date and there is no need to look for new data
    if database_name.lower()=="Trakcare".lower() and  IncrementalLoadFlag==True and watermarkDateNew == lastWaterMarkDate and watermarkTimeNew == lastWaterMarkTime:
        skip_cell = True
        print(f"No new changes reported for: {TargetTableName}")
        #Set Watermark value to NOW
        #watermarkNew = datetime_nz()
        # update_watermark(watermarkNew,etlControlID)
        #update_mi_water_mark_value(watermarkNew, etlControlID, 'Control_CDS')
        print('The table is upto date!')
        print("Processing complete")
	
	#Incremental Load
    elif database_name.lower()=="Trakcare".lower() and  IncrementalLoadFlag==True:
        print(f"Running Incremental Load for: {TargetTableName}")
        print(f"###########################")
        print("")
        print(f"SQL Query Sent to TRAK:")
        print(f"###########################")
        print(" ")
        print({SQLQueryFull})
        print(" ")
        print(f"###########################")
		
        #Get Data from TRAK
        remote_table=get_data_from_trak(SQLQueryFull)		
		#Set Watermark value to NOW
        watermarkNew = datetime_nz()
        # update_mi_water_mark_value(v_watermarkdt_from_trak, etlControlID, 'Control_CDS')
        update_watermark(watermarkNew,etlControlID)
        print('Watermark value updated in SQL MI')
	
	#Full Load
    elif database_name.lower()=="Trakcare".lower():
        print(f"Running Full Load for: {TargetTableName}")
        print(f"###########################")
        print("")
        print(f"SQL Query Sent to TRAK:")
        print(f"###########################")
        print(" ")
        print({SourceQuery})
        print(" ")
        print(f"###########################")
		
		#Get Data from TRAK
        remote_table=get_data_from_trak(SourceQuery)
		
		#Set Watermark value to NOW
        watermarkNew = datetime_nz()
        ##update_mi_water_mark_value(watermarkNew, etlControlID, 'Control_CDS')
        update_watermark(watermarkNew,etlControlID)
        print('Watermark value updated in SQL MI')
		
	#Non-Trak tables

    #Moved to separate notebook
	
	
	
	#Delta Table Merge/Overwrite logic
    if IncrementalLoadFlag==True and watermarkDateNew == lastWaterMarkDate and watermarkTimeNew == lastWaterMarkTime:
        print('Merge to Delta table not required. Table is upto date')
        skip_cell = True
        
    else:
		#Add additional columns
        rt1=remote_table.withColumn("source_file",lit("5 Minute Load"))
        rt1=rt1.withColumn("processing_time",lit(datetime_nz()))

        if not spark.catalog.tableExists(f"{TargetTableSchemaName}.{TargetTableName}"):
            print(f"Creating Delta table: {TargetTableSchemaName}.{TargetTableName}")
            spark.sql(f"CREATE table if not exists {TargetTableSchemaName}.{TargetTableName} Location '{bronze_folder_path}{database_name}_live/{TargetTableName}'")
            rt1.write.format("delta").mode("overwrite").option("mergeSchema", "true").save(f"{bronze_folder_path}{database_name}_live/{TargetTableName}")
            print("Delta Table Loaded")
            print(" ")
			
			#Write Parquet File

			
        elif IncrementalLoadFlag==True:
            print(f"Delta table: {TargetTableSchemaName}.{TargetTableName} exists. Proceeding with Merge")
            rt1.createOrReplaceTempView("updateTable0")
            spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled","true")
            
            spark.sql(f"""
                MERGE INTO {TargetTableSchemaName}.{TargetTableName} t USING updateTable0 s ON  t.{MergeColumn}=s.{MergeColumn}
                    WHEN MATCHED THEN UPDATE SET *
                    WHEN NOT MATCHED THEN INSERT * ;             
                """)
            print("Delta Table Loaded")
            print(" ")
			
            #Write Parquet File
			
        else:
            print(f"Delta table: {TargetTableSchemaName}.{TargetTableName} exists. Proceeding to Overwrite")
            rt1.write.format("delta").mode("overwrite").option("mergeSchema", "true").save(f"{bronze_folder_path}{database_name}_live/{TargetTableName}")
            print("Delta Table Loaded")
            print(" ")
			
            #Write Parquet File

	
except Exception as e:
    dbutils.notebook.exit(f"Error:{e} : {TargetTableName}: ")
	
else:
    print(f"###########################")
    print(" ")
    print(f"{TargetTableName} ran successfully")


# COMMAND ----------

# %sql
# select * from bronze_live.etl_control_cds where etlControlID = 2204
