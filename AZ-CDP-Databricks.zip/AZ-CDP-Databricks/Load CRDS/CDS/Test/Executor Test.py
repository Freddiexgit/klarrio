# Databricks notebook source
import os
import multiprocessing
from concurrent.futures import ThreadPoolExecutor

# COMMAND ----------

# Check number of processors
num_processors_os = os.cpu_count()
num_processors_mp = multiprocessing.cpu_count()

print(f"Number of processors (os): {num_processors_os}")
print(f"Number of processors (multiprocessing): {num_processors_mp}")

# Check default max_workers in ThreadPoolExecutor
executor = ThreadPoolExecutor()
default_max_workers = executor._max_workers
executor.shutdown()

print(f"Default max_workers in ThreadPoolExecutor: {default_max_workers}")
