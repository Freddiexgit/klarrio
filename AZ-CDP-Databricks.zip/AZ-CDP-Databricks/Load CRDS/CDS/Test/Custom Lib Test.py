# Databricks notebook source
from python_wheel import hello

# COMMAND ----------

hello()

# COMMAND ----------


