# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 07-May-2024 | 1       | Siddharth Saravanan     | Create first draft of permanent view vw_cds_trc_wardinterface                                    |
# MAGIC

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_trc_wardinterface""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_trc_wardinterface
AS
(
SELECT
(SELECT MAX(processing_time) FROM bronze_live.trc_wardinterface) AS watermark_value
,CONCAT(wiWardCode,wiIOCode) as UID
,wiWardCode
,wiIOCode
,wiForPMI
,wiForRoster
,wiForPayroll
,processing_time
FROM 
bronze_live.trc_wardinterface WI
)
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from silver_live.vw_cds_trc_wardinterface

# COMMAND ----------


