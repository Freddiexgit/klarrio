# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 07-May-2024 | 1       | Siddharth Saravanan     | Create first draft of permanent view vw_cds_trc_summaryshift                                      |
# MAGIC

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_trc_summaryshift""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_trc_summaryshift
AS
(
SELECT
(SELECT MAX(processing_time) FROM bronze_live.trc_summaryshift) AS watermark_value
,CONCAT(DATE(tlDate),tlShiftCode,tlWardCode) as UID
,date_format(tlDate, 'yyyy-MM-dd HH:mm:ss') as tlDate
,tlShiftCode
,tlWardCode
,tlRequiredHours
,tlClinicalInDeptHours
,tlNumberOfUnCategorisedPatients
,processing_time
FROM 
bronze_live.trc_summaryshift ss
)
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from silver_live.vw_cds_trc_summaryshift

# COMMAND ----------


