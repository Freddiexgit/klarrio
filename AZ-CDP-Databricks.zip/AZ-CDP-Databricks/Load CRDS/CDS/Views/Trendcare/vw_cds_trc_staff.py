# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 07-May-2024 | 1       | Siddharth Saravanan     | Create first draft of permanent view vw_cds_trc_staff                               |
# MAGIC

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_trc_staff""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_trc_staff
AS
(
SELECT
(SELECT MAX(processing_time) FROM bronze_live.trc_staff) AS watermark_value
,stStaffCode as UID
,stGivenNames
,stSurname
,stIsActive
,stStaffCode
,processing_time
FROM 
bronze_live.trc_staff Staff
)
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from silver_live.vw_cds_trc_staff

# COMMAND ----------


