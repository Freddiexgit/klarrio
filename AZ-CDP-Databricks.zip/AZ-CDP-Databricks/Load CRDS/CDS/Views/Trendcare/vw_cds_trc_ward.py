# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 07-May-2024 | 1       | Siddharth Saravanan     | Create first draft of permanent view vw_cds_trc_ward                                       |
# MAGIC

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_trc_ward""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_trc_ward
AS
(
SELECT
(SELECT MAX(processing_time) FROM bronze_live.trc_ward) AS watermark_value
,wdWardCode as UID
,wdWardCode
,wdIsActive
,wdName
,wdStartTimeForDayShift
,wdStartTimeForEveningShift
,wdStartTimeForNightShift
,wdNumberOfHoursInDayShift
,wdNumberOfHoursInEveningShift
,wdNumberOfHoursInNightShift
,wdUnproductiveDueToCaseMix
,wdAllowExtendedUnproductiveFactorOnNightShift
,wdDefaultPatientTypeCode
,wdDefaultCarePathCode
,wdHasSelectedPatientTypes
,wdHasSelectedCarePaths
,wdHandoverTimeOnDayShift
,wdHandoverTimeOnEveningShift
,wdHandoverTimeOnNightShift
,wdIsExcludedFromAcuity
,wdIsExcludedFromHospReports
,wdHasNoPredictivePhase
,wdHasOnlyDayShift
,wdHospitalCode
,wdDischargeTime
,wdDepartmentTypeCode
,wdHideAcuityDataSelReports
,wdWardDietEntryRestrictionFlag
,wdHasSelectedCarePlans
,wdDefaultCarePlanCode
,wdWardRosterSystem
,wdFTEHoursValueForDayShift
,wdFTEHoursValueForEveningShift
,wdFTEHoursValueForNightShift
,wdHideOvertimeAllocateStaff
,wdFundedFTEs
,wdCostCentreCode
,wdIsExcludedFromFlexibleBudgetReporting
,wdTCRosterWardAcronym
,wdDefaultStaffingAreaCode
,wdHideTOILAllocateStaff
,wdAlwaysDisplayOnCallColumn
,wdIsACFIWard
,wdShowMealBreakHrsColumn
,wdShowGenderColumn
,wdNumberOfFundedBeds
,wdShowStaffContractNumber
,wdNumberofInChargePerShift
,wdAllowTransferInFromDifferentHospital
,wdAllowTransferOutToDifferentHospital
,wdMealHoursDayShift
,wdMealHoursEveningShift
,wdMealHoursNightShift
,wdAllowDepartmentToProcessOutpatients
,wdShowNurseShiftOutcomesAllocStaff
,wdShowNurseShiftOutcomesInpShiftData
,wdNurseShiftOutcomesInpShiftDataMandatory
,wdWardFoodAllergyRestrictionFlag
,wdAuditSignonCode
,date_format(wdAuditDateTime, 'yyyy-MM-dd HH:mm:ss') AS wdAuditDateTime
,wdCreationSignonCode
,date_format(wdCreationDateTime, 'yyyy-MM-dd HH:mm:ss') AS wdCreationDateTime
,wdShowSafetyCLUsInpShiftData
,wdSafetyCLUsInpShiftDataMandatory
,wdDefaultPatientClassCode
,processing_time
FROM 
bronze_live.trc_ward ward
)
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from silver_live.vw_cds_trc_ward

# COMMAND ----------


