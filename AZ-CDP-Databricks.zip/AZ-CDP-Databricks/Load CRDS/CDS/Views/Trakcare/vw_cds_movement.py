# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 19-Mar-2024 | 1       | Donne Medley     | Create first draft of permanent view vw_cds_movement                                           |
# MAGIC | 25-Mar-2024 | 2       | Donne Medley     | Updated to remove bed from theatre movements |
# MAGIC | 10-Apr-2024 | 3       | Donne Medley     | Latest updates |
# MAGIC | 17-Apr-2024 | 4       | Donne Medley     | build 1 updates |
# MAGIC | 24-Apr-2024 | 5       | Siddharth Saravanan     | Release 1 defects and Release  2 changes |
# MAGIC | 03-Apr-2024 | 6       | Donne     | Release 3 changes |
# MAGIC | 08-May-2024 | 7       | Donne     | Release 4 changes |
# MAGIC | 22-May-2024 | 8       | Donne     | Release 6 changes |
# MAGIC | 12-Jun-2024 | 9       | Donne     | Release 9 changes |
# MAGIC | 19-Jun-2024 | 10      | Donne     | Release 10 changes|
# MAGIC | 03-Jul-2024 | 11      | Donne     | Release 8 changes|
# MAGIC | 14-Aug-2024 | 12      | Donne     | Release 18 changes|
# MAGIC | 26-Aug-2024 | 13      | Gery Smith | Add Health_Specialty_Code

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_movement""")
# spark.sql(f"""DROP TABLE bronze_live.tc_pa_admtransaction""")
# spark.sql(f"""DROP TABLE bronze_live.tc_rb_operatingroom""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_movement
AS
WITH movement AS
    (
    --Bed Request    
    SELECT 
    CONCAT('BR', trans.TRANS_RowId) AS UID
    ,CAST(trans.TRANS_Childsub AS INT) AS Movement_Sequence
    ,CAST(trans.TRANS_ParRef AS BIGINT) AS Admission_ID 
    ,NULL as Movement_Procedure_ID
    ,CASE 
        WHEN trans.TRANS_TransType_DR = 1 THEN 'Bed Request' 
        END AS Movement_Type
    ,trtype.TRANSTYP_Desc AS Movement_Code 
    ,reqst.REQST_Desc AS Movement_Status 
    ,ward.WARD_LocationDR as Location_ID --Ward_RowID in the PAC_Ward table 
    ,trans.TRANS_Dept_DR AS Speciality_Location_ID 
    ,trans.TRANS_Bed_DR AS Bed_ID
    ,trans.TRANS_Room_DR AS Room_ID
    ,date_format(to_timestamp(CONCAT(CAST(trans.TRANS_CreateDate AS STRING),' ',SUBSTRING(trans.TRANS_CreateTime, 12))),'yyyy-MM-dd HH:mm:ss') AS  Movement_Create_DateTime 
    ,date_format(to_timestamp(CONCAT(CAST(trans.TRANS_StartDate AS STRING),' ',SUBSTRING(trans.TRANS_StartTime, 12))),'yyyy-MM-dd HH:mm:ss') AS Movement_Start_Datetime
    ,date_format(to_timestamp(CONCAT(CAST(trans.TRANS_EndDate AS STRING),' ',SUBSTRING(trans.TRANS_EndTime, 12))),'yyyy-MM-dd HH:mm:ss') AS Movement_End_Datetime
    ,NULL AS Movement_ReadyToLeave_DateTime 
    ,NULL AS Movement_Book_Date
    ,careprov.CTPCP_Desc AS Current_Clinician 
    ,NULL AS Anaesthetist 
    ,careprov_eme.CTPCP_Desc as Emergency_Consultant
    ,careprov_rmc.CTPCP_Desc as RMC
    ,sigfac.SIGNF_Desc as Directorate --Significant Facility
    ,resunit.RU_Desc as CBU -- Responsible Unit
    ,loc.CTLOC_Desc as Specialty --Patient Primarty CBU Description
    ,trans.TRANS_Main AS Movement_Is_Main 
    ,roomtype.ROOMT_Code AS Override_Room_Type 
    ,trans.TRANS_TransferRemark AS Transfer_Remark 
    ,NULL AS Acute_Or_Elective
    ,NULL AS Cancelled_Reason
    ,NULL AS Anaesthetic_Type
    ,NULL AS Health_Specialty_Code
    ,trans.source_file
    ,trans.processing_time
    FROM 
    bronze_live.tc_pa_admtransaction trans
    LEFT JOIN bronze_live.tc_PAC_TransfRequestStatus reqst ON reqst.REQST_RowId = trans.TRANS_Status_DR 
    LEFT JOIN bronze_live.tc_PAC_TransType trtype ON trtype.TRANSTYP_RowId = trans.TRANS_TransType_DR 
    LEFT JOIN bronze_live.tc_CT_CareProv careprov ON careprov.CTPCP_RowId1 = trans.TRANS_CTCP_DR 
    LEFT JOIN bronze_live.tc_CT_CareProv careprov_eme on careprov_eme.CTPCP_RowId1 = trans.TRANS_EmergConsultant_DR 
    LEFT JOIN bronze_live.tc_CT_CareProv careprov_rmc on careprov_rmc.CTPCP_RowId1 = trans.TRANS_RMCCareProv_DR 
    LEFT JOIN bronze_live.tc_CT_Loc loc ON loc.CTLOC_RowId=trans.TRANS_CTLOC_DR 
    LEFT JOIN bronze_live.tc_PAC_RoomType roomtype ON roomtype.ROOMT_RowId = trans.TRANS_OverrideRoomType_DR  
    LEFT JOIN bronze_live.tc_CT_ResponsibleUnit resunit on loc.CTLOC_RespUnit_DR = resunit.RU_RowId  
    LEFT JOIN bronze_live.tc_CT_SignificantFacility sigfac ON loc.CTLOC_SignifFacility_DR = sigfac.SIGNF_RowId  
    LEFT JOIN bronze_live.tc_PAC_Ward ward ON ward.WARD_RowID = trans.TRANS_Ward_DR
    WHERE 
    trans.TRANS_TransType_DR = 1 
    AND trans.TRANS_Status_DR in (1,2,3) --booking 

    UNION 

    --Ward Transfer 
    SELECT  
    CONCAT('WT', trans.TRANS_RowId) AS UID
    ,CAST(trans.TRANS_Childsub AS INT) as Movement_Sequence 
    ,trans.TRANS_ParRef as Admission_ID 
    ,NULL as Movement_Procedure_ID
    ,CASE WHEN trans.TRANS_TransType_DR = 2 THEN 'Ward Transfer' END AS Movement_Type 
    ,trtype.TRANSTYP_Desc AS Movement_Code  
    ,reqst.REQST_Desc AS Movement_Status 
    ,ward.WARD_LocationDR AS Location_ID -- --Ward_RowID in the PAC_Ward table 
    ,NULL AS Speciality_Location_ID 
    ,trans.TRANS_Bed_DR AS Bed_ID 
    ,trans.TRANS_Room_DR AS Room_ID
    ,date_format(to_timestamp(CONCAT(CAST(trans.TRANS_CreateDate AS STRING),' ',SUBSTRING(trans.TRANS_CreateTime, 12))),'yyyy-MM-dd HH:mm:ss') AS  Movement_Create_DateTime 
    ,date_format(to_timestamp(CONCAT(CAST(trans.TRANS_StartDate AS STRING),' ',SUBSTRING(trans.TRANS_StartTime, 12))),'yyyy-MM-dd HH:mm:ss') AS Movement_Start_Datetime
    ,date_format(to_timestamp(CONCAT(CAST(trans.TRANS_EndDate AS STRING),' ',SUBSTRING(trans.TRANS_EndTime, 12))),'yyyy-MM-dd HH:mm:ss') AS Movement_End_Datetime
    ,NULL AS Movement_ReadyToLeave_DateTime 
    ,NULL AS Movement_Book_Date
    ,careprov.CTPCP_Desc AS Current_Clinician 
    ,NULL AS Anaesthetist
    ,careprov_eme.CTPCP_Desc as Emergency_Consultant
    ,careprov_rmc.CTPCP_Desc as RMC
    ,sigfac.SIGNF_Desc as Directorate --Significant Facility
    ,resunit.RU_Desc as CBU -- Responsible Unit
    ,loc.CTLOC_Desc as Specialty --Patient Primarty CBU Description
    ,trans.TRANS_Main AS Movement_Is_Main 
    ,roomtype.ROOMT_Code AS Override_Room_Type 
    ,trans.TRANS_TransferRemark AS Transfer_Remark 
    ,NULL AS Acute_Or_Elective 
    ,NULL AS Cancelled_Reason
    ,NULL AS Anaesthetic_Type
    ,NULL AS Health_Specialty_Code
    ,trans.source_file
    ,trans.processing_time
    FROM
    bronze_live.tc_pa_admtransaction trans
    LEFT JOIN bronze_live.tc_PAC_TransfRequestStatus reqst ON reqst.REQST_RowId = trans.TRANS_Status_DR 
    LEFT JOIN bronze_live.tc_PAC_TransType trtype ON trtype.TRANSTYP_RowId = trans.TRANS_TransType_DR 
    LEFT JOIN bronze_live.tc_CT_CareProv careprov ON careprov.CTPCP_RowId1 = trans.TRANS_CTCP_DR 
    LEFT JOIN bronze_live.tc_CT_CareProv careprov_eme on careprov_eme.CTPCP_RowId1 = trans.TRANS_EmergConsultant_DR 
    LEFT JOIN bronze_live.tc_CT_CareProv careprov_rmc on careprov_rmc.CTPCP_RowId1 = trans.TRANS_RMCCareProv_DR 
    LEFT JOIN bronze_live.tc_CT_Loc loc ON loc.CTLOC_RowId=trans.TRANS_CTLOC_DR 
    LEFT JOIN bronze_live.tc_PAC_RoomType roomtype ON roomtype.ROOMT_RowId = trans.TRANS_OverrideRoomType_DR  
    LEFT JOIN bronze_live.tc_CT_ResponsibleUnit resunit on loc.CTLOC_RespUnit_DR = resunit.RU_RowId  
    LEFT JOIN bronze_live.tc_CT_SignificantFacility sigfac ON loc.CTLOC_SignifFacility_DR = sigfac.SIGNF_RowId  
    LEFT JOIN bronze_live.tc_PAC_Ward ward ON ward.WARD_RowID = trans.TRANS_Ward_DR 
    WHERE 
    trans.TRANS_TransType_DR = 2 
    AND trans.TRANS_Status_DR IN (2,5) 

 
    UNION

     --Case Transfer
    SELECT  
    CONCAT('CT', TRANS_RowId) AS UID 
    ,CAST(trans.TRANS_Childsub AS INT) AS Movement_Sequence 
    ,trans.TRANS_ParRef AS Admission_ID 
    ,NULL as Movement_Procedure_ID
    ,CASE 
        WHEN trans.TRANS_TransType_DR = 3 THEN 'Case Transfer' 
        END AS Movement_Type 
    ,trtype.TRANSTYP_Desc AS Movement_Code  
    ,reqst.REQST_Desc AS Movement_Status 
    , NULL AS Location_ID --Will not have a Ward
    ,trans.TRANS_CTLOC_DR AS Speciality_Location_ID 
    ,trans.TRANS_Bed_DR AS Bed_ID 
    ,trans.TRANS_Room_DR AS Room_ID 
    ,date_format(to_timestamp(CONCAT(CAST(trans.TRANS_CreateDate AS STRING),' ',SUBSTRING(trans.TRANS_CreateTime, 12))),'yyyy-MM-dd HH:mm:ss') AS  Movement_Create_DateTime 
    ,date_format(to_timestamp(CONCAT(CAST(trans.TRANS_StartDate AS STRING),' ',SUBSTRING(trans.TRANS_StartTime, 12))),'yyyy-MM-dd HH:mm:ss') AS Movement_Start_Datetime
    ,date_format(to_timestamp(CONCAT(CAST(trans.TRANS_EndDate AS STRING),' ',SUBSTRING(trans.TRANS_EndTime, 12))),'yyyy-MM-dd HH:mm:ss') AS Movement_End_Datetime
    ,NULL AS Movement_ReadyToLeave_DateTime 
    ,NULL AS Movement_Book_Date
    ,careprov.CTPCP_Desc AS Current_Clinician 
    ,NULL AS Anaesthetist
    ,careprov_eme.CTPCP_Desc as Emergency_Consultant
    ,careprov_rmc.CTPCP_Desc as RMC
    ,sigfac.SIGNF_Desc as Directorate --Significant Facility
    ,resunit.RU_Desc as CBU -- Responsible Unit
    ,loc.CTLOC_Desc as Specialty --Patient Primary CBU Description
    ,trans.TRANS_Main AS Movement_Is_Main 
    ,roomtype.ROOMT_Code AS Override_Room_Type 
    ,trans.TRANS_TransferRemark AS Transfer_Remark 
    ,NULL AS Acute_Or_Elective 
    ,NULL AS Cancelled_Reason
    ,NULL AS Anaesthetic_Type
    ,hsp.HSC_Code AS Health_Specialty_Code
    ,trans.source_file
    ,trans.processing_time
    FROM 
    bronze_live.tc_pa_admtransaction trans
    LEFT JOIN bronze_live.tc_PAC_TransfRequestStatus reqst ON reqst.REQST_RowId = trans.TRANS_Status_DR
    LEFT JOIN bronze_live.tc_PAC_TransType trtype ON trtype.TRANSTYP_RowId = trans.TRANS_TransType_DR 
    LEFT JOIN bronze_live.tc_CT_CareProv careprov ON careprov.CTPCP_RowId1 = trans.TRANS_CTCP_DR 
    LEFT JOIN bronze_live.tc_CT_CareProv careprov_eme on careprov_eme.CTPCP_RowId1 = trans.TRANS_EmergConsultant_DR 
    LEFT JOIN bronze_live.tc_CT_CareProv careprov_rmc on careprov_rmc.CTPCP_RowId1 = trans.TRANS_RMCCareProv_DR 
    LEFT JOIN bronze_live.tc_CT_Loc loc ON loc.CTLOC_RowId=trans.TRANS_CTLOC_DR 
    LEFT JOIN bronze_live.tc_CT_LocHealthSpecCode lhs ON loc.CTLOC_RowId = lhs.HSPC_ParRef and  lhs.HSPC_Childsub = 1
    LEFT JOIN bronze_live.tc_CT_HealthSpecialtyCodes hsp ON lhs.HSPC_HealthSpecCode_DR= hsp.HSC_RowId
    LEFT JOIN bronze_live.tc_PAC_RoomType roomtype ON roomtype.ROOMT_RowId = trans.TRANS_OverrideRoomType_DR  
    LEFT JOIN bronze_live.tc_CT_ResponsibleUnit resunit on loc.CTLOC_RespUnit_DR = resunit.RU_RowId  
    LEFT JOIN bronze_live.tc_CT_SignificantFacility sigfac ON loc.CTLOC_SignifFacility_DR = sigfac.SIGNF_RowId   
    WHERE 
    TRANS_TransType_DR = 3

    UNION

    --Theatre Booking
    SELECT 
    CONCAT('TB',opr.RBOP_RowId) AS UID 
    ,NULL AS Movement_Sequence 
    ,opr.RBOP_PAADM_DR AS Admission_ID 
    ,opr.RBOP_Operation_DR as Movement_Procedure_ID
    ,'Theatre Booking' AS Movement_Type 
    ,NULL AS Movement_Code
    ,appt.APPT_Status AS Movement_Status 
    ,res.RES_CTLOC_DR as Location_ID
    ,opr.RBOP_OperDepartment_DR AS Speciality_Location_ID 
    ,NULL AS Bed_ID 
    ,NULL AS Room_ID
    ,date_format(to_timestamp(CONCAT(CAST(opr.RBOP_CreateDate AS STRING),' ',SUBSTRING(opr.RBOP_CreateTime, 12))),'yyyy-MM-dd HH:mm:ss') AS  Movement_Create_DateTime 
    ,date_format(to_timestamp(CONCAT(CAST(opr.RBOP_DateOper AS STRING),' ',SUBSTRING(opr.RBOP_TimeOper, 12))),'yyyy-MM-dd HH:mm:ss') AS Movement_Start_Datetime
    ,DATEADD(MINUTE, opr.RBOP_EstimatedTime,date_format(to_timestamp(CONCAT(CAST(opr.RBOP_DateOper AS STRING),' ',SUBSTRING(opr.RBOP_TimeOper, 12))),'yyyy-MM-dd HH:mm:ss')) AS Movement_End_Datetime
    ,NULL AS Movement_ReadyToLeave_DateTime 
    ,to_date(CAST(opr.RBOP_DateBook AS STRING)) AS Movement_Book_Date
    ,careprov.CTPCP_Desc AS Current_Clinician
    ,careprov_ana.CTPCP_Desc AS Anaesthetist
    ,NULL AS Emergency_Consultant 
    ,NULL AS RMC 
    ,NULL AS Directorate
    ,NULL AS CBU
    ,NULL AS Specialty 
    ,NULL AS Movement_Is_Main  
    ,NULL AS Override_Room_Type 
    ,NULL AS Transfer_Remark 
    ,opr.RBOP_BookingType AS Acute_Or_Elective 
    ,NULL AS Cancelled_Reason
    ,anam.ANMET_Desc as Anaesthetic_Type 
    ,NULL AS Health_Specialty_Code
    ,opr.source_file
    ,opr.processing_time
    FROM 
    bronze_live.tc_rb_operatingroom opr 
    LEFT JOIN bronze_live.tc_ct_careprov careprov ON careprov.CTPCP_RowId1 = opr.RBOP_Surgeon_DR -- surgeon  
    LEFT JOIN bronze_live.tc_ct_careprov careprov_ana on careprov_ana.CTPCP_RowId1 = opr.RBOP_Anaesthetist_DR -- Join for Anaesthetist 
    LEFT JOIN 
		( 
		 SELECT 
		 ROW_NUMBER() OVER (PARTITION BY appointment.APPT_RBOP_DR ORDER BY appointment.APPT_RBOP_DR DESC) as rownumber 
		 ,appointment.APPT_RBOP_DR 
		 ,appointment.APPT_Status  
		 ,apptStatus.ChildSub 
		 FROM 
		 bronze_live.tc_RB_Appointment appointment 
		 LEFT JOIN bronze_live.tc_websys_standardtypeitem apptStatus ON appointment.APPT_Status = apptStatus.Code 
		 	AND apptStatus.ParRef = 'AppointmentStatus' 
		 WHERE 
		 appointment.APPT_RBOP_DR IS NOT NULL 
		) appt on appt.APPT_RBOP_DR = opr.RBOP_RowId AND appt.ChildSub = 1 
	LEFT JOIN bronze_live.tc_RB_Resource res ON res.RES_RowId = opr.RBOP_Resource_DR  
    LEFT JOIN bronze_live.tc_ORC_AnaestMethod anam on anam.ANMET_RowId = opr.RBOP_AnaestMethod_DR
 
    UNION

    -- Theatre Event
    SELECT 
    CONCAT('TE',ana.ANA_RowID) AS UID 
    ,CAST(ana.ANA_Childsub AS INT) AS Movement_Sequence  
    ,opr.RBOP_PAADM_DR AS Admission_ID 
    ,ana.ANA_RowID as Movement_Procedure_ID
    ,'Theatre Event' AS Movement_Type 
    ,NULL AS Movement_Code
    ,ana.ANA_Status AS Movement_Status 
    ,res.RES_CTLOC_DR as Location_ID
    ,opr.RBOP_OperDepartment_DR AS Speciality_Location_ID 
    ,NULL AS Bed_ID 
    ,NULL AS Room_ID 
    ,date_format(to_timestamp(CONCAT(CAST(opr.RBOP_CreateDate AS STRING),' ',SUBSTRING(opr.RBOP_CreateTime, 12))),'yyyy-MM-dd HH:mm:ss') AS  Movement_Create_DateTime 
    ,date_format(to_timestamp(CONCAT(CAST(ana.ANA_TheatreInDate AS STRING),' ',SUBSTRING(ana.ANA_TheatreInTime, 12))),'yyyy-MM-dd HH:mm:ss') AS Movement_Start_Datetime
    ,date_format(to_timestamp(CONCAT(CAST(ana.ANA_TheatreOutDate AS STRING),' ',SUBSTRING(ana.ANA_TheatreOutTime, 12))),'yyyy-MM-dd HH:mm:ss') AS Movement_End_Datetime
    ,NULL AS Movement_ReadyToLeave_DateTime 
    ,NULL AS Movement_Book_Date
    ,careprov.CTPCP_Desc AS Current_Clinician
    ,careprov_ana.CTPCP_Desc AS Anaesthetist
    ,NULL AS Emergency_Consultant 
    ,NULL AS RMC 
    ,NULL AS Directorate 
    ,NULL AS CBU
    ,NULL AS Specialty 
    ,NULL AS Movement_Is_Main  
    ,NULL AS Override_Room_Type 
    ,NULL AS Transfer_Remark 
    ,opr.RBOP_BookingType AS Acute_Or_Elective 
    ,rfs.SUSP_Desc AS Cancelled_Reason
    ,anam.ANMET_Desc as Anaesthetic_Type 
    ,NULL AS Health_Specialty_Code
    ,opr.source_file
    ,opr.processing_time
    FROM 
    bronze_live.tc_rb_operatingroom opr 
    INNER JOIN bronze_live.tc_or_anaesthesia ana on opr.RBOP_RowId = ana.ANA_RBOperatingRoom_DR  
    LEFT JOIN bronze_live.tc_ct_careprov careprov on careprov.CTPCP_RowId1 = ana.ANA_Consultant_DR 
    LEFT JOIN bronze_live.tc_RB_Resource res ON res.RES_RowId = OPR.RBOP_Resource_DR
    LEFT JOIN bronze_live.tc_ct_careprov careprov_ana on careprov_ana.CTPCP_RowId1 = opr.RBOP_Anaesthetist_DR -- Join for Anaesthetist 
    LEFT JOIN bronze_live.tc_orc_reasonforsuspend rfs ON ANA.ANA_Reason_Suspend_DR = rfs.SUSP_RowId 
    LEFT JOIN bronze_live.tc_ORC_AnaestMethod anam on anam.ANMET_RowId = opr.RBOP_AnaestMethod_DR

    UNION

    -- Post Theatre Event
    SELECT 
    CONCAT('PT',ana.ANA_RowID) AS UID 
    ,CAST(ana.ANA_Childsub AS INT) AS Movement_Sequence  
    ,opr.RBOP_PAADM_DR AS Admission_ID 
    ,ana.ANA_RowID as Movement_Procedure_ID 
    ,'Post Theatre Event' AS Movement_Type 
    ,NULL AS Movement_Code
    ,NULL AS Movement_Status 
    ,res.RES_CTLOC_DR as Location_ID --PACU Unit -- need to check with Lal
    ,opr.RBOP_OperDepartment_DR AS Speciality_Location_ID 
    ,NULL AS Bed_ID 
    ,NULL AS Room_ID 
    ,date_format(to_timestamp(CONCAT(CAST(opr.RBOP_CreateDate AS STRING),' ',SUBSTRING(opr.RBOP_CreateTime, 12))),'yyyy-MM-dd HH:mm:ss') AS  Movement_Create_DateTime 
    ,date_format(to_timestamp(CONCAT(CAST(ana.ANA_PACU_StartDate AS STRING),' ',SUBSTRING(ana.ANA_PACU_StartTime, 12))),'yyyy-MM-dd HH:mm:ss') AS Movement_Start_Datetime
    ,date_format(to_timestamp(CONCAT(CAST(ana.ANA_PACU_FinishDate AS STRING),' ',SUBSTRING(ana.ANA_PACU_FinishTime, 12))),'yyyy-MM-dd HH:mm:ss') AS Movement_End_Datetime
    ,date_format(to_timestamp(
              CASE 
                WHEN ANA_PACU_ReadyLeaveTime IS NULL THEN
                    CONCAT(CAST(ana.ANA_PACU_ReadyLeaveDate AS STRING),' 00:00:00')
                ELSE
                    CONCAT(CAST(ana.ANA_PACU_ReadyLeaveDate AS STRING),' ',SUBSTRING(ana.ANA_PACU_ReadyLeaveTime, 12))
                END
                    ),'yyyy-MM-dd HH:mm:ss') AS Movement_ReadyToLeave_DateTime 
    ,NULL AS Movement_Book_Date
    ,careprov.CTPCP_Desc as Current_Clinician
    ,NULL AS Anaesthetist 
    ,NULL AS Emergency_Consultant 
    ,NULL AS RMC 
    ,NULL AS Directorate 
    ,NULL AS CBU
    ,NULL AS Specialty 
    ,NULL AS Movement_Is_Main 
    ,NULL AS Override_Room_Type 
    ,NULL AS Transfer_Remark 
    ,NULL AS Acute_Or_Elective 
    ,NULL AS Cancelled_Reason 
    ,anam.ANMET_Desc as Anaesthetic_Type 
    ,NULL AS Health_Specialty_Code
    ,opr.source_file
    ,opr.processing_time
    FROM 
    bronze_live.tc_rb_operatingroom opr 
    INNER JOIN bronze_live.tc_or_anaesthesia ana on opr.RBOP_RowId = ana.ANA_RBOperatingRoom_DR  
    LEFT JOIN bronze_live.tc_ct_careprov careprov on careprov.CTPCP_RowId1 = ana.ANA_Consultant_DR 
    LEFT JOIN bronze_live.tc_RB_Resource res ON res.RES_RowId = OPR.RBOP_Resource_DR
    LEFT JOIN bronze_live.tc_ORC_AnaestMethod anam on anam.ANMET_RowId = opr.RBOP_AnaestMethod_DR
    )
,proc_time AS 
    (
    SELECT
    MAX(processing_time) processing_time
    FROM
    movement
    )

SELECT
proc_time.processing_time AS watermark_value
,movement.UID 
,movement.Movement_Sequence  
,movement.Admission_ID 
,movement.Movement_Procedure_ID
,movement.Movement_Type
,movement.Movement_Code 
,movement.Movement_Status 
,movement.Location_ID
,movement.Speciality_Location_ID 
,movement.Bed_ID 
,movement.Room_ID
,movement.Movement_Create_DateTime 
,movement.Movement_Start_Datetime
,movement.Movement_End_Datetime
,movement.Movement_ReadyToLeave_DateTime
,movement.Movement_Book_Date
,movement.Current_Clinician 
,movement.Anaesthetist
,movement.Emergency_Consultant 
,movement.RMC 
,movement.Directorate 
,movement.CBU
,movement.Specialty 
,movement.Movement_Is_Main 
,movement.Override_Room_Type
,movement.Transfer_Remark 
,movement.Acute_Or_Elective 
,movement.Cancelled_Reason 
,movement.Anaesthetic_Type 
,movement.Health_Specialty_Code
,proc_time.processing_time
FROM 
movement
,proc_time
""")

# COMMAND ----------

# MAGIC %sql select distinct Movement_Sequence from silver_live.vw_cds_movement where Movement_Sequence is not null

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from bronze_live.tc_pa_admtransaction limit 100
