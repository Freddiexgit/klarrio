# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 12-Jun-2024 | 1       | Donne Medley     | Create first draft of permanent view vw_cds_waiting_list                                        |
# MAGIC | 17-Jul-2024 | 2       | Donne Medley     | Updated for Release 14                                        |
# MAGIC | 01-Aug-2024 | 3       | Donne Medley     | Updated for Release 15                                        |
# MAGIC | 07-Aug-2024 | 4       | Donne Medley     | Updated for Release 17                |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_bed_status""")
# spark.sql(f"""DROP TABLE bronze_live.tc_pa_waitinglist""")
# spark.sql(f"""DROP TABLE bronze_live.tc_RB_OperatingRoom""")
# spark.sql(f"""DROP TABLE bronze_live.tc_pa_adm""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_waiting_list
AS
WITH waiting_list AS 
    (
    SELECT  
    CONCAT(wl.WL_RowId,'_',IFNULL(adm.PAADM_RowID,1)) as UID  
    ,wl.WL_RowId as WaitingList_ID  
    ,adm.PAADM_RowID as Admission_ID 
    ,op.OPER_RowId as Procedure_ID
    ,wl.WL_PAPMI_DR as Patient_ID  
    ,wl.WL_ProcedureFreeText as Procedure_Free_Text  
    ,wl.WL_Remarks as Remarks  
    ,cbu.RU_Desc as CBU 
    ,cp.CTPCP_Desc as Clinician 
    ,wls.WLS_Code as WaitingList_Status_Code  
    ,wls.WLS_Desc as WaitingList_Status_Desc  
    ,wlt.WLT_Code as WaitingList_Type_Code 
    ,wl.WL_DaysWaiting as Days_Waiting 
    ,wlp.WLP_Desc as WaitingList_Priority
    ,CASE 
        WHEN WL.WL_LastReviewedDate IS NULL THEN wl.WL_Date  
        ELSE wl.WL_LastReviewedDate  
        END AS WaitingList_Review_Date  
    ,r.RBOP_DateOper as Surgery_Date 
    ,date_format(to_timestamp(CONCAT(CAST(wl.WL_Date AS STRING), ' ', SUBSTRING(wl.WL_Time, 12))), 'yyyy-MM-dd HH:mm:ss') AS WaitingList_DateTime
    ,wl.source_file
    ,wl.processing_time 
    FROM 
    bronze_live.tc_PA_WaitingList wl  
    LEFT JOIN bronze_live.tc_PAC_WaitingListStatus wls on wl.WL_WaitListStatus_DR = wls.WLS_RowId 
    LEFT JOIN bronze_live.tc_PAC_WaitingListType wlt ON wl.WL_WaitListType_DR = wlt.WLT_RowId
    LEFT JOIN bronze_live.tc_CT_ResponsibleUnit cbu ON cbu.RU_RowId = wl.WL_ResponsibleUnit_DR 
    LEFT JOIN bronze_live.tc_CT_CareProv cp ON wl.WL_Doctor_DR = cp.CTPCP_RowId1
    LEFT JOIN bronze_live.tc_PA_ADM adm ON adm.PAADM_WaitList_DR = wl.WL_RowId 
    LEFT JOIN bronze_live.tc_ORC_Operation op ON op.OPER_RowId = wl.WL_Operation_DR
    LEFT JOIN bronze_live.tc_PAC_WaitingListPriority wlp on wlp.WLP_RowId = wl.WL_WaitListPrior_DR
    LEFT JOIN 
        (
        SELECT 
        RBOP_PAADM_DR
        ,RBOP_DateOper
        ,RBOP_RowId
        ,date_format(to_timestamp(CONCAT(CAST(r.RBOP_UpdateDate AS STRING), ' ', SUBSTRING(r.RBOP_UpdateTime, 12))), 'yyyy-MM-dd HH:mm:ss') AS Update_Time
        ,RANK() OVER
            (
            PARTITION BY RBOP_PAADM_DR 
            ORDER BY date_format(to_timestamp(CONCAT(CAST(r.RBOP_UpdateDate AS STRING), ' ', SUBSTRING(r.RBOP_UpdateTime, 12))), 'yyyy-MM-dd HH:mm:ss')
            ) as Rank 
        FROM 
        bronze_live.tc_RB_OperatingRoom r 
        WHERE 
        r.RBOP_Status <> 'X'
        ) r ON r.RBOP_RowId = wl.WL_RBOP_DR and r.Rank = 1
    )
,watermark AS 
    (
    SELECT MAX(processing_time) AS watermark_value
    FROM waiting_list
    )
SELECT 
    w.watermark_value,
    wl.*
FROM
    waiting_list wl,
    watermark w
""")

# COMMAND ----------

# MAGIC %sql select * from silver_live.vw_cds_waiting_list limit 10
