# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 06-Mar-2024 | 1       | Donne Medley     | Create first draft of permanent view vw_cds_ref_bed                                        |
# MAGIC | 25-Mar-2024 | 2       | Donne Medley     | Updated to include room                                        |
# MAGIC |17-Apr-2024	|3	| Siddharth Saravanan	|Added fields and tables for Release 1 |
# MAGIC |26-Apr-2024	|4	| Siddharth Saravanan	|Added fields and tables for Release 2 |
# MAGIC |01-May-2024	|5	| Donne	Medley |Removed fields and tables for Release 3 |
# MAGIC |08-May-2024	|6	| Donne Medley 	|Added Ward_ID for Release 4 |
# MAGIC | 07-Aug-2024 | 7       | Donne Medley     | Updated for Release 17                |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_ref_bed""")
# spark.sql(f"""DROP TABLE bronze_live.tc_pac_bed""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_ref_bed
AS
(
SELECT
(SELECT MAX(processing_time) FROM bronze_live.tc_pac_bed) AS watermark_value
,bed.BED_RowID AS UID  
,bed.BED_RowID AS Bed_ID  
,CAST(bed.BED_Childsub AS INT) AS Bed_Number 
,bed.BED_Code AS Bed_Code 
,bed.BED_Available AS Is_Bed_Available 
,bed.BED_Room_DR AS Room_ID 
,bed.BED_WARD_ParRef as Ward_ID
,bed.BED_DateFrom AS Bed_DateFrom
,bed.BED_DateTo AS Bed_DateTo
,bed.source_file
,bed.processing_time
FROM 
bronze_live.tc_pac_bed bed
)
""")

# COMMAND ----------

# MAGIC %sql select * from silver_live.vw_cds_ref_bed
