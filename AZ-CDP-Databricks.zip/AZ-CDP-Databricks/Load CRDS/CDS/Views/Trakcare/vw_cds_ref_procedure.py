# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 18-Mar-2024 | 1       | Donne Medley     | Create first draft of permanent view vw_cds_ref_procedure                                           |
# MAGIC | 27-Mar-2024 | 1       | Donne Medley     | Latest version from modellers                                           |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_ref_procedure""")
# spark.sql(f"""DROP TABLE bronze_live.tc_orc_operation""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_ref_procedure
AS
SELECT 
(SELECT MAX(processing_time) FROM bronze_live.tc_orc_operation) AS watermark_value
,OPER_RowId AS UID
,OPER_RowId AS Procedure_ID
,OPER_Code AS Procedure_Code
,OPER_Desc AS Procedure_Desc
,source_file
,processing_time
FROM 
bronze_live.tc_orc_operation
--WHERE
--IFNULL(OPER_ActiveDateTo,'2099-12-31') > current_date()
  
UNION 

SELECT 
(SELECT MAX(processing_time) FROM bronze_live.tc_orc_operation) AS watermark_value
,99999 AS UID 
,99999 AS Procedure_ID 
,NULL AS Procedure_Code 
,'Anaesthesia' AS Procedure_Desc
,NULL AS source_file
,(SELECT MAX(processing_time) FROM bronze_live.tc_orc_operation) AS processing_time
""")

# COMMAND ----------

# MAGIC %sql 
# MAGIC select * from silver_live.vw_cds_ref_procedure
