# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 15-Mar-2024 | 1       | Donne Medley     | Create first draft of permanent view vw_cds_ref_patient_ethnicity                                           |
# MAGIC | 17-Apr-2024 | 2      | Siddharth Saravanan    | Modified fields for Release 1                |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_ethnicity""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_ref_patient_ethnicity
AS
WITH CTE AS
  (
  SELECT
  eth.Patient_ID
  ,ethnicity.ETHNIC_Desc AS Patient_Ethnicity
  ,ethnicity.ETHNIC_Rank AS Rank
  ,CASE   
    WHEN ethnicity.ETHNIC_Rank = 1 THEN ethnicity.ETHNIC_Desc 
    WHEN ethnicity.ETHNIC_Rank BETWEEN 2 AND 9 THEN 'Pacific' 
    ELSE 'Other' 
    END as Patient_Prioritised_Ethnicity
  ,ROW_NUMBER() OVER(PARTITION BY eth.Patient_ID ORDER BY ethnicity.ETHNIC_Rank ASC) AS Priority
  ,eth.source_file
  ,eth.processing_time
  FROM
    (
    SELECT 
    perseth.ETHNIC_ParRef AS Patient_ID
    ,perseth.source_file
    ,perseth.processing_time
    ,perseth.ETHNIC_Ethnicity_DR
    ,ROW_NUMBER() OVER(PARTITION BY perseth.ETHNIC_ParRef,ethnicity.ETHNIC_Desc ORDER BY perseth.ETHNIC_childsub ASC) AS childsub
    FROM 
    bronze_live.tc_pa_personethnicity perseth
    INNER JOIN bronze_live.tc_pac_ethnicity ethnicity ON perseth.ETHNIC_Ethnicity_DR = ethnicity.ETHNIC_RowId
    ) eth  
  INNER JOIN bronze_live.tc_pac_ethnicity ethnicity ON eth.ETHNIC_Ethnicity_DR = ethnicity.ETHNIC_RowId 
  WHERE 
  eth.childsub = 1
  )
SELECT
(SELECT MAX(processing_time) FROM bronze_live.tc_pa_personethnicity) AS watermark_value
,CONCAT(cte.Patient_ID,'_',cte.Priority) AS UID
,cte.Patient_ID
,cte.Patient_Ethnicity
,cte.Patient_Prioritised_Ethnicity
,cte.Rank
,cte.Priority
,cte.source_file
,cte.processing_time
FROM 
cte
--WHERE
--Priority=1
""")
