# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 15-Mar-2024 | 1       | Donne Medley     | Create first draft of permanent view vw_cds_ethnicity                                           |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_ethnicity""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_ethnicity
AS
WITH ethnicity AS (
    SELECT
        ETHNIC_RowID AS UID,
        ETHNIC_RowID AS Ethnicity_ID,
        ETHNIC_Desc AS Ethnicity_Desc,
        ETHNIC_Rank AS Ethnicity_Rank,
        source_file,
        processing_time
    FROM 
        bronze_live.tc_pac_ethnicity  
),
watermark AS (
    SELECT MAX(processing_time) AS watermark_value
    FROM ethnicity
)
SELECT 
    w.watermark_value,
    e.*
FROM
    ethnicity e,
    watermark w
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from silver_live.vw_cds_ethnicity

# COMMAND ----------


