# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 04-Mar-2024 | 1       | Donne Medley     | Create first draft of permanent view vw_cds_diagnosis                                           |
# MAGIC | 27-Mar-2024 | 2       | Donne Medley     | Based on latest version from modellers                                          |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_diagnosis""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_diagnosis
AS
WITH diagnosis AS (
    SELECT 
        md.MRDIA_RowId AS UID, 
        md.MRDIA_RowId AS Diagnosis_ID, 
        mr.MRADM_ADM_DR AS Admission_ID, 
        mr.MRADM_RowId AS Medical_Record_ID, 
        mr.source_file, 
        mr.processing_time
    FROM 
        bronze_live.tc_mr_diagnos md  
    LEFT JOIN bronze_live.tc_mr_adm mr ON mr.MRADM_RowId = md.MRDIA_MRADM_ParRef 
    WHERE 
        md.MRDIA_RowId IS NOT NULL
),
watermark AS (
    SELECT MAX(processing_time) AS watermark_value
    FROM diagnosis
)
SELECT 
    w.watermark_value,
    d.*
FROM
    diagnosis d,
    watermark w
""")

# COMMAND ----------

# MAGIC %sql select count(1) from bronze_live.tc_mr_adm
