# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 15-May-2024 | 1       | Donne Medley     | Release 5                                        |
# MAGIC | 03-Jul-2024 | 2       | Donne Medley     | Updated for Release 12.                    |
# MAGIC | 17-Jul-2024 | 3       | Donne Medley     | Updated for Release 14.                    |
# MAGIC | 14-Aug-2024 | 4       | Donne Medley     | Updated for Release 18.                    |
# MAGIC | 30-Aug-2024 | 5       | Donne Medley     | Updated for Release 20.                    |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_theatre_session""")
# spark.sql(f"""DROP TABLE  bronze_live.tc_RB_ResEffDateSessOTSpec""")
# spark.sql(f"""DROP TABLE  bronze_live.tc_rb_operatingroom""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_theatre_session
AS
WITH theatre_session AS 
    (
    SELECT DISTINCT
    app.AS_RowId AS UID
    ,app.AS_RowId AS Session_Id
    ,rbr.RES_CTLOC_DR AS Location_ID
    ,rbred.OTSPEC_CTLOC_DR AS Specialty_Location_ID
    ,rbce.EQ_Code AS Theatre_Code
    ,rbr.RES_Desc AS Theatre_Description
    ,orce.EQ_Desc as Dependent_Resource
    ,CASE
        WHEN app.AS_ActualDate IS NOT NULL THEN app.AS_ActualDate
        ELSE app.AS_DATE
       END AS Session_Date
    ,CASE
        WHEN app.AS_ActualDate IS NOT NULL AND app.AS_ActualStartTime IS NOT NULL  
            THEN date_format(to_timestamp(CONCAT(CAST(app.AS_ActualDate AS STRING),' ',SUBSTRING(app.AS_ActualStartTime, 12))),'yyyy-MM-dd HH:mm:ss')
        ELSE date_format(to_timestamp(CONCAT(CAST(app.AS_Date AS STRING),' ',SUBSTRING(app.AS_SessStartTime, 12))),'yyyy-MM-dd HH:mm:ss')
        END AS Session_DateTime
    ,CASE
        WHEN app.AS_ActualStartTime IS NOT NULL
            THEN date_format(to_timestamp(app.AS_ActualStartTime),'HH:mm')
        ELSE date_format(to_timestamp(app.AS_SessStartTime),'HH:mm')
       END AS Session_Start_Time
    ,CASE
        WHEN app.AS_ActualEndTime IS NOT NULL
            THEN date_format(to_timestamp(app.AS_ActualEndTime),'HH:mm')
        ELSE date_format(to_timestamp(app.AS_SessEndTime),'HH:mm')
        END AS Session_End_Time
    ,cp.CTPCP_Desc AS Session_Consultant 
    ,rbre.SESS_OperBookingMethod as Session_Booking_Method_Code 
    ,CASE
        WHEN app.AS_ActualStartTime IS NOT NULL AND app.AS_ActualEndTime IS NOT NULL
            THEN CASE 
                    WHEN DATEDIFF(Hour, app.AS_ActualStartTime, app.AS_ActualEndTime) * 60 > 400 THEN 'All Day'
                    WHEN LEFT(date_format(to_timestamp(app.AS_ActualStartTime),'HH:mm'),2) <= 11 THEN 'AM'
                    WHEN app.AS_ActualStartTime IS NULL THEN NULL
                    ELSE 'PM'
                    END
        ELSE CASE 
                WHEN DATEDIFF(Hour, app.AS_SessStartTime, app.AS_SessEndTime) * 60 > 400 THEN 'All Day'
                WHEN LEFT(date_format(to_timestamp(app.AS_SessStartTime),'HH:mm'),2) <= 11 THEN 'AM' 
                WHEN app.AS_SessStartTime IS NULL THEN NULL
               ELSE 'PM'
               END
       END AS AMPM
    ,CASE 
        WHEN app.AS_EmergencyTheatre='N' THEN 'Elective'
        ELSE 'Acute'
        END AS Session_Type
    ,app.source_file
    ,CAST(app.processing_time AS VARCHAR(19)) AS processing_time
    FROM 
    --bronze_live.tc_RB_ApptSchedule AS app 
    bronze.tc_l_RB_ApptSchedule AS app --using this as full loading of tc_rb_apptschedule fails in RDS processing
    LEFT JOIN bronze_live.tc_RB_Resource rbr ON rbr.RES_RowId = app.AS_RES_ParRef 
    LEFT JOIN bronze_live.tc_RB_ResEffDateSession rbre ON rbre.SESS_RowId = app.AS_RBEffDateSession_DR --AND rbre.SESS_OperBookingMethod = 'S' 
    LEFT JOIN bronze_live.tc_RB_ResEffDateSessOTSpec rbred ON rbred.OTSPEC_ParRef = rbre.SESS_RowId AND rbred.OTSPEC_DateTo IS NULL
    LEFT JOIN bronze_live.tc_CT_LOC ctl ON ctl.CTLOC_RowId = rbred.OTSPEC_CTLOC_DR 
    LEFT JOIN bronze_live.tc_RBC_Equipment rbce ON rbce.EQ_RowId = rbr.RES_EQ_DR 
    LEFT JOIN bronze_live.tc_RBC_EquipmentGroup rbcg ON rbcg.GRP_RowId = rbce.EQ_Group_DR AND rbce.EQ_Group_DR = 1 
    LEFT JOIN bronze_live.tc_ORC_Equipment orce ON orce.EQ_RowId = rbr.RES_EQ_DR 
    LEFT JOIN  
        (
        SELECT
        *
        ,ROW_NUMBER() OVER (PARTITION BY CP_ParRef ORDER BY CP_AddedDate DESC, CP_AddedTime DESC) rn 
        FROM
        bronze_live.tc_RB_ResEffDateSessionCP  
        WHERE 
        CP_CareProviderType = 'S'  
        ) redcp ON rbre.SESS_RowId = redcp.CP_ParRef AND redcp.rn = 1  
    LEFT JOIN bronze_live.tc_CT_CareProv cp on redcp.CP_CTCP_DR = cp.CTPCP_RowId1  
    WHERE 
    rbr.RES_Type='Equipment'  
    AND rbcg.GRP_Code='OT'
    )
,watermark AS 
    (
    SELECT MAX(processing_time) AS watermark_value
    FROM theatre_session
    )
SELECT DISTINCT
    w.watermark_value,
    ts.*
FROM
    theatre_session ts,
    watermark w
""")

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql select * from bronze_live.tc_rb_operatingroom limit 100
