# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 17-Apr-2024 | 1       | Donne Medley     | Create first draft of permanent view vw_cds_bed_status                                        |
# MAGIC | 01-Apr-2024 | 1       | Donne Medley     | Updated for Release 3                                        |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_bed_status""")
# spark.sql(f"""DROP TABLE bronze_live.tc_pac_bed""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_bed_status
AS
WITH bed_status AS (
    SELECT
        bedstat.STAT_RowId AS UID, -- will need to check if it's unique
        bedstat.STAT_ParRef AS Bed_ID,
        date_format(to_timestamp(CONCAT(CAST(bedstat.STAT_Date AS STRING), ' ', SUBSTRING(bedstat.STAT_Time, 12))), 'yyyy-MM-dd HH:mm:ss') AS Bed_Status_Start_DateTime,
        date_format(to_timestamp(CONCAT(CAST(bedstat.STAT_DateTo AS STRING), ' ', SUBSTRING(bedstat.STAT_TimeTo, 12))), 'yyyy-MM-dd HH:mm:ss') AS Bed_Status_Finish_DateTime,
        bednav.RNAV_Desc AS Bed_Reason_Not_Available,
        CASE 
            WHEN date_format(to_timestamp(CONCAT(CAST(bedstat.STAT_DateTo AS STRING), ' ', SUBSTRING(bedstat.STAT_TimeTo, 12))), 'yyyy-MM-dd HH:mm:ss') IS NULL 
                 OR date_format(to_timestamp(CONCAT(CAST(bedstat.STAT_DateTo AS STRING), ' ', SUBSTRING(bedstat.STAT_TimeTo, 12))), 'yyyy-MM-dd HH:mm:ss') > CURRENT_TIMESTAMP
            THEN 'Y' 
            ELSE 'N' 
        END AS Is_Bed_Restricted,
        bedstat.source_file,
        bedstat.processing_time
    FROM 
        bronze_live.tc_pac_bedstatuschange bedstat 
    LEFT JOIN bronze_live.tc_pac_bedreasonnotavail bednav ON bednav.RNAV_RowId = bedstat.STAT_ReasonNotAvail_DR
),
watermark AS (
    SELECT MAX(processing_time) AS watermark_value
    FROM bed_status
)
SELECT 
    w.watermark_value,
    bs.*
FROM
    bed_status bs,
    watermark w
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from silver_live.vw_cds_bed_status

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(1) from bronze_live.tc_pac_bedstatuschange
