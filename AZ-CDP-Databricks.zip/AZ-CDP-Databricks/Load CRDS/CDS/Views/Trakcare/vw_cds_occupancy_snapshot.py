# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 09-May-2024 | 1       | Siddharth Saravanan  | Create first draft of permanent view vw_cds_occupancy_snapshot                    |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_ref_ward""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_occupancy_snapshot
AS
WITH occupancy_snapshot AS (
    SELECT 
        md5(concat(loc.Location_ID, date(adm.Admission_DateTime), hour(adm.Admission_DateTime))) as UID,
        loc.Location_ID,
        DATE(adm.Admission_DateTime) as Admission_Date,
        current_date() as Current_Date,
        hour(adm.Admission_DateTime) as Hour_x,
        count(mv.Admission_ID) as Occupancy,
        GREATEST(MAX(mv.processing_time), MAX(loc.processing_time), MAX(adm.processing_time)) AS processing_time
    FROM 
        silver_live.cds_movement mv
    INNER JOIN silver_live.cds_location loc ON loc.Location_ID = mv.Location_ID
    LEFT JOIN silver_live.cds_admission adm ON mv.Admission_ID = adm.Admission_ID
    WHERE 
        Admission_Type_Code IN ('I', 'E')
        AND Actual_Discharge_DateTime IS NULL
        AND Visit_Status_Code IN ('A')
    --and ca.Admission_DateTime between timestampadd(HOUR, -100, current_timestamp()) and current_timestamp() -- should be between last time snapshot and current run time
    GROUP BY 
        loc.Location_ID, DATE(adm.Admission_DateTime), hour(adm.Admission_DateTime) 
    ORDER BY 
        loc.Location_ID, DATE(adm.Admission_DateTime), hour(adm.Admission_DateTime) ASC
),
watermark AS (
    SELECT MAX(processing_time) AS watermark_value
    FROM occupancy_snapshot
)
SELECT 
    w.watermark_value,
    os.*
FROM 
    occupancy_snapshot os
JOIN 
    watermark w ON 1=1 -- Cartesian product to ensure watermark is applied to every row
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from silver_live.vw_cds_occupancy_snapshot
