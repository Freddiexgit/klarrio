# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 18-Mar-2024 | 1       | Donne Medley     | Create first draft of permanent view vw_cds_ref_ward_room                    |
# MAGIC | 01-May-2024 | 2       | Donne Medley     | Updated for for Release 3                    |
# MAGIC | 15-May-2024 | 3       | Donne Medley     | Updated for for Release 5                    |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_ref_ward_room""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_ref_ward_room
AS
SELECT DISTINCT
(SELECT MAX(processing_time) FROM bronze_live.tc_pac_wardroom) AS watermark_value
,CONCAT(wardroom.ROOM_Room_DR,'_', wardroom.ROOM_ParRef) AS UID
,wardroom.ROOM_Room_DR AS Room_ID 
,wardroom.ROOM_ParRef AS Ward_ID  
,wardroom.source_file
,wardroom.processing_time
FROM 
bronze_live.tc_pac_wardroom wardroom
""")
