# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date         | Version | Author         | Changes                                                                    |
# MAGIC |------------- |---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 04-Mar-2024  | 1       | Donne Medley     | Create first draft of permanent view vw_cds_admission                                           |
# MAGIC | 17-Apr-2024  | 2       | Siddharth Saravanan   | Added fields and tables for Release 1                                           |
# MAGIC | 26-Apr-2024  | 3       | Siddharth Saravanan   | Added fields and tables for Release 2                                           |
# MAGIC | 15-May-2024  | 4       | Donne Medley   | Updated for Release 5                                           |
# MAGIC | 22-May-2024  | 5       | Donne Medley   | Updated for Release 6                                           |
# MAGIC | 29-May-2024  | 6       | Donne    | Added intended_procedure (Release 7)                |
# MAGIC | 05-Jun-2024  | 7       | Donne    | Added short_stay_reason_desc (Release 8)                |
# MAGIC | 31-Jul-2024  | 8       | Donne Medley   | Updated for Release 16                                           |
# MAGIC | 14-Aug-2024  | 9       | Donne Medley   | Updated for Release 18                                           |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_admission""")
# spark.sql(f"""DROP TABLE silver_live.cds_admission""")
# spark.sql(f"""DROP TABLE bronze_live.tc_pa_adm2""")
# spark.sql(f"""DROP TABLE bronze_live.tc_pa_adm""")
# spark.sql(f"""DROP TABLE bronze_live.tc_pac_refdoctor_new""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_admission
AS
WITH admission AS (
    SELECT 
        adm.PAADM_RowID AS UID,
        adm.PAADM_RowID AS Admission_ID,
        adm.PAADM_ADMNo AS Admission_Number,
        date_format(to_timestamp(CONCAT(CAST(adm.PAADM_AdmDate AS STRING), ' ', SUBSTRING(adm.PAADM_AdmTime, 12))), 'yyyy-MM-dd HH:mm:ss') AS Admission_DateTime,
        adm.PAADM_Type AS Admission_Type_Code,
        adt.IPAT_Code AS Inpatient_Admission_Type_Code,
        adt.IPAT_Desc AS Inpatient_Admission_Type_Desc,
        adm.PAADM_OriginalAdmissionDR AS Original_Admission_ID, -- placeholder
        date_format(to_timestamp(CONCAT(CAST(adm2.PAADM2_ActualArrivalDate AS STRING), ' ', SUBSTRING(adm2.PAADM2_ActualArrivalTime, 12))), 'yyyy-MM-dd HH:mm:ss') AS Actual_Arrival_DateTime,
        date_format(to_timestamp(CONCAT(CAST(adm.PAADM_SeenDate AS STRING), ' ', SUBSTRING(adm.PAADM_SeenTime, 12))), 'yyyy-MM-dd HH:mm:ss') AS Clinician_Seen_DateTime,
        date_format(to_timestamp(CONCAT(CAST(adm.PAADM_EstimDischargeDate AS STRING), ' ', SUBSTRING(adm.PAADM_EstimDischargeTime, 12))), 'yyyy-MM-dd HH:mm:ss') AS Estimated_Discharge_DateTime,
        date_format(to_timestamp(CONCAT(CAST(adm.PAADM_MedDischDate AS STRING), ' ', SUBSTRING(adm.PAADM_MedDischTime, 12))), 'yyyy-MM-dd HH:mm:ss') AS Medical_Discharge_DateTime,
        date_format(to_timestamp(CONCAT(CAST(adm.PAADM_DischgDate AS STRING), ' ', SUBSTRING(adm.PAADM_DischgTime, 12))), 'yyyy-MM-dd HH:mm:ss') AS Actual_Discharge_DateTime,
        date_format(to_timestamp(CONCAT(CAST(aud.Intentdate AS STRING), ' ', SUBSTRING(aud.Intenttime, 12))), 'yyyy-MM-dd HH:mm:ss') AS Intent_DateTime,
        date_format(to_timestamp(CONCAT(CAST(adm2.PAADM2_AmbulHandoverCompDate AS STRING), ' ', SUBSTRING(adm2.PAADM2_AmbulHandoverCompTime, 12))), 'yyyy-MM-dd HH:mm:ss') AS Ambul_Handover_Comp_DateTime,
        date_format(to_timestamp(CONCAT(CAST(phh.HOH_StartDate AS STRING), ' ', SUBSTRING(phh.HOH_StartTime, 12))), 'yyyy-MM-dd HH:mm:ss') AS Handover_Start_DateTime,
        date_format(to_timestamp(CONCAT(CAST(phh.HOH_EndDate AS STRING), ' ', SUBSTRING(phh.HOH_EndTime, 12))), 'yyyy-MM-dd HH:mm:ss') AS Handover_End_DateTime,
        phh.HOH_Childsub AS Handover_Childsub,
        phh.HOH_Type AS Handover_Type,
        adm.PAADM_VisitStatus AS Visit_Status_Code,
        adm.PAADM_Remark AS Visit_Comment,
        adm2.PAADM2_ShortStayIntent AS Inpatient_Short_Stay_Intent,
        adm.PAADM_ExpLOS AS Length_Of_Stay,
        str.TRSTR_Desc AS Emergency_Treatment_Streams,
        ac.CTACU_Desc AS Triage_Description,
        ac.CTACU_Code AS Triage_Code,
        prd.REFD_Code AS Ref_Clinician_Code,
        prdc.CLN_Code AS Ref_Clin_Practice_Code,
        cth.HSC_Code AS Health_Specialty_Code,
        pacb.BLM_Code AS Billing_Method_Code,
        pacar.AEARM_Desc AS Arrival_Mode,
        date_format(to_timestamp(CONCAT(CAST(le.ADML_GoingOutDate AS STRING), ' ', SUBSTRING(le.ADML_GoingOutTime, 12))), 'yyyy-MM-dd HH:mm:ss') AS Leave_Going_Out_DateTime,
        date_format(to_timestamp(CONCAT(CAST(le.ADML_ActualDateReturn AS STRING), ' ', SUBSTRING(le.ADML_ActualTimeReturn, 12))), 'yyyy-MM-dd HH:mm:ss') AS Leave_Actual_Return_DateTime,
        date_format(to_timestamp(CONCAT(CAST(le.ADML_CancelDate AS STRING), ' ', SUBSTRING(le.ADML_CancelTime, 12))), 'yyyy-MM-dd HH:mm:ss') AS Leave_Cancel_DateTime,
        lt.LEATYP_Code AS Leave_Type_Code,
        lt.LEATYP_Desc AS Leave_Type_Desc,
        cn.CTPCP_Desc AS Nurse,
        adm.PAADM_PAPMI_DR AS Patient_ID,
        orc.OPER_New_RowId AS Intended_Procedure,
        ssr.SHSTR_Desc AS Short_Stay_Reason_Desc,
        cp.CTPCP_Desc AS PreAdm_Clinician,
        loc.CTLOC_Desc AS PreAdm_Specialty,
        f.Floor_Text as Floor_Plan_Notes,
        adm.PAADM_Current as Is_Current,
        adm.source_file,
        adm.processing_time
    FROM 
    bronze_live.tc_pa_adm adm
    LEFT JOIN bronze_live.tc_pa_adm2 adm2 ON adm2.PAADM2_RowId = adm.PAADM_RowId 
    LEFT JOIN bronze_live.tc_pac_inpatAdmissiontype adt ON adm.PAADM_InPatAdmType_DR = adt.IPAT_RowId
    LEFT JOIN bronze_live.tc_pac_billingmethod pacb ON adm.PAADM_BillingMethod_DR = pacb.BLM_RowId
    LEFT JOIN bronze_live.tc_pac_treatmentstream str ON adm2.PAADM2_TreatmentStream_DR = str.TRSTR_RowId
    LEFT JOIN bronze_live.tc_pac_aearrivalmode pacar ON adm.PAADM_AEArrivalMode_DR = pacar.AEARM_RowId  
    LEFT JOIN bronze_live.tc_pac_refdoctor_new prd ON adm.PAADM_RefDocList_DR = prd.REFD_RowId
    LEFT JOIN bronze_live.tc_pac_refdoctorclinic prdc ON adm.PAADM_RefDocClinic_DR = prdc.CLN_RowId
    LEFT JOIN bronze_live.tc_ct_acuity ac ON adm.PAADM_Priority_DR = ac.CTACU_RowId 
    LEFT JOIN bronze_live.tc_ct_lochealthspeccode ctl ON adm.PAADM_DepCode_DR = ctl.HSPC_ParRef AND ctl.HSPC_Childsub = 1 
    LEFT JOIN bronze_live.tc_ct_healthspecialtycodes cth ON ctl.HSPC_HealthSpecCode_DR = cth.HSC_RowId 
    LEFT JOIN bronze_live.tc_ct_disposit ctd ON adm.PAADM_Dispos_DR = ctd.CTDSP_RowID
    LEFT JOIN bronze_live.tc_ss_audittrail aud ON aud.AUD_PAPMI_DR = adm.PAADM_PAPMI_DR AND aud.rownumber = '1'
    LEFT JOIN 
        ( 
        SELECT  
        ADML_ParRef, 
        ADML_LeaveType_DR, 
        ADML_GoingOutDate,  
        ADML_GoingOutTime,  
        ADML_ActualDateReturn,  
        ADML_ActualTimeReturn,  
        ADML_CancelDate,  
        ADML_CancelTime,  
        ROW_NUMBER() OVER (PARTITION BY ADML_ParRef ORDER BY ADML_GoingOutDate DESC) AS rownumber 
        FROM 
        bronze_live.tc_pa_admleave  
        ) le ON adm.PAADM_RowID = le.ADML_ParRef AND le.rownumber = 1 
    LEFT JOIN bronze_live.tc_pac_leavetype lt ON le.ADML_LeaveType_DR = lt.LEATYP_RowId 
    LEFT JOIN 
        (
        SELECT  
        phh.HOH_ParRef,  
        phh.HOH_Childsub,  
        phh.HOH_CareProvider_DR,
        phh.HOH_Type,
        phh.HOH_StartDate,
        phh.HOH_StartTime,
        phh.HOH_EndDate,
        phh.HOH_EndTime,
        ROW_NUMBER() OVER (PARTITION BY phh.HOH_ParRef ORDER BY phh.HOH_Childsub DESC) AS rownumber 
        FROM 
        bronze_live.tc_pa_adm2handoverhistory phh  
        ) phh ON phh.HOH_ParRef = adm2.PAADM2_RowId AND phh.rownumber = 1 
    LEFT JOIN bronze_live.tc_ct_careprov cn ON cn.CTPCP_RowId1 = phh.HOH_CareProvider_DR 
    LEFT JOIN bronze_live.tc_CT_CareProv cp ON cp.CTPCP_RowId1 = adm.PAADM_AdmDocCodeDR 
    LEFT JOIN bronze_live.tc_CT_Loc loc ON adm.PAADM_DepCode_DR = loc.CTLOC_RowID 
    LEFT JOIN bronze_live.tc_MR_Adm mradm on adm.PAADM_RowID = mradm.MRADM_ADM_DR 
    LEFT JOIN bronze_live.tc_MR_FloorPlanNotes f on mradm.MRADM_RowId = f.FLOOR_ParRef 
    LEFT JOIN bronze_live.tc_mrc_shortstayreason ssr ON adm2.PAADM2_ShortStayReason_DR = ssr.SHSTR_RowId
    LEFT JOIN
        ( 
        SELECT 
        orcall.OPER_RowId AS OPER_RowId
        ,orcactive.OPER_RowId AS OPER_New_RowId 
        FROM 
        bronze_live.tc_orc_operation orcall 
        INNER JOIN 
            (
            SELECT 
            OPER_RowId
            ,OPER_CODE
            ,ROW_NUMBER() OVER (PARTITION BY OPER_Code ORDER BY IFNULL(OPER_ActiveDateTo,'2099-12-31') DESC) AS rownumber
            FROM bronze_live.tc_orc_operation
            ) orcactive ON orcall.oper_code = orcactive.oper_code AND rownumber = 1 
        ) orc ON adm.PAADM_Oper_DR = orc.OPER_RowId 
    WHERE
    adm.PAADM_AdmDate > ADD_MONTHS(CURRENT_DATE(), -12)
    OR adm.PAADM_Current = 'Y'
    ),
watermark AS (
    SELECT MAX(processing_time) AS watermark_value
    FROM admission
)
SELECT 
    w.watermark_value,
    a.*
FROM
    admission a,
    watermark w
""")

# COMMAND ----------

# MAGIC %sql select * from silver_live.cds_admission where Admission_Number = 'V6747854' limit 10
