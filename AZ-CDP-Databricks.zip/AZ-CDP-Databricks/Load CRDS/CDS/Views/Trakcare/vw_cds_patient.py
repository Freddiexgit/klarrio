# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 10-Mar-2024 | 1       | Donne Medley     | Create first draft of permanent view vw_cds_patient                                           |
# MAGIC | 15-Mar-2024 | 2       | Donne Medley     | First released version                                           |
# MAGIC | 17-Apr-2024 | 3       |Siddharth Saravanan    |Added fields and tables for Release 1                                          |
# MAGIC | 26-Apr-2024 | 4       |Siddharth Saravanan    |Added fields and tables for Release 2                                          |
# MAGIC | 22-May-2024 | 5       |Donne Medley    |Added fields and tables for Release 6                                          |
# MAGIC | 12-Jun-2024 | 6      | Donne Medley    | Updated the table for Release 9, TPACDS-645 fix                 |
# MAGIC | 12-Jun-2024 | 7      | Donne Medley    | Updated the table for Release 15                 |
# MAGIC | 31-Jun-2024 | 8      | Donne Medley    | Updated the table for Release 16                 |
# MAGIC | 30-Aug-2024 | 9      | Donne Medley    | Updated the table for Release 20                 |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_ref_diagnosis""")
# spark.sql(f"""DROP TABLE bronze_live.tc_pa_pregnancy""")
# spark.sql(f"""DROP VIEW silver_live.vw_cds_patient""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_patient
AS
SELECT DISTINCT
GREATEST (patmas.processing_time,perseth.processing_time,sex.processing_time)  AS watermark_value
,patmas.PAPMI_RowId1 AS UID
,patmas.PAPMI_RowId1 AS Patient_ID
,patmas.PAPMI_No AS Patient_NHI
,patmas.PAPMI_Name2 as Patient_First_Name 
,patmas.PAPMI_Name3 as Patient_Middle_Name
,patmas.PAPMI_Name as Patient_Last_Name 
,CASE 
    WHEN unix_timestamp(patmas.PAPMI_DOB,'yyyy-MM-dd') IS NOT NULL 
      THEN to_date(from_unixtime(unix_timestamp(patmas.PAPMI_DOB,'yyyy-MM-dd')))
    ELSE to_date(DATEADD(DAY,patmas.PAPMI_DOB,'1840-12-31'),'yyyy-MM-dd')
    END AS Patient_DOB
--,to_date(patmas.PAPMI_DOB) AS Patient_DOB 
,patmas.PAPMI_Email as Patient_Email 
,patmas.PAPMI_MobPhone as Patient_Mobile_Phone
,patmas.PAPER_AgeYr as Patient_Age_Year 
,patmas.PAPER_AgeMth as Patient_Age_Month 
,sex.CTSEX_Code AS Patient_Gender_Code
,sex.CTSEX_Desc AS Patient_Sex 
,preg.PREG_EdcAgreed as EDC_Agreed_Date 
,patmas.PAPMI_Deceased_Date AS Patient_Deceased_Date
,patmas.PAPER_DomicileCode AS Patient_Domicile_Code
,dhb.NATC_MappedValue as Patient_DHB 
,perseth.Patient_Ethnicity AS Patient_Ethnicity
,perseth.Patient_Prioritised_Ethnicity AS Patient_Prioritised_Ethnicity
,patmas.PAPER_InterpreterRequired as Is_Interpreter_Required 
,prflang.PREFL_Desc AS Preferred_Language
,CASE  
  WHEN pa.ALERT_Desc IS NOT NULL  
  THEN '!'  
  END AS AlertFlag 
,refdoc.REFD_Code AS GP_Code
,refclin.CLN_Code AS GP_Practice_Code
,patmas.source_file
,GREATEST(patmas.processing_time,perseth.processing_time,sex.processing_time) AS processing_time
FROM 
bronze_live.tc_pa_patmas patmas 
--INNER JOIN bronze_live.tc_pa_person person ON patmas.PAPMI_PAPER_DR = person.PAPER_RowId 
INNER JOIN bronze_live.tc_ct_sex sex ON patmas.PAPER_Sex_DR = sex.CTSEX_RowId
LEFT JOIN bronze_live.tc_pac_preferredlanguage prflang on prflang.PREFL_RowId = patmas.PAPMI_PrefLanguage_DR 
LEFT JOIN
  (
  SELECT
  Patient_ID
  ,Patient_Ethnicity
  ,Patient_Prioritised_Ethnicity
  ,processing_time 
  FROM 
  silver_live.cds_ref_patient_ethnicity 
  WHERE
  Priority=1
  ) perseth ON patmas.PAPER_RowID=perseth.Patient_ID
--LEFT JOIN silver_live.cds_ref_patient_ethnicity perseth ON patmas.PAPMI_RowId1=perseth.Patient_ID AND perseth.Priority=1
LEFT JOIN 
  ( 
  SELECT 
  PREG_Person_DR
  ,CASE 
    WHEN unix_timestamp(PREG_EdcAgreed,'yyyy-MM-dd') IS NOT NULL 
      THEN to_date(from_unixtime(unix_timestamp(PREG_EdcAgreed,'yyyy-MM-dd')))
    ELSE to_date(DATEADD(DAY,PREG_EdcAgreed,'1840-12-31'),'yyyy-MM-dd')
    END PREG_EdcAgreed
  ,ROW_NUMBER() OVER (PARTITION BY PREG_Person_DR ORDER BY PREG_EdcAgreed DESC) AS rownumber 
  FROM 
  bronze_live.tc_PA_Pregnancy 
  WHERE
  PREG_Status = 2 
  ) preg ON preg.PREG_Person_DR = patmas.PAPMI_RowId1 AND PREG.rownumber = 1 
LEFT JOIN
  (
  SELECT 
  alm.ALM_PAPMI_ParRef,  
  alm.ALM_Alert_DR, 
  alm.ALM_ChildSub, 
  ROW_NUMBER() OVER (PARTITION BY alm.ALM_PAPMI_ParRef ORDER BY alm.ALM_ChildSub DESC) AS rownumber 
  FROM 
  bronze_live.tc_PA_AlertMsg alm
  ) pms ON pms.ALM_PAPMI_ParRef = patmas.PAPMI_RowId1 AND pms.rownumber = 1 
LEFT JOIN bronze_live.tc_PAC_PatientAlert pa ON pa.ALERT_RowId = pms.ALM_Alert_DR  
LEFT JOIN 
  (
  SELECT 
  pac.NATC_ActualValue
  ,pac.NATC_MappedValue  
  FROM 
  bronze_live.tc_pac_nationalcodes pac 
  LEFT JOIN bronze_live.tc_PAC_ReportingType pr ON pac.NATC_ReportingType_DR = pr.REPTYPE_RowId 
  WHERE
  pr.REPTYPE_Code LIKE 'NZAD_DOM1' 
  AND pac.NATC_DateTo IS NULL
  ) dhb ON patmas.PAPER_DomicileCode = dhb.NATC_ActualValue
LEFT JOIN bronze_live.tc_PAC_RefDoctor_new refdoc ON patmas.PAPER_FamilyDoctor_DR = refdoc.REFD_RowID
LEFT JOIN bronze_live.tc_PAC_RefDoctorClinic refclin ON patmas.PAPER_FamilyDoctorClinic_DR = refclin.CLN_RowID
""")

# COMMAND ----------

# MAGIC %sql select * from silver_live.vw_cds_patient  where EDC_Agreed_Date is not null limit 100
