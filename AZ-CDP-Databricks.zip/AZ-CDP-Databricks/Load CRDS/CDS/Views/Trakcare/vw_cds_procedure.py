# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 04-Mar-2024 | 1       | Donne Medley     | Create first draft of permanent view vw_cds_procedure                                           |
# MAGIC | 27-Mar-2024 | 2       | Donne Medley     | Latest version provided by modellers                                           |
# MAGIC | 15-May-2024 | 3       | Donne Medley     | Updated for Release 5                                          |
# MAGIC | 22-May-2024 | 4       | Donne Medley     | Updated for Release 6                                         |
# MAGIC | 12-Jun-2024 | 5       | Donne Medley     | Updated for Release 9                                         |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_procedure""")
# spark.sql(f"""DROP TABLE silver_live.cds_procedure""")

# COMMAND ----------


spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_procedure
AS
WITH a AS
    ( 
    --Anaesthesia
    SELECT 
    ana.ANA_RowId AS UID 
    ,ana.ANA_RBOperatingRoom_DR AS Operating_Room_ID 
    ,ana.ANA_PAADM_ParRef AS Admission_ID 
    ,99999 AS Procedure_ID 
    ,NULL as Movement_Procedure_ID
    ,rbop.RBOP_BookingType AS Booking_Type 
    ,rbop.RBOP_Status AS Procedure_Status
    ,rfs.SUSP_Desc AS Cancelled_Reason 
    ,r.RES_Code AS Resource_Code
    ,class.ORASA_Code AS ASA
    ,anam.ANMET_Desc AS Theatre_Module_Procedure_Code
    ,date_format(to_timestamp(CONCAT(CAST(rbop.RBOP_DateOper AS STRING),' ',SUBSTRING(rbop.RBOP_TimeOper, 12))),'yyyy-MM-dd HH:mm:ss') AS Booked_Create_DateTime
    ,date_format(to_timestamp(CONCAT(CAST(rbop.RBOP_CreateDate AS STRING),' ',SUBSTRING(rbop.RBOP_CreateTime, 12))),'yyyy-MM-dd HH:mm:ss') AS Booking_Create_DateTime
    ,date_format(to_timestamp(CONCAT(CAST(ana.ANA_Date AS STRING),' ',SUBSTRING(ana.ANA_AnaStartTime, 12))),'yyyy-MM-dd HH:mm:ss') AS Start_DateTime
    ,date_format(to_timestamp(CONCAT(CAST(ana.ANA_Date AS STRING),' ',SUBSTRING(ana.ANA_AnaFinishTime, 12))),'yyyy-MM-dd HH:mm:ss') AS Finish_DateTime
    ,date_format(to_timestamp(CONCAT(CAST(ana.ANA_TheatreOutDate AS STRING),' ',SUBSTRING(ana.ANA_TheatreOutTime, 12))),'yyyy-MM-dd HH:mm:ss') AS Theatre_Out_DateTime
    ,rbop.RBOP_TotalPlanTheatreTime AS Total_Plan_Theatre_Time
    ,0 AS Is_Primary 
    ,ana.source_file
    ,GREATEST(ana.processing_time,rbop.processing_time) AS processing_time
    FROM 
    bronze_live.tc_or_anaesthesia ana 
    INNER JOIN bronze_live.tc_rb_operatingroom rbop ON rbop.RBOP_RowId = ana.ANA_RBOperatingRoom_DR 
    LEFT JOIN bronze_live.tc_RB_Resource r ON r.RES_RowId = rbop.RBOP_Resource_DR 
    LEFT JOIN bronze_live.tc_ORC_ReasonForSuspend rfs ON ana.ANA_Reason_Suspend_DR = rfs.SUSP_RowId 
    LEFT JOIN bronze_live.tc_ORC_ASA_ClassPhActiv class ON ana.ANA_ASA_DR = class.ORASA_RowId 
    LEFT JOIN bronze_live.tc_orc_anaestmethod anam ON anam.ANMET_RowId=ana.ANA_Method 

    UNION

    -- Primary surgical operation
    SELECT 
    anaop.ANAOP_RowId AS UID 
    ,ANA.ANA_RBOperatingRoom_DR AS Operating_Room_ID 
    ,ana.ANA_PAADM_ParRef AS Admission_ID 
    ,anaop.ANAOP_Type_DR AS Procedure_ID 
    ,anaop.ANAOP_Par_Ref AS Movement_Procedure_ID
    ,rbop.RBOP_BookingType AS Booking_Type 
    ,rbop.RBOP_Status AS Procedure_Status 
    ,rfs.SUSP_Desc AS Cancelled_Reason 
    ,r.RES_Code AS Resource_Code 
    ,class.ORASA_Code AS ASA
    ,anam.ANMET_Desc AS Theatre_Module_Procedure_Code
    ,date_format(to_timestamp(CONCAT(CAST(rbop.RBOP_DateOper AS STRING),' ',SUBSTRING(rbop.RBOP_TimeOper, 12))),'yyyy-MM-dd HH:mm:ss') AS Booked_Create_DateTime
    ,date_format(to_timestamp(CONCAT(CAST(rbop.RBOP_CreateDate AS STRING),' ',SUBSTRING(rbop.RBOP_CreateTime, 12))),'yyyy-MM-dd HH:mm:ss') AS Booking_Create_DateTime
    ,date_format(to_timestamp(CONCAT(CAST(anaop.ANAOP_OpStartDate AS STRING),' ',SUBSTRING(anaop.ANAOP_OpStartTime, 12))),'yyyy-MM-dd HH:mm:ss') AS Start_DateTime
    ,date_format(to_timestamp(CONCAT(CAST(anaop.ANAOP_OpEndDate AS STRING),' ',SUBSTRING(anaop.ANAOP_OpEndTime, 12))),'yyyy-MM-dd HH:mm:ss') AS Finish_DateTime
    ,date_format(to_timestamp(CONCAT(CAST(anaop.ANAOP_TheatreOutDate AS STRING),' ',SUBSTRING(anaop.ANAOP_TheatreOutTime, 12))),'yyyy-MM-dd HH:mm:ss') AS Theatre_Out_DateTime
    ,rbop.RBOP_TotalPlanTheatreTime as Total_Plan_Theatre_Time
    ,CASE 
        WHEN ANAOP.rownumber = 1 THEN 1 
        ELSE 0 
        END AS Is_Primary 
    ,anaop.source_file
    ,anaop.processing_time
    FROM 
    (SELECT *, ROW_NUMBER() OVER (PARTITION BY ANAOP_Par_Ref ORDER BY ANAOP_No ) AS rownumber FROM bronze_live.tc_or_anaest_operation) anaop
    INNER JOIN bronze_live.tc_or_anaesthesia ana ON ana.ANA_RowId = anaop.ANAOP_Par_Ref 
    INNER JOIN bronze_live.tc_rb_operatingroom rbop ON rbop.RBOP_RowId = ana.ANA_RBOperatingRoom_DR
    LEFT JOIN bronze_live.tc_RB_Resource r ON r.RES_RowId = rbop.RBOP_Resource_DR 
    LEFT JOIN bronze_live.tc_ORC_ReasonForSuspend rfs ON ana.ANA_Reason_Suspend_DR = rfs.SUSP_RowId
    LEFT JOIN bronze_live.tc_ORC_ASA_ClassPhActiv class ON ana.ANA_ASA_DR = class.ORASA_RowId 
    LEFT JOIN bronze_live.tc_orc_anaestmethod anam ON anam.ANMET_RowId=ana.ANA_Method 

    UNION 

    -- Non primary surgical operation
    SELECT 
    secpr.SECPR_RowId AS UID 
    ,ana.ANA_RBOperatingRoom_DR AS Operating_Room_ID
    ,ana.ANA_PAADM_ParRef AS Admission_ID 
    ,secpr.SECPR_Operation_DR AS Procedure_ID 
    ,anaop.ANAOP_Par_Ref AS Movement_Procedure_ID
    ,rbop.RBOP_BookingType AS Booking_Type 
    ,rbop.RBOP_Status AS Procedure_Status
    ,NULL AS Cancelled_Reason
    ,r.RES_Code AS Resource_Code
    ,NULL AS ASA
    ,NULL AS Theatre_Module_Procedure_Code
    ,NULL AS Booked_Create_DateTime
    ,NULL AS Booking_Create_DateTime
    ,NULL AS Start_DateTime
    ,NULL AS Finish_DateTime
    ,NULL AS Theatre_Out_DateTime
    ,'1970-01-01T00:00:00.000+00:00' AS Total_Plan_Theatre_Time --zero. NULL causes error.
    ,0 AS Is_Primary 
    ,secpr.source_file
    ,GREATEST(secpr.processing_time, anaop.processing_time, ana.processing_time,rbop.processing_time) AS processing_time
    FROM 
    bronze_live.tc_or_an_oper_secondaryproc secpr 
    INNER JOIN bronze_live.tc_or_anaest_Operation anaop ON secpr.SECPR_ParRef = anaop.ANAOP_RowId 
    INNER JOIN bronze_live.tc_or_anaesthesia ana ON ana.ANA_RowId = anaop.ANAOP_Par_Ref 
    INNER JOIN bronze_live.tc_rb_operatingroom rbop ON rbop.RBOP_RowId = ana.ANA_RBOperatingRoom_DR
    LEFT JOIN bronze_live.tc_RB_Resource r ON r.RES_RowId = rbop.RBOP_Resource_DR
    )
,proc_time AS 
    (
    SELECT
    MAX(processing_time) processing_time
    FROM
    a
    )

SELECT
proc_time.processing_time AS watermark_value
,a.UID
,a.Operating_Room_ID
,a.Admission_ID
,a.Procedure_ID
,a.Movement_Procedure_ID
,a.Booking_Type
,a.Procedure_Status 
,a.Cancelled_Reason
,a.Resource_Code 
,a.ASA
,a.Theatre_Module_Procedure_Code
,a.Booked_Create_DateTime
,a.Booking_Create_DateTime
,a.Start_DateTime
,a.Finish_DateTime
,a.Theatre_Out_DateTime
,a.Total_Plan_Theatre_Time
,a.Is_Primary 
,a.source_file
,a.processing_time
FROM 
a
,proc_time
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from silver_live.vw_cds_procedure
