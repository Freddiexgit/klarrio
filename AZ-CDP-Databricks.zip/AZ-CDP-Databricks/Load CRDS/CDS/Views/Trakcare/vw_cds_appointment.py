# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 16-May-2024 | 1       | Donne Medley     | Create first draft of permanent view vw_cds_appointment. Release 5.                    |
# MAGIC | 12-Jun-2024 | 2       | Donne Medley     | Updated for Release 9.                    |
# MAGIC | 03-Jul-2024 | 3       | Donne Medley     | Updated for Release 12.                    |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_ref_room""")
# spark.sql(f"""DROP TABLE bronze_live.tc_rb_appointment""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_appointment
AS
WITH appointment AS (
    SELECT 
    app.APPT_RowId as UID,
    app.APPT_RowId as Appointment_ID,
    app.APPT_AS_ParRef as Session_ID,
    app.APPT_Adm_DR as Admission_ID,
    app.APPT_RBOP_DR as Operating_Room_ID,
    cp.CTPCP_Desc as Seen_By_Clinician,
    date_format(to_timestamp(CONCAT(CAST(app.APPT_DateComp AS STRING),' ',SUBSTRING(app.APPT_TimeComp, 12))),'yyyy-MM-dd HH:mm:ss') AS Appointment_DateTime,
    date_format(to_timestamp(CONCAT(CAST(app.APPT_CancelDate AS STRING),' ',SUBSTRING(app.APPT_CancelTime, 12))),'yyyy-MM-dd HH:mm:ss') AS Appointment_Cancel_DateTime,
    app.APPT_Status as Appointment_Status,
    CAST(app.APPT_Duration AS INT) as Appointment_Duration,
    date_format(to_timestamp(rbo.RBOP_TimeOper),'HH:mm') as Appointment_Start_Time,
    date_format(
        TIMESTAMPADD(
            MINUTE, 
            app.APPT_Duration, 
            to_timestamp(CONCAT(CAST(rbo.RBOP_DateOper AS STRING), ' ', SUBSTRING(rbo.RBOP_TimeOper, 12)))
        ),
        'HH:mm'
    ) as Appointment_End_Time,
    app.source_file,
    app.processing_time
    FROM 
    bronze_live.tc_RB_Appointment app
    LEFT JOIN bronze_live.tc_ct_careprov cp ON app.APPT_SeenDoctor_DR = cp.CTPCP_RowId1
    LEFT JOIN bronze_live.tc_RB_OperatingRoom rbo ON app.APPT_RowId = rbo.RBOP_Appoint_DR
    ),
watermark AS (
    SELECT MAX(processing_time) AS watermark_value
    FROM appointment
)
SELECT 
    w.watermark_value,
    ad.*
FROM
    appointment ad,
    watermark w
""")
