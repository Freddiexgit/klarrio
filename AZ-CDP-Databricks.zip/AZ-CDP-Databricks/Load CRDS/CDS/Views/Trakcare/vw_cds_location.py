# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 04-Mar-2024 | 1       | Donne Medley     | Create first draft of permanent view vw_cds_location                                           |
# MAGIC | 10-Mar-2024 | 2       | Donne Medley     | Added approved_beds                                           |
# MAGIC | 17-Apr-2024 | 3      | Siddharth Saravanan    | Modified fields for Release 1                |
# MAGIC | 18-Apr-2024 | 3.1      | Siddharth Saravanan    | Modified fields for Release 1 Defects                |
# MAGIC | 08-May-2024 | 4      | Siddharth Saravanan    | Modified fields for Release 4 Defects                |
# MAGIC | 15-May-2024 | 4      | Donne Medley    | Modified fields for Release 5                |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_location""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_location
AS
WITH location AS 
    (
    SELECT 
    loc.CTLOC_RowID as UID,
    loc.CTLOC_RowID AS Location_ID,
    loc.CTLOC_Hospital_DR AS Hospital_ID,
    LTRIM(RTRIM(loc.CTLOC_Code)) AS Location_Code,
    loc.CTLOC_Desc AS Location_Desc,
    std.Description AS Location_Type,
    cbu.specialtycode AS Speciality_Code,
    cbu.specialtydesc AS Speciality_Desc,
    trust.TRUST_Code AS Trust_Code,
    trust.TRUST_Desc,
    CASE 
        WHEN current_timestamp() <= COALESCE(loc.CTLOC_DateActiveTo, current_timestamp()) THEN 'Y'
        ELSE 'N' 
        END AS Is_Active,
    CASE 
        WHEN loc.CTLOC_Code in ('AED','CED','CDU') THEN 'Y' 
        ELSE 'N' 
        END AS Is_Emergency,
    CASE 
        WHEN loc.CTLOC_Code IN ('AWATEA', 'MARINO', 'MOTU', 'RANGI', 'REMURA', '10SURG', '31MED', '31W', '41', '42', '51', '61', '62', '63', '64', '65', '66', '67', '68', '71', '72', '73', '74', '75', '76', '77', '78', '71', '81', '83', '97') THEN 'Adult Inpatient'
        WHEN loc.CTLOC_Code IN ('23B', '24A', '24B', '25', '26A', '26B', '27B') THEN 'Child Health Inpatient'
        WHEN loc.CTLOC_Code IN ('BRC', 'CFUO', 'FMU', 'B', 'C', 'TWT', 'A', 'TUPU') THEN 'Mental Health Inpatient'
        WHEN loc.CTLOC_Code IN ('TAMAKI', '96', '98') THEN 'Womens Inpatient'
        END AS Inpatient_Type,
    CAST(bed.APB_NUMBEROFBEDS AS BIGINT) AS Approved_Beds,
    --locspeccode.HSPC_Childsub, 
    loc.source_file,
    loc.processing_time
    FROM 
    bronze_live.tc_ct_loc loc
    LEFT JOIN bronze_live.tc_websys_standardtypeitem std ON std.Code = loc.CTLOC_Type 
        AND std.ParRef = 'LocationType'
    LEFT JOIN bronze_live.tc_ct_locapprovedbeds bed ON bed.APB_ParRef = loc.CTLOC_RowID 
        AND (
            (bed.APB_DateFrom <= GETDATE() OR bed.APB_DateFrom IS NULL) 
            AND (bed.APB_DateFrom >= GETDATE() OR bed.APB_DateTo IS NULL)
            )
    LEFT JOIN bronze_live.tc_CT_Hospital hosp ON loc.CTLOC_Hospital_DR = hosp.HOSP_RowId
    LEFT JOIN bronze_live.tc_CT_HospitalTrusts hosptrust on hosp.HOSP_RowId = hosptrust.TRUST_ParRef
    LEFT JOIN bronze_live.tc_PAC_Trust trust on hosptrust.TRUST_Trust_DR = trust.TRUST_RowId
    LEFT JOIN silver_db.vw_tc_s_cbu cbu ON cbu.cbuid = loc.CTLOC_RespUnit_DR
    --LEFT JOIN --awaiting confirmation re requirement for HSPC_Childsub
        --(
        --SELECT 
        --*  
        --FROM 
        --bronze_live_tc_CT_LocHealthSpecCode  
        --WHERE 
        --HSPC_ChildSub=1 
        --) AS locspeccode ON locspeccode.HSPC_ParRef=loc.CTLOC_RowId  
    --LEFT JOIN bronze_live.tc_ct_HealthSpecialtyCodes AS speccode ON speccode.HSC_RowId=locspeccode.HSPC_HealthSpecCode_DR
    )
,watermark AS 
    (
    SELECT 
    MAX(processing_time) AS watermark_value
    FROM 
    location
    )
SELECT 
w.watermark_value,
l.*
FROM
location l
,watermark w
""")

# COMMAND ----------

# MAGIC %sql select * from bronze_live.tc_pac_refdoctor_new
