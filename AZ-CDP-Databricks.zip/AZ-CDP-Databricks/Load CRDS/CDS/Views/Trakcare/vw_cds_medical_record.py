# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 27-Mar-2024 | 1       | Donne Medley   | Create first draft of permanent view vw_cds_medical_record     |
# MAGIC | 10-Apr-2024 | 2       | Donne Medley   | Added present_complaint     |
# MAGIC | 17-Apr-2024 | 3       | Siddharth Saravanan   | Added fields for Release 1                                           |
# MAGIC | 17-Apr-2024 | 4       | Donne Medley   | Added fields for Release 12                                           |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_medical_record""")
# spark.sql(f"""DROP TABLE bronze_live.tc_mr_adm""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_medical_record
AS
WITH medical_record AS 
    (
    SELECT
        mr.MRADM_RowId AS UID,
        mr.MRADM_RowId AS Medical_Record_ID,
        mr.MRADM_ADM_DR AS Admission_ID,
        mr.MRADM_PresentComplaint AS Present_Complaint,
        CAST(mr.MRADM_ICUHours AS Double) AS ICU_Hours,
        ctd.CTDSP_Code AS Discharge_Type_Code,
        ct.CARETYP_Desc AS Care_Type_Desc,
        dis.DSCL_Code AS Discharge_Code,
        tr.TRD_Desc AS Transfer_Destination,
        mode.TRANSM_Desc AS Transfer_Means_Desc,
        mr.source_file,
        mr.processing_time
    FROM 
    bronze_live.tc_mr_adm mr
    LEFT JOIN bronze_live.tc_pac_transferdestination tr ON tr.TRD_RowId = mr.MRADM_TransfDest_DR
    LEFT JOIN bronze_live.tc_pac_transfermeans mode on mode.TRANSM_RowId = MR.MRADM_TransferMeans_DR 
    LEFT JOIN bronze_live.tc_pac_dischclassification dis on mr.MRADM_DischClassif_DR = dis.DSCL_RowId 
    LEFT JOIN bronze_live.tc_ct_disposit ctd ON mr.MRADM_DischType_DR = ctd.CTDSP_RowID 
    LEFT JOIN bronze_live.tc_PAC_CareType ct ON mr.MRADM_CareType_DR = ct.CARETYP_RowId
    )
,watermark AS 
    (
    SELECT 
    MAX(processing_time) AS watermark_value
    FROM 
    medical_record
    )
SELECT 
w.watermark_value,
mr.*
FROM
medical_record mr,
watermark w
""")

# COMMAND ----------

# MAGIC %sql select * from silver_live.vw_cds_medical_record where ICU_Hours is not null

# COMMAND ----------

# MAGIC %sql select * from bronze_live.tc_mr_adm where MRADM_ICUHours is not null

# COMMAND ----------

# MAGIC %sql select * from silver_live.cds_medical_record where ICU_Hours is not null
