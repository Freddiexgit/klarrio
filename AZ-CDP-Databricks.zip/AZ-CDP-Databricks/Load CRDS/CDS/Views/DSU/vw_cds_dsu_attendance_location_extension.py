# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 30-Apr-2024 | 1       | Siddharth Saravanan | Create first draft of permanent view vw_dsu_attendance_location_extension                  |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_dsu_attendance_location_extension""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_dsu_attendance_location_extension
AS
SELECT 
(SELECT MAX(date_format(processing_time, 'yyyy-MM-dd HH:mm:ss')) FROM bronze.dsu_l_attendance_location_extension) AS watermark_value
,lAttendanceLocationId AS UID
,lAttendanceLocationId
,ICU_Ward_Flag
,ED_Ward_Flag
,Admit_Ward_Flag
,Discharge_Ward_Flag
,ED_Ward_PCM_Flag
,Eligible_Ward_Flag
,Offsite_Ward_Flag
,NWB_Ward_Flag
,Triage_Ward_Flag
,Post_Triage_Ward_Flag
,Inpatient_Ward_Flag
,APU_Ward_Flag
,MH_Ward_Flag
,MH_Ward_Historic_Flag
,MH_MoHTeam_Code
,ED_6Hr_Rule_Ward_Flag
,WardCode
,date_format(processing_time, 'yyyy-MM-dd HH:mm:ss') AS processing_time
FROM 
bronze.dsu_l_attendance_location_extension
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from silver_live.vw_cds_dsu_attendance_location_extension
