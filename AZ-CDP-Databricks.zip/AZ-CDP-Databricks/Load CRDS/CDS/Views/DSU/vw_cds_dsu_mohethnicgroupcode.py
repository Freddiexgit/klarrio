# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 30-Apr-2024 | 1       | Siddharth Saravanan | Create first draft of permanent view vw_dsu_mohethnicgroupcode   

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_dsu_mohethnicgroupcode""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_dsu_mohethnicgroupcode
AS
SELECT 
    (SELECT MAX(date_format(processing_time, 'yyyy-MM-dd HH:mm:ss')) FROM bronze.dsu_l_mohethnicgroupcode) AS watermark_value,
    EthnicGroupCode AS UID,
    EthnicGroupCode,
    EthnicGroupCodeDesc,
    EthnicGroupPriority,
    EthnicGroupLevel,
    date_format(processing_time, 'yyyy-MM-dd HH:mm:ss') AS processing_time
FROM 
    bronze.dsu_l_mohethnicgroupcode;
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from silver_live.vw_cds_dsu_mohethnicgroupcode
