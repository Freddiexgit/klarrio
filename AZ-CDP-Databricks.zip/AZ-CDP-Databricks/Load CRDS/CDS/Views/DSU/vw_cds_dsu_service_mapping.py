# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 09-May-2024 | 1       | Siddharth Saravanan    | Create first draft of permanent view vw_cds_IOCAS_WardService                                         |                                      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_diagnosis""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_dsu_service_mapping
AS
SELECT DISTINCT
(SELECT MAX(date_format(processing_time, 'yyyy-MM-dd HH:mm:ss')) FROM bronze.dsu_l_service_mapping) AS watermark_value
,CONCAT(WardCode,ServiceCode,DirectorateCode) as UID
,a.WardCode
,a.ServiceCode
,a.ServiceName
,a.DirectorateCode
,CASE a.DirectorateCode
  WHEN 'E27' THEN 'The Auckland Regional Public Health Service'
  WHEN 'E29' THEN 'Women''s Health'
  WHEN 'E30' THEN 'Child Health'
  WHEN 'E31' THEN 'Cancer & Blood Services'
  WHEN 'E32' THEN 'Cardiovascular Services'
  WHEN 'E33' THEN 'Clinical Support Services'
  WHEN 'E34' THEN 'Mental Health'
  WHEN 'E35' THEN 'Adult Community & Long Term Conditions'
  WHEN 'E36' THEN 'Adult Medical Services'
  WHEN 'E37' THEN 'Surgical Services'
  WHEN 'E42' THEN 'Patient Management Services'
  WHEN 'E43' THEN 'Perioperative Services'
  ELSE NULL END AS DirectorateDesc
,date_format(processing_time, 'yyyy-MM-dd HH:mm:ss') AS processing_time
FROM bronze.dsu_l_service_mapping a
WHERE a.WardCode IS NOT NULL
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from silver_live.vw_cds_dsu_service_mapping

# COMMAND ----------


