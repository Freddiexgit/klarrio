# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 06-Mar-2024 | 1       | Donne Medley     | Create first draft of permanent view vw_cds_disposition                                           |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

spark.sql(f"""DROP VIEW silver_live.vw_cds_disposition""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_disposition
AS
SELECT 
(SELECT MAX(processing_time) FROM bronze_live.tc_ct_disposit) AS watermark_value
,CTDSP_RowID AS uid
,CTDSP_RowID AS disposition_id
,CTDSP_Code AS disposition_code
,CTDSP_Desc AS disposition_desc
,source_file
,processing_time
FROM 
bronze_live.tc_ct_disposit
""")
