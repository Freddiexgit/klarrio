# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 04-Mar-2024 | 1       | Donne Medley     | Create first draft of permanent view vw_cds_location                                           |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_location""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_location
AS
WITH loc AS
    (
    SELECT 
    bed.BED_RowID AS bed 
    ,bed.BED_Room_DR AS room 
    ,bed.BED_WARD_ParRef AS ward 
    ,ward.WARD_LocationDR AS location 
    ,loc.CTLOC_Hospital_DR AS hospital 
    ,bed.source_file
    ,GREATEST(loc.processing_time, bed.processing_time,ward.processing_time) AS processing_time
    FROM
    bronze_live.tc_pac_bed bed 
    INNER JOIN bronze_live.tc_pac_ward ward ON bed.BED_WARD_ParRef = ward.WARD_RowID 
    INNER JOIN bronze_live.tc_ct_loc loc on ward.WARD_LocationDR = loc.CTLOC_RowID 

    UNION 
    
    SELECT 
    'TL' AS Bed 
    ,1749 AS Room 
    ,81 AS Ward 
    ,2 AS Location 
    ,3 AS Hospital 
    ,NULL AS source_file
    ,NULL AS processing_time

    UNION  

    SELECT 
    resource.RES_RowId AS Bed 
    ,NULL as Room 
    ,NULL AS Ward 
    ,resource.RES_CTLOC_DR AS Location 
    ,loc.CTLOC_Hospital_DR AS Hospital 
    ,NULL AS source_file
    ,GREATEST(resource.processing_time, loc.processing_time) AS processing_time
    FROM 
    bronze_live.tc_rb_resource resource
    INNER JOIN bronze_live.tc_ct_loc loc on resource.RES_CTLOC_DR = loc.CTLOC_RowID 
    WHERE 
    resource.RES_Type = 'Equipment'
    )
,proc_time AS 
    (
    SELECT
    MAX(processing_time) processing_time
    FROM
    loc
    )
SELECT
proc_time.processing_time AS watermark_value
,CONCAT(COALESCE(loc.hospital,'000'),'_',COALESCE(loc.location,'000'),'_',COALESCE(loc.ward,'000'),'_',COALESCE(loc.room,'000'),'_',COALESCE(loc.bed,'000')) AS UID
,loc.hospital AS Hospital_ID
,loc.location AS Location_ID
,loc.ward AS Ward_ID
,loc.room AS Room_ID
,loc.bed AS Bed_ID
,loc.source_file
,loc.processing_time 
FROM 
loc
,proc_time
""")

# COMMAND ----------

# MAGIC %sql select * from silver_live.vw_cds_location where hospital is not null order by uid
