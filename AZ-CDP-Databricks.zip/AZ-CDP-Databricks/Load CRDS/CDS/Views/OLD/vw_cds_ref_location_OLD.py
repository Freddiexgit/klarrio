# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 06-Mar-2024 | 1       | Donne Medley     | Create first draft of permanent view vw_cds_ref_ward                                        |
# MAGIC | 20-Mar-2024 | 2       | Donne Medley     | Converted to vw_cds_ref_location at request of James Choi                                        |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

spark.sql(f"""DROP table silver_live.acuity""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_ref_location
AS
SELECT 
(SELECT MAX(processing_time) FROM bronze_live.tc_pac_ward) AS watermark_value
,CTLOC_RowID AS uid
,CTLOC_RowID AS Location_ID
,CTLOC_Code AS Location_Code
,CASE
	WHEN CTLOC_Type = 'MR' THEN 'Medical_Record'
	WHEN CTLOC_Type = 'L' THEN 'Laboratory'
	WHEN CTLoc_Type = 'E' THEN 'Execution_Team'
	WHEN CTLoc_Type = 'CL' THEN 'Outpatient_Clinic'
	WHEN CTLOC_Type = 'W' THEN 'Ward'
	WHEN CTLOC_Type = 'EM' THEN 'Ward'
	WHEN CTLOC_Type = 'OP' THEN 'Ward'
	WHEN CTLOC_Type = 'O' THEN 'unknown'
	WHEN CTLOC_Type = 'M' THEN 'Mortuary'
	WHEN CTLOC_Type = 'OR' THEN 'Outpatient_Room'
    ELSE 'N/A'
	END AS Location_Type
,CTLOC_Desc AS Location_Desc
,CASE
    WHEN current_timestamp() <= COALESCE(CTLOC_DateActiveTo, current_timestamp()) THEN 'Y'
    ELSE 'N'
    END AS Is_Active
,CASE
    WHEN CTLOC_Type IN ('W','EM','OP') THEN 'Y'
    ELSE 'N'
    END AS Is_Inpatient
,CASE
    WHEN CTLOC_Code in ('AED','CED') THEN 'Y'
    ELSE 'N'
    END AS Is_Emergency
,source_file
,processing_time
FROM 
bronze_live.tc_ct_loc
""")
