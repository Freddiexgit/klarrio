# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 04-Mar-2024 | 1       | Donne Medley     | Create first draft of permanent view vw_cds_location                                           |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_location""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_location
AS
SELECT 
--(SELECT MAX(processing_time) FROM bronze_live.tc_ct_hospital) AS watermark_value
GREATEST(loc.processing_time, hosp.processing_time,ward.processing_time,wardroom.processing_time,room.processing_time,bed.processing_time) AS watermark_value
,CONCAT(hosp.HOSP_RowID,'_',ward.WARD_RowID,'_',room.ROOM_RowID,'_',bed.BED_RowID) AS uid
,hosp.HOSP_RowID AS hospital_id 
,ward.WARD_RowID AS ward_id
,room.ROOM_RowID AS room_id 
,bed.BED_RowID AS bed_id 
,loc.source_file 
,GREATEST(loc.processing_time, hosp.processing_time,ward.processing_time,wardroom.processing_time,room.processing_time,bed.processing_time) AS processing_time
FROM 
bronze_live.tc_ct_loc loc
LEFT JOIN bronze_live.tc_ct_hospital hosp ON loc.CTLOC_Hospital_DR = hosp.HOSP_RowId
LEFT JOIN bronze_live.tc_pac_ward ward ON loc.CTLOC_RowID = ward.WARD_LocationDR
LEFT JOIN bronze_live.tc_pac_wardroom wardroom ON ward.WARD_RowID = wardroom.ROOM_ParRef  --check this
LEFT JOIN bronze_live.tc_pac_room room ON wardroom.ROOM_Room_DR = room.ROOM_RowID
LEFT JOIN bronze_live.tc_pac_bed bed ON room.ROOM_RowID = bed.BED_Room_DR
WHERE
loc.CTLOC_Type in ('W','EM','OP')
""")

# COMMAND ----------

# MAGIC %sql select * from silver_live.vw_cds_location where ward_id=1

# COMMAND ----------

# MAGIC %sql select * from bronze_live.tc_pac_bed limit 2

# COMMAND ----------

# MAGIC %sql select * from bronze_live.tc_pac_room where ROOM_RowID=1236

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from bronze_live.tc_pac_wardroom  where room_room_dr in (1236)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from bronze_live.tc_pac_ward where WARD_RowID=102 limit 2 --where WARD_RoomDR is not null

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from bronze_live.tc_ct_hospital limit 2
