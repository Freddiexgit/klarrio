# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 04-Mar-2024 | 1       | Donne Medley     | Create first draft of permanent view vw_cds_location                                           |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_location""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_location
AS
SELECT 
--(SELECT MAX(processing_time) FROM bronze_live.tc_ct_hospital) AS watermark_value
MAX(location.processing_time) AS watermark_value
,CONCAT(location.bed,'_',COALESCE(location.room,'000'),'_',COALESCE(location.ward,'000'),'_',COALESCE(location.location,'000'),'_',COALESCE(location.hospital,'000')) AS uid
,location.hospital 
,location.location 
,location.ward
,location.room
,location.bed
,location.source_file
,MAX(location.processing_time) AS processing_time
FROM 
  (
  SELECT 
  bed.BED_RowID AS bed 
  ,bed.BED_Room_DR AS room 
  ,bed.BED_WARD_ParRef AS ward 
  ,ward.WARD_LocationDR AS location 
  ,loc.CTLOC_Hospital_DR AS hospital 
  ,bed.source_file
  ,GREATEST(loc.processing_time, bed.processing_time,ward.processing_time) AS processing_time
  FROM
  bronze_live.tc_pac_bed bed 
  INNER JOIN bronze_live.tc_pac_ward ward ON bed.BED_WARD_ParRef = ward.WARD_RowID 
  INNER JOIN bronze_live.tc_ct_loc loc on ward.WARD_LocationDR = loc.CTLOC_RowID 
  UNION  
  SELECT 
  'TL' AS Bed 
  ,1749 AS Room 
  ,81 AS Ward 
  ,2 AS Location 
  ,3 AS Hospital 
  ,NULL AS source_file
  ,NULL AS processing_time
  UNION  
  SELECT 
  resource.RES_RowId AS Bed 
  ,NULL as Room 
  ,NULL AS Ward 
  ,resource.RES_CTLOC_DR AS Location 
  ,loc.CTLOC_Hospital_DR AS Hospital 
  ,NULL AS source_file
  ,GREATEST(resource.processing_time, loc.processing_time) AS processing_time
  FROM 
  bronze_live.tc_rb_resource resource
  INNER JOIN bronze_live.tc_ct_loc loc on resource.RES_CTLOC_DR = loc.CTLOC_RowID 
  WHERE 
  resource.RES_Type = 'Equipment'
  ) AS location
""")

# COMMAND ----------

# MAGIC %sql select * from silver_live.vw_cds_location where ward_id=1

# COMMAND ----------

# MAGIC %sql select * from bronze_live.tc_pac_bed limit 2

# COMMAND ----------

# MAGIC %sql select * from bronze_live.tc_pac_room where ROOM_RowID=1236

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from bronze_live.tc_pac_wardroom  where room_room_dr in (1236)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from bronze_live.tc_pac_ward where WARD_RowID=102 limit 2 --where WARD_RoomDR is not null

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from bronze_live.tc_ct_hospital limit 2
