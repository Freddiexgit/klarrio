# Databricks notebook source


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 06-Mar-2024 | 1       | Donne Medley     | Create first draft of permanent view vw_cds_health_specialty_code                                         |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

spark.sql(f"""DROP VIEW silver_live.vw_cds_health_specialty_code""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_health_specialty_code
AS
SELECT 
(SELECT MAX(processing_time) FROM bronze_live.tc_ct_healthspecialtycodes) AS watermark_value
,HSC_RowId AS uid
,HSC_RowId AS health_specialty_id
,HSC_Code AS health_specialty_code
,HSC_Desc AS health_specialty_desc
,source_file
,processing_time
FROM 
bronze_live.tc_ct_healthspecialtycodes
""")
