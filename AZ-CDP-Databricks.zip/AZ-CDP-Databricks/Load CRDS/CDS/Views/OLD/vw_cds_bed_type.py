# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 06-Mar-2024 | 1       | Donne Medley     | Create first draft of permanent view vw_cds_bed_type                                       |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

spark.sql(f"""DROP VIEW silver_live.vw_cds_bed_type""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_bed_type
AS
SELECT 
(SELECT MAX(processing_time) FROM bronze_live.tc_pac_bedtype) AS watermark_value
,BEDTP_RowId AS uid
,BEDTP_RowId AS bed_type_id
,BEDTP_Code AS bed_type_code
,BEDTP_Desc AS bed_type_desc
,source_file
,processing_time
FROM 
bronze_live.tc_pac_bedtype
""")
