# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 06-Mar-2024 | 1       | Donne Medley     | Create first draft of permanent view vw_cds_care_provider                                           |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

spark.sql(f"""DROP VIEW silver_live.vw_cds_care_provider""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_care_provider
AS
SELECT 
(SELECT MAX(processing_time) FROM bronze_live.tc_ct_careprov) AS watermark_value
,CTPCP_RowId1 AS uid
,CTPCP_RowId1 AS care_provider_id
,CTPCP_Code AS care_provider_code
,CTPCP_Desc AS care_provider_desc
,CTPCP_CarPrvTp_DR
,CTPCP_Surgeon AS surgeon
,CTPCP_Anaesthetist AS anaesthetist
,source_file
,processing_time
FROM 
bronze_live.tc_ct_careprov
""")
