# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 07-May-2024 | 1       | Siddharth Saravanan     | Create first draft of permanent view vw_cds_vrm_tbl_for_scorecardwards                               |
# MAGIC

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_vrm_tbl_for_scorecardwards""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_vrm_tbl_for_scorecardwards
AS
(
SELECT
(SELECT MAX(processing_time) FROM bronze_live.vrm_tbl_for_scorecardwards) AS watermark_value
,ID as UID
,WardID
,ScorecardKey
,ID
,processing_time
FROM 
bronze_live.vrm_tbl_for_scorecardwards SCW
)
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from silver_live.vw_cds_vrm_tbl_for_scorecardwards
