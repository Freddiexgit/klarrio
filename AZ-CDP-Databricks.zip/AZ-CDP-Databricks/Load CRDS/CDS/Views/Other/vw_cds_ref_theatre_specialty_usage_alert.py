# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 26-Jun-2024 | 1       | Donne Medley    | Create first draft of permanent view vw_cds_ref_theatre_specialty_usage_alert  |                                      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_ref_theatre_specialty_usage_alert""")
# spark.sql(f"""DROP TABLE bronze_live.bis_theatre_specialty_usage_alerts""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_ref_theatre_specialty_usage_alert
AS
  SELECT 
  (SELECT MAX(processing_time) FROM bronze_live.bis_theatre_specialty_usage_alerts) AS watermark_value
  ,CONCAT(Specialty,'_',SessionType,'_',WeekNumber) AS UID
  ,Specialty
  ,SessionType AS Session_Type
  ,WeekNumber AS Week_Number
  ,Target
  ,RedMax AS Red_Max
  ,OrangeMax AS Orange_Max
  ,GreenMax AS Green_Max
  ,source_file
  ,processing_time
  FROM 
  bronze_live.bis_theatre_specialty_usage_alerts
""")

# COMMAND ----------

# MAGIC %sql select * from silver_live.vw_cds_ref_theatre_specialty_usage_alert
