# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 26-Jun-2024 | 1       | Donne Medley    | Create first draft of permanent view vw_cds_ref_outpatient_community_service  |                                      |
# MAGIC | 03-Jul-2024 | 2       | Donne Medley     | Updated for Release 12.                    |
# MAGIC | 10-Jul-2024 | 3       | Donne Medley     | Updated for Release 13. Renamed from ref_outpatient_community_service to ref_outpatient_appointment                    |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_ref_outpatient_appointment""")
# spark.sql(f"""DROP TABLE bronze_live.titan_outpatient_appointment""")
# spark.sql(f"""DROP TABLE bronze_live.bis_pharmacy_patient_score""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_ref_outpatient_appointment
AS
SELECT DISTINCT
(SELECT MAX(processing_time) FROM bronze_live.titan_outpatient_appointment) AS watermark_value
,CONCAT(NHI,'_',Appointment_Date,'_',Appointment_Time) AS UID
,NHI AS Patient_NHI
,Appointment_Date 
,Appointment_Time
,Appointment_Duration
,Appointment_Type
,Appointment_Desc
,Appointment_Clinician
,Appointment_Clinic
,Appointment_Location
,Appointment_Site
,Source_System
,Load_Date AS load_date
,source_file
,processing_time
FROM 
bronze_live.titan_outpatient_appointment
""")

# COMMAND ----------

# MAGIC %sql 
# MAGIC -- select uid, count(1) cnt from silver_live.vw_cds_ref_outpatient_appointment group by uid having count(1) > 1
# MAGIC select * from silver_live.vw_cds_ref_outpatient_appointment where uid = 'PXZ5969_08/08/2024_09:00:00'
