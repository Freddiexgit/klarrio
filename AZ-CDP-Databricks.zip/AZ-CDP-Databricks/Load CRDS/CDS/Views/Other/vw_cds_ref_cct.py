# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 09-May-2024 | 1       | Siddharth Saravanan    | Create first draft of permanent view vw_cds_bis_cct                                        |                                      |
# MAGIC | 09-May-2024 | 1       | Siddharth Saravanan    | changed name to ww_cds_ref_cct                                         |                                      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_bis_cct""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_ref_cct
AS
SELECT DISTINCT
(SELECT MAX(processing_time) FROM bronze_live.bis_cct) AS watermark_value
,Code AS UID
,CCT_ID
,Name
,ID
,Code
,Description
,SourceSystem
,source_file
,processing_time
FROM bronze_live.bis_cct
""")
