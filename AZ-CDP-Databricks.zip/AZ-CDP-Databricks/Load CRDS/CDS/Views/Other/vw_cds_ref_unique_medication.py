# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 26-Jun-2024 | 1       | Donne Medley    | Create first draft of permanent view vw_cds_ref_unique_medication  |                                      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_ref_unique_medication""")
# spark.sql(f"""DROP TABLE bronze_live.ecl_unique_meds""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_ref_unique_medication
AS
SELECT 
  (SELECT MAX(date_format(RunDate, 'yyyy-MM-dd HH:mm:ss')) FROM bronze_live.ecl_unique_meds) AS watermark_value
  ,NHI AS UID
  ,NHI AS Patient_NHI
  ,Meds_Count
  ,date_format(RunDate, 'yyyy-MM-dd HH:mm:ss') AS Run_Date
  ,Meds_Name 
  ,'' AS source_file
  ,date_format(RunDate, 'yyyy-MM-dd HH:mm:ss') AS processing_time
  FROM 
  bronze_live.ecl_unique_meds
""")
