# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 26-Jun-2024 | 1       | Donne Medley    | Create first draft of permanent view vw_cds_ref_pharmacy_patient_score  |                                      |
# MAGIC | 10-Jul-2024 | 2       | Donne Medley    | Create dummy table for Release 13.|                                      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_ref_pharmacy_patient_score""")
# spark.sql(f"""DROP TABLE bronze_live.titan_pharmacy_patient_score""")

# COMMAND ----------

# spark.sql(f"""
# CREATE OR REPLACE VIEW silver_live.vw_cds_ref_pharmacy_patient_score
# AS
# SELECT 
#   --(SELECT MAX(processing_time) FROM bronze_live.bis_pharmacy_patient_score) AS watermark_value
#   '1900-01-01 01:01:01' AS watermark_value
#   ,'XXX0001' AS UID
#   ,'XXX0001' AS Patient_NHI
#   ,1 AS Total_Score
#   ,2 AS PHS_Score
#   ,3 AS ED_Score
#   ,4 AS Past_Clinical_Score
#   ,'dummy data' AS source_file
#   ,current_timestamp() AS processing_time
#   --FROM 
#   --bronze_live.bis_pharmacy_patient_score
# """)

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_ref_pharmacy_patient_score
AS
WITH EthnicityScore AS
    (
    SELECT
    pt.Patient_NHI AS NHI 
    ,CASE 
        WHEN pt.Patient_Age_Year >= 65 OR (pt.Patient_Age_Year BETWEEN 55 AND 64 AND eth.Rank BETWEEN 2 and 9) THEN 10
        WHEN pt.Patient_Age_Year < 55 AND eth.Rank BETWEEN 2 and 9 THEN 2
        ELSE 0
        END AS Ethnicity_Score
    FROM 
    silver_live.cds_patient pt
    LEFT JOIN silver_live.cds_ref_patient_ethnicity eth ON pt.Patient_ID = eth.Patient_ID 
        AND eth.Priority=1
    LEFT JOIN silver_live.cds_admission ad ON ad.Patient_ID = pt.Patient_ID
    WHERE
    ad.Admission_Type_Code IN ('I', 'E')
    AND ad.Actual_Discharge_DateTime IS NULL
    AND ad.Visit_Status_Code IN ('A', 'P')
    )
,ClinicalScore AS
    (
    SELECT 
    ps.NHI
    ,SUM(cs.Score) AS Clinical_Score
    FROM 
    bronze_live.titan_pharmacy_patient_score ps
    INNER JOIN silver_live.cds_ref_pharmacy_clinical_score cs ON ps.Diag_Code LIKE CONCAT('%',cs.Value,'%')
    GROUP BY 
    ps.NHI
    )

SELECT DISTINCT
(SELECT MAX(processing_time) FROM bronze_live.titan_pharmacy_patient_score) AS watermark_value
,ps.NHI AS UID
,ps.NHI AS Patient_NHI
,IFNULL(es.Ethnicity_Score, 0) + IFNULL(ps.PHS_Score, 0) + IFNULL(ps.ED_Score, 0) + IFNULL(cs.Clinical_Score, 0) AS Total_Score
,IFNULL(es.Ethnicity_Score, 0) AS Ethnicity_Score
,IFNULL(ps.PHS_Score, 0) AS PHS_Score
,IFNULL(ps.ED_Score, 0) AS ED_Score
,IFNULL(cs.Clinical_Score, 0) AS Clinical_Score
,ps.source_file
,ps.processing_time
FROM 
bronze_live.titan_pharmacy_patient_score ps
LEFT JOIN EthnicityScore es ON ps.NHI=es.NHI
LEFT JOIN ClinicalScore cs ON ps.NHI=cs.NHI
WHERE
ps.NHI IS NOT NULL

""")
