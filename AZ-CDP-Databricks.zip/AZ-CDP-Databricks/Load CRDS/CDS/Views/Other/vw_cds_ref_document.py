# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 19-Jun-2024 | 1       | Donne Medley    | Create first draft of permanent view vw_cds_ref_document  |                                      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_ref_document""")
# spark.sql(f"""DROP TABLE bronze_live.smt_document""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_ref_document
AS
 WITH cte AS
  (
  SELECT DISTINCT
  (SELECT MAX(processing_time) FROM bronze_live.smt_document) AS watermark_value
  ,ExtEventId AS Ext_Event_Id
  ,PatientID AS Patient_NHI
  ,TemplateCode AS Template_Code
  ,DATEADD(MINUTE, CreateDateTimeOffset,date_format(CreateDateTime,'yyyy-MM-dd HH:mm:ss')) AS Create_Datetime
  ,ROW_NUMBER() OVER (PARTITION BY ExtEventId ORDER BY DATEADD(MINUTE, CreateDateTimeOffset,date_format(CreateDateTime,'yyyy-MM-dd HH:mm:ss')) DESC ) AS Row_Number  
  ,source_file
  ,processing_time
  FROM 
  bronze_live.smt_document
  WHERE 
  TemplateCode = '1MRF'
  AND status = 'Final'
  AND inActive = 'N'
  )
SELECT
watermark_value
,CONCAT(Ext_Event_Id,'_',Row_Number) AS UID
,Ext_Event_Id
,Patient_NHI
,Template_Code
,Create_Datetime
,Row_Number
,source_file
,processing_time
FROM cte
  """)
