# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 16-May-2024 | 1       | Donne Medley     | Create first draft of permanent view vw_cds_date                    |
# MAGIC

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW silver_live.vw_cds_dates""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW silver_live.vw_cds_date
AS
WITH dates AS 
(
SELECT explode(sequence(add_months(to_date('{current_datetime_nz}'),-36),add_months(to_date('{current_datetime_nz}'),36))) AS  date 
)

SELECT
date_format(a.date,'yyyyMMdd') AS uid,
date_format(a.date,'yyyyMMdd') AS date_key,
a.date AS date,
date_format(DATEADD(day,1,a.date),'yyyy-MM-dd') AS date_next,
date_format(a.date,'dd-MM-yyyy') AS dd_mm_yyyy,
date_format(a.date,'MM-dd-yyyy') AS mm_dd_yyyy,
date_format(a.date,'yyyy-dd-MM') AS yyyy_dd_mm,
date_part('YEAR',a.date) AS year,
date_part('MONTH',a.date) AS month,
date_part('DAY',a.date) AS day,
date_format(a.date,'EEE') AS day_of_week_str,
dayofweek(a.date) AS day_of_week,
dayofmonth(a.date) AS day_of_month,
dayofyear(a.date) AS day_of_year,
datediff(a.date,to_date('{current_datetime_nz}')) day_diff, --use NZ datetime
date_add(to_date('1900-01-01'),INT(ROUND(DATEDIFF(a.date-3,to_date('1900-01-01'))/7,0)*7)) AS week_start_mon,
date_add(to_date('1900-01-01'),INT(ROUND(DATEDIFF(a.date-3,to_date('1900-01-01'))/7,0)*7+6)) AS week_end_mon,
CASE 
  WHEN a.date = to_date('{current_datetime_nz}') THEN 1 
  ELSE 0
  END AS current_day,
CASE 
  WHEN a.date BETWEEN date_add(to_date('1900-01-01'),INT(ROUND(DATEDIFF(to_date('{current_datetime_nz}')-3,to_date('1900-01-01'))/7,0)*7)) AND date_add(to_date('1900-01-01'),INT(ROUND(DATEDIFF(to_date('{current_datetime_nz}')-3,to_date('1900-01-01'))/7,0)*7+6)) THEN 1 
  ELSE 0 
  END AS current_week,
CASE
  WHEN date_part('YEAR',a.date) = date_part('YEAR',to_date('{current_datetime_nz}'))
    AND date_part('MONTH',a.date) = date_part('MONTH',to_date('{current_datetime_nz}'))
  THEN 1
  ELSE 0
  END AS current_month,
CASE
  WHEN date_part('YEAR',a.date) = date_part('YEAR',to_date('{current_datetime_nz}')) THEN 1
  ELSE 0
  END AS current_year,
--to_timestamp('{current_datetime_nz}') AS watermark_value,
date_format('{current_datetime_nz}', 'yyyy-MM-dd HH:mm:ss') AS watermark_value,
date_format('{current_datetime_nz}', 'yyyy-MM-dd HH:mm:ss') AS processing_time,
'' AS source_file
FROM
dates as a
ORDER BY
date
""")	

# COMMAND ----------

# MAGIC %sql select * from silver_live.vw_cds_date 

# COMMAND ----------

# MAGIC %sql
# MAGIC --drop view silver_live.vw_cds_date 

# COMMAND ----------


