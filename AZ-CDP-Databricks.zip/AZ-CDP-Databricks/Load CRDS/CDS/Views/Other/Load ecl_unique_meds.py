# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 25-Jun-2024 | 1       | Siddharth Saravanan   | Create first draft of permanent view vw_cds_ecl_unique_meds  |                                      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

file_path = f"{bronze_folder_path}/Sid/ecl_unique_meds.csv"

# COMMAND ----------

schema = StructType([
    StructField("NHI", StringType(), True),
    StructField("Meds_Count", IntegerType(), True),
    StructField("Meds_Name", StringType(), True),
    StructField("RunDate", TimestampType(), True)
])

# COMMAND ----------

df = spark.read.format("csv").option("header", "false").schema(schema).load(file_path)


# COMMAND ----------

df.display()

# COMMAND ----------

table_name = "bronze_live.ecl_unique_meds"
df.write.mode("overwrite").saveAsTable(table_name) 
