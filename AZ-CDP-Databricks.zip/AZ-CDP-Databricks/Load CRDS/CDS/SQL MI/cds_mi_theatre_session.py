# Databricks notebook source
# MAGIC %md
# MAGIC ###Notebook to merge data into Ref Room table in Azure SQL MI database DA_CRDS

# COMMAND ----------

# MAGIC %md
# MAGIC ####Import libraries

# COMMAND ----------

import pandas as pd
import datetime
import pytz
import pyodbc
from pyspark.sql.window import Window
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import SparkSession

# COMMAND ----------

# MAGIC %md
# MAGIC ####Call Utilities notebook

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# %run "../../Utilities/utils"

# COMMAND ----------

# MAGIC %md
# MAGIC ####Get variables

# COMMAND ----------

# DBTITLE 1,Variables
# p_etlcontrolid can be passed as a parameter from ADF
dbutils.widgets.text("p_batchid","0")
v_batchid = int(dbutils.widgets.get("p_batchid"))
dbutils.widgets.text("p_etlcontrolid","2287")
v_etlcontrolid = dbutils.widgets.get("p_etlcontrolid")

# COMMAND ----------

# Create variables from etl.Control_CDS table
# WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
qry = f"""
       SELECT 
              ETLControlID
            , SourceSystem
            , SourceSystemType
            , SourceEntityPath
            , SourceTableSchemaName
            , SourceTableName
            , CASE WHEN IncrementalLoad = 1 THEN WaterMarkValue ELSE '1900-01-01' END WaterMarkValue
            , TargetSystemType
            , TargetEntityPath
            , TargetTableSchemaName
            , TargetTableName
            , IncrementalLoad
            , IsActive
            , CustomConfig
            , StoredProcName
            , SourceQuery
        FROM ADM_CONFIG.etl.Control_CDS 
        WHERE ETLControlID = {v_etlcontrolid}"""

df_control = read_from_mi_db('ADM_CONFIG', qry)

v_watermark_date = df_control.select("WaterMarkValue").collect()[0][0]
v_incremental_load = df_control.select("IncrementalLoad").collect()[0][0]
v_source_system = df_control.select("SourceSystem").collect()[0][0]
v_source_database = df_control.select("SourceEntityPath").collect()[0][0]
v_source_table_name = df_control.select("SourceTableName").collect()[0][0]
v_source_table_schema = df_control.select("SourceTableSchemaName").collect()[0][0]
v_target_table_name = df_control.select("TargetTableName").collect()[0][0]
v_target_table_schema = df_control.select("TargetTableSchemaName").collect()[0][0]
v_target_database = df_control.select("TargetEntityPath").collect()[0][0]
v_stored_proc = df_control.select("StoredProcName").collect()[0][0]
v_merge_column = df_control.select("CustomConfig").collect()[0][0]
v_source_query = df_control.select("SourceQuery").collect()[0][0]
v_source_view = f'{v_source_table_schema}.{v_source_table_name}'
v_target_table = f'{v_target_table_schema}.{v_target_table_name}'

# COMMAND ----------

# Create new watermark variable from SQLMI RDS (via view)
qry = f"""
       SELECT 
       MAX(processing_time) AS watermark
       FROM 
       {v_source_view}"""

df_control = read_from_mi_db(v_source_database, qry)
v_new_watermark_value = df_control.select("watermark").collect()[0][0]

# COMMAND ----------

# MAGIC %md
# MAGIC ####Merge data from SQLMI RDS to SQLMI CDS

# COMMAND ----------

# Execute merge process
exec_sqlmi_merge(v_target_database, v_stored_proc, v_source_view, v_merge_column, v_target_table, v_watermark_date)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Update etl.Control watermark

# COMMAND ----------

# DBTITLE 0,Update WaterMarkValue
# update the etl.Control table WaterMarkValue with the latest processing date from the RDS table
# if the old and the new watermark dates have different values
from datetime import datetime
if v_watermark_date != datetime.strptime(v_new_watermark_value, '%Y-%m-%d %H:%M:%S') : 
    update_mi_water_mark_value (v_new_watermark_value, v_etlcontrolid,'Control_CDS')
