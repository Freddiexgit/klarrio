# Databricks notebook source
# MAGIC %md
# MAGIC #### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 04-Mar-2024 | 1      | Donne    | First draft of delta table version of Ref Procedure                 |

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# DBTITLE 1,Reset
# Use the function below if you need to reset the development and start from scratch.  
# reset_table('silver_live', 'trakcare_live/CDS', 'cds_ref_procedure', 2204)

# COMMAND ----------

# DBTITLE 1,Assign etl.Control variables
# p_etlcontrolid is passed as a parameter from ADF
dbutils.widgets.text("p_batchid","0")
v_batchid = int(dbutils.widgets.get("p_batchid"))

dbutils.widgets.text("p_etlcontrolid","2204")   
v_etlcontrolid = dbutils.widgets.get("p_etlcontrolid")

# COMMAND ----------

# DBTITLE 1,Look up other etl.Control variables
# Create variables from etl.Control table
# WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
qry = f"""
       SELECT 
              ETLControlID
            , SourceSystem
            , SourceSystemType
            , SourceTableSchemaName
            , SourceTableName
            , CASE WHEN IncrementalLoad = 1 THEN WaterMarkValue ELSE '1900-01-01' END WaterMarkValue
            , TargetSystemType
            , TargetTableSchemaName
            , TargetTableName
            , IncrementalLoad
            , IsActive
            , TargetEntityPath
            , CustomConfig
        FROM ADM_CONFIG.etl.Control 
        WHERE ETLControlID = {v_etlcontrolid}"""

df_control = read_from_mi_db('ADM_CONFIG', qry)

v_watermark_date = df_control.select("WaterMarkValue").collect()[0][0]
v_incremental_load = df_control.select("IncrementalLoad").collect()[0][0]
v_source_database = df_control.select("SourceTableSchemaName").collect()[0][0]
v_source_table_name = df_control.select("SourceTableName").collect()[0][0]
v_target_table_name = df_control.select("TargetTableName").collect()[0][0]
v_target_database = df_control.select("TargetTableSchemaName").collect()[0][0]
v_merge_column = df_control.select("CustomConfig").collect()[0][0]
v_source_view = f'{v_source_database}.{v_source_table_name}'

# COMMAND ----------

# MAGIC %md
# MAGIC ### Processing

# COMMAND ----------

# DBTITLE 1,Create data frame
# this is a dataframe containing source view data with a processing_time greater than the last watermark value
df_view = spark.sql(f"SELECT * FROM {v_source_view} WHERE processing_time > '{v_watermark_date}'")

# COMMAND ----------

# DBTITLE 1,Merge
# set the merge condition required for the merge functions
merge_condition = 'TARGET.uid = SOURCE.uid'

# merge the data
merge_delta_tables(df_hashed, v_target_database, v_target_table_name, merge_condition)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Post-processing

# COMMAND ----------

# DBTITLE 1,Set new WaterMarkValue
# New WaterMarkValue is the latest processing date from RDS table. 
v_new_watermark_value = spark.sql(f"""SELECT DISTINCT watermark_value AS v_new_watermark_value FROM {v_source_view}""")

# COMMAND ----------

# DBTITLE 1,Update etl.Control WaterMarkValue
# update the etl.Control table WaterMarkValue with the latest processing date from the RDS joining tables
# if the old and the new watermark dates have different values
if v_watermark_date != v_new_watermark_value :
    update_mi_water_mark_value (v_new_watermark_value.select('v_new_watermark_value').collect()[0][0], v_etlcontrolid)
