# Databricks notebook source
# MAGIC %md
# MAGIC #### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 6-Apr-2024 | 1      | Siddharth Saravanan    | First draft of CDS Child notebook                 |
# MAGIC
# MAGIC

# COMMAND ----------

import pandas as pd
import datetime
import pytz
import pyodbc
from pyspark.sql.window import Window
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import SparkSession

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# %run "/Workspace/Repos/donnem_ext@hanz.health.nz/AZ-CDP-Databricks/Load RDS/Trakcare/IntersystemUtils"

# COMMAND ----------

# MAGIC %run "/Shared/Load RDS/Trakcare/IntersystemUtils"

# COMMAND ----------

# DBTITLE 1,Reset
# Use the function below if you need to reset the development and start from scratch.  
# reset_table('silver_live', 'trakcare_live/CDS', 'cds_admission', 2193)

# COMMAND ----------

dbutils.widgets.text("etlControlID", "","")

# COMMAND ----------

etlControlID=dbutils.widgets.get("etlControlID")
print(etlControlID)

# COMMAND ----------

# DBTITLE 1,Look up other etl.Control variables
# Create variables from etl.Control table
# WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
qry = f"""
       SELECT 
              ETLControlID
            , SourceSystem
            , SourceSystemType
            , SourceEntityPath
            , SourceTableSchemaName
            , SourceTableName
            , SourceQuery
            , CASE WHEN IncrementalLoad = 1 THEN WaterMarkValue ELSE '1900-01-01' END WaterMarkValue
            , TargetSystemType
            , TargetTableSchemaName
            , TargetTableName
            , StoredProcName
            , IncrementalLoad
            , IsActive
            , TargetEntityPath
            , CustomConfig
        FROM ADM_CONFIG.etl.Control_CDS 
        WHERE ETLControlID = {etlControlID}"""

df_control = read_from_mi_db('ADM_CONFIG', qry)

v_watermark_date = df_control.select("WaterMarkValue").collect()[0][0]
v_incremental_load = df_control.select("IncrementalLoad").collect()[0][0]

v_source_system = df_control.select("SourceSystem").collect()[0][0]
v_source_database = df_control.select("SourceEntityPath").collect()[0][0]
v_source_table_name = df_control.select("SourceTableName").collect()[0][0]
v_source_table_schema = df_control.select("SourceTableSchemaName").collect()[0][0]

v_target_system_type = df_control.select("TargetSystemType").collect()[0][0]
v_target_table_name = df_control.select("TargetTableName").collect()[0][0]
v_target_table_schema = df_control.select("TargetTableSchemaName").collect()[0][0]
v_target_mi_database = df_control.select("TargetEntityPath").collect()[0][0]

v_stored_proc = df_control.select("StoredProcName").collect()[0][0]
v_merge_column = df_control.select("CustomConfig").collect()[0][0]
v_source_query = df_control.select("SourceQuery").collect()[0][0]

v_source_view = f'{v_source_table_schema}.{v_source_table_name}'
v_source_mi_view = f'{v_source_database}.{v_source_table_schema}.{v_source_table_name}'
v_target_table = f'{v_target_table_schema}.{v_target_table_name}'

# COMMAND ----------

print(qry)

# COMMAND ----------

print(v_watermark_date)

# COMMAND ----------

print(v_target_system_type)

# COMMAND ----------

if v_target_system_type == "ADLS":
    print(f"Get Max WaterMarkValue Start Time: {datetime_nz1()}")
    v_new_watermark = (
        spark.sql(
            f"SELECT max(watermark_value) AS v_new_watermark_value FROM {v_source_view}"
        )
        .select("v_new_watermark_value")
        .collect()[0][0]
    )

    if v_new_watermark is None:
        dbutils.notebook.exit("Watermark value is empty in bronze table")
    else:
        print(v_new_watermark)
    print(f"Get Max WaterMarkValue End Time: {datetime_nz1()}")

# COMMAND ----------

if v_target_system_type == "ADLS":
    print('Running ADLS')
    print(f"Running ADLS Start Time: {datetime_nz1()}")
    if v_watermark_date >= v_new_watermark:
        print(f"Update Watermark Start Time: {datetime_nz1()}")
        print('Do not run the query')
        run_query = False
        print('Updating the watermark value to current runtime')
        watermark_toUpdate = datetime_nz1()
        update_mi_water_mark_value (watermark_toUpdate, etlControlID,'Control_CDS')
        print('watermark updated')
        print(watermark_toUpdate)
        print(f"Update Watermark End Time: {datetime_nz1()}")
        dbutils.notebook.exit("Processing complete")


    else: 
        print('Run the query')
        print(f"Update Watermark Start Time: {datetime_nz1()}")
        run_query = True
        print(run_query)
        if run_query == True:
            print('Getting the delta records')
            df_view = spark.sql(f"SELECT * FROM {v_source_view} WHERE processing_time > '{v_watermark_date}'")
            # set the merge condition required for the merge functions
            merge_condition = 'TARGET.uid = SOURCE.uid'

            # merge the data from df_hashed to target delta table
            print(etlControlID)
            print('TargetDatabase')
            print(v_target_table_schema)
            print('TargetTableName')
            print(v_target_table_name)
            rint('merge_condition')
            print(merge_condition)
            print(df_view)
            merge_delta_tables(df_view, v_target_table_schema, v_target_table_name, merge_condition)
            print('Data merged to the target table')

            #Updating Watermark value
            print('value to update to watermark after running the query')
            watermark_toUpdate = datetime_nz1()
            print(watermark_toUpdate)
            update_mi_water_mark_value (watermark_toUpdate, etlControlID,'Control_CDS')
            print('watermark updated')
        print(f"Update Watermark End Time: {datetime_nz1()}")
    print(f"Running ADLS End Time: {datetime_nz1()}")

elif v_target_system_type == "SQLMI":

    print('Running SQL MI')
    print(f"Running SQL MI Start Time: {datetime_nz1()}")
    # Create new watermark variable from SQLMI RDS (via view)
    qry = f"""
       SELECT 
       MAX(processing_time) AS watermark
       FROM 
       {v_source_mi_view}"""
    print(f"Read from SQL MI Start Time: {datetime_nz1()}")
    df_control = read_from_mi_db(v_source_database, qry)
    v_new_watermark_value = df_control.select("watermark").collect()[0][0]
    print('date loaded')
    print(v_new_watermark_value)
    print(qry)
    print(f"Read from SQL MI End Time: {datetime_nz1()}")

    print(f"Execute Merge Start Time: {datetime_nz1()}")
    # Execute merge process
    # print(v_target_database, v_stored_proc, v_source_mi_view, v_merge_column, v_target_table, v_watermark_date)
    exec_sqlmi_merge(v_target_mi_database, v_stored_proc, v_source_mi_view, v_merge_column, v_target_table, v_watermark_date)
    print('load complete')
    print(f"Execute Merge End Time: {datetime_nz1()}")

    #Updating Watermark value
    print(f"Update WaterMark Start Time: {datetime_nz1()}")
    print('value to update to watermark after running the query')
    watermark_toUpdate = datetime_nz1()
    print(watermark_toUpdate)
    update_mi_water_mark_value (watermark_toUpdate, etlControlID,'Control_CDS')
    print('watermark updated')
    print(f"Update WaterMark End Time: {datetime_nz1()}")
  
    print(f"Running SQL MI End Time: {datetime_nz1()}")

# COMMAND ----------


