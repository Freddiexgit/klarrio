# Databricks notebook source
# MAGIC %md
# MAGIC #### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 02-May-2024 | 1      | Siddharth Saravanan    | First draft               |
# MAGIC

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

dbutils.widgets.dropdown("Database", "bronze_live", ["silver_live", "bronze_live"])
v_database = dbutils.widgets.get("Database")

dbutils.widgets.dropdown("Folder", "bronze", ["bronze", "landing","silver"])
v_folder = dbutils.widgets.get("Folder")

if v_folder == "bronze":
    v_folder_path = 'trakcare_live/'
elif v_folder == "landing":
    v_folder_path = 'trakcare_live/Archive/'
elif v_folder == "silver":
    v_folder_path = 'trakcare_live/silver'

v_control_table='Control_CDS'

# COMMAND ----------

print(v_folder)

# COMMAND ----------

print(v_folder_path)

# COMMAND ----------

def folder_remove(dbr_database , v_sourcesystem , v_table_name):
    import os
    try:
        
        # if v_folder == "landing":
        #     folder_path_full = f"{landing_folder_path}{v_sourcesystem}/{v_table_name}/"
        # elif v_folder_path == "bronze":
        #     folder_path_full = f"{bronze_folder_path}{v_sourcesystem}/{v_table_name}/"
        # else:
        #     folder_path_full = f"{silver_folder_path}{v_sourcesystem}/{v_table_name}/"

        folder_path_full = f"{landing_folder_path}{v_sourcesystem}/{v_table_name}/"
        print(folder_path_full)

        # if the folder exists
        # Check if the folder exists
        folder_exists = False

        folder_exists = os.path.exists(f"/dbfs{folder_path_full}")

        print(folder_exists)
        folder_exists = file_exists(f"{folder_path_full}")
        print(folder_path_full)
        print(folder_exists)

        if folder_exists:
            print(f"{v_table_name} - folder exists")
            paths = get_file_content(f"{folder_path_full}")
            print(paths)

            file_remove(paths)

            subfolders_remove(paths)

            # print("Files in main folder removed")
            dbutils.fs.rm(f"{folder_path_full}",  True)
            print(f"{v_table_name} - Main folder removed ")
        else:
            print(f"{v_table_name} - folder does not exist")

    except ValueError as err:
        print(err)
        exit()

# COMMAND ----------

def get_file_content(ls_path):
    try:
        dir_paths = dbutils.fs.ls(ls_path)
        subdir_paths = [get_file_content(p.path) for p in dir_paths if p.isDir() and p.path != ls_path]
        flat_subdir_paths = [p for subdir in subdir_paths for p in subdir]
        return list(map(lambda p: p.path, dir_paths)) + flat_subdir_paths
    except java.io.FileNotFoundException:
        # Handle the case where the directory does not exist
        print(f"Directory '{ls_path}' does not exist")
        return []

# COMMAND ----------

def file_remove(dir_content):
    files = []

    for i in dir_content:
        if i[len(i)-1:] != '/':
            files.append(i)

    if len(files) > 0:
        for i in files:
            # print(i)
            i_new = i.replace("dbfs:",'')
            # print(i_new)
            dbutils.fs.rm(i_new)
            # print(i_new)
        print(len(files), "file(s) deleted")
        print("Files in the folder removed")
    else: 
        print("No files to remove")

# COMMAND ----------

def subfolders_remove(dir_content):
    folders = []

    for i in dir_content:
        if i[len(i)-1:] == '/':
            folders.append(i)

    if len(folders) > 0:
        reverse_folders = sorted(folders, key=len, reverse=True)
        # print(reverse_folders)
        for f in reverse_folders:
            # print(f)
            f_new = f.replace("dbfs:",'')
            # print(f_new)
            dbutils.fs.rm(f_new)
            # print(f_new)
        print(len(folders), "sub-folder(s) deleted")
        print("All the Sub-folder removed")
    else:
        print("No sub-folders to remove")

# COMMAND ----------

def file_exists(path):
  try:
    dbutils.fs.ls(path)
    return True
  except Exception as e:
    if 'java.io.FileNotFoundException' in str(e):
      return False
    else:
      raise

# COMMAND ----------

# DBTITLE 1,Look up other etl.Control variables
# Create variables from etl.Control table
# WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
qry = f"""
       SELECT 
             SourceTableName
       
       FROM ADM_CONFIG.etl.Control_CDS 
       WHERE Token = 'RDS' """

df_control = read_from_mi_db('ADM_CONFIG', qry)

v_source_table_name = df_control.select("SourceTableName")



# COMMAND ----------

display(v_source_table_name)

# COMMAND ----------

for row in v_source_table_name.collect():
    # Extract the table name from the row
    table_name = row["SourceTableName"]
    print(table_name)
    folder_remove(v_database, v_folder_path, table_name) 

    

# COMMAND ----------

file_exists('/dbfs/mnt/devcdpadlsae1/silver/trakcare_live//tc_rbc_equipment/')

# COMMAND ----------


