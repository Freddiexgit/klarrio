# Databricks notebook source
# MAGIC %md
# MAGIC #### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 02-May-2024 | 1      | Siddharth Saravanan    | First draft               |
# MAGIC

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../../../Utilities/utils"

# COMMAND ----------

# %run /Shared/Utilities/utils

# COMMAND ----------

dbutils.widgets.dropdown("Database", "bronze_live", ["silver_live", "bronze_live"])
v_database = dbutils.widgets.get("Database")

dbutils.widgets.dropdown("All_Tables", "All", ["All","No"])
v_all_tables = dbutils.widgets.get("All_Tables")

dbutils.widgets.text("Table_Name", "")
v_table_name = dbutils.widgets.get("Table_Name")

# COMMAND ----------

# Create variables from etl.Control table
# WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
qry = f"""
       SELECT 
             TargetTableName
       
       FROM adm_config.Control_CDS 
       WHERE SourceTableName like 'tc_%' and Token = 'RDS' and IsActive = 1 """

df_control_dbr = spark.sql(qry)

v_source_table_name = df_control_dbr.select("TargetTableName")

# COMMAND ----------

# # Create variables from etl.Control table
# # WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
# qry = f"""
#        SELECT 
#              TargetTableName
       
#        FROM ADM_CONFIG.etl.Control_CDS 
#        WHERE SourceTableName like 'tc_%' and Token = 'RDS' and IsActive = 1 """

# df_control = read_from_mi_db('ADM_CONFIG', qry)

# v_source_table_name = df_control.select("TargetTableName")

# COMMAND ----------

# def remove_table(v_database, v_table_name):
#     try:
#         if spark.catalog.tableExists(f"{v_database}.{v_table_name}"):
#             spark.sql(f"DROP TABLE IF EXISTS {v_database}.{v_table_name}")
#             print(f"{v_table_name} Table dropped")
#         else:
#             print(f"{v_table_name} Table does not exist")
#     except Exception as e:
#         print(f"Error while dropping table {v_table_name}: {str(e)}")

# COMMAND ----------

def delete_table(v_database,v_table_name):
    spark.sql(f"DROP TABLE IF EXISTS {v_database}.{v_table_name}")
    print(f"{v_table_name} Table dropped")

# COMMAND ----------

display(v_source_table_name)

# COMMAND ----------

if v_all_tables == "All":
    for table in v_source_table_name.collect():
        table_name = table["TargetTableName"]
        # Perform operations with each value
        delete_table(v_database, table_name)
elif v_all_tables == "No":
    delete_table(v_database, v_table_name)

# COMMAND ----------

# spark.sql(f"""DROP TABLE bronze_live.tc_pac_refdoctor""")

# COMMAND ----------

# remove_table('bronze_live','tc_ct_careprov')  
