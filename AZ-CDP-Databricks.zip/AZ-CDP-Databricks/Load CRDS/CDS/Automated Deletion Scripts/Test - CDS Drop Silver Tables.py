# Databricks notebook source
# MAGIC %md
# MAGIC #### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 6-Apr-2024 | 1      | Siddharth Saravanan    | First draft of CDS Child notebook                 |
# MAGIC
# MAGIC

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# DBTITLE 1,Reset
# Use the function below if you need to reset the development and start from scratch.  
# reset_table('silver_live', 'trakcare_live/CDS', 'cds_admission', 2193)

# COMMAND ----------

dbutils.widgets.text("etlControlID", "","")

# COMMAND ----------

etlControlID=dbutils.widgets.get("etlControlID")
print(etlControlID)

# COMMAND ----------

# DBTITLE 1,Look up other etl.Control variables
# Create variables from etl.Control table
# WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
qry = f"""
       SELECT 
              ETLControlID
            , SourceSystem
            , SourceSystemType
            , SourceTableSchemaName
            , SourceTableName
            , CASE WHEN IncrementalLoad = 1 THEN WaterMarkValue ELSE '1900-01-01' END WaterMarkValue
            , TargetSystemType
            , TargetTableSchemaName
            , TargetTableName
            , IncrementalLoad
            , IsActive
            , TargetEntityPath
            , CustomConfig
        FROM ADM_CONFIG.etl.Control_CDS 
        WHERE ETLControlID = {etlControlID}"""

df_control = read_from_mi_db('ADM_CONFIG', qry)

v_watermark_date = df_control.select("WaterMarkValue").collect()[0][0]
v_incremental_load = df_control.select("IncrementalLoad").collect()[0][0]
v_source_database = df_control.select("SourceTableSchemaName").collect()[0][0]
v_source_table_name = df_control.select("SourceTableName").collect()[0][0]
v_target_table_name = df_control.select("TargetTableName").collect()[0][0]
v_target_database = df_control.select("TargetTableSchemaName").collect()[0][0]
v_merge_column = df_control.select("CustomConfig").collect()[0][0]
v_source_view = f'{v_source_database}.{v_source_table_name}'

# COMMAND ----------

# MAGIC %sql
# MAGIC Drop table silver_live.cds_admission;

# COMMAND ----------

# MAGIC %sql
# MAGIC Drop table silver_live.cds_bed_status;

# COMMAND ----------

# MAGIC %sql
# MAGIC Drop table silver_live.cds_diagnosis;

# COMMAND ----------

# MAGIC %sql
# MAGIC Drop table silver_live.cds_location;

# COMMAND ----------

# MAGIC %sql
# MAGIC Drop table silver_live.cds_medical_record;

# COMMAND ----------

# MAGIC %sql
# MAGIC Drop table silver_live.cds_movement;

# COMMAND ----------

# MAGIC %sql
# MAGIC Drop table silver_live.cds_patient;

# COMMAND ----------

# MAGIC %sql
# MAGIC Drop table silver_live.cds_procedure;

# COMMAND ----------

# MAGIC %sql
# MAGIC Drop table silver_live.cds_ref_bed;

# COMMAND ----------

# MAGIC %sql
# MAGIC Drop table silver_live.cds_ref_diagnosis;

# COMMAND ----------

# MAGIC %sql
# MAGIC Drop table silver_live.cds_ref_hospital;

# COMMAND ----------

# MAGIC %sql
# MAGIC Drop table silver_live.cds_ref_location;

# COMMAND ----------

# MAGIC %sql
# MAGIC Drop table silver_live.cds_ref_patient_ethnicity;

# COMMAND ----------

# MAGIC %sql
# MAGIC Drop table silver_live.cds_ref_procedure;

# COMMAND ----------


