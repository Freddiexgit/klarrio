# Databricks notebook source
# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# MAGIC %md
# MAGIC ### Reset trakcare
# MAGIC
# MAGIC 1. Clean the trakcare folder in the landing, bronze and silver container
# MAGIC 2. Drop the tc_ tables from the bronze and silver_db databases
# MAGIC 3. Reset the watermark value in the ADM_CONFIG.etl.Control table to 1900-01-01

# COMMAND ----------

def update_watermark(watermark,etlControlID):
    spark.sql(f"""
    UPDATE adm_config.control_cds
    SET WaterMarkValue = '{watermark}'
    WHERE ETLControlID = {etlControlID}
    """)

# COMMAND ----------

def datetime_nz():
    return pytz.utc.localize(datetime.datetime.utcnow()).astimezone(pytz.timezone("Pacific/Auckland")).strftime('%Y-%m-%d %H:%M:%S')

# COMMAND ----------

reset_folder(landing_folder_path, 'trakcare_live')

# COMMAND ----------

#display(landing_folder_path)

# COMMAND ----------

reset_folder(bronze_folder_path, 'trakcare_live')

# COMMAND ----------

#display(bronze_folder_path)

# COMMAND ----------

# DBTITLE 1,Reset SQL MI Control Table
qry = f"""
       SELECT 
              ETLControlID
            , SourceSystem
            , SourceSystemType
            , SourceTableSchemaName
            , SourceTableName
            , CASE WHEN IncrementalLoad = 1 THEN WaterMarkValue ELSE '1900-01-01' END WaterMarkValue
            , TargetSystemType
            , TargetTableSchemaName
            , TargetTableName
            , IncrementalLoad
            , IsActive
            , TargetEntityPath
            , Token
        FROM ADM_CONFIG.etl.Control_CDS 
        WHERE
        --SourceSystem = 'trakcare' and IsNull(Token,'') not in ('CDS', 'TRAK')
        Token in ('RDS','CDS_Delta') and IsActive = 1 
        """

df_control = read_from_mi_db('ADM_CONFIG', qry)

df_control_rds = df_control.select("ETLControlID",'TargetTableSchemaName' ,'TargetTableName').filter("Token = 'RDS'")
df_control_cds = df_control.select("ETLControlID",'TargetTableSchemaName' ,'TargetTableName').filter("Token = 'CDS_Delta'")
# display(df_control_bronze)
# display(df_control_silver)

for i in df_control_rds.collect():
    update_mi_water_mark_value ('1900-01-01 00:00:00', int(i["ETLControlID"]), 'Control_CDS')

for i in df_control_cds.collect():
    update_mi_water_mark_value ('1900-01-01 00:00:00', int(i["ETLControlID"]), 'Control_CDS')

# COMMAND ----------

# DBTITLE 1,Reset Databricks Control Table
# qry = f"""
#        SELECT 
#               ETLControlID
#             , SourceSystem
#             , SourceSystemType
#             , SourceTableSchemaName
#             , SourceTableName
#             , CASE WHEN IncrementalLoad = 1 THEN WaterMarkValue ELSE '1900-01-01' END WaterMarkValue
#             , TargetSystemType
#             , TargetTableSchemaName
#             , TargetTableName
#             , IncrementalLoad
#             , IsActive
#             , TargetEntityPath
#             , Token
#         FROM adm_config.control_cds 
#         WHERE
#         --SourceSystem = 'trakcare' and IsNull(Token,'') not in ('CDS', 'TRAK')
#         Token in ('RDS','CDS_Delta') and IsActive = 1 
#         """

# df_control = spark.sql(qry)

# df_control_rds = df_control.select("ETLControlID",'TargetTableSchemaName' ,'TargetTableName').filter("Token = 'RDS'")
# df_control_cds = df_control.select("ETLControlID",'TargetTableSchemaName' ,'TargetTableName').filter("Token = 'CDS_Delta'")
# # display(df_control_bronze)
# # display(df_control_silver)

# for i in df_control_rds.collect():
#     update_watermark('1900-01-01 00:00:00', int(i["ETLControlID"]))

# for i in df_control_cds.collect():
#     update_watermark('1900-01-01 00:00:00', int(i["ETLControlID"]))
