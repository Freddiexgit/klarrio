# Databricks notebook source
# MAGIC %md
# MAGIC #### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 6-Apr-2024 | 1      | Siddharth Saravanan    | First draft of CDS Child notebook                 |
# MAGIC
# MAGIC

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# DBTITLE 1,Reset
# Use the function below if you need to reset the development and start from scratch.  
# reset_table('silver_live', 'trakcare_live/CDS', 'cds_admission', 2193)

# COMMAND ----------

dbutils.widgets.text("etlControlID", "","")

# COMMAND ----------

etlControlID=dbutils.widgets.get("etlControlID")
print(etlControlID)

# COMMAND ----------

# MAGIC %sql
# MAGIC Drop table if exists bronze_live.trc_ward                        ;
# MAGIC Drop table if exists bronze_live.tc_pa_admtransaction            ;
# MAGIC Drop table if exists bronze_live.tc_ct_acuity                    ;
# MAGIC Drop table if exists bronze_live.tc_ct_careprov                  ;
# MAGIC Drop table if exists bronze_live.tc_ct_disposit                  ;
# MAGIC Drop table if exists bronze_live.tc_ct_hospital                  ;
# MAGIC Drop table if exists bronze_live.tc_ct_loc                       ;
# MAGIC Drop table if exists bronze_live.tc_ct_lochealthspeccode         ;
# MAGIC Drop table if exists bronze_live.tc_ct_responsibleunit           ;
# MAGIC Drop table if exists bronze_live.tc_ct_sex                       ;
# MAGIC Drop table if exists bronze_live.tc_mr_adm                       ;
# MAGIC Drop table if exists bronze_live.tc_mr_diagnos                   ;
# MAGIC Drop table if exists bronze_live.tc_mrc_icddx                    ;
# MAGIC Drop table if exists bronze_live.tc_mrc_icdedition               ;
# MAGIC Drop table if exists bronze_live.tc_pac_refdoctor                ;
# MAGIC Drop table if exists bronze_live.tc_ct_healthspecialtycodes      ;
# MAGIC Drop table if exists bronze_live.tc_pa_adm                       ;
# MAGIC Drop table if exists bronze_live.tc_orc_anaestmethod             ;
# MAGIC Drop table if exists bronze_live.tc_or_anaest_operation          ;
# MAGIC Drop table if exists bronze_live.tc_orc_operation                ;
# MAGIC Drop table if exists bronze_live.tc_or_an_oper_secondaryproc     ;
# MAGIC Drop table if exists bronze_live.tc_orc_asa_classphactiv         ;
# MAGIC Drop table if exists bronze_live.tc_orc_reasonforsuspend         ;
# MAGIC Drop table if exists bronze_live.tc_pa_patmas                    ;
# MAGIC Drop table if exists bronze_live.tc_pa_personethnicity           ;
# MAGIC Drop table if exists bronze_live.tc_pac_admcategory              ;
# MAGIC Drop table if exists bronze_live.tc_pac_bed                      ;
# MAGIC Drop table if exists bronze_live.tc_pac_billingmethod            ;
# MAGIC Drop table if exists bronze_live.tc_pac_dischclassification      ;
# MAGIC Drop table if exists bronze_live.tc_pac_ethnicity                ;
# MAGIC Drop table if exists bronze_live.tc_pac_inpatdmissiontype        ;
# MAGIC Drop table if exists bronze_live.tc_pac_refdoctorclinic          ;
# MAGIC Drop table if exists bronze_live.tc_pac_room                     ;
# MAGIC Drop table if exists bronze_live.tc_pac_roomtype                 ;
# MAGIC Drop table if exists bronze_live.tc_pac_transferdestination      ;
# MAGIC Drop table if exists bronze_live.tc_pac_transfermeans            ;
# MAGIC Drop table if exists bronze_live.tc_pac_transfrequeststatus      ;
# MAGIC Drop table if exists bronze_live.tc_pac_ward                     ;
# MAGIC Drop table if exists bronze_live.tc_pac_wardroom                 ;
# MAGIC Drop table if exists bronze_live.tc_rb_reseffdate                ;
# MAGIC Drop table if exists bronze_live.tc_rb_reseffdatesession         ;
# MAGIC Drop table if exists bronze_live.tc_rb_reseffdatesessotspec      ;
# MAGIC Drop table if exists bronze_live.tc_rb_resource                  ;
# MAGIC Drop table if exists bronze_live.tc_rbc_equipment                ;
# MAGIC Drop table if exists bronze_live.tc_websys_standardtypeitem      ;
# MAGIC Drop table if exists bronze_live.tc_rb_appointment               ;
# MAGIC Drop table if exists bronze_live.vrm_tbl_tran_scorecard          ;
# MAGIC Drop table if exists bronze_live.tc_rb_operatingroom             ;
# MAGIC Drop table if exists bronze_live.tc_or_anaesthesia               ;
# MAGIC Drop table if exists bronze_live.tc_pac_bedstatus                ;
# MAGIC Drop table if exists bronze_live.tc_pac_bedtype                  ;
# MAGIC Drop table if exists bronze_live.tc_rb_apptschedule              ;
# MAGIC Drop table if exists bronze_live.tc_ct_locapprovedbeds           ;
# MAGIC Drop table if exists bronze_live.tc_pac_bedstatuschange          ;
# MAGIC Drop table if exists bronze_live.tc_pac_transtype                ;
# MAGIC Drop table if exists bronze_live.vrm_tbl_for_scorecardwards      ;
# MAGIC Drop table if exists bronze_live.tc_pa_person                    ;
# MAGIC Drop table if exists bronze_live.vrm_tbl_detail_alertrules       ;
# MAGIC Drop table if exists bronze_live.tc_pa_adm2                      ;
# MAGIC Drop table if exists bronze_live.trc_summaryshift                ;
# MAGIC Drop table if exists bronze_live.trc_wardinterface               ;
# MAGIC Drop table if exists bronze_live.tc_pac_treatmentstream          ;
# MAGIC Drop table if exists bronze_live.tc_pac_aearrivalmode            ;
# MAGIC Drop table if exists bronze_live.tc_ct_significantfacility       ;
# MAGIC Drop table if exists bronze_live.tc_pac_bedreasonnotavail        ;
# MAGIC Drop table if exists bronze_live.tc_pac_preferredlanguage        ;
# MAGIC Drop table if exists bronze_live.tc_ss_audittrail				;
# MAGIC Drop table if exists bronze_live.tc_pa_adm2handoverhistory;
# MAGIC Drop table if exists bronze_live.tc_pa_admleave;
# MAGIC Drop table if exists bronze_live.tc_pa_alertmsg;
# MAGIC Drop table if exists bronze_live.tc_pac_inpatadmissiontype;
# MAGIC Drop table if exists bronze_live.tc_pac_leavetype;
# MAGIC Drop table if exists bronze_live.tc_pac_patientalert;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC Drop table if exists bronze_live.tc_pa_admtransaction            ;
# MAGIC Drop table if exists bronze_live.tc_ct_acuity                    ;
# MAGIC Drop table if exists bronze_live.tc_ct_careprov                  ;
# MAGIC Drop table if exists bronze_live.tc_ct_disposit                  ;
# MAGIC Drop table if exists bronze_live.tc_ct_hospital                  ;
# MAGIC Drop table if exists bronze_live.tc_ct_loc                       ;
# MAGIC Drop table if exists bronze_live.tc_ct_lochealthspeccode         ;
# MAGIC Drop table if exists bronze_live.tc_ct_responsibleunit           ;
# MAGIC Drop table if exists bronze_live.tc_ct_sex                       ;
# MAGIC Drop table if exists bronze_live.tc_mr_adm                       ;
# MAGIC Drop table if exists bronze_live.tc_mr_diagnos                   ;
# MAGIC Drop table if exists bronze_live.tc_mrc_icddx                    ;
# MAGIC Drop table if exists bronze_live.tc_mrc_icdedition               ;
# MAGIC Drop table if exists bronze_live.tc_pac_refdoctor                ;
# MAGIC Drop table if exists bronze_live.tc_ct_healthspecialtycodes      ;
# MAGIC Drop table if exists bronze_live.tc_pa_adm                       ;
# MAGIC Drop table if exists bronze_live.tc_orc_anaestmethod             ;
# MAGIC Drop table if exists bronze_live.tc_or_anaest_operation          ;
# MAGIC Drop table if exists bronze_live.tc_orc_operation                ;
# MAGIC Drop table if exists bronze_live.tc_or_an_oper_secondaryproc     ;
# MAGIC Drop table if exists bronze_live.tc_orc_asa_classphactiv         ;
# MAGIC Drop table if exists bronze_live.tc_orc_reasonforsuspend         ;
# MAGIC Drop table if exists bronze_live.tc_pa_patmas                    ;
# MAGIC Drop table if exists bronze_live.tc_pa_personethnicity           ;
# MAGIC Drop table if exists bronze_live.tc_pac_admcategory              ;
# MAGIC Drop table if exists bronze_live.tc_pac_bed                      ;
# MAGIC Drop table if exists bronze_live.tc_pac_billingmethod            ;
# MAGIC Drop table if exists bronze_live.tc_pac_dischclassification      ;
# MAGIC Drop table if exists bronze_live.tc_pac_ethnicity                ;
# MAGIC Drop table if exists bronze_live.tc_pac_inpatdmissiontype        ;
# MAGIC Drop table if exists bronze_live.tc_pac_refdoctorclinic          ;
# MAGIC Drop table if exists bronze_live.tc_pac_room                     ;
# MAGIC Drop table if exists bronze_live.tc_pac_roomtype                 ;
# MAGIC Drop table if exists bronze_live.tc_pac_transferdestination      ;
# MAGIC Drop table if exists bronze_live.tc_pac_transfermeans            ;
# MAGIC Drop table if exists bronze_live.tc_pac_transfrequeststatus      ;
# MAGIC Drop table if exists bronze_live.tc_pac_ward                     ;
# MAGIC Drop table if exists bronze_live.tc_pac_wardroom                 ;
# MAGIC Drop table if exists bronze_live.tc_rb_reseffdate                ;
# MAGIC Drop table if exists bronze_live.tc_rb_reseffdatesession         ;
# MAGIC Drop table if exists bronze_live.tc_rb_reseffdatesessotspec      ;
# MAGIC Drop table if exists bronze_live.tc_rb_resource                  ;
# MAGIC Drop table if exists bronze_live.tc_rbc_equipment                ;
# MAGIC Drop table if exists bronze_live.tc_websys_standardtypeitem      ;
# MAGIC Drop table if exists bronze_live.tc_rb_appointment               ;
# MAGIC Drop table if exists bronze_live.vrm_tbl_tran_scorecard          ;
# MAGIC Drop table if exists bronze_live.tc_rb_operatingroom             ;
# MAGIC Drop table if exists bronze_live.tc_or_anaesthesia               ;
# MAGIC Drop table if exists bronze_live.tc_pac_bedstatus                ;
# MAGIC Drop table if exists bronze_live.tc_pac_bedtype                  ;
# MAGIC Drop table if exists bronze_live.tc_rb_apptschedule              ;
# MAGIC Drop table if exists bronze_live.tc_ct_locapprovedbeds           ;
# MAGIC Drop table if exists bronze_live.tc_pac_bedstatuschange          ;
# MAGIC Drop table if exists bronze_live.tc_pac_transtype                ;
# MAGIC Drop table if exists bronze_live.vrm_tbl_for_scorecardwards      ;
# MAGIC Drop table if exists bronze_live.tc_pa_person                    ;
# MAGIC Drop table if exists bronze_live.vrm_tbl_detail_alertrules       ;
# MAGIC Drop table if exists bronze_live.tc_pa_adm2                      ;
# MAGIC Drop table if exists bronze_live.trc_summaryshift                ;
# MAGIC Drop table if exists bronze_live.trc_wardinterface               ;
# MAGIC Drop table if exists bronze_live.tc_pac_treatmentstream          ;
# MAGIC Drop table if exists bronze_live.tc_pac_aearrivalmode            ;
# MAGIC Drop table if exists bronze_live.tc_ct_significantfacility       ;
# MAGIC Drop table if exists bronze_live.tc_pac_bedreasonnotavail        ;
# MAGIC Drop table if exists bronze_live.tc_pac_preferredlanguage        ;
# MAGIC Drop table if exists bronze_live.tc_ss_audittrail				;
# MAGIC Drop table if exists bronze_live.tc_pa_adm2handoverhistory;
# MAGIC Drop table if exists bronze_live.tc_pa_admleave;
# MAGIC Drop table if exists bronze_live.tc_pa_alertmsg;
# MAGIC Drop table if exists bronze_live.tc_pac_inpatadmissiontype;
# MAGIC Drop table if exists bronze_live.tc_pac_leavetype;
# MAGIC Drop table if exists bronze_live.tc_pac_patientalert;

# COMMAND ----------

spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pa_admtransaction")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_ct_acuity")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_ct_careprov")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_ct_disposit")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_ct_hospital")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_ct_loc")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_ct_lochealthspeccode")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_ct_responsibleunit")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_ct_sex")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_mr_adm")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_mr_diagnos")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_mrc_icddx")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_mrc_icdedition")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_refdoctornew")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_ct_healthspecialtycodes")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pa_adm")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_orc_anaestmethod")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_or_anaest_operation")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_orc_operation")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_or_an_oper_secondaryproc")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_orc_asa_classphactiv")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_orc_reasonforsuspend")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pa_patmas")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pa_personethnicity")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_admcategory")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_bed")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_billingmethod")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_dischclassification")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_ethnicity")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_inpatdmissiontype")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_refdoctorclinic")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_room")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_roomtype")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_transferdestination")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_transfermeans")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_transfrequeststatus")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_ward")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_wardroom")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_rb_reseffdate")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_rb_reseffdatesession")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_rb_reseffdatesessotspec")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_rb_resource")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_rbc_equipment")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_websys_standardtypeitem")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_rb_appointment")
spark.sql("DROP TABLE IF EXISTS bronze_live.vrm_tbl_tran_scorecard")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_rb_operatingroom")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_or_anaesthesia")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_bedstatus")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_bedtype")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_rb_apptschedule")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_ct_locapprovedbeds")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_bedstatuschange")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_transtype")
spark.sql("DROP TABLE IF EXISTS bronze_live.vrm_tbl_for_scorecardwards")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pa_person")
spark.sql("DROP TABLE IF EXISTS bronze_live.vrm_tbl_detail_alertrules")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pa_adm2")
spark.sql("DROP TABLE IF EXISTS bronze_live.trc_summaryshift")
spark.sql("DROP TABLE IF EXISTS bronze_live.trc_wardinterface")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_treatmentstream")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_aearrivalmode")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_ct_significantfacility")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_bedreasonnotavail")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_preferredlanguage")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_ss_audittrail")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pa_adm2handoverhistory")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pa_admleave")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pa_alertmsg")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_inpatadmissiontype")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_leavetype")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_patientalert")


# COMMAND ----------

spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_refdoctor_new")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_waitingliststatus")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_waitinglisttype")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pa_pregnancy")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pa_waitinglist")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_trust")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_reportingtype")

# COMMAND ----------

spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_nationalcodes")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_mrc_shortstayreason")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_ct_hospitaltrusts")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_rbc_equipmentgroup")


# COMMAND ----------

# spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_nationalcodes")
# spark.sql("DROP TABLE IF EXISTS bronze_live.tc_mrc_shortstayreason")
# spark.sql("DROP TABLE IF EXISTS bronze_live.tc_ct_hospitaltrusts")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_rbc_equipment")

# COMMAND ----------

spark.sql("DROP TABLE IF EXISTS bronze_live.tc_pac_caretype")
spark.sql("DROP TABLE IF EXISTS bronze_live.tc_orc_equipment")
