# Databricks notebook source
# MAGIC %md
# MAGIC #### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 02-May-2024 | 1      | Siddharth Saravanan    | First draft               |
# MAGIC

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../../../Utilities/utils"

# COMMAND ----------

# %run /Shared/Utilities/utils

# COMMAND ----------

dbutils.widgets.dropdown("Database", "silver_live", ["silver_live", "bronze_live"])
v_database = dbutils.widgets.get("Database")

dbutils.widgets.dropdown("All_Tables", "All", ["All","No"])
v_all_tables = dbutils.widgets.get("All_Tables")


# COMMAND ----------

# Create variables from etl.Control table
# WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
qry = f"""
       SELECT
             TargetTableName
       
       FROM adm_config.Control_CDS 
       WHERE Token = 'CDS_Delta' and IsActive = 1 and sourcesystem = 'trakcare' """

df_control_dbr = spark.sql(qry)   

v_source_table_name = df_control_dbr.select("TargetTableName")

# COMMAND ----------

# # Create variables from etl.Control table
# # WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
# qry = f"""
#        SELECT
#              TargetTableName
       
#        FROM ADM_CONFIG.etl.Control_CDS 
#        WHERE Token = 'CDS_Delta' and IsActive = 1 and sourcesystem = 'trakcare' """

# df_control = read_from_mi_db('ADM_CONFIG', qry)

# v_source_table_name = df_control.select("TargetTableName")



# COMMAND ----------

display(v_source_table_name)

# COMMAND ----------

table_names_list = []

# Iterate over the DataFrame and append each value to the list
for row in v_source_table_name.collect():
    table_names_list.append(row['TargetTableName'])

# Print the list of table names
print(table_names_list)

# COMMAND ----------


dbutils.widgets.dropdown("Table_List", table_names_list[0], table_names_list)
v_table_name = dbutils.widgets.get("Table_List")


# COMMAND ----------

def remove_table(v_database,v_table_name):
    if spark.catalog.tableExists(f"{v_database}.{v_table_name}"):
        spark.sql(f"DROP TABLE {v_database}.{v_table_name}")
        print(f"{v_table_name} Table dropped")

# COMMAND ----------

if v_all_tables == "All":

    for table in table_names_list:
        # Perform operations with each value
        remove_table(v_database,table)

elif v_all_tables == "No":

    remove_table(v_database,v_table_name)


    
