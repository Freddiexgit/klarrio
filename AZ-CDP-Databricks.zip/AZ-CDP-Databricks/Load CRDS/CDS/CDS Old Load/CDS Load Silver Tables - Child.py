# Databricks notebook source
# MAGIC %md
# MAGIC #### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 6-Apr-2024 | 1      | Siddharth Saravanan    | First draft of CDS Child notebook                 |
# MAGIC
# MAGIC

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# DBTITLE 1,Reset
# Use the function below if you need to reset the development and start from scratch.  
# reset_table('silver_live', 'trakcare_live/CDS', 'cds_admission', 2193)

# COMMAND ----------

dbutils.widgets.text("etlControlID", "","")

# COMMAND ----------

etlControlID=dbutils.widgets.get("etlControlID")
print(etlControlID)

# COMMAND ----------

# DBTITLE 1,Look up other etl.Control variables
# Create variables from etl.Control table
# WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
qry = f"""
       SELECT 
              ETLControlID
            , SourceSystem
            , SourceSystemType
            , SourceTableSchemaName
            , SourceTableName
            , CASE WHEN IncrementalLoad = 1 THEN WaterMarkValue ELSE '1900-01-01' END WaterMarkValue
            , TargetSystemType
            , TargetTableSchemaName
            , TargetTableName
            , IncrementalLoad
            , IsActive
            , TargetEntityPath
            , CustomConfig
        FROM ADM_CONFIG.etl.Control_CDS 
        WHERE ETLControlID = {etlControlID}"""

df_control = read_from_mi_db('ADM_CONFIG', qry)

v_watermark_date = df_control.select("WaterMarkValue").collect()[0][0]
v_incremental_load = df_control.select("IncrementalLoad").collect()[0][0]
v_source_database = df_control.select("SourceTableSchemaName").collect()[0][0]
v_source_table_name = df_control.select("SourceTableName").collect()[0][0]
v_target_table_name = df_control.select("TargetTableName").collect()[0][0]
v_target_database = df_control.select("TargetTableSchemaName").collect()[0][0]
v_merge_column = df_control.select("CustomConfig").collect()[0][0]
v_source_view = f'{v_source_database}.{v_source_table_name}'

# COMMAND ----------

print(qry)

# COMMAND ----------

print(v_watermark_date)

# COMMAND ----------

v_new_watermark = spark.sql(f"SELECT max(watermark_value) AS v_new_watermark_value FROM {v_source_view}").select("v_new_watermark_value").collect()[0][0]

if v_new_watermark is None:
    dbutils.notebook.exit("Watermark value is empty in bronze table")
else:
    print(v_new_watermark)

# COMMAND ----------

if v_watermark_date >= v_new_watermark:
    
    print('Do not run the query')
    run_query = False
    print('Updating the watermark value to current runtime')
    watermark_toUpdate = datetime_nz()
    update_mi_water_mark_value (watermark_toUpdate, etlControlID,'Control_CDS')
    print('watermark updated')
    print(watermark_toUpdate)
    dbutils.notebook.exit("Processing complete")


else: 
    print('Run the query')
    run_query = True
    print(run_query)
    if run_query == True:
        print('Getting the delta records')
        df_view = spark.sql(f"SELECT * FROM {v_source_view} WHERE processing_time > '{v_watermark_date}'")
        # set the merge condition required for the merge functions
        merge_condition = 'TARGET.uid = SOURCE.uid'

        # merge the data from df_hashed to target delta table
        print(etlControlID)
        print('TargetDatabase')
        print(v_target_database)
        print('TargetTableName')
        print(v_target_table_name)
        print('merge_condition')
        print(merge_condition)
        print(df_view)
        merge_delta_tables(df_view, v_target_database, v_target_table_name, merge_condition)
        print('Data merged to the target table')

        #Updating Watermark value
        print('value to update to watermark after running the query')
        watermark_toUpdate = datetime_nz()
        print(watermark_toUpdate)
        update_mi_water_mark_value (watermark_toUpdate, etlControlID,'Control_CDS')
        print('watermark updated')
  
    
