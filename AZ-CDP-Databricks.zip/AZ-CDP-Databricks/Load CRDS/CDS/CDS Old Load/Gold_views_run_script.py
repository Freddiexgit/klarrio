# Databricks notebook source
from multiprocessing.pool import ThreadPool
gold_views=[
    "vw_pres_admission",
    "vw_pres_diagnosis",
    "vw_pres_ioc_bed_request",
    "vw_pres_ioc_bed_to_ward_details",
    "vw_pres_ioc_date",
    "vw_pres_ioc_expected_arrivals",
    "vw_pres_ioc_inpatient_signon",
    "vw_pres_ioc_occupancy_snapshot",
    "vw_pres_ioc_room_to_ward_details",
    "vw_pres_iocstarship_ced_triage_breaches",
    "vw_pres_theatrehours",
    "vw_pres_l2_ed_process",
    "vw_pres_l2_ed_process_cdu",
    "vw_pres_l2_em_wait_time",
    "vw_pres_l2_hourly_presentations",
    "vw_pres_location",
    "vw_pres_medical_record",
    "vw_pres_movement",
    "vw_pres_outpatient",
    "vw_pres_outpatient_admission",
    "vw_pres_patient",
    "vw_pres_procedure",
    "vw_pres_ref_diagnosis",
    "vw_pres_ref_hospital",
    "vw_pres_ref_procedure",
    "vw_pres_ref_patient_ethnicity",
    "vw_pres_ref_ward",
    "vw_pres_surgical_waiting_list",
    "vw_pres_theatre_movement",
    "vw_pres_theatre_session",
    "vw_pres_trendcare_staff_level",
    "vw_pres_trendcare_variance",
    "vw_pres_vis_score",
    "vw_pres_appointment",
    "vw_pres_ref_outpatient_community_service"
]

pool = ThreadPool(20)
pool.map(lambda gold_views: dbutils.notebook.run(f"/Shared/Load CRDS/CDS/Gold_Views/{gold_views}", timeout_seconds= 300),gold_views)
