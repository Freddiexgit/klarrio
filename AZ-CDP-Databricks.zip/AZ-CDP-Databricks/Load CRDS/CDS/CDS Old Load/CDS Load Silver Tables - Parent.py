# Databricks notebook source
# MAGIC %md
# MAGIC # Notebook to implement multi processing/parallel runs of CDS fast load 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 6-Apr-2024 | 1      | Siddharth S    | Created first draft for CDS parent load                 |
# MAGIC

# COMMAND ----------

# DBTITLE 1,Parameters
dbutils.widgets.dropdown("BatchType", "CDS_Live", ["CDS_Live", "CDS_Full"])
v_BatchType = dbutils.widgets.get("BatchType")

dbutils.widgets.dropdown("Token", "CDS_Delta", ["CDS_Delta", "cds_ioc_mi"])
v_Token = dbutils.widgets.get("Token")

dbutils.widgets.dropdown("TargetSystem", "ADLS", ["ADLS", "SQLMI"])
v_TargetSystem = dbutils.widgets.get("TargetSystem")

dbutils.widgets.text("TrakCareSource","DM")
v_TrakCareSource= dbutils.widgets.get("TrakCareSource")

# COMMAND ----------

# DBTITLE 1,Importing libraries needed
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor

# COMMAND ----------

# DBTITLE 1,Calling Common function Notebook
# MAGIC %run "/Shared/Utilities/utils"

# COMMAND ----------

# DBTITLE 1,Function to call the Child Notebook
def processRDSLoad(etlControlID):
    v_Message = dbutils.notebook.run(path = "./CDS Load Silver Tables - Childnew",  #Test cds_admission - CDS Load Process IRIS Child
                                        timeout_seconds = 1200, 
                                        arguments = {"etlControlID":etlControlID,"TrakCareSource":v_TrakCareSource})
    return(v_Message)


# COMMAND ----------

# DBTITLE 1,Query to get Child Notebook Control IDs list
qry = f"""
        SELECT 
             C.ETLcontrolid 
        FROM 
            etl.Control_CDS as C 
        where 
            Token = '{v_Token}' and TargetSystemType = '{v_TargetSystem}'
            --C.SourceSystem = 'trakcare'
            and IsActive = 1 and BatchType = '{v_BatchType}'
            """
EtlControl_df = read_from_mi_db('ADM_CONFIG', qry)

# COMMAND ----------

display(EtlControl_df)

# COMMAND ----------

# DBTITLE 1,Executing the CDS child notebooks in parallel
Table_Count = EtlControl_df.count()
print(f'Total no of tables processed:{Table_Count}')
listOfNumbers = list(EtlControl_df.select('ETLcontrolid').toPandas()['ETLcontrolid']) # => [1, 2, 3, 4]
max_workers = 15
with ThreadPoolExecutor(max_workers=max_workers) as executor:
  for result in executor.map(processRDSLoad, listOfNumbers):
    print(result)



# COMMAND ----------


