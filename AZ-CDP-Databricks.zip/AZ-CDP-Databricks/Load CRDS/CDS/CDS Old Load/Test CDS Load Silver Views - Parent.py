# Databricks notebook source
# MAGIC %md
# MAGIC # Notebook to implement multi processing/parallel runs of CDS fast load 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 6-Apr-2024 | 1      | Siddharth S    | Created first draft for CDS parent load                 |
# MAGIC

# COMMAND ----------

# DBTITLE 1,Parameters
dbutils.widgets.text("TrakCareSource","DM")
v_TrakCareSource= dbutils.widgets.get("TrakCareSource")

# COMMAND ----------

# DBTITLE 1,Importing libraries needed
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor

# COMMAND ----------

# DBTITLE 1,Calling Common function Notebook
# MAGIC %run "/Shared/Utilities/utils"

# COMMAND ----------

# DBTITLE 1,Function to call the Child Notebook
def processRDSLoad(NotebookPath):
    v_Message = dbutils.notebook.run(path = f"{NotebookPath}",  #Test cds_admission - CDS Load Process IRIS Child
                                        timeout_seconds = 1200, 
                                        arguments = {"NotebookPath":NotebookPath,"TrakCareSource":v_TrakCareSource})
    return(v_Message)


# COMMAND ----------

# DBTITLE 1,Query to get Child Notebook Control IDs list
qry = f"""
        SELECT 
            CONCAT(C.DatabricksNotebook,C.SourceTableName) as NotebookPath
        FROM 
            etl.Control_CDS as C 
        where 
             sourcetableschemaname = 'silver_live'--or TargetSystemType = 'SQLMI') 
             and IsActive = 1
            """
EtlControl_df = read_from_mi_db('ADM_CONFIG', qry)

# COMMAND ----------

display(EtlControl_df)

# COMMAND ----------

# DBTITLE 1,Executing the CDS child notebooks in parallel
Table_Count = EtlControl_df.count()
print(f'Total no of tables processed:{Table_Count}')
listOfNumbers = list(EtlControl_df.select('NotebookPath').toPandas()['NotebookPath']) # => [1, 2, 3, 4]
with ThreadPoolExecutor() as executor:
  for result in executor.map(processRDSLoad, listOfNumbers):
    print(result)



# COMMAND ----------


