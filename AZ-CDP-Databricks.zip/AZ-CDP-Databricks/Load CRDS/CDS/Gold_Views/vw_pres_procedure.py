# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 28-Mar-2024 | 1       | Siddharth S    | Create first draft of presentation view from cds_procedure  delta table      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_procedure""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_procedure
AS

With current_datetime AS (
  SELECT from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
)

SELECT 
 Operating_Room_ID
, Admission_ID
, pr.Procedure_ID
, Booking_Type
, Procedure_Status
, Cancelled_Reason
, Resource_Code
, ASA
, Theatre_Module_Procedure_Code
, Booked_Create_DateTime
, Booking_Create_DateTime
, Start_DateTime
, Finish_DateTime
, Theatre_Out_DateTime
, Total_Plan_Theatre_Time
, Is_Primary
, rpr.Procedure_Code
, rpr.Procedure_Desc
, CASE WHEN rpr.Procedure_Code IN('1652000', '1652001','1652002','1652003','1652004','1652005') THEN 'Y' ELSE 'N' END as WH_CSection_Flag
, pr.watermark_value
, case when CAST(pr.Booked_Create_DateTime AS DATE) = CAST (now AS DATE) then 'Y' else 'N' end as Procedure_Booked_Today
from silver_live.cds_procedure pr, current_datetime
left outer join silver_live.cds_ref_procedure rpr on rpr.Procedure_ID = pr.Procedure_ID

""")

# COMMAND ----------


