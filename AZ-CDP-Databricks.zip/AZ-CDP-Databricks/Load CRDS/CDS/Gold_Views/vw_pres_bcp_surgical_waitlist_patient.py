# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 12-Jul-2024 | 1       | Janesa R       | Update view to get BCP surgical waitlist patients only                  |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_bcp_surgical_waitlist_patient""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_bcp_surgical_waitlist_patient
AS

WITH current_datetime AS (
SELECT
    from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
)
SELECT
    DISTINCT
  pt.Patient_ID,
    Patient_NHI,
    Patient_First_Name,
    Patient_Middle_Name,
    Patient_Last_Name,
    Patient_DOB,
    Patient_DOB_Year,
    Patient_DOB_Month,
    Patient_Gender_Code,
    Patient_Sex,
    EDC_Agreed_Date,
    Patient_Deceased_Date,
    Patient_Domicile_Code,
    Patient_DHB,
    Patient_Ethnicity,
    Is_Interpreter_Required,
    Preferred_Language,
    AlertFlag,
    concat(Patient_Last_Name, ', ', Patient_First_Name) as Patient_Full_Name,
    pt.source_file,
    pt.processing_time
FROM
    silver_live.cds_patient pt,
    current_datetime
INNER JOIN gold_live.vw_pres_bcp_waiting_list wl
  on pt.Patient_ID = wl.Patient_ID

  
""")

# COMMAND ----------


