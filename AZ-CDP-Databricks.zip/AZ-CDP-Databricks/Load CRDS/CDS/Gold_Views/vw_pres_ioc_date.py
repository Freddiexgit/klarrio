# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 15 Aug 2024 | 1       | Janesa R    | Initial draft      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_ioc_date""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_ioc_date
AS
WITH current_time AS (
  SELECT from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
)

select
 date_key
, date
, date_next
, dd_mm_yyyy
, mm_dd_yyyy
, yyyy_dd_mm
, year
, month
, day
, day_of_week_str
, day_of_week
, day_of_month
, day_of_year
, day_diff
, week_start_mon
, week_end_mon
, current_day
, current_week
, current_month
, current_year
, case when datediff(DATE(now), cast(date as date)) = 0 then 'Today' 
        when datediff(DATE(now), cast(date as date)) >= 1 and datediff(DATE(now), cast(date as date)) <=7 then 'Previous'
        when datediff(DATE(now), cast(date as date)) = -1 then 'Tomorrow'
        when  date between dateadd(day, 1, now) and dateadd(day, 7, now) then date
        else null end as 7Day_Filter 
, CASE
        WHEN date BETWEEN date_trunc('week', now) AND date_trunc('week', date_add(now, 7)) THEN 'Current Week'
        WHEN date BETWEEN date_trunc('week', date_add(now, 7)) AND date_trunc('week', date_add(now, 14)) THEN 'T-1'
        WHEN date BETWEEN date_trunc('week', date_add(now, 14)) AND date_trunc('week', date_add(now, 21)) THEN 'T-2'
        WHEN date BETWEEN date_trunc('week', date_add(now, 21)) AND date_trunc('week', date_add(now, 28)) THEN 'T-3'
        WHEN date BETWEEN date_trunc('week', date_add(now, 28)) AND date_trunc('week', date_add(now, 35)) THEN 'T-4'
        WHEN date BETWEEN date_trunc('week', date_add(now, 35)) AND date_trunc('week', date_add(now, 42)) THEN 'T-5'
        WHEN date BETWEEN date_trunc('week', date_add(now, 42)) AND date_trunc('week', date_add(now, 49)) THEN 'T-6'
    END AS WeekNumber
from silver_live.cds_date, current_time
where date between dateadd(year, -1, now) and dateadd(year, 1, now)
""")

# COMMAND ----------


