# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 01-Jul-2024 | 1       | Khalid Jameel    | Create theatre summary list to be used for BCP TH69/70 Reporting         |
# MAGIC | 09-Jul-2024 | 2       | Khalid Jameel    | Update the summary view as per CDS model changes and Report requirements |
# MAGIC | 16-Jul-2024 | 2       | Khalid Jameel    | Update the summary view as per CDS model changes and Business Feedback |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_ref_procedure""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_bcp_theatre_summary
AS
WITH current_time AS (
SELECT
    from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
)
SELECT
    TH_SESSION.Theatre_Code,
    CAST(date_format(TH_SESSION.Session_DateTime, 'yyyyMMdd') AS INT) as Session_Start_Date_Key,
    TH_SESSION.Session_DateTime AS SessionStartDateTime,
    TH_SESSION.AMPM AS AMPM,
    TH_SESSION.Session_Type AS SessionType,
    MAX(DATEDIFF(MINUTE , TH_SESSION.Session_Start_Time, TH_SESSION.Session_End_Time)) AS SessionDuration,
    SUM(DATEDIFF(MINUTE , APT.Appointment_Start_Time, APT.Appointment_End_Time)) AS BookedDuration,
    SUM(DATEDIFF(MINUTE , APT.Appointment_Start_Time, APT.Appointment_End_Time)) / MAX(DATEDIFF(MINUTE , TH_SESSION.Session_Start_Time, TH_SESSION.Session_End_Time)) * 100 AS BookedPercent,
	MAX(DATEDIFF(MINUTE , TH_SESSION.Session_Start_Time, TH_SESSION.Session_End_Time)) - SUM(DATEDIFF(MINUTE , APT.Appointment_Start_Time, APT.Appointment_End_Time)) AS AvailableMins
FROM
    hive_metastore.silver_live.cds_procedure PROC
LEFT OUTER JOIN hive_metastore.silver_live.cds_theatre_session TH_SESSION
ON
    TH_SESSION.Theatre_Code = PROC.Resource_Code
    AND PROC.Booked_Create_DateTime = TH_SESSION.Session_DateTime
LEFT OUTER JOIN hive_metastore.silver_live.vw_cds_appointment APT 
ON
    APT.Session_ID = TH_SESSION.Session_Id
    AND APT.Admission_ID = PROC.Admission_ID
WHERE
    PROC.Procedure_ID IS NOT NULL
    AND PROC.Procedure_ID <> '99999'
    AND PROC.Is_Primary = '1'
GROUP BY
    TH_SESSION.Theatre_Code,
    TH_SESSION.Session_DateTime,
    TH_SESSION.AMPM,
    TH_SESSION.Session_Type
""")

# COMMAND ----------


