# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 27-Mar-2024 | 1       | Siddharth S    | Create first draft of presentation view from cds_admission delta table     |
# MAGIC | 19-Apr-2024 | 2       | Janesa R       | Update view to add new columns                                             |
# MAGIC | 04-Jul-2024 | 3       | Khalid J       | Update view to add new columns                                             |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_admission""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_admission
AS

WITH current_time AS (
  SELECT from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
)

SELECT 
ad.UID
, ad.Admission_ID
, Admission_Number
, Admission_DateTime
, Admission_Type_Code
, Inpatient_Admission_Type_Code
, Inpatient_Admission_Type_Desc
, Original_Admission_ID
, Actual_Arrival_DateTime
, Clinician_Seen_DateTime
, Estimated_Discharge_DateTime
, Medical_Discharge_DateTime
, Actual_Discharge_DateTime
, Intent_DateTime
, Ambul_Handover_Comp_DateTime
, Handover_Start_DateTime
, Handover_End_DateTime
, Handover_Childsub
, Handover_Type
, Visit_Status_Code
, Visit_Comment
, Inpatient_Short_Stay_Intent
, Length_Of_Stay
, Emergency_Treatment_Streams
, Triage_Description
, Triage_Code
, Ref_Clinician_Code
, Ref_Clin_Practice_Code
, Health_Specialty_Code
, Billing_Method_Code
, Arrival_Mode
, Leave_Going_Out_DateTime
, Leave_Actual_Return_DateTime
, Leave_Cancel_DateTime
, Leave_Type_Code
, Leave_Type_Desc
, Nurse
, Patient_ID
, Intended_Procedure
, Short_Stay_Reason_Desc
, rpr.Procedure_Code as Intended_Procedure_Code
, CASE WHEN Admission_Type_Code = 'I' Then 'INP' Else 'ED' End as Visit_Type_Code 
, case when mr.Present_Complaint like '%IOL%' or rpr.Procedure_Code in ('9046500','9046501','9046502') then 'IOL' else null end as IOL
, datediff(minute, Admission_DateTime, nz.now) as Attendance_Duration
, case when DATE(Estimated_Discharge_DateTime) = DATE(nz.now) Then 'Y' else 'N' end EDD_Today
, case when nz.now > DATEADD(hour, 1, Estimated_Discharge_DateTime) Then 'Y' else 'N' end EDD_Overdue
, Round(Case When Actual_Discharge_DateTime is null and Medical_Discharge_DateTime is null and Intent_DateTime is null  Then (unix_timestamp(nz.now) - unix_timestamp(Admission_DateTime)) / 3600
      When Actual_Discharge_DateTime is not null and Medical_Discharge_DateTime is null and Intent_DateTime is null Then (unix_timestamp(Actual_Discharge_DateTime) - unix_timestamp(Admission_DateTime)) / 3600 
      When Actual_Discharge_DateTime is null and Medical_Discharge_DateTime is not null and Intent_DateTime is null Then (unix_timestamp(Medical_Discharge_DateTime) - unix_timestamp(Admission_DateTime)) / 3600
      When Actual_Discharge_DateTime is null and Medical_Discharge_DateTime is null and Intent_DateTime is not null Then (unix_timestamp(Intent_DateTime) - unix_timestamp(Admission_DateTime)) / 3600
         End, 0) as ED_LOS
, Case When Clinician_Seen_DateTime is not null or Handover_Start_DateTime is not null Then 'Y' Else 'N' End as EM_Signon
, Case When Clinician_Seen_DateTime is not null Then Clinician_Seen_DateTime Else nz.now End as Clock_End_Datetime
, case when mr.Discharge_Code in('EDIP', 'CDUIP', 'EDOT', 'CDUOT') then 'Admitted to IP Ward' 
		when mr.Discharge_Code is null and ad.Inpatient_Short_Stay_Intent is null then 'In CED'
		when mr.Discharge_Code is null and ad.Inpatient_Short_Stay_Intent is not null then 'SS in CED'
		else 'Discharged from CED'
end as CED_Visit_Status
, CASE 
    WHEN DATE(Estimated_Discharge_DateTime) <=  nz.now THEN 
      CASE WHEN DateDiff(HOUR, nz.now, Estimated_Discharge_DateTime) <= 4  THEN 1 ELSE 0 END 
    ELSE 0 END AS EDD_4Hours
, Case WHEN ad.Medical_Discharge_DateTime IS NOT NULL THEN Datediff(Hour,ad.Medical_Discharge_DateTime , DATEADD(HOUR, 12, nz.now) ) Else 0 End as Intenttimer
, Case When ad.Leave_Type_Code in ('WL', 'S31WL') and ad.Leave_Actual_Return_DateTime is null and ad.Leave_Actual_Return_DateTime is null and ad.Leave_Going_Out_DateTime is not null
     and ad.Visit_Status_Code = 'A' then 'Y' else 'N' end as Ward_Leave_Flag
, case when ad.Medical_Discharge_DateTime is not null and datediff(hour, ad.Medical_Discharge_DateTime, now) >= 24 then 'Y' else 'N' end as RTG_Delay_Flag
, case when (ad.Actual_Arrival_DateTime is not null and ad.Ambul_Handover_Comp_DateTime is null and mr.Transfer_Means_Desc like '%Ambulance%') then 'Y' else 'N' end as Ambulatory_Offload_Flag
, mr.Transfer_Means_Desc as Transfer_Means_Per_Admission
, DATE_FORMAT(Admission_DateTime, 'HH:mm') as TCI
, CASE WHEN DATE_FORMAT(Admission_DateTime, 'HH:mm') < '12:00' THEN 'AM' ELSE 'PM' END AS AM_PM
, CAST(date_format(Estimated_Discharge_DateTime, 'yyyyMMdd') AS INT) as Estimated_Discharge_Date_Key
, ad.Floor_Plan_Notes
, ad.PreAdm_Clinician
, ad.PreAdm_Specialty  
, ad.Is_Current
, ad.processing_time
, ad.watermark_value
FROM silver_live.cds_admission ad, current_time nz
left outer join silver_live.cds_medical_record mr on mr.Admission_ID = ad.Admission_ID
left outer join silver_live.cds_ref_procedure rpr on rpr.Procedure_ID = ad.Intended_Procedure
where Admission_Type_Code in ('I', 'E')
and Actual_Discharge_DateTime is null
and Visit_Status_Code in ('A', 'P') 

""")

# COMMAND ----------


