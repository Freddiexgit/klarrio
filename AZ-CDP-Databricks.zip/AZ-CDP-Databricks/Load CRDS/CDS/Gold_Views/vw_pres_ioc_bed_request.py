# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 11-May-2024 | 1       | Janesa R       | Initial build of bed request view

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_ioc_bed_request""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_ioc_bed_request
AS

With current_time AS (
  SELECT from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
),

WT as (
select Admission_ID, Location_ID, Bed_ID
from silver_live.cds_movement WT -- current ward transfer
    where wt.Movement_Type = 'Ward Transfer' and wt.Movement_End_Datetime is null
)

select
br.UID,
br.Admission_ID,
WT.Location_ID  as Current_Ward_ID,
br.Next_Location_ID,
wt.Bed_ID,
br.Movement_Start_Datetime,
br.Transfer_Remark,
br.CBU,
LPAD(CAST((unix_timestamp(current_time.now) - unix_timestamp(br.Movement_Start_Datetime)) / 3600 AS STRING), 2, '0') || ':' ||
  CASE
    WHEN ROUND(((unix_timestamp(current_time.now) - unix_timestamp(br.Movement_Start_Datetime)) % 3600) / 60) < 10
    THEN '0' || CAST(ROUND(((unix_timestamp(current_time.now) - unix_timestamp(br.Movement_Start_Datetime)) % 3600) / 60) AS STRING)
    ELSE CAST(ROUND(((unix_timestamp(current_time.now) - unix_timestamp(br.Movement_Start_Datetime)) % 3600) / 60) AS STRING)
  END as  Bed_Request_Duration,
/*CASE WHEN br.Movement_Status = 'Accepted' then 'Completed'
            WHEN br.Movement_Status = 'Accepted' and br.Movement_Create_DateTime > now then 'Overdue'
            WHEN br.Movement_Status = 'Requested' and br.Movement_Create_DateTime <= now then 'Active'
            END as Bed_Request_Status,
*/
CASE WHEN br.Movement_Status = 'Accepted' and datediff(minute, br.Movement_Start_DateTime, now)<60 
			then 'Accepted and Not Overdue'----bed request is accepted, patient hasn't yet moved, scheduled move date is in future
      WHEN br.Movement_Status = 'Accepted' and datediff(minute, br.Movement_Start_DateTime, now)>=60 
			then 'Accepted and Overdue >=1 Hr'----bed request is accepted, patient hasn't yet moved, scheduled move date is in the past
      WHEN br.Movement_Status = 'Requested' 
      then 'Requested' ----bed request has not yet been accepted (yellow)
            END as Bed_Request_Status,
ROUND(DATEDIFF(now, br.Movement_Start_Datetime))*24 AS Next_Attendance_Timer
from hive_metastore.gold_live.vw_pres_movement br, current_time 
left outer join WT on WT.Admission_ID = br.Admission_ID
where br.movement_type = 'Bed Request' and br.Movement_End_Datetime is null

""")

# COMMAND ----------


