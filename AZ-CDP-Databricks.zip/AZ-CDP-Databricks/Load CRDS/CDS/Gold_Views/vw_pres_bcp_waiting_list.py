# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 19 June 2024 | 1       | Janesa R    | Initial Build               |
# MAGIC | 09 July 2024 | 1       | Khalid J    | Updated to Add Columns      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_bcp_waiting_list""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_bcp_waiting_list
AS

WITH current_time AS (
  SELECT from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
)

select 
 WaitingList_ID
, Admission_ID
, Procedure_ID
, Patient_ID
, Procedure_Free_Text
, Remarks
, CBU
, Clinician
, WaitingList_Status_Code
, WaitingList_Status_Desc
, WaitingList_Type_Code
, Days_Waiting
, WaitingList_Priority
, WaitingList_Review_Date
,Surgery_Date
, WaitingList_DateTime
, Processing_Time
from 
hive_metastore.silver_live.cds_waiting_list, current_time
where Surgery_Date >= now


""")

# COMMAND ----------


