# Databricks notebook source


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 28-Mar-2024 | 1       | Janesa R       | Create first draft of presentation view for Inpatient SignOn      |
# MAGIC

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_ioc_inpatient_signon""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_ioc_inpatient_signon
AS

WITH current_time AS (
  SELECT from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
),

current_ward_transfer as (
select Admission_ID, Bed_ID, Movement_Start_Datetime, Room_ID
from silver_live.cds_movement
where Movement_Type = 'Ward Transfer' and Movement_End_Datetime is null
),

previous_case_transfer as (
select Admission_ID, Bed_ID, Movement_Start_Datetime, Specialty, CBU, Current_Clinician, Movement_Start_Datetime, Movement_Is_Main
from silver_live.cds_movement
where Movement_Type = 'Case Transfer' and Movement_End_Datetime is not null
     and Specialty not in ('Emergency Medicine', 'Adult Emergency Department', 'Clinical Decision Unit', 'Adult Emergency Dept')
),

room_without_beds_code_check as (
select room_id, room_code
from gold_live.vw_pres_ioc_room_to_ward_details
where IOC_RoomToWard_Type <> 'Non-IOC Ward'
),

room_with_beds_code_check as (
select bed_id, room_code
from gold_live.vw_pres_ioc_bed_to_ward_details
where IOC_BedToWard_Type <> 'Non-IOC Ward'
),

main_query as (
select
ct.UID,
ct.Admission_ID Current_Case_Admission_ID,
--wt.Location ID,
ct.Current_Location_ID Current_Case_Location_ID,
wt.Bed_ID Current_Case_Bed_ID,
wt.Room_ID,
case when wt.Bed_ID is null and wt.Room_ID is not null then rmw.Room_Code 
    when wt.Bed_ID is not null then rmb.Room_Code
    else null end as Room_Code,
--ct.CBU as CBU,
case when ct.Specialty = 'Clinical Decision Unit' then pct.CBU else ct.CBU end as CBU,
case when ct.Specialty = 'Clinical Decision Unit' then pct.Specialty else ct.Specialty end as Specialty,
wt.Movement_Start_Datetime,
case when ct.current_clinician = 'Awaiting IP clinician Sign on' then datediff(minute, ct.Movement_Start_Datetime, now) 
    when ct.CBU <> pct.CBU and ct.Current_Clinician <> pct.Current_Clinician then date_diff(minute, pct.Movement_Start_Datetime, ct.Movement_Start_Datetime)
    when ct.CBU = pct.CBU and ct.Current_Clinician <> pct.Current_Clinician then date_diff(minute, pct.Movement_Start_Datetime, ct.Movement_Start_Datetime)
    when ct.current_clinician <> 'Awaiting IP clinician Sign on' and (pct.current_clinician <> 'Awaiting IP clinician Sign on' or pct.current_clinician is null)  then 0
    when pct.CBU is null then date_diff(minute, ct.Movement_Start_Datetime, now) 
    end as TimeWaitingMinutes,
case when ct.current_clinician = 'Awaiting IP clinician Sign on' then 'Case1' 
    when ct.CBU <> pct.CBU and ct.Current_Clinician <> pct.Current_Clinician then 'Case2'
    when ct.CBU = pct.CBU and ct.Current_Clinician <> pct.Current_Clinician then 'Case3'
    when ct.current_clinician <> 'Awaiting IP clinician Sign on' and (pct.current_clinician <> 'Awaiting IP clinician Sign on' or pct.current_clinician is null) then 'Case4'
    when pct.CBU is null then 'Case 5'
 end as TimeWaiting_test,
ct.transfer_remark as Referral_Reason,
ct.current_clinician Current_Case_Clinician,
case when ct.current_clinician = 'Awaiting IP clinician Sign on' then null
    when ct.CBU <> pct.CBU and ct.Current_Clinician <> pct.Current_Clinician then ct.Movement_Start_Datetime
    when ct.CBU = pct.CBU and ct.Current_Clinician <> pct.Current_Clinician then ct.Movement_Start_Datetime
    when pct.CBU is null then null end as Referred,
case when ct.current_clinician is null or ct.current_clinician = 'Awaiting IP clinician Sign on' then 'N' else 'Y' end as SignedOn,
case when ct.current_clinician is null or ct.current_clinician = 'Awaiting IP clinician Sign on' then null else ct.Movement_Start_Datetime end as SignOnDateTime,
ct.Movement_is_Main as Main_Care_Provider,
CASE WHEN ct.Specialty IN('General Gynaecology','LMC Obstetricians','Maternal and Fetal Medicine','Maternity Community-Midwives','Gynae Oncology','LMC Midwives',
'Maternity Obstetrics','Maternity Diabetes', 'Te Manawa O Hine') THEN 'Y' ELSE 'N' END as WH_Specialty_Flag
from hive_metastore.gold_live.vw_pres_movement ct, current_time -- current case transfer
left outer join current_ward_transfer Wt -- current ward transfer
    on WT.Admission_ID = CT.Admission_ID
left outer join previous_case_transfer pct -- previous case transfer (completed)
    on pct.Admission_ID = CT.Admission_ID and pct.Movement_Is_Main = ct.Movement_Is_Main
left outer join room_with_beds_code_check rmb on wt.Bed_ID = rmb.Bed_ID
left outer join room_without_beds_code_check rmw on wt.Room_ID = rmw.Room_ID
where ct.movement_type = 'Case Transfer'
and ct.movement_code = 'Transfer'
and ct.movement_status = 'Transfer'
and ct.Movement_End_Datetime is null
)

select
*,
LPAD(CAST(FLOOR(TimeWaitingMinutes/60) AS STRING), 2, '0') || ':' ||
LPAD(CAST(TimeWaitingMinutes % 60 AS STRING), 2, '0' ) as Time_Waiting_Hours_Mins
from main_query
where Specialty is not null and Specialty not in ('Emergency Medicine', 'Adult Emergency Department', 'Clinical Decision Unit', 'Adult Emergency Dept')

""")

# COMMAND ----------


