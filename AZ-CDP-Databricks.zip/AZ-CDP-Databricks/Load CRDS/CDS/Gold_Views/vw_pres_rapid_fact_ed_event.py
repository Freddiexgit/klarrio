# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 15 Aug 2024 | 1       | Janesa R    | Initial draft      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_rapid_fact_ed_event """)

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_rapid_fact_ed_event
AS

WITH current_time AS (
  SELECT from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
),

Prioritised_Ethnicity AS 
(
	SELECT distinct   Admission.Patient_ID									
					, PatientEthnicity.Rank
					, PatientEthnicity.Patient_Ethnicity						
					, PatientEthnicity.Priority
					, EthnicGroup.EthnicGroupCode
	FROM (SELECT DISTINCT cds_admission.Patient_ID						
			FROM hive_metastore.silver_live.cds_admission cds_admission				 	
			WHERE	1=1
				AND cds_admission.Admission_DateTime >= '2020-01-01'	
				AND cds_admission.Admission_Type_Code IN  ('E')			
		 ) Admission
	JOIN hive_metastore.silver_live.cds_ref_patient_ethnicity PatientEthnicity	
				ON Admission.Patient_ID = PatientEthnicity.Patient_ID	
					AND PatientEthnicity.Priority = 1 										-- Only prioritised ethnicity needs to be selected for patient having multiple ethnicities
	LEFT JOIN hive_metastore.silver_live.vw_cds_dsu_mohethnicgroupcode EthnicGroup					-- should this dsu table be in silver_db?
				ON PatientEthnicity.Rank = EthnicGroup.EthnicGroupPriority
)
SELECT DISTINCT
	 CAST(Patient.Patient_NHI as VARCHAR(10)) as NHI
	,Admission.Admission_Number	as ED_encounter_id											
	,Admission.Admission_DateTime as ED_presentation_date
	,Hospital.Hospital_Code as hospital_code      
	,1022 as DHB_of_service_code  
	,Patient.Patient_Domicile_Code as domicile_code  
	,Admission.Triage_Code as Triage_Code
	,Patient.Patient_DOB as date_of_birth  
	,Patient.Patient_Gender_Code as sex_code  
	,Prioritised_Ethnicity.EthnicGroupCode as ethnic_group_code    	
	,Admission.Ref_Clinician_Code as GP_code  
	,Admission.Ref_Clin_Practice_Code as GPPractice_code  			
	,Admission.Actual_Discharge_DateTime as ED_discharge_date 
	,CASE WHEN Admission.Actual_Discharge_DateTime IS NULL THEN NULL ELSE 'M05' END  as ED_discharge_specialty  
	,Medical_Record.Discharge_Type_Code  as ED_event_end_type_code	
	,Patient.Patient_Deceased_Date as date_of_death
	,now as extract_date_time  
	,0 as archive_flag  
	,'ED' as setting  
	,CASE WHEN Medical_Record.Transfer_Destination = 'Auckland Mental Health Services' THEN 'F03067-A'	
		  WHEN Medical_Record.Transfer_Destination = 'Starship Childrens Hospital' THEN 'F03052-K'		
		  WHEN Medical_Record.Transfer_Destination = 'Greenlane Hospital' THEN 'F03026-J'				
		  ELSE 'F03067-A'
	 END as HPI_FACILITY_CODE  
	,'N' as INVALID_ENCOUNTER_FLAG	
	,'ADHB TrakCare' as CLIENT_SOURCE_SYSTEM  
	,Admission.Actual_Discharge_DateTime as DEPARTURE_DATETIME	
	,CAST(NULL as varchar(10)) as PURCHASE_UNIT_CODE	
 	,CASE WHEN Medical_Record.Discharge_Code in ('EDDNW', 'CDUDNW') THEN 'DNW'					
							  ELSE 'ATT' 
	 END as ATTENDANCE_CODE
	,CAST(NULL as varchar(50)) as SNOMED_PRESENTING_COMPLAINT
	,CAST(NULL as varchar(15)) as SNOMED_DIAGNOSIS
	,Medical_Record.Present_Complaint as PRESENTING_COMPLAINT_TEXT
	,CAST(NULL as Date) as BED_BOOKING_DATETIME
	,Admission.Arrival_Mode as ARRIVAL_MODE
	,CAST(NULL as INT) as INAPPROPRIATE_SPACE_MINUTES
FROM 
	 hive_metastore.silver_live.cds_admission 			Admission, current_time																	
LEFT JOIN hive_metastore.silver_live.cds_patient 		Patient			ON Admission.Patient_ID 	= Patient.Patient_ID 					
LEFT JOIN Prioritised_Ethnicity											ON Admission.Patient_ID 	= Prioritised_Ethnicity.Patient_ID
LEFT JOIN hive_metastore.silver_live.cds_movement 		Movement		ON Admission.Admission_ID 	= Movement.Admission_ID				
LEFT JOIN hive_metastore.silver_live.cds_location 		Location		ON Location.Location_ID 	= Movement.Location_ID					
LEFT JOIN hive_metastore.silver_live.cds_ref_hospital 	Hospital		ON Hospital.Hospital_ID 	= Location.Hospital_ID					
LEFT JOIN hive_metastore.silver_live.cds_diagnosis 		Diagnosis		ON Admission.Admission_ID 	= Diagnosis.Admission_ID
LEFT JOIN hive_metastore.silver_live.cds_ref_diagnosis 	REF_Diagnosis	ON Diagnosis.Diagnosis_ID 	= REF_Diagnosis.Diagnosis_ID
LEFT JOIN hive_metastore.silver_live.cds_medical_record	Medical_Record	ON Admission.Admission_ID 	= Medical_Record.Admission_ID
WHERE 1=1
	AND	Admission.Admission_DateTime >= '2020-01-01'	-- Completed IP/ED events from 01-01-2020 is required by Waitemata
--	AND Movement.Movement_Is_Main = 'Y' -- or PA_AdmTransaction.TRANS_Main = 'Y'		-- Only the primary case need to be selected for this extract	
	AND (											-- Select the current inpatient episodes in the hospital
		 Admission.Admission_Type_Code IN  ('E')		
--		 AND Admission.Actual_Discharge_DateTime IS NULL	--AND PAADM_DischgTime IS NULL 
--		 AND Admission.Visit_Status_Code = ('A')	--AND enumList.Code = 'A'
													--AND enumList.ParRef = 'AdmStatus'
		)

""")
