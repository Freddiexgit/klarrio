# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 23 May 2024 | 1       | Janesa R    | Initial Build      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_iocstarship_ced_triage_breaches""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_iocstarship_ced_triage_breaches
AS

WITH EM_Wait_Time as(
select em.NA30minsBreach, em.Triage2Breach, em.Triage3Breach, em.Triage4Breach
from gold_live.vw_pres_l2_em_wait_time em where em.Ward = 'CED'
)

select 'NA > 30 mins' as Category, SUM(NA30minsBreach) as Breach from EM_Wait_Time
union all
select 'Category 2 > 10 mins' as Category, SUM(Triage2Breach) as Breach from EM_Wait_Time
union all
select 'Category 3 > 30 mins' as Category, SUM(Triage3Breach) as Breach from EM_Wait_Time
union all
select 'Category 4 > 1 Hr' as Category, SUM(Triage4Breach) as Breach from EM_Wait_Time

""")

# COMMAND ----------


