# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 28-Mar-2024 | 1       | Siddharth S    | Create first draft of presentation view from cds_medical_record  delta table      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_medical_record""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_medical_record
AS
SELECT 
watermark_value,
UID,
Medical_Record_ID,
Admission_ID,
Present_Complaint,
ICU_Hours,
Discharge_Type_Code,
Discharge_Code,
Transfer_Destination,
Transfer_Means_Desc,
Care_Type_Desc,
CASE WHEN UPPER(Care_Type_Desc) = 'WARD REVIEW' THEN 'WR' ELSE NULL END AS WR,
source_file,
processing_time
FROM 
silver_live.cds_medical_record
""")

# COMMAND ----------


