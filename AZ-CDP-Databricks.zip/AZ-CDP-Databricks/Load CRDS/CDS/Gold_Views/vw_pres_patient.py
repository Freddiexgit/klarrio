# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 28-Mar-2024 | 1       | Siddharth S    | Create first draft of presentation view from cds_patient  delta table      |
# MAGIC | 23-Apr-2024 | 2       | Janesa R       | Update view to get current inpatient and ED patients only                  |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_patient""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_patient
AS

WITH current_datetime AS (
SELECT
    from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
)
SELECT
    DISTINCT
  pt.Patient_ID,
    Patient_NHI,
    Patient_First_Name,
    Patient_Middle_Name,
    Patient_Last_Name,
    Patient_DOB,
    CAST(Patient_Age_Year AS INT),
    CAST(Patient_Age_Month AS INT),
    Patient_Gender_Code,
    Patient_Sex,
    EDC_Agreed_Date,
    Patient_Deceased_Date,
    Patient_Domicile_Code,
    Patient_DHB,
    pt.Patient_Ethnicity,
    Is_Interpreter_Required,
    Preferred_Language,
    AlertFlag,
    40 - CEIL(DATEDIFF(DAY, now, pt.EDC_Agreed_Date) / 7) || '.' || ABS(CEIL(DATEDIFF(DAY, now, pt.EDC_Agreed_Date) % 7)) AS Gesta,
    FLOOR(ROUND(DATEDIFF(HOUR, pt.Patient_DOB, now) / 8766.0, 2)) AS Age,
    DATEDIFF(DAY, now, pt.EDC_Agreed_Date) as Gesta_test,
    concat(Patient_Last_Name, ', ', Patient_First_Name) as Patient_Full_Name,
    pt.source_file,
    pt.processing_time, 
    CASE WHEN eth.Rank = 1 THEN eth.Patient_Ethnicity
	     WHEN Rank BETWEEN 2 AND 9 THEN 'Pacific' ELSE 'Other' END as Patient_Ethnicity_Group
FROM
    silver_live.cds_patient pt,
    current_datetime
LEFT JOIN silver_live.cds_admission ad ON
    ad.Patient_ID = pt.Patient_ID
LEFT JOIN silver_live.cds_ref_patient_ethnicity eth ON
    eth.Patient_ID = pt.Patient_ID
    AND eth.Priority = '1'
WHERE
    ad.Admission_Type_Code IN ('I', 'E')
    AND ad.Actual_Discharge_DateTime IS NULL
    AND ad.Visit_Status_Code IN ('A', 'P')
    AND pt.Patient_NHI <> 'MBP0603' -- filter out wrong Patient_DOB for now
  
""")

# COMMAND ----------


