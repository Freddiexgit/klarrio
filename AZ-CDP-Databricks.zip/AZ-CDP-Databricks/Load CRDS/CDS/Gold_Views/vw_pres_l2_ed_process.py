# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 03-May-2024 | 1       | Janesa R       | Created vw_pres_l2_ed_process                         |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_l2_ed_process""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_l2_ed_process
AS

----Order has been changed
SELECT
    Ward,
		CASE AEDStage
	    WHEN 'AwaitingAmbulatoryOffload' THEN "Awaiting Ambulatory Offload"
		When 'AEDAwaitingPlacement' Then "AED Awaiting Placement"
		When 'Waiting' Then "Waiting"
		WHEN 'AwaitingEMSignon' THEN "Awaiting EM Signon"
		WHEN 'AwaitingEDDecision' THEN "Awaiting ED Decision"
		WHEN 'AwaitingIPSignon' THEN "Awaiting IP Signon" 
		WHEN 'ShortStayPatient' THEN "Short Stay Patients"
		WHEN 'ShortStay' THEN "Short Stay"
		WHEN 'CDUScheduled' THEN "CDU Scheduled"
		WHEN 'BedRequestActive' THEN "Bed Request Active"
		WHEN 'BedReady' THEN "Bed Ready"
		WHEN 'BedRequestAccepted'THEN "Bed Request Accepted"
	END as EDStage,
	Sum(PatientCount) AS PatientCount,
	CASE AEDStage
	    WHEN 'AwaitingAmbulatoryOffload' THEN 1
		When 'AEDAwaitingPlacement' Then 2
		When 'Waiting' Then 3
		WHEN 'AwaitingEMSignon' THEN 3
		WHEN 'AwaitingEDDecision' THEN 4
		WHEN 'ShortStayPatient' THEN 5
		WHEN 'ShortStay'        THEN 5
		WHEN 'AwaitingIPSignon' THEN 6
		WHEN 'CDUScheduled' THEN 7
		WHEN 'BedRequestActive' THEN 8
		WHEN 'BedRequestAccepted'THEN 9
		WHEN 'BedReady' THEN 10
	END as EDStageOrder,
    Case When (AEDStage = 'AwaitingAmbulatoryOffload' and sum(PatientCount) >= 15) or (AEDStage IN ('AEDAwaitingPlacement','CEDAwaitingPlacement') and sum(PatientCount) >= 15) or (AEDStage = 'AwaitingEMSignon' and sum(PatientCount) >= 30) Then '#ED1010'
	   	  Else '#4875AF'
		  End as RAGColour
    From 
(
Select Ward,
AEDStage,
PAtientCount
from 
(
Select
Ward,
AdmissionNumber,
BedRequestActive,
BedRequestAccepted,
BedReady,
CDUScheduled,
AwaitingAmbulatoryOffload,
AEDAwaitingPlacement,
Waiting,
ShortStayPatient,
ShortStay,
AwaitingEMSignon,
CASE 
    WHEN AwaitingEMSignon = 0 
         AND BedRequestActive = 0 
         AND BedRequestAccepted = 0 
         AND SSFlag = 'N' 
         AND Medical_Discharge_DateTime IS NULL 
         AND (Current_Clinician IS NOT NULL
              OR RMC IS NOT NULL
              OR Emergency_Consultant IS NOT NULL)
         AND Movement_End_Datetime IS NULL
         AND CBU IN ('Emergency Medicine', 'Adult Emergency Department',"Children's Emergency Medicine")  
    THEN 1 
    ELSE 0 
  END AS AwaitingEDDecision,
  AwaitingIPSignon
from
(  
WITH currenttime AS (
    SELECT from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
  ),
  wt AS (
    SELECT 
      ad.Admission_ID as AdmissionID,
      ad.Admission_Number as AdmissionNumber,
      ad.Inpatient_Short_Stay_Intent,
      loc.Location_Code as CurrWard,
      r.Room_Code,
      ad.Actual_Arrival_DateTime,
      ad.Ambul_Handover_Comp_DateTime,
      mv2.Movement_End_Datetime
    FROM hive_metastore.silver_live.cds_admission ad
    LEFT JOIN hive_metastore.silver_live.cds_movement mv2 ON ad.Admission_ID = mv2.Admission_ID
    LEFT JOIN hive_metastore.silver_live.cds_location loc ON mv2.Location_ID = loc.Location_ID
    LEFT JOIN hive_metastore.silver_live.cds_ref_room r ON mv2.Room_ID = r.Room_ID
    WHERE mv2.Movement_Type = 'Ward Transfer'
      AND mv2.Movement_End_Datetime IS NULL
  )
  SELECT
    wt.CurrWard AS Ward,
    loc1.Location_Code,
    ad.Admission_Number AS AdmissionNumber,
    ad.Arrival_Mode,
    ad.Actual_Arrival_DateTime,
    pat.Patient_NHI,
    mv1.CBU,
    mv1.Current_Clinician,
    mv1.RMC,
    mv1.Emergency_Consultant,
    mv1.Movement_Status,
    mv1.Movement_Type,
    mv1.Movement_End_Datetime,
    ad.Medical_Discharge_DateTime,
    ad.Inpatient_Short_Stay_Intent,
    currenttime.now,
    CASE 
      WHEN wt.Inpatient_Short_Stay_Intent = 'Y' OR wt.Room_Code IN ('SS1','SS2','SS3','SS4','SS5') THEN 'Y' 
      ELSE 'N' 
    END AS SSFlag,
    CASE 
      WHEN mv1.Movement_Type = 'Bed Request' 
           AND mv1.Movement_Status = 'Requested' 
           AND (loc1.Location_Code <> 'CDU' OR loc1.Location_Code IS NULL) 
      THEN 1 
      ELSE 0 
    END AS BedRequestActive,
    CASE 
      WHEN mv1.Movement_Type = 'Bed Request' 
           AND mv1.Movement_Status = 'Accepted' 
           AND (loc1.Location_Code <> 'CDU' OR loc1.Location_Code IS NULL)  
      THEN 1 
      ELSE 0 
    END AS BedRequestAccepted,
    CASE 
      WHEN mv1.Movement_Type = 'Bed Request' 
           AND mv1.Movement_Status = 'Accepted' 
           AND DATEDIFF(Hour, mv1.Movement_Start_Datetime, currenttime.now) > 1 
      THEN 1 
      ELSE 0 
    END AS BedReady,
    CASE 
      WHEN mv1.Movement_Type = 'Bed Request' 
           AND loc1.Location_Code = 'CDU' 
           AND mv1.Movement_Status IN ('Requested', 'Accepted') 
      THEN 1 
      ELSE 0 
    END AS CDUScheduled,
    CASE 
      WHEN (wt.Room_Code IS NULL 
            AND ad.Ambul_Handover_Comp_DateTime IS NULL  
            AND mv1.Movement_Type = 'Ward Transfer' 
            AND mv1.Movement_End_Datetime IS NULL 
            AND mr.Transfer_Means_Desc = 'Ambulance') 
           OR (wt.Room_Code = 'STJ' 
               --AND ad.Ambul_Handover_Comp_DateTime IS NULL  
               AND mv1.Movement_Type = 'Ward Transfer' 
               AND mv1.Movement_End_Datetime IS NULL 
               --AND mr.Transfer_Means_Desc LIKE '%Ambulance%'
               ) 
              OR (wt.Room_Code IS NULL 
            AND ad.Ambul_Handover_Comp_DateTime IS NOT NULL  
            AND mv1.Movement_Type = 'Ward Transfer' 
            AND mv1.Movement_End_Datetime IS NULL 
            AND mr.Transfer_Means_Desc = 'Ambulance')  
               
      THEN 1 
      ELSE 0 
    END AS AwaitingAmbulatoryOffload,
    CASE 
      WHEN r1.Room_Code IN (  'R', 'MR', 'ACUTE','AMB') 
           AND mv1.Movement_End_Datetime IS NULL 
      THEN 1 
      ELSE 0 
    END AS AEDAwaitingPlacement,
    CASE 
      WHEN (r1.Room_Code IN ('WAIT', 'EDWait', 'GWAIT', 'WR') or r1.Room_Code is null)
           AND mv1.Movement_End_Datetime IS NULL 
           AND mv1.Movement_Type = 'Ward Transfer'
      THEN 1 
      ELSE 0 
    END AS Waiting,
    CASE 
      WHEN wt.Inpatient_Short_Stay_Intent = 'Y' 
           AND mv1.Movement_Type = 'Ward Transfer' 
           AND mv1.Movement_End_Datetime IS NULL  
           OR (wt.Room_Code IN ('SS1', 'SS2', 'SS3', 'SS4', 'SS5') 
               AND (wt.Inpatient_Short_Stay_Intent <> 'N' 
                    OR wt.Inpatient_Short_Stay_Intent IS NULL)   
               AND mv1.Movement_Type = 'Ward Transfer' 
               AND mv1.Movement_End_Datetime IS NULL) 
      THEN 1 
      ELSE 0 
    END AS ShortStayPatient,
     CASE 
      WHEN wt.Inpatient_Short_Stay_Intent = 'Y' 
           AND mv1.Movement_Type = 'Ward Transfer' 
           AND mv1.Movement_End_Datetime IS NULL  
      THEN 1 
      ELSE 0 
    END AS ShortStay,
    CASE 
      WHEN mv1.Movement_Type = 'Case Transfer' 
           AND mv1.Current_Clinician IS NULL 
           AND mv1.RMC IS NULL
           AND mv1.Emergency_Consultant is NULL
           AND mv1.CBU IN ('Emergency Medicine', 'Adult Emergency Department', "Children's Emergency Medicine") 
           AND mv1.Movement_End_Datetime IS NULL 
      THEN 1 
      ELSE 0 
    END AS AwaitingEMSignon,
    CASE 
      WHEN mv1.Movement_Type = 'Case Transfer' 
           AND mv1.Specialty NOT IN ('Adult Emergency Dept', 'Clinical Decision Unit', 'Child Emergency Dept') 
           AND mv1.Current_Clinician = 'Awaiting IP clinician Sign on' 
           AND mv1.Movement_End_Datetime IS NULL 
           --AND mv1.Movement_Is_Main = 'Y'
           OR (mv1.Movement_Type = 'Case Transfer' 
               AND mv1.Movement_End_Datetime IS NULL 
               AND mv1.Specialty NOT IN ('Adult Emergency Dept', 'Clinical Decision Unit', 'Child Emergency Dept') 
               AND mv1.Current_Clinician IS NULL) 
      THEN 1 
      ELSE 0 
    END AS AwaitingIPSignon
  FROM hive_metastore.silver_live.cds_admission ad
  JOIN currenttime ON 1=1
  LEFT JOIN hive_metastore.silver_live.cds_medical_record mr ON ad.Admission_ID = mr.Admission_ID
  LEFT JOIN hive_metastore.silver_live.cds_movement mv1 ON ad.Admission_ID = mv1.Admission_ID
  LEFT JOIN hive_metastore.silver_live.cds_location loc1 ON mv1.Location_ID = loc1.Location_ID
  LEFT JOIN hive_metastore.silver_live.cds_patient pat ON ad.Patient_ID = pat.Patient_ID
  LEFT JOIN hive_metastore.silver_live.cds_ref_room r1 ON mv1.Room_ID = r1.Room_ID
  LEFT JOIN wt ON wt.AdmissionID = mv1.Admission_ID
  WHERE wt.CurrWard IN ('AED', 'CED')
    AND ad.Visit_Status_Code = 'A'
) as Q1
) as Q2
UNPIVOT 
	(
		PatientCount FOR AEDStage IN (BedRequestActive,BedRequestAccepted, BedReady, CDUScheduled, AwaitingAmbulatoryOffload, AEDAwaitingPlacement,Waiting,ShortStayPatient,ShortStay,AwaitingEMSignon, AwaitingEDDecision,AwaitingIPSignon)
	) AS UP
)as Q3
GROUP BY
    Ward,
    AEDStage
UNION --------------To get the available beds for CED
Select 
        Ward,
    "Available Beds" as EDStage,
	CEDAvailable AS PatientCount,
	"1" as EDStageOrder,
    NULL as RAGColour
    From 
(
select CurrWard as Ward,
Round(( ApprovedBeds - OccupiedBeds)) as CEDAvailable
from (
select wt.CurrWard, count(distinct(mv1.Bed_ID)) as OccupiedBeds, AVG(loc1.Approved_Beds) as ApprovedBeds
from hive_metastore.silver_live.cds_admission ad
left join hive_metastore.silver_live.cds_movement mv1 on ad.Admission_ID = mv1.Admission_ID
left join hive_metastore.silver_live.cds_location loc1 on mv1.Location_ID = loc1.Location_ID
left join hive_metastore.silver_live.cds_ref_bed bed on bed.Bed_ID = mv1.Bed_ID
left join 
(
    select 
        ad.Admission_ID as AdmissionID,
        ad.Admission_Number as AdmissionNumber,
        ad.Inpatient_Short_Stay_Intent,
        loc.Location_Code as CurrWard,
        r.Room_Code,
        ad.Actual_Arrival_DateTime,
        ad.Ambul_Handover_Comp_DateTime,
        mv2.Movement_End_Datetime
    from hive_metastore.silver_live.cds_admission ad
    left join hive_metastore.silver_live.cds_movement mv2 on ad.Admission_ID = mv2.Admission_ID
    left join hive_metastore.silver_live.cds_location loc on mv2.Location_ID = loc.Location_ID
    left join hive_metastore.silver_live.cds_ref_room r on mv2.Room_ID = r.Room_ID
    where mv2.Movement_Type = 'Ward Transfer'
      and mv2.Movement_End_Datetime is null
) wt on wt.AdmissionID = mv1.Admission_ID
where 1 = 1
  and ad.Admission_Type_Code = 'E'
  and wt.CurrWard IN ('CED')
  and ad.Visit_Status_Code = 'A'
 group by wt.CurrWard
 )Q1
 )Q2
 Order by Ward,EDStageOrder Asc

""")

# COMMAND ----------


