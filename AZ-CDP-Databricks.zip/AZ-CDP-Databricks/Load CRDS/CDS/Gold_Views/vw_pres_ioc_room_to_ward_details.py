# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 9 May-2024 | 1       | Janesa R    | Create first draft of presentation view for room without beds      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_ref_room_to_ward_details""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_ioc_room_to_ward_details
AS

select 
--rm.watermark_value
rm.UID
, rm.Room_ID
, Room_Code
, Room_Desc
, Room_Type_Code
, ROOM_Query
, Room_Description
, Ward_Code
, WARD_Desc
, wd.IOC_Ward_Type as IOC_RoomToWard_Type
 , case when wd.Ward_Code = 'AED'
       then
              case when rm.Room_Code like 'OBS%' then 'Acute'
                     when rm.Room_Code like 'AMB%' then 'Ambulatory'
                     when rm.Room_Code like 'CON%' then 'Consult'
                     when rm.Room_Code like 'M%' then 'Monitored'
                     when rm.Room_Code like 'PRO%' then 'Procedure'
                     when rm.Room_Code like 'R%' then 'Resus'
                     when rm.Room_Code like 'SS%' then 'Short Stay'
              else 'Acute' end
       else case when wd.Ward_code = 'CED' then 
	            case when rm.Room_Code like 'RR%' then 'CED Resus'
                     when rm.Room_Code in ('8P','9P','10P','11P','12P' ) then 'CED Central Monitored'
                     when rm.Room_Code in ('1P','4P','5P','INT1') then 'CED Immunocompromised'
                     when rm.Room_Code in ('14P','15P') then 'CED Isolation'
                     when rm.Room_Code in ('2P','3P','6P','7P','13A','13B','13C','13D','13E','13F','13G','13H') then 'CED Acute' end 
                    
            else null end
       end as LevelTwoZone
from hive_metastore.silver_live.cds_ref_room rm
left outer join (select room_id, ward_id from  hive_metastore.silver_live.cds_ref_ward_room
group by  room_id, ward_id) wr on wr.Room_ID = rm.Room_ID
left outer join hive_metastore.gold_live.vw_pres_ref_ward wd on wd.Ward_ID = wr.Ward_ID
--where Room_Description in ('Multi Patient Room', 'Booked Area') 


""")

# COMMAND ----------


