# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 13-May-2024 | 1       | Janesa R    | Initial build of TrendCare Staff Level view |
# MAGIC

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_trendcare_staff_level""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_trendcare_staff_level
AS

WITH current_time AS (
  SELECT from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
),

tbl as(
	SELECT 
	SummaryShiftStaff.ssDate AS Date
	, CASE 
		WHEN DATE_PART('Hour', CAST(now AS DATE)) < 7 THEN DATE_Add(day, (datediff(day, TIMESTAMP'1900-01-01', CAST(now AS DATE) - 1)), TIMESTAMP'1900-01-01')
		ELSE Date_Add(day, datediff(day, TIMESTAMP'1900-01-01', CAST(now AS DATE)),  TIMESTAMP'1900-01-01')
	  END AS CurrentShiftDate
	, RTRIM(Ward.wdName) AS WardName
	, RTRIM(SummaryShiftStaff.ssTitle) AS TitleCode
	, RTRIM(TATitles.leName) AS Title
	, SummaryShiftStaff.ssWorkStatusCode AS WorkStatusCode
	, RTRIM(TAWorkStatus.wsName) AS StaffType
	, Staff.stSurname + ', ' + Staff.stGivenNames AS StaffName
	, Staff.stSurname As StaffLastName
	, Staff.stGivenNames As StaffFirstName
	, SummaryShiftStaff.ssShiftCode AS ShiftCode
	, CAST(SummaryShiftStaff.ssWardCode AS INT) AS TCWardCode
	, SummaryShiftStaff.ssStaffCode AS StaffCode
	, RTRIM(SummaryShiftStaff.ssMajorLevel) AS MajorLevel
	, SummaryShiftStaff.ssStartTime AS StartTime
	, SummaryShiftStaff.ssShortComment AS ShortComment
	, SummaryShiftStaff.ssIsInCharge AS IsInCharge
	, SummaryShiftStaffArea.saStaffingAreaCode AS StaffingAreaCode
	, SummaryShiftStaffArea.saHours AS Hours
	, RTRIM(TAStaffingArea.arDescription) AS StaffingAreaDescription
	, TAStaffingArea.arClassification AS Classification
--	, LEFT(CAST(SummaryShiftStaff.ssDate AS VARCHAR(120)), 10)  + '_' +  Ward.wdWardCode + '_' + SummaryShiftStaff.ssShiftCode  AS DateWardShift
 	, CONCAT(LEFT(CAST(SummaryShiftStaff.ssDate AS VARCHAR(120)), 10)  , '_' ,  Ward.wdWardCode , '_' , SummaryShiftStaff.ssShiftCode)  AS DateWardShift
	, '' AS Blank  -- For formatting in the report
FROM silver_live.cds_trc_summaryshiftstaff AS SummaryShiftStaff, current_time
JOIN silver_live.cds_trc_ward AS Ward ON SummaryShiftStaff.ssWardCode = Ward.wdWardCode
JOIN silver_live.cds_ref_cct  WardCCT ON substring(WardCCT.code, 1, 3) = Ward.wdWardCode and WardCCT.name = 'IOC Trendcare Wards Staff Level'
JOIN silver_live.cds_trc_taworkstatus AS TAWorkStatus ON SummaryShiftStaff.ssWorkStatusCode = TAWorkStatus.wsWorkStatusCode
JOIN silver_live.cds_trc_tatitles AS TATitles ON SummaryShiftStaff.ssTitle = TATitles.leTitle
JOIN silver_live.cds_trc_staff AS Staff ON SummaryShiftStaff.ssStaffCode = Staff.stStaffCode
JOIN silver_live.cds_trc_summaryshiftstaffarea AS SummaryShiftStaffArea  ON 
	(SummaryShiftStaff.ssStaffCode  = SummaryShiftStaffArea.saStaffCode
	AND SummaryShiftStaff.ssDate  = SummaryShiftStaffArea.saDate
	AND SummaryShiftStaff.ssShiftCode  = SummaryShiftStaffArea.saShiftCode
	AND SummaryShiftStaffArea.saWardCode = SummaryShiftStaff.ssWardCode)
JOIN silver_live.cds_trc_tastaffingarea AS TAStaffingArea ON SummaryShiftStaffArea.saStaffingAreaCode = TAStaffingArea.arStaffingAreaCode
WHERE ssDate >= DATE_Add(day, (datediff(day, TIMESTAMP'1900-01-01',  now) - 1), TIMESTAMP'1900-01-01')
)

SELECT
	Date
	, CurrentShiftDate as Current_Shift_Date
	, WardName as Ward_Name
	,'Res ' + TitleCode + ' ' + StaffFirstName +' ' + StaffLastName AS Resource_Staff_Name
	, TitleCode as Title_Code
	, Title
	, WorkStatusCode as Work_Status_Code
	, StaffType as Staff_Type
	, StaffLastName as Staff_Last_Name
	, StaffFirstName as Staff_First_Name
	, StaffName as Staff_Name
	, ShiftCode as Shift_Code
	, TCWardCode as TC_Ward_Code
	, StaffCode as Staff_Code
	, MajorLevel as Major_Level
	, StartTime
	, ShortComment as Short_Comment
	, IsInCharge as IsInCharge
	, StaffingAreaCode as Staffing_Area_Code
	, Hours
	, StaffingAreaDescription as Staffing_Area_Description
	, Classification
	, DateWardShift as Ward_Shift_Date
	, Blank
FROM tbl
WHERE Date = DATE_Add(day, (datediff(day, TIMESTAMP'1900-01-01', tbl.CurrentShiftDate)), TIMESTAMP'1900-01-01')   -- Restrict to the date the night shift is part of. 


UNION ALL

SELECT '2099-01-01 00:00:00.000',NULL,NULL,NULL,'HCA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'Sick',NULL,'2099-01-01_203_D',NULL

UNION ALL

SELECT '2099-01-01 00:00:00.000',NULL,NULL,NULL,'HCA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'Clinical In Department',NULL,'2099-01-01_203_D',NULL

UNION ALL

SELECT '2099-01-01 00:00:00.000',NULL,NULL,NULL,'HCA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'Bereavement Leave',NULL,'2099-01-01_203_D',NULL


UNION ALL

SELECT NULL,NULL,NULL,NULL,'EN_',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL

UNION ALL

SELECT NULL,NULL,NULL,NULL,'HCA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL

UNION ALL

SELECT NULL,NULL,NULL,NULL,'RN',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL




""")
