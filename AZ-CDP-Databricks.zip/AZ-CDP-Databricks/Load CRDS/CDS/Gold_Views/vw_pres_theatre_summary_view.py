# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 15 Aug 2024 | 1       | Janesa R    | Initial draft      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_theatre_summary_view""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_theatre_summary_view
AS

WITH current_time AS (
    SELECT from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
)

SELECT
    cts.Session_Id,
    cl2.Location_Code AS TheatreSuite,
    cts.Theatre_Code AS TheatreCode,

    CASE
        WHEN cts.Session_Date BETWEEN date_trunc('week', now) AND date_trunc('week', date_add(now, 7)) THEN 'Current Week'
        WHEN cts.Session_Date BETWEEN date_trunc('week', date_add(now, 7)) AND date_trunc('week', date_add(now, 14)) THEN 'T-1'
        WHEN cts.Session_Date BETWEEN date_trunc('week', date_add(now, 14)) AND date_trunc('week', date_add(now, 21)) THEN 'T-2'
        WHEN cts.Session_Date BETWEEN date_trunc('week', date_add(now, 21)) AND date_trunc('week', date_add(now, 28)) THEN 'T-3'
        WHEN cts.Session_Date BETWEEN date_trunc('week', date_add(now, 28)) AND date_trunc('week', date_add(now, 35)) THEN 'T-4'
        WHEN cts.Session_Date BETWEEN date_trunc('week', date_add(now, 35)) AND date_trunc('week', date_add(now, 42)) THEN 'T-5'
        WHEN cts.Session_Date BETWEEN date_trunc('week', date_add(now, 42)) AND date_trunc('week', date_add(now, 49)) THEN 'T-6'
    END AS WeekNumber,

    CASE
        WHEN cts.Session_Date BETWEEN date_trunc('week', now) AND date_trunc('week', date_add(now, 7)) THEN concat(cl.Location_Desc, '_', cts.Session_Type, '_1')
        WHEN cts.Session_Date BETWEEN date_trunc('week', date_add(now, 7)) AND date_trunc('week', date_add(now, 14)) THEN concat(cl.Location_Desc, '_', cts.Session_Type, '_2')
        WHEN cts.Session_Date BETWEEN date_trunc('week', date_add(now, 14)) AND date_trunc('week', date_add(now, 21)) THEN concat(cl.Location_Desc, '_', cts.Session_Type, '_3')
        WHEN cts.Session_Date BETWEEN date_trunc('week', date_add(now, 21)) AND date_trunc('week', date_add(now, 28)) THEN concat(cl.Location_Desc, '_', cts.Session_Type, '_4')
        WHEN cts.Session_Date BETWEEN date_trunc('week', date_add(now, 28)) AND date_trunc('week', date_add(now, 35)) THEN concat(cl.Location_Desc, '_', cts.Session_Type, '_5')
        WHEN cts.Session_Date BETWEEN date_trunc('week', date_add(now, 35)) AND date_trunc('week', date_add(now, 42)) THEN concat(cl.Location_Desc, '_', cts.Session_Type, '_6')
        WHEN cts.Session_Date BETWEEN date_trunc('week', date_add(now, 42)) AND date_trunc('week', date_add(now, 49)) THEN concat(cl.Location_Desc, '_', cts.Session_Type, '_7')
    END AS StaticWeekNumber_Key,

    CAST(date_format(cts.Session_DateTime, 'yyyyMMdd') AS CHAR(8)) AS Session_Start_Date_Key,
    cts.Session_Date AS SessionDate,
    cts.AMPM AS AMPM,
    cts.Session_Start_Time AS SessionStartTime,
    cts.Session_End_Time AS SessionEndTime,
    cl.Location_Desc AS SessionSpecialty,
    cts.Session_Type,
    cts.Session_Consultant AS SessionConsultant,

    MAX(DATEDIFF(MINUTE, cts.Session_Start_Time, cts.Session_End_Time)) AS SessionDuration,
    SUM(DATEDIFF(MINUTE, ca.Appointment_Start_Time, ca.Appointment_End_Time)) AS BookedMins,
    MAX(DATEDIFF(MINUTE, cts.Session_Start_Time, cts.Session_End_Time)) - SUM(DATEDIFF(MINUTE, ca.Appointment_Start_Time, ca.Appointment_End_Time)) AS AvailableMins,
    SUM(DATEDIFF(MINUTE, ca.Appointment_Start_Time, ca.Appointment_End_Time)) / MAX(DATEDIFF(MINUTE, cts.Session_Start_Time, cts.Session_End_Time)) * 100 AS BookedPercent

FROM 
    silver_live.cds_theatre_session cts
    LEFT OUTER JOIN silver_live.cds_location cl ON cl.Location_ID = cts.Specialty_Location_ID
    LEFT OUTER JOIN silver_live.cds_location cl2 ON cl2.Location_ID = cts.Location_ID
    LEFT OUTER JOIN silver_live.cds_movement cm ON cm.Location_ID = cts.Location_ID AND cm.Movement_Type IN ('THEATRE BOOKING')
    LEFT OUTER JOIN silver_live.cds_appointment ca ON ca.Session_ID = cts.Session_Id,
    current_time

GROUP BY
    cts.Session_Id,
    cl2.Location_Code,
    cts.Theatre_Code,
    cts.Session_Date,
    cts.AMPM,
    cts.Session_Type,
    cts.Session_DateTime,
    cts.Session_Start_Time,
    cts.Session_End_Time,
    cl.Location_Desc,
    cts.Session_Consultant,
    now


""")

# COMMAND ----------


