# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 20-May-2024 | 1       | Janesa R    | Initial build      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_l2_em_wait_time""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_l2_em_wait_time
AS

WITH currenttime AS 
(
    SELECT from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
),
wt AS
(
    SELECT 
        ad.Admission_ID AS AdmissionID,
        ad.Admission_Number AS AdmissionNumber,
        loc.Location_Code AS CurrWard,
        mv2.Movement_End_Datetime
    FROM hive_metastore.silver_live.cds_admission ad
    LEFT JOIN hive_metastore.silver_live.cds_movement mv2 
        ON ad.Admission_ID = mv2.Admission_ID
    LEFT JOIN hive_metastore.silver_live.cds_location loc 
        ON mv2.Location_ID = loc.Location_ID
    WHERE mv2.Movement_Type = 'Ward Transfer'
      AND mv2.Movement_End_Datetime IS NULL
),
br AS 
(
    SELECT
        ad.Admission_ID AS AdmissionID,
        ad.Admission_Number AS AdmissionNumber,
        loc.Location_Code AS SchWard,
        mv2.Movement_Start_Datetime AS BRStartDatetime,
        mv2.Movement_End_Datetime AS BREndDatetime
    FROM hive_metastore.silver_live.cds_admission ad
    LEFT JOIN hive_metastore.silver_live.cds_movement mv2 
        ON ad.Admission_ID = mv2.Admission_ID
    LEFT JOIN hive_metastore.silver_live.cds_location loc 
        ON mv2.Location_ID = loc.Location_ID
    WHERE mv2.Movement_Type = 'Bed Request'
)
SELECT
    CurrWard AS Ward,
    CBU,
    Admission_Number,
    Patient_NHI,
    Admission_DateTime,
    ClockStartDatetime,
    ClockEndDatetime,
    Handover_Start_DateTime,
    HOHWaitTimeMins,
    Clinician_Seen_DateTime,
    TriageCode,
    EMSignon,
    currentday,
    now,
    DATEDIFF(MINUTE, ClockStartDatetime, ClockEndDatetime) AS Triage2EMWaitTime,
    CASE 
        WHEN EMSignon = 'N' AND CurrWard IN ('AED') THEN DATEDIFF(MINUTE, ClockStartDatetime, ClockEndDatetime) ELSE 0 End AS EMMedianMins,
    CASE 
        WHEN EMSignon = 'N' AND CurrWard IN ('AED', 'CED') THEN EMWaitTime 
        ELSE 0
    END AS `EM Wait Time`,
    EDLOSMins,
    ROUND(EDLOS) AS `ED LOS Hours`,
    DATEDIFF(Hour, BedRequestStartDatetime, BedRequestEndDatetime) AS `BR to ED Leave`,
    DATEDIFF(Hour, CDUBRStartDatetime, CDUBREndDatetime) AS `BR to CDULeave`,
    CASE 
        WHEN NurseSignon = 'N'
             AND Movement_End_Datetime is NULL
             AND TriageCode IN ('3', '4', '5', '6') 
             AND HOHWaitTimeMins > 30 THEN '1'
        ELSE 0
    END AS NA30minsBreach,
    CASE 
        WHEN TriageCode = 2
             --AND Movement_End_Datetime is NULL
             AND DATEDIFF(MINUTE, ClockStartDatetime, ClockEndDatetime) <= 10 THEN '1'
        ELSE '0'
    END AS Triage2Compliant,
    CASE 
        WHEN EMSignon = 'N'
            -- AND Movement_End_Datetime is NULL
             AND TriageCode = 2 
             AND EMWaitTimeMins > 10 THEN '1'
        ELSE '0'
    END AS Triage2Breach,
    CASE 
        WHEN EMSignon = 'N'
            -- AND Movement_End_Datetime is NULL
             AND TriageCode = 3 
             AND EMWaitTimeMins > 30 THEN '1'
        ELSE '0'
    END AS Triage3Breach,
    CASE 
        WHEN EMSignon = 'N'
           --  AND Movement_End_Datetime is NULL
             AND TriageCode IN ('4', '5', '6') 
             AND EMWaitTimeMins > 60 THEN '1'
        ELSE '0'
    END AS Triage4Breach
FROM (
    SELECT
        ad.Admission_Number,
        pat.Patient_NHI,
        wt.CurrWard,
        mv1.CBU,
        mv1.Current_Clinician,
        mv1.RMC,
        ad.Triage_Code AS TriageCode,
        mr.Discharge_Code,
        mv1.Movement_Type,
        ad.Medical_Discharge_DateTime,
        ad.Clinician_Seen_DateTime,
        ad.Intent_DateTime,
        ad.Admission_DateTime,
        ad.Admission_DateTime AS ClockStartDatetime,
        mv1.Movement_Start_Datetime,
        mv1.Movement_End_Datetime,
        Handover_Start_DateTime,
        DATE_TRUNC('DAY', currenttime.now) as currentday,
        currenttime.now,
        CASE 
            WHEN ad.Clinician_Seen_DateTime IS NOT NULL THEN 'Y'
            ELSE 'N'
        END AS EMSignon,
         CASE 
            WHEN ad.Nurse is Not Null OR ad.Handover_Start_DateTime IS NOT NULL THEN 'Y'
            ELSE 'N'
        END AS NurseSignon,
        CASE 
            WHEN ad.Clinician_Seen_DateTime IS NOT NULL THEN ad.Clinician_Seen_DateTime
            ELSE DATEADD(HOUR, 12, CURRENT_TIMESTAMP)
        END AS ClockEndDatetime,
        ROUND(
            CASE 
                WHEN mv1.Current_Clinician IS NULL THEN DATEDIFF(MINUTE, mv1.Movement_Start_Datetime, DATEADD(HOUR, 12, CURRENT_TIMESTAMP)) / 60.0
                ELSE DATEDIFF(MINUTE, mv1.Movement_Start_Datetime, ad.Clinician_Seen_DateTime) / 60.0
            END
        ) AS EMWaitTime,
        ROUND(
            CASE 
                WHEN mv1.Current_Clinician IS NULL THEN DATEDIFF(MINUTE, mv1.Movement_Start_Datetime, DATEADD(HOUR, 12, CURRENT_TIMESTAMP))
                ELSE DATEDIFF(MINUTE, mv1.Movement_Start_Datetime, ad.Clinician_Seen_DateTime)
            END
        ) AS EMWaitTimeMins,
         ROUND(
            CASE 
                WHEN ad.Nurse IS NULL THEN DATEDIFF(MINUTE, mv1.Movement_Start_Datetime, DATEADD(HOUR, 12, CURRENT_TIMESTAMP))
                ELSE DATEDIFF(MINUTE, mv1.Movement_Start_Datetime, ad.Handover_Start_DateTime)
            END
        ) AS HOHWaitTimeMins,
        ROUND(
            CASE 
                WHEN ad.Actual_Discharge_DateTime IS NULL 
                     AND ad.Medical_Discharge_DateTime IS NULL 
                     AND (ad.Intent_DateTime IS NULL OR ad.Intent_DateTime < ad.Admission_DateTime) THEN DATEDIFF(MINUTE, ad.Admission_DateTime, DATEADD(HOUR, 12, CURRENT_TIMESTAMP)) / 60.0
                WHEN ad.Actual_Discharge_DateTime IS NOT NULL THEN DATEDIFF(MINUTE, ad.Admission_DateTime, ad.Actual_Discharge_DateTime) / 60.0
                WHEN ad.Medical_Discharge_DateTime IS NOT NULL THEN DATEDIFF(MINUTE, ad.Admission_DateTime, ad.Medical_Discharge_DateTime) / 60.0
                WHEN ad.Inpatient_Short_Stay_Intent = 'Y' 
                     AND ad.Intent_DateTime IS NOT NULL 
                     AND ad.Intent_DateTime > ad.Admission_DateTime THEN DATEDIFF(MINUTE, ad.Admission_DateTime, ad.Intent_DateTime) / 60.0
            END
        ) AS EDLOS,
          ROUND(
            CASE 
                WHEN ad.Actual_Discharge_DateTime IS NULL 
                     AND ad.Medical_Discharge_DateTime IS NULL 
                     AND (ad.Intent_DateTime IS NULL OR ad.Intent_DateTime < ad.Admission_DateTime) THEN DATEDIFF(MINUTE, ad.Admission_DateTime, DATEADD(HOUR, 12, CURRENT_TIMESTAMP))
                WHEN ad.Actual_Discharge_DateTime IS NOT NULL THEN DATEDIFF(MINUTE, ad.Admission_DateTime, ad.Actual_Discharge_DateTime)
                WHEN ad.Medical_Discharge_DateTime IS NOT NULL THEN DATEDIFF(MINUTE, ad.Admission_DateTime, ad.Medical_Discharge_DateTime)
                WHEN ad.Inpatient_Short_Stay_Intent = 'Y' 
                     AND ad.Intent_DateTime IS NOT NULL 
                     AND ad.Intent_DateTime > ad.Admission_DateTime THEN DATEDIFF(MINUTE, ad.Admission_DateTime, ad.Intent_DateTime)
            END
        ) AS EDLOSMins,
        br.BRStartDatetime AS BedRequestStartDatetime,
        CASE 
            WHEN ad.Actual_Discharge_DateTime IS NULL THEN br.BREndDatetime
            ELSE ad.Actual_Discharge_DateTime
        END AS BedRequestEndDatetime,
        CASE 
            WHEN wt.CurrWard = 'CDU' AND br.AdmissionID IS NOT NULL THEN br.BRStartDatetime 
        END AS CDUBRStartDatetime,
        CASE 
            WHEN wt.CurrWard = 'CDU' AND br.AdmissionID IS NOT NULL 
                 AND br.BREndDatetime IS NULL THEN DATEADD(HOUR, 12, CURRENT_TIMESTAMP) 
            ELSE br.BREndDatetime 
        END AS CDUBREndDatetime,
        wt.CurrWard,
        mv1.CBU
    FROM hive_metastore.silver_live.cds_admission ad
    JOIN currenttime ON 1 = 1
    LEFT JOIN hive_metastore.silver_live.cds_medical_record mr 
        ON ad.Admission_ID = mr.Admission_ID
    LEFT JOIN hive_metastore.silver_live.cds_movement mv1 
        ON ad.Admission_ID = mv1.Admission_ID
    LEFT JOIN hive_metastore.silver_live.cds_location loc1 
        ON mv1.Location_ID = loc1.Location_ID
    LEFT JOIN hive_metastore.silver_live.cds_patient pat 
        ON ad.Patient_ID = pat.Patient_ID
    LEFT JOIN hive_metastore.silver_live.cds_ref_room r1 
        ON mv1.Room_ID = r1.Room_ID
    LEFT JOIN wt 
        ON wt.AdmissionID = mv1.Admission_ID
    LEFT JOIN br 
        ON br.AdmissionID = mv1.Admission_ID
    WHERE 1 = 1
      AND ad.Admission_Type_Code = 'E'
      AND wt.CurrWard IN ('AED', 'CED', 'CDU')
      AND (mr.Discharge_Code NOT IN ('CDUDNW', 'EDDNW') OR mr.Discharge_Code IS NULL)
      AND mv1.CBU IN ('Emergency Medicine', 'Adult Emergency Department', "Children's Emergency Medicine")
      AND ad.Admission_DateTime BETWEEN DATE_TRUNC('DAY', currenttime.now) AND currenttime.now
) Q1


""")

# COMMAND ----------


