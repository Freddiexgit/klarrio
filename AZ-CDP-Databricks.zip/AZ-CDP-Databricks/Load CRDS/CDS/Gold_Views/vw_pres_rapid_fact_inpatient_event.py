# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 15-Aug-2024 | 1       | Janesa R    | Initial Draft      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_rapid_fact_inpatient_event""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_rapid_fact_inpatient_event
AS

WITH current_time AS (
  SELECT from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
),

Prioritised_Ethnicity AS 
(
	SELECT distinct   Admission.Patient_ID									
					, PatientEthnicity.Rank
					, PatientEthnicity.Patient_Ethnicity						
					, PatientEthnicity.Priority
					, EthnicGroup.EthnicGroupCode
	FROM (SELECT DISTINCT cds_admission.Patient_ID						
			FROM hive_metastore.silver_live.cds_admission cds_admission				 	
			WHERE	1=1
				AND cds_admission.Admission_DateTime >= '2020-01-01'	
				AND cds_admission.Admission_Type_Code IN  ('I','E')			
		 ) Admission
	JOIN hive_metastore.silver_live.cds_ref_patient_ethnicity PatientEthnicity	
				ON Admission.Patient_ID = PatientEthnicity.Patient_ID	
					AND PatientEthnicity.Priority = 1 										-- Only prioritised ethnicity needs to be selected for patient having multiple ethnicities
	LEFT JOIN hive_metastore.silver_live.vw_cds_dsu_mohethnicgroupcode EthnicGroup			
				ON PatientEthnicity.Rank = EthnicGroup.EthnicGroupPriority
)
SELECT DISTINCT
	 Patient.Patient_NHI as NHI
	,Admission.Admission_Number	as IP_encounter_id											
	,CASE WHEN Admission.Admission_Type_Code = 'E' THEN Admission.Admission_Number	
		  ELSE NULL
	 END as ED_Encounter_Id
	,Admission.Admission_DateTime as admission_date
	,Hospital.Hospital_Code as hospital_code      
	,Admission.Inpatient_Admission_Type_Code as admission_type_code  
	,1022 as DHB_of_service_code  
	,Patient.Patient_Domicile_Code as domicile_code  
	,Patient.Patient_Gender_Code as sex_code  
	,Prioritised_Ethnicity.EthnicGroupCode as ethnic_group_code    	--Need to replace with EthnicGroupCode when dsu_mohethnicgroupcode table is available in DataBricks  
	,Patient.Patient_DOB as date_of_birth  
	,Patient.Patient_Deceased_Date as date_of_death  
	,Admission.Ref_Clinician_Code as GP_code  
	,Admission.Ref_Clin_Practice_Code as GPPractice_code  			
	,Admission.Actual_Discharge_DateTime as discharge_date  
	,CASE WHEN Admission.Actual_Discharge_DateTime IS NULL THEN NULL ELSE Admission.Health_Specialty_Code END  as discharge_specialty_code  
	,Medical_Record.Discharge_Type_Code as Event_end_type_code
	,now as extract_date_time
	,0 as archive_flag  
	,Medical_Record.ICU_Hours as icu_hours  
	,REF_Diagnosis.Diagnosis_Code as primary_diagnosis  
	,CASE WHEN Admission.Actual_Discharge_DateTime IS NULL THEN NULL ELSE Location.Location_Code END as discharge_ward  		-- This field needs to be confirmed, including if there are exclusions
	,dsu_attendance_location_extension.ICU_Ward_Flag as CURRENTLY_IN_ICBED_FLAG  												-- this one needs to check 
	,CASE WHEN Medical_Record.Transfer_Destination = 'Auckland Mental Health Services' THEN 'F03067-A'			
		  WHEN Medical_Record.Transfer_Destination = 'Starship Childrens Hospital' THEN 'F03052-K'				
		  WHEN Medical_Record.Transfer_Destination = 'Greenlane Hospital' THEN 'F03026-J'						
		  ELSE 'F03067-A'
	 END as HPI_FACILITY_CODE  
	,'IP' as setting  
	,'ADHB TrakCare' as CLIENT_SOURCE_SYSTEM  
	,Admission.Billing_Method_Code as principal_health_service_purchaser  									
FROM 
	 hive_metastore.silver_live.cds_admission 			Admission, current_time																	
LEFT JOIN hive_metastore.silver_live.cds_patient 		Patient			ON Admission.Patient_ID 	= Patient.Patient_ID 					
LEFT JOIN Prioritised_Ethnicity											ON Admission.Patient_ID 	= Prioritised_Ethnicity.Patient_ID
LEFT JOIN hive_metastore.silver_live.cds_movement 		Movement		ON Admission.Admission_ID 	= Movement.Admission_ID				
LEFT JOIN hive_metastore.silver_live.cds_location 		Location		ON Location.Location_ID 	= Movement.Location_ID		AND 	Movement.Location_ID IS NOT NULL		
LEFT JOIN hive_metastore.silver_live.cds_ref_hospital 	Hospital		ON Hospital.Hospital_ID 	= Location.Hospital_ID					
LEFT JOIN hive_metastore.silver_live.cds_diagnosis 		Diagnosis		ON Admission.Admission_ID 	= Diagnosis.Admission_ID
LEFT JOIN hive_metastore.silver_live.cds_ref_diagnosis 	REF_Diagnosis	ON Diagnosis.Diagnosis_ID 	= REF_Diagnosis.Diagnosis_ID
LEFT JOIN hive_metastore.silver_live.cds_medical_record	Medical_Record	ON Admission.Admission_ID 	= Medical_Record.Admission_ID
LEFT JOIN hive_metastore.silver_live.cds_dsu_attendance_location_extension dsu_attendance_location_extension	ON dsu_attendance_location_extension.lAttendanceLocationId = Location.Location_ID   -- this needs to check
WHERE 1=1
	AND	Admission.Admission_DateTime >= '2020-01-01'		-- Completed IP/ED events from 01-01-2020 is required by Waitemata
--	AND Movement.Movement_Is_Main = 'Y' 					-- Only the primary case need to be selected for this extract	
	AND (													-- Select the current inpatient episodes in the hospital
		 Admission.Admission_Type_Code IN  ('E', 'I')		
--		 AND Admission.Actual_Discharge_DateTime IS NULL	
--		 AND Admission.Visit_Status_Code = ('A')			
		)
ORDER BY IP_encounter_id --Admission.Admission_Number

""")

# COMMAND ----------


