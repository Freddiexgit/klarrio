# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 15-Jul-2024 | 1       | Khalid J    | Create first draft of presentation view for Theatre Utilization (TU) rolling Weeks Summary Report      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_tu_theatre_session_rolling_weeks_summary""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_tu_theatre_session_rolling_weeks_summary
AS
WITH current_time AS (
SELECT
    from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
),
Session_Appointments AS (
SELECT
    appointment_sid,
    SUM(BookedDuration) as Total_Booked_Duration
FROM
    (
    SELECT
        A.Session_id as appointment_sid,
        S.Session_id as session_sid,
        S.Location_ID,
        S.Specialty_Location_ID,
        S.Theatre_Code,
        S.Session_Date,
        S.Session_Start_Time,
        S.Session_End_Time,
        S.AMPM,
        A.Admission_ID,
        A.Appointment_DateTime,
        A.Appointment_Cancel_DateTime,
        A.Appointment_Status,
        A.Appointment_Duration as BookedDuration,
        A.Appointment_Start_Time,
        A.Appointment_End_Time
    FROM
        hive_metastore.silver_live.cds_theatre_session S
    INNER JOIN hive_metastore.silver_live.cds_appointment A
ON
        A.Session_id = S.Session_id
)
GROUP BY
    appointment_sid 
),
Theatre_Session_Statistics as (
SELECT
    TH_SESSION.Session_id AS SessionID,
    TH_SESSION.Location_ID,
    TH_SESSION.Session_Date AS SessionDate,
    T_LOC.Location_Desc as SessionSpecialty,
    TH_SESSION.Theatre_Code AS TheatreCode,
    TH_SESSION.AMPM AS AMPM,
    TH_SESSION.Session_Start_Time AS StartTime,
    TH_SESSION.Session_End_Time AS EndTime,
    DATEDIFF(MINUTE, TH_SESSION.Session_Start_Time, TH_SESSION.Session_End_Time) AS SessionDuration,
    -- in MINS
CASE
WHEN TH_SESSION.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now)), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') THEN 'Current Week'
WHEN TH_SESSION.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01') THEN 'T-1'
WHEN TH_SESSION.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') THEN 'T-2'
WHEN TH_SESSION.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') THEN 'T-3'
WHEN TH_SESSION.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') THEN 'T-4'
WHEN TH_SESSION.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') THEN 'T-5'
WHEN TH_SESSION.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 7), TIMESTAMP'1900-01-01') THEN 'T-6'
ELSE 'OTHER'
END AS WeekNumber,
A.Total_Booked_Duration AS Total_Booked_Duration,
ROUND((A.Total_Booked_Duration / DATEDIFF(MINUTE, TH_SESSION.Session_Start_Time, TH_SESSION.Session_End_Time) )*100 ,2) AS Percent_Time_Booked,
CASE WHEN (A.Total_Booked_Duration IS NULL) THEN 'Y' ELSE 'N' END AS Session_With_No_Booking,
CAST(date_format(TH_SESSION.Session_DateTime, 'yyyyMMdd') AS INT) as Session_Start_Date_Key
FROM hive_metastore.silver_live.cds_theatre_session TH_SESSION, current_time
LEFT OUTER JOIN silver_live.cds_location T_LOC 
ON T_LOC.Location_ID = TH_SESSION.Location_ID
LEFT OUTER JOIN Session_Appointments A
ON A.appointment_sid = TH_SESSION.Session_id
WHERE (TH_SESSION.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now)), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') 
OR TH_SESSION.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01')
OR TH_SESSION.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') 
OR TH_SESSION.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') 
OR TH_SESSION.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') 
OR TH_SESSION.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') 
OR TH_SESSION.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 7), TIMESTAMP'1900-01-01')
)--AND T_LOC.Location_Desc = 'AKCH4'
),
Sessions_With_Zero_Bookings as (
SELECT SessionSpecialty, WeekNumber, 
COUNT(Session_With_No_Booking) as SessionsWithZeroBookings
FROM Theatre_Session_Statistics WHERE Session_With_No_Booking = 'Y'
GROUP BY SessionSpecialty, WeekNumber
),
Session_Target_Definitions as (
SELECT 
Specialty as SessionSpecialty, 
CASE WHEN Week_Number = '1' THEN 'Current Week' 
	 WHEN Week_Number = '2' THEN 'T-1'
	 WHEN Week_Number = '3' THEN 'T-2' 
	 WHEN Week_Number = '4' THEN 'T-3' 
	 WHEN Week_Number = '5' THEN 'T-4' 
	 WHEN Week_Number = '6' THEN 'T-5' 
	 WHEN Week_Number = '7' THEN 'T-6' END AS WeekNumber,
Target*100 AS TargetPercent,
Red_Max*100 AS RedMaxPercent,
Orange_Max*100 AS OrangeMaxPercent,
Green_Max*100 AS GreenMaxPercent
FROM Silver_live.cds_ref_theatre_specialty_usage_alert 
)

SELECT S.SessionSpecialty, S.WeekNumber, 
SUM(S.SessionDuration) as SessionDuration, 
SUM(S.Total_Booked_Duration) as TimeBooked, 
COUNT(S.SessionSpecialty) as TotalSessions,
SUM(S.Total_Booked_Duration)/SUM(SessionDuration)*100 as PercentTimeBooked,
'tbd' as SessionMeetingTarget,
MIN(S.Percent_Time_Booked) as LowestPercentBooked, 
MAX(S.Percent_Time_Booked) as HighestPercentBooked,
AVG(S.Percent_Time_Booked) as AveragePercentBooked, 
MAX(ZB.SessionsWithZeroBookings) as SessionsWithZeroBookings, --ONE VALUE PER WEEK SO MAX WILL NOT IMPACT
MAX(TargetPercent) as TargetPercent,
MAX(RedMaxPercent) as RedMaxPercent,
MAX(OrangeMaxPercent) as OrangeMaxPercent,
MAX(GreenMaxPercent) as GreenMaxPercent
FROM Theatre_Session_Statistics S
LEFT OUTER JOIN Sessions_With_Zero_Bookings ZB
ON ZB.SessionSpecialty = S.SessionSpecialty AND ZB.WeekNumber = S.WeekNumber
LEFT OUTER JOIN Session_Target_Definitions TGT
ON TGT.WeekNumber = S.WeekNumber AND TGT.SessionSpecialty = 'Default'--= s.SessionSpecialty
GROUP BY S.SessionSpecialty, S.WeekNumber;
""")

# COMMAND ----------


