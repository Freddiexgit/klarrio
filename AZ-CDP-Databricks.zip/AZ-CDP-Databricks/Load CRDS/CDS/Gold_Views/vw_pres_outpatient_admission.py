# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 23-May-2024 | 2       | Janesa R       | Initial build                                            |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_outpatient_admission""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_outpatient_admission
AS

SELECT 
ad.UID
,ad.Admission_ID
,Admission_Number
,Admission_DateTime
,Admission_Type_Code
,Inpatient_Admission_Type_Code
,Inpatient_Admission_Type_Desc
,Original_Admission_ID
,Actual_Arrival_DateTime
,Estimated_Discharge_DateTime
,Medical_Discharge_DateTime
,Actual_Discharge_DateTime
,Intent_DateTime
,Ambul_Handover_Comp_DateTime
,Handover_Start_DateTime
,Handover_End_DateTime
,Handover_Childsub
,Handover_Type
,Visit_Status_Code
,Visit_Comment
,Inpatient_Short_Stay_Intent
,Emergency_Treatment_Streams
,Triage_Description
,Triage_Code
,Ref_Clinician_Code
,Ref_Clin_Practice_Code
,Health_Specialty_Code
,Billing_Method_Code
,Arrival_Mode
,Patient_ID
,ad.processing_time
FROM silver_live.cds_admission ad
left outer join silver_live.cds_medical_record mr on mr.Admission_ID = ad.Admission_ID
where Admission_Type_Code = 'O'
and Actual_Discharge_DateTime is null
and Visit_Status_Code in ('A', 'P') 

""")

# COMMAND ----------


