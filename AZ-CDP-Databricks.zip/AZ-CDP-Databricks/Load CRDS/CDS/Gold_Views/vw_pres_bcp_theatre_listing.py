# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 26-June-2024 | 1       | Khalid Jameel    | Create first draft of presentation view from bcp theatre list for BCP |
# MAGIC | 09-July-2024 | 2       | Khalid Jameel    | Updates made to bring in the new columns as per updates in CDS Model  |
# MAGIC | 10-July-2024 | 2       | Khalid Jameel    | Updates made to bring in the new columns as per reporting requirement |
# MAGIC | 18-July-2024 | 2       | Khalid Jameel    | Updates made to bring in the new columns as per reporting requirement |
# MAGIC | 18-July-2024 | 2       | Khalid Jameel    | Updates made to bring in the session table new columns into the view  |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_procedure""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_bcp_theatre_listing
AS
WITH current_time AS (
SELECT
    from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
),
Case_Consultant AS (
SELECT
    Admission_ID,
    Current_Clinician as CaseConsultant,
    Specialty AS CaseSpecialtyDesc
FROM
    hive_metastore.silver_live.cds_movement
WHERE
    UPPER(Movement_Code) = 'TRANSFER'
    AND UPPER(Movement_Status) = 'TRANSFER'
    AND UPPER(Movement_Type) = 'CASE TRANSFER'
    AND Movement_End_Datetime IS NULL
    AND UPPER(Movement_Is_Main) = 'Y'
),
Admit_Ward AS(
SELECT
    Admission_ID,
    Location_ID,
    Bed_ID
FROM
    (
    SELECT
        Admission_ID,
        ROW_NUMBER() OVER (PARTITION BY Admission_ID
    ORDER BY
        Movement_End_Datetime DESC) AS rownumber,
        Location_ID,
        Bed_ID
    FROM
        hive_metastore.silver_live.cds_movement
    WHERE
        UPPER(Movement_Code) = 'MOVE'
        -- trans type
AND UPPER(Movement_Status) = 'TRANSFER' -- request code
AND Movement_End_DateTime IS NULL
AND UPPER(Movement_Type) = 'WARD TRANSFER' ) WHERE rownumber = '1'),
Next_Ward AS (
SELECT Admission_ID, Location_ID, Bed_ID FROM (
SELECT Admission_ID, ROW_NUMBER() OVER (PARTITION BY Admission_ID ORDER BY Movement_End_Datetime DESC) AS rownumber, Location_ID, Bed_ID
FROM hive_metastore.silver_live.cds_movement  
WHERE UPPER(Movement_Status) IN('ACCEPTED', 'REQUESTED') AND UPPER(Movement_Type) = 'BED REQUEST' 
AND UPPER(Movement_Type) = 'WARD TRANSFER' ) WHERE rownumber = '1'),
Theatre_Event AS (
SELECT Admission_ID, Anaesthetist
--ROW_NUMBER() OVER (PARTITION BY Admission_ID ORDER BY Movement_End_Datetime DESC) AS rownumber
FROM hive_metastore.silver_live.cds_movement
WHERE UPPER(Movement_Type) = 'THEATRE EVENT'),
Theatre_Booking AS (
SELECT Admission_ID, Movement_Start_Datetime, Movement_End_Datetime, DATEDIFF(MINUTE ,Movement_Start_Datetime, Movement_End_Datetime) AS TheatreTime
FROM hive_metastore.silver_live.cds_movement 
WHERE UPPER(Movement_Type) = 'THEATRE BOOKING')

SELECT 
PROC.Procedure_ID, PROC.Admission_id, Case_Consultant.CaseConsultant, Case_Consultant.CaseSpecialtyDesc, Curr_LOC.Location_Code AS AdmitWard ,Next_LOC.Location_Code AS NextWard,Theatre_Event.Anaesthetist, 
Theatre_Booking.TheatreTime, 
PROC.Booked_Create_DateTime AS SurgeryStartDateTime,
PROC.Booking_Type AS OperatingType,
PROC.theatre_module_procedure_code AS AnestheticTypeDesc,
PROC_REF.Procedure_Desc AS ProcedureDesc,
PROC.Operating_Room_ID AS TheatreEventRefNo,
TH_SESSION.Session_DateTime AS SessionStartDateTime,
TH_SESSION.Theatre_Code AS TheatreCode, 
TH_SESSION.Session_Type AS SessionType,
CASE WHEN TH_SESSION.Theatre_Code LIKE '%V%' THEN 'Y' ELSE 'N' END AS Virtual_Theatre_Flag,
APT.Appointment_Start_Time AS CaseStartTime,
APT.Appointment_End_Time AS CaseEndTime,
TH_SESSION.Session_Start_Time AS SessionStartTime,
TH_SESSION.Session_End_Time AS SessionEndTime,
APT.Appointment_Start_Time || ' - ' || APT.Appointment_End_Time AS CaseTime,
DATEDIFF(MINUTE ,APT.Appointment_Start_Time, APT.Appointment_End_Time) AS CaseDuration,
TH_SESSION.Dependent_Resource AS DependentResource,
TH_SESSION.Session_ID as TheatreSessionID,
T_LOC.Location_Code as TheatreSuite,
T_LOC.Location_Desc as SessionSpecialty,
CASE
WHEN TH_SESSION.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now)), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') THEN 'Current Week'
WHEN TH_SESSION.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01') THEN 'T-1'
WHEN TH_SESSION.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') THEN 'T-2'
WHEN TH_SESSION.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') THEN 'T-3'
WHEN TH_SESSION.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') THEN 'T-4'
WHEN TH_SESSION.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') THEN 'T-5'
WHEN TH_SESSION.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 7), TIMESTAMP'1900-01-01') THEN 'T-6'
END AS WeekNumber,
CAST(date_format(TH_SESSION.Session_DateTime, 'yyyyMMdd') AS INT) as Session_Start_Date_Key,
TH_SESSION.Session_Consultant
FROM hive_metastore.silver_live.cds_procedure PROC, current_time
LEFT OUTER JOIN hive_metastore.silver_live.cds_ref_procedure PROC_REF
ON PROC_REF.Procedure_ID = PROC.Procedure_ID
LEFT OUTER JOIN hive_metastore.silver_live.cds_theatre_session TH_SESSION
ON TH_SESSION.Theatre_Code  = PROC.Resource_Code AND PROC.Booked_Create_DateTime = TH_SESSION.Session_DateTime
LEFT OUTER JOIN Case_Consultant
ON Case_Consultant.Admission_ID = PROC.Admission_ID
LEFT OUTER JOIN Admit_Ward
ON Admit_Ward.Admission_ID = PROC.Admission_ID
LEFT OUTER JOIN Next_Ward
ON Next_Ward.Admission_ID = PROC.Admission_ID
LEFT OUTER JOIN Theatre_Event
ON Theatre_Event.Admission_ID = PROC.Admission_ID
LEFT OUTER JOIN Theatre_Booking
ON Theatre_Booking.Admission_ID = PROC.Admission_ID
LEFT OUTER JOIN hive_metastore.silver_live.cds_location Curr_LOC
ON Curr_LOC.Location_ID = Admit_Ward.Location_ID
LEFT OUTER JOIN hive_metastore.silver_live.cds_location Next_LOC
ON Next_LOC.Location_ID = Next_Ward.Location_ID
LEFT OUTER JOIN hive_metastore.silver_live.cds_appointment APT 
ON APT.Session_ID = TH_SESSION.Session_Id AND APT.Admission_ID = PROC.Admission_ID
LEFT OUTER JOIN silver_live.cds_location T_LOC 
ON T_LOC.Location_ID = TH_SESSION.Specialty_Location_ID
WHERE PROC.Procedure_ID  IS NOT NULL
AND PROC.Procedure_ID <> '99999'
AND PROC.Is_Primary = '1';


""")

# COMMAND ----------


