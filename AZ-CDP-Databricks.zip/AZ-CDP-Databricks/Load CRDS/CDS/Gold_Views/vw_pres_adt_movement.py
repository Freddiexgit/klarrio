# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 10-Jul-2024 | 1       | Khalid J    | Create first draft of presentation view for ADT Movement Report     |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_adt_movement""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_adt_movement
AS
WITH following_attendance as (
	select
		Original.UID
		, Original.Admission_ID
		, Original.movement_Start_Datetime
		, Original.ward_code
		, new_ranking.Movement_start_Datetime as following_Attendance_Datetime
		, new_ranking.ward_code as following_attendance_ward_code
		, CONCAT(IFNULL(new_ranking.ward_code,''),' ',new_ranking.Movement_start_Datetime) as Following_Attendance
		, Original.Movement_Code
	FROM(
	select 
		distinct 
			m.UID 
			, m.Admission_ID 
			, m.Movement_Start_Datetime 
			, m.Movement_Code 
			, w.Ward_Code
			,ROW_NUMBER() over (PARTITION by m.Admission_ID order by Movement_Start_Datetime) as rank
		from silver_live.cds_movement m
		left join silver_live.cds_ref_bed b on m.Bed_ID =b.Bed_ID
		left join silver_live.cds_ref_ward w on b.Ward_ID =w.Ward_ID
		where m.Movement_Code in ('Move' ,'Booking')
		order by m.Admission_ID , m.Movement_Start_Datetime) original -- use ranking to define the order of movement_start_datetime
	left join(
		select 
			next.Admission_ID
			, Movement_Start_Datetime
			, Movement_Code 
			, ward_code
			,rank-1 as next_ranking
		from (
		select 
			distinct 
				m2.Admission_ID 
				, m2.Movement_Start_Datetime 
				, m2.Movement_Code 
				, w2.Ward_Code
				,ROW_NUMBER() over (PARTITION by m2.Admission_ID order by Movement_Start_Datetime) as rank
			from silver_live.cds_movement m2
			left join silver_live.cds_ref_bed b2 on m2.Bed_ID =b2.Bed_ID
			left join silver_live.cds_ref_ward w2 on b2.Ward_ID = w2.Ward_ID
			where m2.Movement_Code in ('Move' ,'Booking')
			order by m2.Admission_ID , m2.Movement_Start_Datetime) next) new_ranking -- define a new ranking by -1, to merge the ranking of next starttime with the ranking of currenttime, thus get the following attending time
			on original.Admission_ID = new_ranking.Admission_ID
			and original.rank = new_ranking.next_ranking
			and original.Movement_Code = new_ranking.Movement_Code
			),
los as (
	select 
		distinct 
			m.UID 
			, a.Admission_ID
			, a.Patient_ID 
			, w.Ward_Code 
			, a.Admission_DateTime 
			, a.Estimated_Discharge_DateTime 
			, m.Movement_Start_Datetime 
			, m.Movement_End_Datetime
			, case when m.Movement_Start_Datetime is null then Admission_DateTime else m.Movement_Start_Datetime end as startdate
			, case when m.Movement_End_Datetime is null then Estimated_Discharge_DateTime else m.Movement_End_Datetime end as enddate
			, DATEDIFF(enddate,startdate) as LOS
		from silver_live.cds_movement m
		left join silver_live.cds_admission a on a.Admission_ID = m.Admission_ID
		left join silver_live.cds_ref_bed b on m.Bed_ID =b.Bed_ID
		left join silver_live.cds_ref_ward w on b.Ward_ID = w.Ward_ID
		where w.Ward_Code is not null
		and m.Movement_Code in ('Move' ,'Booking')
		)
select
	vcm.UID
	, vcm.Admission_ID
	, vcm.Movement_Procedure_ID
	, vcm.Movement_Type
	, vcm.Movement_Code
	, vcm.Movement_Status
	, vcm.Location_ID
	, vcm.Speciality_Location_ID
	, vcm.Bed_ID
	, vcm.Room_ID
	, vcm.Movement_Create_DateTime
	, vcm.Movement_Start_Datetime
	, vcm.Movement_End_Datetime
	, vcm.Movement_ReadyToLeave_DateTime
	, vcm.Movement_Book_Date
	, vcm.Current_Clinician
	, vcm.Anaesthetist
	, vcm.Emergency_Consultant
	, vcm.RMC
	, vcm.Directorate
	, vcm.CBU
	, vcm.Specialty
	, vcm.Movement_Is_Main
	, vcm.Override_Room_Type
	, vcm.Transfer_Remark
	, vcm.Acute_Or_Elective
	, vcm.Cancelled_Reason
	, vcm.processing_time
	, fa.Following_Attendance
	, los.LOS
from silver_live.cds_movement vcm
left join following_attendance fa on vcm.UID = fa.UID
left join los on vcm.UID = los.UID
""")

# COMMAND ----------


