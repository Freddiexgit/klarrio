# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 21-Aug-2024 | 1       | Janesa R    | Initial Draft     |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_rapid_fact_regional_theatre_session""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_rapid_fact_regional_theatre_session
AS

WITH current_time AS (
SELECT
    from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
)
SELECT
    DISTINCT 
  CASE
        WHEN cds_location.Location_Code = 'AKCH3' THEN 'F03067-A'
        WHEN cds_location.Location_Code = 'AKCH4' THEN 'F03067-A'
        WHEN cds_location.Location_Code = 'AKCH8' THEN 'F03067-A'
        WHEN cds_location.Location_Code = 'AKCH9' THEN 'F03067-A'
        WHEN cds_location.Location_Code = 'GSU' THEN 'F03026-J'
        WHEN cds_location.Location_Code = 'SST' THEN 'F03052-K'
        WHEN cds_location.Location_Code = 'AKCH5' THEN 'F03067-A'
        ELSE 'FZZ999-C'
    END as HPI_Facility_Code
,
    CASE
        WHEN cds_ref_hospital.Hospital_Code = '3260B' then '3239'
        -- Starship
    WHEN cds_ref_hospital.Hospital_Code = '3260A' then '3212' -- Greenlane Clinical Centre
    WHEN cds_ref_hospital.Hospital_Code = '3260C' then '3260' -- Auckland City Hospital 
    ELSE cds_ref_hospital.Hospital_Code 
  END as NC_FACILITY_CODE
, cds_theatre_session.Session_Id as Session_Id									
, CASE 
	WHEN cds_theatre_session.Theatre_Code='A4OR01' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A4OR02' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A4OR03' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A4OR04' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A4OR05' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A4OR06' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A4OR07' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A4VOR2' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='A4VOR3' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='A4VPACU' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='A8OR01' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A8OR02' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A8OR03' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A8OR04' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A8OR05' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A8OR06' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A8OR07' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A8OR08' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A8OR09' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A8OR10' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A8OR11' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A8OR12' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A8OR13' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A8VASSES' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='A8VDSA1' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='A8VDSA2' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='A8VDSA3' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='A8VGASTRO' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='A8VL5CT' THEN 'Radiology'
	WHEN cds_theatre_session.Theatre_Code='A8VL5MRI' THEN 'Radiology'
	WHEN cds_theatre_session.Theatre_Code='A8VPACU' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='A9OR01' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A9OR02' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A9OR03' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A9OR04' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A9VOR1' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='CIRA3R1' THEN 'Cath Lab'
	WHEN cds_theatre_session.Theatre_Code='CIRA3R2' THEN 'Cath Lab'
	WHEN cds_theatre_session.Theatre_Code='CIRA3R3EP' THEN 'Cath Lab'
	WHEN cds_theatre_session.Theatre_Code='CIRA3R4PA' THEN 'Cath Lab'
	WHEN cds_theatre_session.Theatre_Code='CIRS1R1' THEN 'Cath Lab'
	WHEN cds_theatre_session.Theatre_Code='GSUOR01' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='GSUOR02' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='GSUOR03' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='GSUOR04' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='GSUOR05' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='GSUOR06' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='GSUOR07' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='GSUOR08' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='GSUVFERT' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='GSUVOR1' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='GSUVPACU' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='S2OR1' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='S2OR2' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='S2OR3' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='S2OR4' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='S2OR5' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='S2OR6' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='S2OR7'THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='SHVL5ANGIO' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='SHVMRI' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='SHVNICU' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='SHVPACU' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='SHVPICU' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='SHVRTY' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='SHVSSCT' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='A8VOR01' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='SHVL5CT' THEN 'Radiology'
	WHEN cds_theatre_session.Theatre_Code='SHVL7ONC' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='A3VMRI' THEN 'Radiology'
	WHEN cds_theatre_session.Theatre_Code='A5NUCMED' THEN 'Radiology'
	WHEN cds_theatre_session.Theatre_Code='A5VFLUORO' THEN 'Radiology'
	WHEN cds_theatre_session.Theatre_Code='A5VL5CT' THEN 'Radiology'
	WHEN cds_theatre_session.Theatre_Code='A5VMRI' THEN 'Radiology'
	WHEN cds_theatre_session.Theatre_Code='A5VNUCMED' THEN 'Radiology'
	WHEN cds_theatre_session.Theatre_Code='A5VOR01' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A5VOR02' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A5VOR03' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='BSVOR01' THEN 'Full'
	WHEN cds_theatre_session.Theatre_Code='A5VPR01' THEN 'Procedure'
	WHEN cds_theatre_session.Theatre_Code='A5VPICC' THEN 'Procedure'
	ELSE NULL
  END as Theatre_Type_Code
, cds_location.Location_Code as Theatre_Suite									
, cds_theatre_session.Theatre_Code as Theatre_Code								
, cds_theatre_session.Theatre_Description as Theatre_Description				
, CAST(NULL as INT) as Session_Cancelled_Flag
, CAST(NULL as TIMESTAMP) as Session_Cancelled_datetime
, CAST(NULL as VARCHAR(50)) as Session_Cancelled_reason
, cds_theatre_session.Session_DateTime as session_start_datetime			
, CAST(CONCAT(cds_theatre_session.Session_Date,' ',cds_theatre_session.Session_End_Time) as Timestamp) as session_end_datetime		
, cds_theatre_session.Session_Type as Session_Type								
, ctl.Speciality_Code as Session_Specialty										
--, ctl.Speciality_Desc as Session_Specialtydesc 									
, '1022' as District_Of_Service
, now as Extract_dtm
, CAST(NULL as INT) as Invalid_Encounter_Flag
from      
hive_metastore.silver_live.cds_theatre_session cds_theatre_session , current_time
left join hive_metastore.silver_live.cds_location cds_location					on cds_location.Location_ID = cds_theatre_session.Location_ID
left join hive_metastore.silver_live.cds_ref_hospital cds_ref_hospital			on cds_ref_hospital.Hospital_ID = cds_location.Hospital_ID 
left join hive_metastore.silver_live.cds_location ctl							on cds_theatre_session.Specialty_Location_ID = ctl.Location_ID 
WHERE 1=1
--	and	RB_Resource.RES_Type='Equipment'								-- already included in the built of cds_theatre_session
--	and RBC_EquipmentGroup.GRP_Code='OT'								-- already included in the built of cds_theatre_session
	and cds_theatre_session.Session_DateTime >='2023-01-01' 			
	and cds_location.Location_Type = 'Operating Theatre';


""")

# COMMAND ----------


