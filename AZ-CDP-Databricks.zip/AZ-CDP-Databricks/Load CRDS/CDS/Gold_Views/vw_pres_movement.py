# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 28-Mar-2024 | 1       | Siddharth S    | Create first draft of presentation view from cds_movement delta table      |
# MAGIC | 01-May-2024 | 2       | Janesa R       | Added Movement_Sequence2

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_movement""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_movement
AS

WITH current_time AS (
  SELECT date_format(from_utc_timestamp(now(), 'Pacific/Auckland'), 'yyyy-MM-dd HH:mm:ss') AS now
),

    Ward_Transfer_Movement as (
        select distinct
        Admission_ID
        , Location_ID
        , Bed_ID
        , Room_ID -- for case transfers: current location
        , row_number() over (partition by Admission_ID  order by Movement_Sequence asc) as first_movement_flag
        , row_number() over (partition by Admission_ID  order by Movement_Sequence desc) as last_movement_flag
        , Movement_Sequence
        from hive_metastore.silver_live.cds_movement
            where Movement_Type = 'Ward Transfer'
            --and Movement_End_Datetime is null 
            and Location_ID is not null
            order by Movement_Sequence
), 

--select * from Ward_Transfer_Movement

    Main_Case_Transfer_Movement as (
        select distinct
        Admission_ID
        , Current_Clinician -- for ward transfers: current clinician and specialty
        , Specialty
        , row_number() OVER (PARTITION BY Admission_ID ORDER BY Movement_Sequence DESC) as Row_Number
        from hive_metastore.silver_live.cds_movement 
             where Movement_Type = 'Case Transfer' and Movement_End_Datetime is null and Movement_Is_Main = 'Y'
)

SELECT 
mv1.UID,
mv1.Movement_Sequence,
mv1.Admission_ID,
mv1.Movement_Type,
mv1.Movement_Code,
mv1.Movement_Status,
mv1.Location_ID,
Case When mv1.Movement_Type = 'Bed Request' then prev.Location_ID 
    when mv1.Movement_Type = 'Case Transfer' then prev.Location_ID
    when mv1.Movement_Type = 'Ward Transfer' then prev.Location_ID
    end as Previous_Location_ID,
Case When mv1.Movement_Type = 'Bed Request' then cur.Location_ID 
    when mv1.Movement_Type = 'Case Transfer' then cur.Location_ID
    when mv1.Movement_Type = 'Ward Transfer' then mv1.Location_ID
    end as Current_Location_ID,
Case When mv1.Movement_Type = 'Bed Request' then first.Location_ID 
    when mv1.Movement_Type = 'Case Transfer' then first.Location_ID
    when mv1.Movement_Type = 'Ward Transfer' then first.Location_ID
    end as First_Location_ID,
Case When mv1.Movement_Type = 'Bed Request' then mv1.Location_ID 
    when mv1.Movement_Type = 'Case Transfer' then null
    when mv1.Movement_Type = 'Ward Transfer' and mv1.Movement_Start_Datetime > now then mv1.Location_ID
    when mv1.Movement_Type = 'Ward Transfer' and mv1.Movement_Start_Datetime <= now then null
    end as Next_Location_ID,
mv1.Speciality_Location_ID,
mv1.Bed_ID,
mv1.Room_ID,
case when mv1.Bed_ID is null then rm.Room_Code else bed.Room_Code end as Room_Code_Combined,
mv1.Movement_Create_DateTime,
mv1.Movement_Start_Datetime,
mv1.Movement_End_Datetime,
mv1.Movement_ReadyToLeave_DateTime,
mv1.Current_Clinician,
mv1.Emergency_Consultant,
mv1.RMC,
mv1.Directorate,
mv1.CBU,
mv1.Specialty,
mv1.Movement_Is_Main,
mv1.Override_Room_Type,
mv1.Transfer_Remark,
mv1.Acute_Or_Elective,
mv1.processing_time,
case when mv1.Movement_Type = 'Case Transfer' and mv1.Movement_Code = 'Transfer' and mv1.Movement_Status = 'Transfer' and mv1.Movement_End_Datetime is null and mv1.Movement_Is_Main = 'Y'
        then 'Y' else 'N' end Current_Main_Case,
case when mv1.Movement_Type = 'Ward Transfer' and mv1.Movement_Code = 'Move' and mv1.Movement_Status = 'Transfer' and mv1.Movement_End_Datetime is null
        then 'Y' else 'N' end Current_Ward_Transfer,
/*case when mv1.Movement_Type = 'Bed Request' then 
        (CASE WHEN mv1.Movement_Status = 'Accepted' then 'Completed'
            WHEN mv1.Movement_Status = 'Requested' and mv1.Movement_Create_DateTime >  GETDATE() then 'Overdue'
            WHEN mv1.Movement_Status = 'Requested' and mv1.Movement_Create_DateTime <= GETDATE() then 'Active'
            END) else null end as Bed_Request_Status, */
case when mv1.Movement_Type = 'Bed Request' then (
CASE WHEN mv1.Movement_Status = 'Accepted' and datediff(minute, mv1.Movement_Start_DateTime, now)<60 
			then 'Accepted and Not Overdue'----bed request is accepted, patient hasn't yet moved, scheduled move date is in future
      WHEN mv1.Movement_Status = 'Accepted' and datediff(minute, mv1.Movement_Start_DateTime, now)>=60 
			then 'Accepted and Overdue'----bed request is accepted, patient hasn't yet moved, scheduled move date is in the past
      WHEN mv1.Movement_Status = 'Requested' 
			then 'Active'----bed request has not yet been accepted (yellow)
            END) else null end as Bed_Request_Status,
case when mv1.Movement_Type = 'Case Transfer' then prev.Location_ID else cur.Location_ID end as Case_Location_ID, -- remove this later 
case when mv1.Movement_Type = 'Case Transfer' then prev.Bed_ID else cur.Bed_ID end as Case_Bed_ID, 
case when mv1.Movement_Type = 'Case Transfer' then prev.Room_ID else cur.Room_ID end as Case_Room_ID,
case when mv1.Movement_Type in ('Ward Transfer', 'Bed Request') then main_case.Current_Clinician else mv1.Current_Clinician end as WT_Main_Clinician,
case when mv1.Movement_Type in ('Ward Transfer', 'Bed Request') then main_case.Specialty else mv1.Specialty end as WT_Main_Specialty,
case when mv1.Movement_Type = 'Ward Transfer' and mv1.Movement_Status = 'Transfer'  and mv1.Bed_ID in ('35||394', '35||395', '35||396', '35||397', '35||398', '35||399', '35||400', '35||401', '35||402', '35||403', '35||404') then 'Y' else 'N' end as Movement_Short_Stay_Flag,
case when mv1.Movement_Type = 'Ward Transfer' then 
  (case when mv1.Movement_End_Datetime is null and mv1.Movement_Start_Datetime < now  then datediff(hour,mv1.Movement_Start_Datetime,  now) 
        when mv1.Movement_End_Datetime is not null then datediff(hour,  mv1.Movement_Start_Datetime, mv1.Movement_End_Datetime)
        else 0 end) else 0 end as Ward_Transfer_Duration,
case when CAST(mv1.Movement_Start_Datetime AS DATE) = CAST (now AS DATE) then 'Y' else 'N' end as Movement_Start_Today
FROM hive_metastore.silver_live.cds_movement mv1, current_time -- all movements
left outer join Ward_Transfer_Movement prev on prev.Admission_ID = mv1.Admission_ID and prev.last_movement_flag = 2 -- previous ward transfer
left outer join Ward_Transfer_Movement cur on cur.Admission_ID = mv1.Admission_ID and cur.last_movement_flag = 1 -- current ward transfer
left outer join Ward_Transfer_Movement first on first.Admission_ID = mv1.Admission_ID and first.first_movement_flag = 1 -- first ward transfer
left outer join Main_Case_Transfer_Movement main_case on main_case.Admission_ID = mv1.Admission_ID and main_case.Row_Number = 1 -- main case transfer
left outer join gold_live.vw_pres_ioc_bed_to_ward_details bed on bed.Bed_ID = mv1.Bed_ID
left outer join silver_live.cds_ref_room rm on rm.Room_ID = mv1.Room_ID
where mv1.Movement_Type in ('Bed Request', 'Case Transfer', 'Ward Transfer')


 """)

# COMMAND ----------


