# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 28-Mar-2024 | 1       | Janesa R       | Create first draft of presentation view for Theatre Hours      |
# MAGIC

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_ioc_theatre_hours""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_ioc_theatre_hours
AS

WITH current_time AS (
  SELECT from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
),
pacumv AS (
  SELECT Movement_ReadyToLeave_DateTime,
         movement_start_datetime,
         Admission_ID,
         movement_type 
  FROM hive_metastore.silver_live.cds_movement
  WHERE movement_type = 'Post Theatre Event'
), 
thmv AS (
  SELECT movement_start_datetime,
         Admission_ID 
  FROM hive_metastore.silver_live.cds_movement
  WHERE movement_type = 'Theatre Event'
)
SELECT
       Distinct
       mv.Admission_ID,
       mv.Location_ID,
       DATEDIFF(minute, mv.Movement_Start_Datetime, mv.Movement_End_Datetime) AS Estimated_Theatre_Hours,
       mv.Movement_Start_Datetime,
       CASE 
          WHEN hour(thmv.movement_start_datetime) != 0
               AND (hour(pacumv.movement_start_datetime) IS NULL OR hour(pacumv.movement_start_datetime) = 0)
               THEN 'In Theatre'
          ELSE 'Not in Theatre'
       END AS Theatre_ProgressTest,
       CASE
          WHEN COALESCE(hour(pacumv.Movement_ReadyToLeave_DateTime), 0) != 0 
               THEN 'Fit to leave'
          WHEN COALESCE(hour(pacumv.Movement_ReadyToLeave_DateTime), 0) = 0 
                  AND COALESCE(hour(pacumv.movement_start_datetime), 0) != 0
               THEN 'In PACU'
          WHEN COALESCE(hour(thmv.movement_start_datetime), 0) != 0
               AND COALESCE(hour(pacumv.movement_start_datetime), 0) = 0
               THEN 'In Theatre'
          ELSE 'Not in Theatre'
       END AS Theatre_Progress,
       loc.Location_Code AS Theatre,
       loc2.Location_Desc AS Speciality,
       CASE
          WHEN loc.Location_Code = 'AKCH8' AND loc2.Location_Desc IN ('Gen Surg - Acute Surgical Unit') THEN 'ASU Acute'
          WHEN loc.Location_Code = 'AKCH8' AND (
                loc2.Location_Desc LIKE '%Vascular%' 
                OR loc2.Location_Desc LIKE '%Neurosurgery%' 
                OR loc2.Location_Desc LIKE '%Urology%'
            ) THEN 'General Acute'
          WHEN loc.Location_Code = 'AKCH8' AND loc2.Location_Desc = 'Orthopaedics' THEN 'Ortho Acute'
          ELSE 'Other'
       END AS Theatre_Category,
       mv.Acute_Or_Elective AS BookingType
FROM hive_metastore.silver_live.cds_movement mv
LEFT JOIN hive_metastore.silver_live.cds_location loc ON loc.Location_ID = mv.Location_ID
LEFT JOIN hive_metastore.silver_live.cds_location loc2 ON loc2.Location_ID = mv.Speciality_Location_ID
LEFT JOIN pacumv ON mv.Admission_ID = pacumv.Admission_ID
LEFT JOIN thmv ON mv.Admission_ID = thmv.Admission_ID
JOIN current_time ON 1=1
WHERE mv.Movement_Type = 'Theatre Booking'
AND mv.Acute_Or_Elective = 'EM'
AND mv.Movement_Start_Datetime >= CAST(current_time.now AS DATE)
AND mv.Movement_Start_Datetime <= current_time.now

""")

# COMMAND ----------


