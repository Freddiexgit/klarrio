# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 15 May 2024 | 1       | Janesa R    | Initial build of Trendcare Variance view |
# MAGIC

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_trendcare_variance""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_trendcare_variance
AS

WITH current_time AS (
  SELECT from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
),

VW_TrendCare_Variance as(select 
							ss.tlWardCode as WardCode
							, ss.tlDate as SummaryDate
							, ss.tlShiftCode as ShiftCode
							, CASE
      								WHEN (ss.tlShiftCode = 'D') THEN 1
       								WHEN (ss.tlShiftCode = 'E') THEN 2
       								WHEN (ss.tlShiftCode = 'N') THEN 3
       								ELSE 9
   								END AS ShiftNumber
							, CASE
        							WHEN ( ss.tlShiftCode = 'D' AND (date_part('hour', now) >= 7 AND date_part('hour', now) <= 14) ) THEN 'Y'
        							WHEN ( ss.tlShiftCode = 'E' AND (date_part('hour', now) >= 15 AND date_part('hour', now) <= 22) ) THEN 'Y'
        							WHEN ( ss.tlShiftCode = 'N' AND (date_part('hour', now) >= 23 OR date_part('hour', now) <= 6) ) THEN 'Y'
        							ELSE 'N'
    							END AS CurrentShift
							, CASE
       								WHEN ( date_part('hour', now) >= 0 AND date_part('hour', now) <= 6 ) THEN Date_Add(day, datediff(day, TIMESTAMP'1900-01-01', ss.tlDate) + 1,  TIMESTAMP'1900-01-01')
       								ELSE ss.tlDate
  								END AS ReportDate
							, (ss.tlClinicalInDeptHours - ss.tlRequiredHours) AS VarianceHours
							, ss.tlNumberOfUnCategorisedPatients AS NumberUncategorised
							from silver_live.cds_trc_summaryshift ss, current_time),

tbl as (
 SELECT 
                        CAST(Ward.wdWardCode as INT) AS TCWardCode
						,WI.wiIOCode as CMSWardCode
                        , rtrim(Ward.wdName) AS WardName
                        , VW_TrendCare_Variance.SummaryDate
                        , CASE 
                            WHEN DATE_PART('Hour', now) < 7 THEN DATE_Add(day, (datediff(day, TIMESTAMP'1900-01-01', now) - 1), TIMESTAMP'1900-01-01')
                            ELSE DATE_Add(day, (datediff(day, TIMESTAMP'1900-01-01', now) - 1), TIMESTAMP'1900-01-01')
                          END AS CurrentShiftDate
                        , VW_TrendCare_Variance.ShiftCode
                        , VW_TrendCare_Variance.ShiftNumber
                        , VW_TrendCare_Variance.CurrentShift
                        , VW_TrendCare_Variance.VarianceHours
                        , VW_TrendCare_Variance.NumberUncategorised
						/*, CASE 
                            WHEN VW_TrendCare_Variance.VarianceHours >= 0
                              THEN CAST(CAST(floor(VW_TrendCare_Variance.VarianceHours) AS INT) AS Varchar(120))  || ':' ||  RIGHT( CAST(CAST((VW_TrendCare_Variance.VarianceHours - floor(VW_TrendCare_Variance.VarianceHours)) * 60.0 AS INT) AS VARCHAR(120)),2)
                            ELSE 
                                CAST(CAST(ceiling(VW_TrendCare_Variance.VarianceHours) AS INT) AS Varchar(120)) + ':' + RIGHT( CAST(CAST((VW_TrendCare_Variance.VarianceHours - ceiling(VW_TrendCare_Variance.VarianceHours)) * -60.0 AS INT) AS VARCHAR(120)),2)
                        	END AS VarianceHourMinute */
              ,   CASE WHEN VW_TrendCare_Variance.VarianceHours >= 0 THEN 
                      CONCAT( CAST(FLOOR(VW_TrendCare_Variance.VarianceHours) AS STRING), ':', 
                      LPAD(CAST(CAST((VW_TrendCare_Variance.VarianceHours - FLOOR(VW_TrendCare_Variance.VarianceHours)) * 60 AS INT) AS STRING), 2, '0'))
                  ELSE 
                      CONCAT(CAST(CEILING(VW_TrendCare_Variance.VarianceHours) AS STRING), ':', 
                      LPAD(CAST(CAST((VW_TrendCare_Variance.VarianceHours - CEILING(VW_TrendCare_Variance.VarianceHours)) * -60 AS INT) AS STRING), 2, '0'))
                  END AS VarianceHourMinute
                        , CASE 
                            WHEN VW_TrendCare_Variance.VarianceHours <= 0 THEN 1
                            END AS TrendCareColourRed
                        , CASE 
                            WHEN VW_TrendCare_Variance.VarianceHours > 0 THEN 1
                            END AS TrendCareColourGreen
                        , CASE 
                            WHEN VW_TrendCare_Variance.VarianceHours > 0 THEN 'Over'                                -- used for filtering
                            WHEN VW_TrendCare_Variance.VarianceHours = 0 THEN 'Zero'
                            ELSE 'Under'
                            END AS TrendCareVarianceText
                        --, LEFT(CAST(VW_TrendCare_Variance.SummaryDate AS VARCHAR(120)), 10) + '_' + Ward.wdWardCode + '_' + VW_TrendCare_Variance.ShiftCode as DateWardShift  -- for joining to other tables
                        , CONCAT(SUBSTRING(CAST(VW_TrendCare_Variance.SummaryDate AS STRING), 1, 10), '_', Ward.wdWardCode, '_', VW_TrendCare_Variance.ShiftCode)  AS DateWardShift
                        --, CONCAT(Ward.wdWardCode, '_' ,VW_TrendCare_Variance.ShiftCode) as WardShift    -- for joining to Model of Care
                        , SummaryShift.tlClinicalInDeptHours AS ClinicalHours
                        ,SummaryShift.tlRequiredHours  AS RequiredHours
                        --, VarianceHours/(SummaryShift.tlRequiredHours - SummaryShift.[tlClinicalInDeptHours]) as VarianceperFTE
                    FROM  VW_TrendCare_Variance, current_time
                    JOIN silver_live.cds_trc_ward AS Ward ON (VW_TrendCare_Variance.WardCode = Ward.wdWardCode)
                    JOIN silver_live.cds_trc_summaryshift AS SummaryShift ON 
                    (VW_TrendCare_Variance.SummaryDate = SummaryShift.tlDate 
                    AND VW_TrendCare_Variance.ShiftCode = SummaryShift.tlShiftCode
                    AND VW_TrendCare_Variance.WardCode = SummaryShift.tlWardCode)
					LEFT Join silver_live.cds_trc_wardinterface WI on Ward.wdWardCode = WI.wiWardCode and WI.wiForPMI =1
                    WHERE VW_TrendCare_Variance.SummaryDate >= DATE_Add(day, (datediff(day, TIMESTAMP'1900-01-01', now) - 1), TIMESTAMP'1900-01-01')                                -- Retrieve data from the day before to reduce the size of the inner-query.
					
                    AND Ward.wdName NOT LIKE 'Z%'  -- ignore records where the ward name has been prefixed
                    and VW_TrendCare_Variance.CurrentShift = 'Y' and WI.wiIOCode is not null
)

SELECT
    TCWardCode
	,CMSWardCode
    , WardName
    , SummaryDate
    , ShiftCode
    , ShiftNumber
    , CurrentShift
    , VarianceHours
    , NumberUncategorised
    , VarianceHourMinute
    , TrendCareColourRed
    , TrendCareColourGreen
    , TrendCareVarianceText
    , DateWardShift
    ,ClinicalHours
    ,RequiredHours
	,Case when ClinicalHours = 0 then null else (ClinicalHours-RequiredHours)/(ClinicalHours/8) END AS  VariancePerFTE
	, Case when ClinicalHours = 0 Then '0'
		ELSE 
			REPLACE(cast(cast((ClinicalHours-RequiredHours)/(ClinicalHours/8) as int)
														+ (
														(((ClinicalHours-RequiredHours)/(ClinicalHours/8) 
														- cast((ClinicalHours-RequiredHours)/(ClinicalHours/8) as int))*.60)
														)
													 as decimal(10,2))
													 , '.', ':')
			END as VariancePerFTEHourMinute
	, '' AS Blank
FROM tbl
WHERE tbl.SummaryDate = DATE_Add(day, (datediff(day, TIMESTAMP'1900-01-01', tbl.CurrentShiftDate)), TIMESTAMP'1900-01-01')     



""")

# COMMAND ----------


