# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 9 Sept 2024 | 1       | Janesa R    | Initial draft      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_covid_patient_admissions_details """)

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_covid_patient_admissions_details
AS

WITH current_datetime AS (
SELECT
    from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
)

SELECT DISTINCT 
pt.Patient_ID
, Patient_NHI
, Patient_First_Name
, Patient_Middle_Name
, Patient_Last_Name
, CONCAT(Patient_Last_Name, ', ', Patient_First_Name) as Patient_Full_Name
, Patient_DOB
, CAST(Patient_Age_Year AS INT) as Patient_Age_Year
, Patient_Deceased_Date
, CASE WHEN Patient_Deceased_Date IS NOT NULL THEN 'Y' ELSE 'N' END as Patient_Deceased_Flag
, ad.Admission_ID 
, Admission_Number
, Admission_DateTime
, Admission_Type_Code
, Inpatient_Admission_Type_Code
, Inpatient_Admission_Type_Desc
, Original_Admission_ID
, Actual_Arrival_DateTime
, Clinician_Seen_DateTime
, Estimated_Discharge_DateTime
, Medical_Discharge_DateTime
, Actual_Discharge_DateTime
, Intent_DateTime
, Ambul_Handover_Comp_DateTime
, Visit_Status_Code
, Visit_Comment
, Inpatient_Short_Stay_Intent
, Length_Of_Stay
, ad.Is_Current
, ad.processing_time
, ad.watermark_value
FROM
    hive_metastore.silver_live.cds_patient pt, current_datetime
INNER JOIN silver_live.cds_admission ad ON  ad.Patient_ID = pt.Patient_ID
WHERE
    ad.Admission_Type_Code IN ('I', 'E')
    AND ((ad.Visit_Status_Code = 'A' and ad.Actual_Discharge_DateTime is null)
    OR (ad.Visit_Status_Code = 'D' AND cast(ad.Actual_Discharge_DateTime as date) = cast(DATEADD(day, -1, now) as date)))  -- deceased from yesterday
    AND pt.Patient_NHI <> 'MBP0603' -- temporarily remove to exclude incorrect DOB

""")

# COMMAND ----------


