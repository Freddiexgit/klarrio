# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 23 May 2024 | 1       | Janesa R       | Initial build of inpatient and ED view                                     |
# MAGIC

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_outpatient""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_outpatient
AS
SELECT DISTINCT
  pt.Patient_ID,
  Patient_NHI,
  Patient_First_Name,
  Patient_Middle_Name,
  Patient_Last_Name,
  Patient_DOB,
  Patient_Age_Year,
  Patient_Age_Month,
  Patient_Gender_Code,
  Patient_Sex,
  EDC_Agreed_Date,
  Patient_Deceased_Date,
  Patient_Domicile_Code,
  Patient_Ethnicity,
  Is_Interpreter_Required,
  Preferred_Language,
  AlertFlag,
  FLOOR(ROUND(DATEDIFF(HOUR, pt.Patient_DOB, from_utc_timestamp(current_timestamp(), 'Pacific/Auckland')) / 8766.0, 2)) AS Age,
  concat(Patient_Last_Name, ', ', Patient_First_Name) as Patient_Full_Name,
  pt.source_file,
  pt.processing_time
FROM
   silver_live.cds_patient pt
LEFT JOIN silver_live.cds_admission ad ON
    ad.Patient_ID = pt.Patient_ID
WHERE
    ad.Admission_Type_Code in ('O')
    AND ad.Actual_Discharge_DateTime IS NULL
    AND ad.Visit_Status_Code in ('A', 'P')
""")
