# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 30-Aug-2024 | 1       | Khalid J       | Create first draft of presentation view for icag dashboard      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_ioc_icag_occupancy""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_ioc_icag_occupancy
AS

With current_time AS (
SELECT
    from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
),
Total_Reserved_Beds_Today as(
-- the allocated beds today only 
Select
    DISTINCT COUNT(mvmt.Admission_id) as Total_Reserved_Beds,
    mvmt.Location_ID
from
    hive_metastore.silver_live.cds_movement mvmt,
    current_time
where
    mvmt.Movement_End_Datetime is null
    and mvmt.Movement_Code IN('Move', 'Booking')
    and mvmt.Movement_Status IN('Transfer', 'Requested', 'Accepted')
    and mvmt.Movement_Type IN('Ward Transfer', 'Bed Request')
    and mvmt.Movement_End_Datetime IS NULL
    and mvmt.Location_ID IS NOT NULL
    and date(mvmt.Movement_Start_Datetime) = date(now)
    and mvmt.bed_id IS NOT NULL
group by
    mvmt.Location_ID
),
Total_Occupied_Beds as( --Both allocated and not allocated beds will come from here 
Select
    DISTINCT COUNT(adm.Admission_id) as Total_Occupied_Beds,
    mvmt.Location_ID
from
    hive_metastore.silver_live.cds_movement mvmt
Left outer join hive_metastore.silver_live.cds_admission adm on
    adm.admission_id = mvmt.admission_id
Left outer join hive_metastore.silver_live.cds_medical_record mr on
     mvmt.admission_id = mr.Admission_ID 
where
    mvmt.Movement_Code = 'Move'
    and mvmt.Movement_Status = 'Transfer'
    and mvmt.Movement_Type = 'Ward Transfer'
    and mvmt.Movement_End_Datetime IS NULL
    --and adm.Estimated_Discharge_DateTime IS NOT NULL
    and adm.Actual_Discharge_DateTime IS NULL
    and adm.Admission_Type_Code IN('I')
    and adm.Visit_Status_Code IN('A')
    group by
        mvmt.Location_ID
),
Total_Restricted_Beds as (
select
    w.IOC_Ward_Type,
    w.Ward_Code,
    count( distinct rb.Bed_ID) as Total_Restricted_Beds
from
    hive_metastore.silver_live.cds_ref_bed rb
LEFT JOIN hive_metastore.silver_live.cds_ref_room R on
    R.room_ID = RB.Room_ID
left join hive_metastore.gold_live.vw_pres_ref_ward w on
    w.Ward_ID = rb.Ward_ID
left join hive_metastore.silver_live.cds_bed_status bs on
    rb.bed_id = bs.Bed_ID
where
    Is_Bed_Restricted = 'Y'
group by
    w.Ward_Code,
    w.IOC_Ward_Type
),
HITH_Details_Snapshot as (
select 
	'252' as Location_ID,
    'HITH' as Location_Code,
    'HITH - Split Set 1' as Location_Desc,
    20 as Approved_Beds,
    0 as Total_Restricted_Beds,
	0 as Total_Reserved_Beds, 
	20 as Total_Resourced_Beds,
	COUNT(adm.Admission_Id) AS Total_Occupied_Beds,
    20 - COUNT(adm.Admission_Id)  AS Total_Available_Beds,
	(COUNT(adm.Admission_Id) / 20) AS Percent_Occupancy 
from 
	hive_metastore.silver_live.cds_admission adm
where
	adm.PreAdm_Clinician in('HITH Doctor')
),
RCAT_Details_Snapshot as (
select 
	'252' as Location_ID,
    'RCAT' as Location_Code,
    'RCAT - Split Set 2' as Location_Desc,
    20 as Approved_Beds,
    0 as Total_Restricted_Beds,
	0 as Total_Reserved_Beds, 
	20 as Total_Resourced_Beds,
	COUNT(adm.Admission_Id) AS Total_Occupied_Beds,
    20 - COUNT(adm.Admission_Id)  AS Total_Available_Beds,
	(COUNT(adm.Admission_Id) / 20) AS Percent_Occupancy 
from 
	hive_metastore.silver_live.cds_admission adm
where
	adm.PreAdm_Clinician in('RCAT Doctor')
)
SELECT
    Loc.Location_ID,
    Loc.Location_Code,
    Loc.Location_Desc,
    20 as Approved_Beds,   
    IFNULL(R.Total_Restricted_Beds,0) as Total_Restricted_Beds,
	IFNULL(RB.Total_Reserved_Beds,0) AS Total_Reserved_Beds, 
	20 - IFNULL(R.Total_Restricted_Beds,0) as Total_Resourced_Beds,
	IFNULL(OCC.Total_Occupied_Beds,0) AS Total_Occupied_Beds,
    20 - IFNULL(OCC.Total_Occupied_Beds,0) - IFNULL(R.Total_Restricted_Beds,0) AS Total_Available_Beds,
	IFNULL(OCC.Total_Occupied_Beds,0) / (20 - IFNULL(R.Total_Restricted_Beds,0) ) AS Percent_Occupancy   	 
FROM hive_metastore.silver_live.cds_location Loc
LEFT OUTER JOIN Total_Occupied_Beds OCC ON
    Loc.Location_ID = OCC.Location_ID
LEFT OUTER JOIN Total_Reserved_Beds_Today RB ON
    Loc.Location_ID = RB.Location_ID
LEFT OUTER JOIN Total_Restricted_Beds R ON
    Loc.Location_Code = R.Ward_Code
WHERE Loc.Location_ID IN('261')
UNION --For RCAT and HITH calculations
SELECT
	Location_ID,
	Location_Code,
	Location_Desc,
	Approved_Beds,
	Total_Restricted_Beds,
	Total_Reserved_Beds, 
	Total_Resourced_Beds,
	Total_Occupied_Beds,
	Total_Available_Beds,
	Percent_Occupancy 
from HITH_Details_Snapshot
UNION
SELECT
	Location_ID,
	Location_Code,
	Location_Desc,
	Approved_Beds,
	Total_Restricted_Beds,
	Total_Reserved_Beds, 
	Total_Resourced_Beds,
	Total_Occupied_Beds,
	Total_Available_Beds,
	Percent_Occupancy 
from RCAT_Details_Snapshot


""")

# COMMAND ----------


