# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 28-Mar-2024 | 1       | Siddharth S    | Create first draft of presentation view from cds_diagnosis  delta table      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_theatre_target_colors""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_theatre_target_colors
AS

WITH current_time AS (
SELECT
    from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
    )
,StaticMapping AS (
select 
cts.Session_Id 
, CASE
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now)), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') THEN 'Current Week'
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01') THEN 'T-1'
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') THEN 'T-2'
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') THEN 'T-3'
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') THEN 'T-4'
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') THEN 'T-5'
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 7), TIMESTAMP'1900-01-01') THEN 'T-6'
END AS WeekNumber
, case
	when cl.Speciality_Desc like '%Liver Transplant%' 
		then 'Liver Transplant'
	when cl.Speciality_Desc like '%Urology%' 
		then 'Urology'
	when cl.Speciality_Desc like '%Ophthalmology%' 
		then 'Ophthalmology'
	when cl.Speciality_Desc like '%Paediatric%' 
		then 'Paediatric Surgery'
	when cl.Speciality_Desc like '%Neurosurgery%' 
		then 'Neurosurgery'
	when cl.Speciality_Desc like '%Orthopaedics%' 
		then 'Orthopaedics'
	when cl.Speciality_Desc like '%Gynaecological%' 
							or cl.Speciality_Desc like '%Gynae%'
		then 'Gynaecological'
	when cl.Speciality_Desc like '%General Surgery%' 
							or cl.Speciality_Desc like '%General%'
		then 'General Surgery'
	when cl.Speciality_Desc like '%Renal Transplant%'
		then 'Renal Transplant'
	when cl.Speciality_Desc is not null	or cl.Location_Desc is not null			
		then 'Default'
	else NULL
end as StaticSpecialty
, CASE
	--week 1
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now)), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') 
		and cl.Speciality_Desc like '%Liver Transplant%'
		THEN  concat('Liver Transplant' , '_', cts.Session_Type, '_' , '1')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now)), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') 
		and cl.Speciality_Desc like '%Urology%'
		THEN  concat('Urology' , '_', cts.Session_Type, '_' , '1')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now)), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') 
		and cl.Speciality_Desc like '%Ophthalmology%'
		THEN  concat('Ophthalmology' , '_', cts.Session_Type, '_' , '1')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now)), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') 
		and cl.Speciality_Desc like '%Paediatric%'
		THEN  concat('Paediatric Surgery' , '_', cts.Session_Type, '_' , '1')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now)), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') 
		and cl.Speciality_Desc like '%Neurosurgery%'
		THEN  concat('Neurosurgery' , '_', cts.Session_Type, '_' , '1')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now)), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') 
		and cl.Speciality_Desc like '%Orthopaedics%'
		THEN  concat('Orthopaedics' , '_', cts.Session_Type, '_' , '1')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now)), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') 
		and (cl.Speciality_Desc like '%Gynaecological%'
			or cl.Speciality_Desc like '%Gynae%')
		THEN  concat('Gynaecological' , '_', cts.Session_Type, '_' , '1')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now)), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') 
		and (cl.Speciality_Desc like '%General Surgery%' 
			or cl.Speciality_Desc like '%General%')
		THEN  concat('General Surgery' , '_', cts.Session_Type, '_' , '1')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now)), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') 
		and cl.Speciality_Desc like '%Renal Transplant%'
		THEN  concat('Renal Transplant' , '_', cts.Session_Type, '_' , '1')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now)), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') 
		and (cl.Speciality_Desc is not null	or cl.Location_Desc is not null)
		THEN  concat('Default' , '_', cts.Session_Type, '_' , '1')

	-- week 2	
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01') 
		and cl.Speciality_Desc like '%Liver Transplant%'
		THEN  concat('Liver Transplant' , '_', cts.Session_Type, '_' , '2')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Urology%'
		THEN  concat('Urology' , '_', cts.Session_Type, '_' , '2')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Ophthalmology%'
		THEN  concat('Ophthalmology' , '_', cts.Session_Type, '_' , '2')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Paediatric%'
		THEN  concat('Paediatric Surgery' , '_', cts.Session_Type, '_' , '2')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Neurosurgery%'
		THEN  concat('Neurosurgery' , '_', cts.Session_Type, '_' , '2')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Orthopaedics%'
		THEN  concat('Orthopaedics' , '_', cts.Session_Type, '_' , '2')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01')
		and (cl.Speciality_Desc like '%Gynaecological%'
			or cl.Speciality_Desc like '%Gynae%')
		THEN  concat('Gynaecological' , '_', cts.Session_Type, '_' , '2')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01')
		and (cl.Speciality_Desc like '%General Surgery%' 
			or cl.Speciality_Desc like '%General%')
		THEN  concat('General Surgery' , '_', cts.Session_Type, '_' , '2')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Renal Transplant%'
		THEN  concat('Renal Transplant' , '_', cts.Session_Type, '_' , '2')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01')
		and (cl.Speciality_Desc is not null	or cl.Location_Desc is not null)
		THEN  concat('Default' , '_', cts.Session_Type, '_' , '2')	
		
	-- week 3
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') 
		and cl.Speciality_Desc like '%Liver Transplant%'
		THEN  concat('Liver Transplant' , '_', cts.Session_Type, '_' , '3')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Urology%'
		THEN  concat('Urology' , '_', cts.Session_Type, '_' , '3')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Ophthalmology%'
		THEN  concat('Ophthalmology' , '_', cts.Session_Type, '_' , '3')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Paediatric%'
		THEN  concat('Paediatric Surgery' , '_', cts.Session_Type, '_' , '3')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Neurosurgery%'
		THEN  concat('Neurosurgery' , '_', cts.Session_Type, '_' , '3')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Orthopaedics%'
		THEN  concat('Orthopaedics' , '_', cts.Session_Type, '_' , '3')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01')
		and (cl.Speciality_Desc like '%Gynaecological%'
			or cl.Speciality_Desc like '%Gynae%')
		THEN  concat('Gynaecological' , '_', cts.Session_Type, '_' , '3')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01')
		and (cl.Speciality_Desc like '%General Surgery%' 
			or cl.Speciality_Desc like '%General%')
		THEN  concat('General Surgery' , '_', cts.Session_Type, '_' , '3')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Renal Transplant%'
		THEN  concat('Renal Transplant' , '_', cts.Session_Type, '_' , '3')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01')
		and (cl.Speciality_Desc is not null	or cl.Location_Desc is not null)
		THEN  concat('Default' , '_', cts.Session_Type, '_' , '3')
		
	-- week 4
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') 
		and cl.Speciality_Desc like '%Liver Transplant%'
		THEN  concat('Liver Transplant' , '_', cts.Session_Type, '_' , '4')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Urology%'
		THEN  concat('Urology' , '_', cts.Session_Type, '_' , '4')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Ophthalmology%'
		THEN  concat('Ophthalmology' , '_', cts.Session_Type, '_' , '4')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Paediatric%'
		THEN  concat('Paediatric Surgery' , '_', cts.Session_Type, '_' , '4')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Neurosurgery%'
		THEN  concat('Neurosurgery' , '_', cts.Session_Type, '_' , '4')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Orthopaedics%'
		THEN  concat('Orthopaedics' , '_', cts.Session_Type, '_' , '4')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01')
		and (cl.Speciality_Desc like '%Gynaecological%'
			or cl.Speciality_Desc like '%Gynae%')
		THEN  concat('Gynaecological' , '_', cts.Session_Type, '_' , '4')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01')
		and (cl.Speciality_Desc like '%General Surgery%' 
			or cl.Speciality_Desc like '%General%')
		THEN  concat('General Surgery' , '_', cts.Session_Type, '_' , '4')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Renal Transplant%'
		THEN  concat('Renal Transplant' , '_', cts.Session_Type, '_' , '4')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01')
		and (cl.Speciality_Desc is not null	or cl.Location_Desc is not null)
		THEN  concat('Default' , '_', cts.Session_Type, '_' , '4')	
		
	-- week 5
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') 
		and cl.Speciality_Desc like '%Liver Transplant%'
		THEN  concat('Liver Transplant' , '_', cts.Session_Type, '_' , '5')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Urology%'
		THEN  concat('Urology' , '_', cts.Session_Type, '_' , '5')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Ophthalmology%'
		THEN  concat('Ophthalmology' , '_', cts.Session_Type, '_' , '5')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Paediatric%'
		THEN  concat('Paediatric Surgery' , '_', cts.Session_Type, '_' , '5')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Neurosurgery%'
		THEN  concat('Neurosurgery' , '_', cts.Session_Type, '_' , '5')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Orthopaedics%'
		THEN  concat('Orthopaedics' , '_', cts.Session_Type, '_' , '5')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01')
		and (cl.Speciality_Desc like '%Gynaecological%'
			or cl.Speciality_Desc like '%Gynae%')
		THEN  concat('Gynaecological' , '_', cts.Session_Type, '_' , '5')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01')
		and (cl.Speciality_Desc like '%General Surgery%' 
			or cl.Speciality_Desc like '%General%')
		THEN  concat('General Surgery' , '_', cts.Session_Type, '_' , '5')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Renal Transplant%'
		THEN  concat('Renal Transplant' , '_', cts.Session_Type, '_' , '5')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01')
		and (cl.Speciality_Desc is not null	or cl.Location_Desc is not null)
		THEN  concat('Default' , '_', cts.Session_Type, '_' , '5')	
		
	-- week 6
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') 
		and cl.Speciality_Desc like '%Liver Transplant%'
		THEN  concat('Liver Transplant' , '_', cts.Session_Type, '_' , '6')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Urology%'
		THEN  concat('Urology' , '_', cts.Session_Type, '_' , '6')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Ophthalmology%'
		THEN  concat('Ophthalmology' , '_', cts.Session_Type, '_' , '6')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Paediatric%'
		THEN  concat('Paediatric Surgery' , '_', cts.Session_Type, '_' , '6')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Neurosurgery%'
		THEN  concat('Neurosurgery' , '_', cts.Session_Type, '_' , '6')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Orthopaedics%'
		THEN  concat('Orthopaedics' , '_', cts.Session_Type, '_' , '6')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01')
		and (cl.Speciality_Desc like '%Gynaecological%'
			or cl.Speciality_Desc like '%Gynae%')
		THEN  concat('Gynaecological' , '_', cts.Session_Type, '_' , '6')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01')
		and (cl.Speciality_Desc like '%General Surgery%' 
			or cl.Speciality_Desc like '%General%')
		THEN  concat('General Surgery' , '_', cts.Session_Type, '_' , '6')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Renal Transplant%'
		THEN  concat('Renal Transplant' , '_', cts.Session_Type, '_' , '6')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01')
		and (cl.Speciality_Desc is not null	or cl.Location_Desc is not null)
		THEN  concat('Default' , '_', cts.Session_Type, '_' , '6')	
		
	-- week 7
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 7), TIMESTAMP'1900-01-01') 
		and cl.Speciality_Desc like '%Liver Transplant%'
		THEN  concat('Liver Transplant' , '_', cts.Session_Type, '_' , '7')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 7), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Urology%'
		THEN  concat('Urology' , '_', cts.Session_Type, '_' , '7')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 7), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Ophthalmology%'
		THEN  concat('Ophthalmology' , '_', cts.Session_Type, '_' , '7')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 7), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Paediatric%'
		THEN  concat('Paediatric Surgery' , '_', cts.Session_Type, '_' , '7')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 7), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Neurosurgery%'
		THEN  concat('Neurosurgery' , '_', cts.Session_Type, '_' , '7')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 7), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Orthopaedics%'
		THEN  concat('Orthopaedics' , '_', cts.Session_Type, '_' , '7')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 7), TIMESTAMP'1900-01-01')
		and (cl.Speciality_Desc like '%Gynaecological%'
			or cl.Speciality_Desc like '%Gynae%')
		THEN  concat('Gynaecological' , '_', cts.Session_Type, '_' , '7')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 7), TIMESTAMP'1900-01-01')
		and (cl.Speciality_Desc like '%General Surgery%' 
			or cl.Speciality_Desc like '%General%')
		THEN  concat('General Surgery' , '_', cts.Session_Type, '_' , '7')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 7), TIMESTAMP'1900-01-01')
		and cl.Speciality_Desc like '%Renal Transplant%'
		THEN  concat('Renal Transplant' , '_', cts.Session_Type, '_' , '7')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 7), TIMESTAMP'1900-01-01')
		and (cl.Speciality_Desc is not null	or cl.Location_Desc is not null)
		THEN  concat('Default' , '_', cts.Session_Type, '_' , '7')	
		
	END AS StaticWeekNumber_Key
, CAST(date_format(cts.Session_DateTime, 'yyyyMMdd') AS char(8)) as Session_Start_Date_Key
, cts.Session_Date as SessionDate
, cl.Location_Desc as SessionSpecialty
, cts.Session_Type 
from silver_live.cds_theatre_session cts , current_time
left outer join silver_live.cds_location cl on cl.Location_ID = cts.Specialty_Location_ID 
left outer join silver_live.cds_location cl2 on cl2.Location_ID = cts.Location_ID 
--left outer join silver_live.cds_movement cm on cm.Location_ID = cts.Location_ID  and cm.Movement_Type in ('THEATRE BOOKING')
where 1=1
)


/* TheatreSummary View for Gold_Live */

select 
cts.Session_Id 
, cl2.Location_Code as TheatreSuite
, cts.Theatre_Code  as TheatreCode 
, CASE
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now)), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') THEN 'Current Week'
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01') THEN 'T-1'
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') THEN 'T-2'
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') THEN 'T-3'
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') THEN 'T-4'
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') THEN 'T-5'
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 7), TIMESTAMP'1900-01-01') THEN 'T-6'
END AS WeekNumber
, CASE
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now)), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') 
		THEN  concat(cl.Location_Desc , '_', cts.Session_Type, '_' , '1')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 1), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01') 
		THEN concat(cl.Location_Desc , '_', cts.Session_Type, '_' , '2')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 2), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') 
		THEN concat(cl.Location_Desc , '_', cts.Session_Type, '_' , '3')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 3), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') 
		THEN concat(cl.Location_Desc , '_', cts.Session_Type, '_' , '4')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 4), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') 
		THEN concat(cl.Location_Desc , '_', cts.Session_Type, '_' , '5')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 5), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') 
		THEN concat(cl.Location_Desc , '_', cts.Session_Type, '_' , '6')
	WHEN cts.Session_Date BETWEEN DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 6), TIMESTAMP'1900-01-01') AND DATE_Add(week, (datediff(Week, TIMESTAMP'1900-01-01', now) + 7), TIMESTAMP'1900-01-01') 
		THEN concat(cl.Location_Desc , '_', cts.Session_Type, '_' , '7')
END AS StaticWeekNumber_Key
, CAST(date_format(cts.Session_DateTime, 'yyyyMMdd') AS char(8)) as Session_Start_Date_Key
, cts.Session_Date as SessionDate
, cts.AMPM as AMPM
, cts.Session_Start_Time as SessionStartTime 
, cts.Session_End_Time as SessionEndTime
, cl.Location_Desc as SessionSpecialty
, cts.Session_Type 
, cts.Session_Consultant as SessionConsultant
, MAX(DATEDIFF(MINUTE , cts.Session_Start_Time, cts.Session_End_Time)) AS SessionDuration
, SUM(DATEDIFF(MINUTE , ca.Appointment_Start_Time, ca.Appointment_End_Time)) AS BookedMins
, MAX(DATEDIFF(MINUTE , cts.Session_Start_Time, cts.Session_End_Time)) - SUM(DATEDIFF(MINUTE , ca.Appointment_Start_Time, ca.Appointment_End_Time)) AS AvailableMins
, SUM(DATEDIFF(MINUTE , ca.Appointment_Start_Time, ca.Appointment_End_Time)) / MAX(DATEDIFF(MINUTE , cts.Session_Start_Time, cts.Session_End_Time)) * 100 AS BookedPercent
, tsua.Target*100 as Target
, tsua.Red_Max*100 as Red_Max
, tsua.Orange_Max*100 as Orange_Max
, tsua.Green_Max*100 as Green_Max
, sm.StaticSpecialty
, CASE 
	when sm.WeekNumber in ('Current Week', 'T-1', 'T-2', 'T-3', 'T-4', 'T-5', 'T-6' )  and sm.StaticSpecialty in ('Liver Transplant', 'Urology', 'Ophthalmology', 'Paediatric Surgery', 'Neurosurgery' , 'Orthopaedics' , 'Gynaecological' , 'Default', 'General Surgery', 'Renal Transplant')
		and SUM(DATEDIFF(MINUTE , ca.Appointment_Start_Time, ca.Appointment_End_Time)) / MAX(DATEDIFF(MINUTE , cts.Session_Start_Time, cts.Session_End_Time)) * 100 < tsua.Red_Max*100
	then 'Red'
	when sm.WeekNumber in ('Current Week', 'T-1', 'T-2', 'T-3', 'T-4', 'T-5', 'T-6' )  and sm.StaticSpecialty in ('Liver Transplant', 'Urology', 'Ophthalmology', 'Paediatric Surgery', 'Neurosurgery' , 'Orthopaedics' , 'Gynaecological' , 'Default', 'General Surgery', 'Renal Transplant') 
		and SUM(DATEDIFF(MINUTE , ca.Appointment_Start_Time, ca.Appointment_End_Time)) / MAX(DATEDIFF(MINUTE , cts.Session_Start_Time, cts.Session_End_Time)) * 100 between tsua.Red_Max and tsua.Orange_Max*100
	then 'Orange'
	when sm.WeekNumber in ('Current Week', 'T-1', 'T-2', 'T-3', 'T-4', 'T-5', 'T-6' )  and sm.StaticSpecialty in ('Liver Transplant', 'Urology', 'Ophthalmology', 'Paediatric Surgery', 'Neurosurgery' , 'Orthopaedics' , 'Gynaecological' , 'Default', 'General Surgery', 'Renal Transplant')  
		and SUM(DATEDIFF(MINUTE , ca.Appointment_Start_Time, ca.Appointment_End_Time)) / MAX(DATEDIFF(MINUTE , cts.Session_Start_Time, cts.Session_End_Time)) * 100 between tsua.Orange_Max and tsua.Green_Max*100
	then 'Green'
	when sm.WeekNumber in ('Current Week', 'T-1', 'T-2', 'T-3', 'T-4', 'T-5', 'T-6' )  and sm.StaticSpecialty in ('Liver Transplant', 'Urology', 'Ophthalmology', 'Paediatric Surgery', 'Neurosurgery' , 'Orthopaedics' , 'Gynaecological' , 'Default', 'General Surgery', 'Renal Transplant')  
		and SUM(DATEDIFF(MINUTE , ca.Appointment_Start_Time, ca.Appointment_End_Time)) / MAX(DATEDIFF(MINUTE , cts.Session_Start_Time, cts.Session_End_Time)) * 100 > tsua.Green_Max*100
	then 'Purple'
	-- Additional Colours
	when sm.WeekNumber in ('Current Week', 'T-1', 'T-2', 'T-3', 'T-4', 'T-5', 'T-6' ) 
		and (tsua.Target = 0 or tsua.Target IS NULL) and (SUM(DATEDIFF(MINUTE , ca.Appointment_Start_Time, ca.Appointment_End_Time)) / MAX(DATEDIFF(MINUTE , cts.Session_Start_Time, cts.Session_End_Time)) * 100 = 0 
		or SUM(DATEDIFF(MINUTE , ca.Appointment_Start_Time, ca.Appointment_End_Time)) / MAX(DATEDIFF(MINUTE , cts.Session_Start_Time, cts.Session_End_Time)) * 100 IS NULL)
		then 'White'
	when sm.WeekNumber in ('Current Week', 'T-1', 'T-2', 'T-3', 'T-4', 'T-5', 'T-6' ) and (SUM(DATEDIFF(MINUTE , ca.Appointment_Start_Time, ca.Appointment_End_Time)) / MAX(DATEDIFF(MINUTE , cts.Session_Start_Time, cts.Session_End_Time)) * 100 = 0 
		or SUM(DATEDIFF(MINUTE , ca.Appointment_Start_Time, ca.Appointment_End_Time)) / MAX(DATEDIFF(MINUTE , cts.Session_Start_Time, cts.Session_End_Time)) * 100 IS NULL)
		then 'Pink'
END as colourflag

from silver_live.cds_theatre_session cts , current_time
left outer join silver_live.cds_location cl on cl.Location_ID = cts.Specialty_Location_ID 
left outer join silver_live.cds_location cl2 on cl2.Location_ID = cts.Location_ID 
left outer join silver_live.cds_movement cm on cm.Location_ID = cts.Location_ID  and cm.Movement_Type in ('THEATRE BOOKING')
left outer join silver_live.cds_appointment ca on ca.Session_ID = cts.Session_Id 
left outer join StaticMapping sm on sm.Session_Id = cts.Session_Id 
left outer join silver_live.cds_ref_theatre_specialty_usage_alert tsua on tsua.UID = sm.StaticWeekNumber_Key
where 1=1
GROUP BY
	cts.Session_Id
	, cl2.Location_Code 
    , cts.Theatre_Code
    , cts.Session_Date
    , cts.AMPM
    , cts.Session_Type
    , cts.Session_DateTime
    , cts.Session_Start_Time 
    , cts.Session_End_Time 
    , cl.Location_Desc 
    , cts.Session_Consultant
    , now
    , tsua.Target 
    , tsua.Red_Max
    , tsua.Orange_Max
    , tsua.Green_Max
    , sm.StaticSpecialty
    , sm.WeekNumber

""")

# COMMAND ----------


