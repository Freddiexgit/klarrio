# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 03-May-2024 | 1       | Janesa R       | Created vw_pres_ioc_expected_arrivals
# MAGIC | 06-Aug-2024 | 2       | Khalid J       | Updated vw_pres_ioc_expected_arrivals to accomodate Clinican and Specialty details for Pre-Admissions

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_ioc_expected_arrivals""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_ioc_expected_arrivals
AS

With current_time AS (
SELECT
    from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
),
Completed_Ward_Transfer as (
select
    Admission_ID,
    Location_ID,
    row_number() OVER (PARTITION BY Admission_ID
ORDER BY
    Movement_Sequence DESC) as Row_Number
from
    hive_metastore.silver_live.cds_movement
where
    Movement_Code = 'Move'
    and Movement_Status = 'Done'
    and Movement_Type = 'Ward Transfer'
   
),
Prev_Ward_Transfer as (
select
    Admission_ID,
    Location_ID
from
    Completed_Ward_Transfer
where
    Row_Number = 1 
),
Prev_Location as (
select
    Location_ID,
    Location_Code
from
    hive_metastore.silver_live.cds_location loc
where
    loc.Location_Type in ('Emergency', 'Ward')
),
Admission_Status_Check as(
select
    Admission_ID,
    Visit_Status_Code,
    PreAdm_Clinician, 
    PreAdm_Specialty
from
    silver_live.cds_admission
where
    Visit_Status_Code = 'P'
),
Occupied_Bed_Check as(
select
    Bed_ID
from
    gold_live.vw_pres_movement
where
    Current_Ward_Transfer = 'Y'
)
SELECT
    eam.UID,
    eam.Admission_ID,
    eam.Next_Location_ID as Sch_Location_ID,
    eam.Next_Location_ID as Sch_As_Current_Location_ID, -- for testing with Occupancy
    eam.Bed_ID,
    case
        when obc.Bed_ID is not null then 'Y'
        else 'N'
    end as EA_with_Occupied_Bed_Flag,
    case
        when adc.Visit_Status_Code = 'P' then null
        else loc.Location_Code
    end as Prev_Location,
    eam.Movement_Start_Datetime,
    CAST(date_format(eam.Movement_Start_Datetime, 'yyyyMMdd') AS INT) as Movement_Start_Date_Key,
    eam.Movement_Type,
    case
    	when adc.Visit_Status_Code = 'P' then adc.PreAdm_Specialty else eam.WT_Main_Specialty
    end as Specialty,
    case 
    	when adc.Visit_Status_Code = 'P' then adc.PreAdm_Clinician else eam.WT_Main_Clinician
    end as Current_Clinician,
    case
        when now > dateadd(hour, 1, eam.Movement_Start_Datetime) then 'Y'
        else 'N'
    end as EA_Overdue_Flag,
    'Y' as EA_flag
FROM
    hive_metastore.gold_live.vw_pres_movement eam,
    current_time
left outer join Prev_Ward_Transfer prev_wt on
    eam.Admission_ID = prev_wt.Admission_ID
    --left outer join hive_metastore.silver_live.cds_movement ct
--  on ct.Admission_ID = eam.Admission_ID and ct.Movement_Code = 'Transfer' and ct.Movement_Status = 'Transfer' and ct.Movement_Type = 'Case Transfer'
--  and ct.Movement_End_Datetime is null and ct.Movement_Is_Main = 'Y'
left outer join Prev_Location loc on loc.Location_ID =  
(case when (eam.Movement_Type = 'Bed Request') then eam.Current_Location_ID
    when (eam.Movement_Type = 'Ward Transfer' ) then prev_wt.Location_ID end)
left outer join Admission_Status_Check adc on adc.Admission_ID = eam.Admission_ID
left outer join Occupied_Bed_Check obc on obc.Bed_ID = eam.Bed_ID
where eam.Movement_End_Datetime is null 
and ((eam.Movement_Status in ('Accepted', 'Requested') and eam.Movement_Type = 'Bed Request')
      or (eam.Movement_Status = 'Transfer' and eam.Movement_Type = 'Ward Transfer' 
	  and eam.Location_ID is not null and eam.Location_ID not in (225, 226, 227) and eam.Bed_ID is null))
and eam.Movement_Start_Datetime between dateadd(day, -7, now) and dateadd(day, 7, now);

""")

# COMMAND ----------


