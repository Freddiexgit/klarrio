# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 28-Mar-2024 | 1       | Siddharth S    | Create first draft of presentation view from cds_diagnosis  delta table      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_l2_cdu_br_to_cdu_leave""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_l2_cdu_br_to_cdu_leave
AS

----Applied for active patients only
WITH currenttime AS 
(
    SELECT from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
),
wt AS
(
    SELECT 
        ad.Admission_ID AS AdmissionID,
        ad.Admission_Number AS AdmissionNumber,
        loc.Location_Code AS CurrWard,
        mv2.Movement_End_Datetime,
        ROW_NUMBER() OVER (PARTITION BY ad.Admission_Number ORDER BY mv2.Movement_Start_Datetime DESC) AS RowNum
    FROM hive_metastore.silver_live.cds_admission ad
    LEFT JOIN hive_metastore.silver_live.cds_movement mv2 
        ON ad.Admission_ID = mv2.Admission_ID
    LEFT JOIN hive_metastore.silver_live.cds_location loc 
        ON mv2.Location_ID = loc.Location_ID
    WHERE mv2.Movement_Type = 'Ward Transfer'
),
br AS 
(
    SELECT
        ad.Admission_ID AS AdmissionID,
        ad.Admission_Number AS AdmissionNumber,
        loc.Location_Code AS SchWard,
        mv2.Movement_Start_Datetime AS BRStartDatetime,
        mv2.Movement_End_Datetime AS BREndDatetime
    FROM hive_metastore.silver_live.cds_admission ad
    LEFT JOIN hive_metastore.silver_live.cds_movement mv2 
        ON ad.Admission_ID = mv2.Admission_ID
    LEFT JOIN hive_metastore.silver_live.cds_location loc 
        ON mv2.Location_ID = loc.Location_ID
    WHERE mv2.Movement_Type = 'Bed Request'
)
Select
Case When Ward = 'CDU' Then DATEDIFF(Hour, BedRequestStartDatetime, BedRequestEndDatetime) Else NULL End AS `CDU BR to CDU Leave`
,*
from 
(
SELECT
        ad.Admission_Number,
        ad.Admission_Type_Code,
        pat.Patient_NHI,
        mr.Discharge_Code,
        mv1.Movement_Type,
        mv1.movement_status,
        mv1.movement_end_datetime,
        wt.RowNum,
        ad.Admission_DateTime,
        ad.Actual_Discharge_DateTime,
        br.BRStartDatetime AS BedRequestStartDatetime,
        CASE 
            WHEN ad.Actual_Discharge_DateTime IS NULL THEN currenttime.now
            ELSE ad.Actual_Discharge_DateTime
        END AS BedRequestEndDatetime,
        wt.CurrWard as Ward
    FROM hive_metastore.silver_live.cds_admission ad
    JOIN currenttime ON 1 = 1
    LEFT JOIN hive_metastore.silver_live.cds_medical_record mr 
        ON ad.Admission_ID = mr.Admission_ID
    LEFT JOIN hive_metastore.silver_live.cds_movement mv1 
        ON ad.Admission_ID = mv1.Admission_ID
    LEFT JOIN hive_metastore.silver_live.cds_patient pat 
        ON ad.Patient_ID = pat.Patient_ID
    LEFT JOIN wt 
        ON wt.AdmissionID = mv1.Admission_ID
    LEFT JOIN br 
        ON br.AdmissionID = mv1.Admission_ID
    WHERE 1 = 1
     -- AND Admission_Type_Code = 'E'
      AND Movement_Type = 'Bed Request'
      AND (mr.Discharge_Code NOT IN ('CDUDNW', 'EDDNW') OR mr.Discharge_Code IS NULL)
      AND mv1.Specialty NOT IN ('Adult Emergency Department', 'Clinical Decision Unit')
      AND ad.Visit_Status_Code = 'A'
     )
     Where 1 = 1 
     and Ward IN ('CDU')
     and RowNum = 1

""")

# COMMAND ----------


