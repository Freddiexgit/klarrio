# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 28-Mar-2024 | 1       | Janesa R    | Initial build     |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_ioc_occupancy_snapshot""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_ioc_occupancy_snapshot
AS

SELECT 
    Location_ID, 
    Hour_x,
    AVG(Occupancy) AS Occupancy_PerHour,
    CASE 
        WHEN Admission_Date >= Current_Date THEN 'Today' 
        ELSE 'Other' 
    END AS Day -- for testing
--        CASE 
--        WHEN Admission_Date >= to_date(current_timestamp()) THEN 'Today' 
--        ELSE 'Other' 
--    END AS Day
FROM hive_metastore.silver_live.vw_cds_occupancy_snapshot
WHERE 
Admission_Date >= date_sub(Current_Date, 7)
--Admission_Date >= date_sub(to_date(current_timestamp()), 7)
GROUP BY 
    Location_ID, 
    Hour_x,
    CASE 
        WHEN Admission_Date >= Current_Date THEN 'Today' 
        ELSE 'Other' 
    END
--    CASE 
--        WHEN Admission_Date >= to_date(current_timestamp()) THEN 'Today' 
--        ELSE 'Other' 
--    END

""")

# COMMAND ----------


