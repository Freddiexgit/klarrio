# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 15 Aug 2024 | 1       | Janesa R    | Initial draft      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_rapid_fact_regional_theatre_event""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_rapid_fact_regional_theatre_event
AS

WITH current_time AS (
  SELECT from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
),

LatestAnaestheticRecord AS 
(
SELECT 
	  RBOP.RBOP_RowId
	, RBOP.Movement_Create_DateTime as RBOP_Movement_Create_DateTime
	, RBOP.Movement_Start_DateTime as RBOP_Movement_Start_DateTime
	, ANA.ANA_RowId
	, ANA.Movement_Create_DateTime
	, ANA.Movement_Start_DateTime
	, ROW_NUMBER() OVER (partition by RBOP.RBOP_RowId ORDER BY ANA.Movement_Create_DateTime desc) rowNumber
FROM 
	(SELECT cds_movement.Admission_ID, cds_movement.UID as RBOP_RowId, cds_movement.Movement_Start_DateTime, cds_movement.Movement_Create_DateTime, cds_movement.Movement_End_DateTime
	 FROM hive_metastore.silver_live.cds_movement cds_movement
	 WHERE cds_movement.Movement_Type = 'Theatre Booking') as RBOP	
LEFT JOIN 
	(SELECT cds_movement.Admission_ID, cds_movement.UID as ANA_RowId, cds_movement.Movement_Start_DateTime, cds_movement.Movement_Create_DateTime, cds_movement.Movement_End_DateTime
	 FROM hive_metastore.silver_live.cds_movement cds_movement
	 WHERE cds_movement.Movement_Type = 'Theatre Event') as ANA
		ON ANA.Admission_ID = RBOP.Admission_ID and ANA.Movement_Create_DateTime = RBOP.Movement_Create_DateTime
)
SELECT DISTINCT
	  CASE
		WHEN cds_location.Location_Code = 'AKCH3' THEN 'F03067-A'											
		WHEN cds_location.Location_Code = 'AKCH4' THEN 'F03067-A'
		WHEN cds_location.Location_Code = 'AKCH8' THEN 'F03067-A'
		WHEN cds_location.Location_Code = 'AKCH9' THEN 'F03067-A'
		WHEN cds_location.Location_Code = 'GSU'   THEN 'F03026-J'
		WHEN cds_location.Location_Code = 'SST'   THEN 'F03052-K'
        WHEN cds_location.Location_Code = 'AKCH5' THEN 'F03067-A'
		ELSE 'FZZ999-C'
	  END	as	HPI_FACILITY_CODE
	, CASE
    	WHEN cds_ref_hospital.Hospital_Code = '3260B' then '3239' -- Starship								
    	WHEN cds_ref_hospital.Hospital_Code = '3260A' then '3212' -- Greenlane Clinical Centre
    	WHEN cds_ref_hospital.Hospital_Code = '3260C' then '3260' -- Auckland City Hospital 
    	ELSE cds_ref_hospital.Hospital_Code 
	  END as nc_facility_code
	, cds_patient.Patient_NHI as NHI																		
	, cds_admission.Admission_Number as Encounter_ID														
	, cds_appointment.Session_ID as Session_ID																		
	, CASE WHEN cds_appointment.Appointment_Cancel_DateTime IS NOT NULL THEN 1 ELSE 0 END as Cancelled_Flag			
	, cds_appointment.Appointment_Cancel_DateTime as cancelled_datetime												
	, cds_movement.Cancelled_Reason as cancelled_reason																
	, CASE 																											
      	WHEN cds_movement.Cancelled_Reason ='Acute Bed Unavailable - Ward' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Acute Bed Unavailable -ICU/ NICU' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Acute Cancelled By Patient' THEN 'Patient Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Acute Equip/Enviro Unavailable' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Acute Operation not needed' THEN 'Other'
      	WHEN cds_movement.Cancelled_Reason ='Acute Other' THEN 'Other'
      	WHEN cds_movement.Cancelled_Reason ='Acute Overbook Difficult case' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Acute Overbook Plan By Surgeon' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Acute Previous List Overrun' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Acute Pt DNA app Confirmed' THEN 'Patient Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Acute Pt unfit - Cx By Surgeon' THEN 'Patient Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Acute Pt Unfit -acute Unwell' THEN 'Patient Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Acute Pt Unfit -Cx by Anaesthetist' THEN 'Patient Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Acute Pt Unfit not fasted' THEN 'Patient Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Acute Staff iss Anaes Tech' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Acute Staff iss Dr Anaesthetist' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Acute Staff iss Dr Surgeon' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Acute Staff iss Nurses' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Acute Sub by Acute' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Acute Sub by Elective' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Acute. Cancellation' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Bed Unavailable - ICU/NICU' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Bed Unavailable - Ward' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Cancelled by Patient' THEN 'Patient Initiated'
      	WHEN cds_movement.Cancelled_Reason ='COVID-19 Positive' THEN 'Patient Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Duplicate Booking' THEN 'Other'
      	WHEN cds_movement.Cancelled_Reason ='Duplicate Booking/ Booked In Error' THEN 'Other'
      	WHEN cds_movement.Cancelled_Reason ='Equip/Enviro - Malfunction' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Equip/Enviro - Plant Problems' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Equip/Enviro - Unavailable' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Operation not needed' THEN 'Other'
      	WHEN cds_movement.Cancelled_Reason ='Other' THEN 'Other'
      	WHEN cds_movement.Cancelled_Reason ='Overbooking-planned-by surgeon' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Overbooking-unanti difficult case' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Pandemic - Administrative' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Pandemic - Anaesthetist' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Pandemic - Nurse' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Pandemic - Other' THEN 'Other'
      	WHEN cds_movement.Cancelled_Reason ='Pandemic - Patient' THEN 'Patient Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Pandemic - Surgeon' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Patient DNA - app confirmed' THEN 'Patient Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Patient DNA - app not confirmed' THEN 'Patient Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Patient unfit - acutely unwell' THEN 'Patient Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Patient unfit - Cx by Anaesthetist' THEN 'Patient Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Patient unfit - Cx by Surgeon' THEN 'Patient Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Patient unfit - not fasted' THEN 'Patient Initiated'
      	WHEN cds_movement.Cancelled_Reason ='PCR Unavailable' THEN 'Other'
      	WHEN cds_movement.Cancelled_Reason ='Previous List Overrun' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='PT Booking Brought Forward' THEN 'Other'
      	WHEN cds_movement.Cancelled_Reason ='Pt Deceased' THEN 'Other'
      	WHEN cds_movement.Cancelled_Reason ='Rebooked' THEN 'Other'
      	WHEN cds_movement.Cancelled_Reason ='Staff issues - Nurses' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Staff issues-Anaesth Tech' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Staff issues-Dr- Anaesthetist' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Staff issues-Dr-Surgeon' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Staff issues-Perfusionist' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Staff issues-Radiographer' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Substitution by Acute' THEN 'Hospital Initiated'
      	WHEN cds_movement.Cancelled_Reason ='Substitution by Elective' THEN 'Hospital Initiated'
      	ELSE NULL 
      END as cancelled_reason_type
	, CASE 	WHEN cds_appointment.Appointment_Status = 'A' THEN 'CANCEL'											--RB_Appointment.APPT_Status
		 	WHEN cds_appointment.Appointment_Status = 'D' THEN 
		 		CASE WHEN cds_procedure1.procedure_status = 'D' THEN 'DONE'										--OR_Anaest_Operation.ANAOP_Status to CDS
		 			 ELSE 'ABANDON'
		 		END
		 	WHEN cds_appointment.Appointment_Status = 'S' THEN 
		 		CASE WHEN cds_movement.Movement_Status = 'X' THEN 'CANCEL'										--OR_Anaesthesia.ANA_Status								
		 			 WHEN cds_movement.Movement_Status = 'C' AND cds_procedure1.procedure_status IN ('A','D') THEN 'CANCEL'
		 			 ELSE 'SUSPEND'
		 		END
		 	WHEN cds_appointment.Appointment_Status IS NULL THEN
		 		CASE WHEN cds_movement.Movement_Status = 'X' THEN 'CANCEL'
		 			 WHEN cds_movement.Movement_Status = 'C' AND cds_procedure1.procedure_status IN ('A','D') THEN 'CANCEL'
		 			 ELSE 'SCHEDULED'
		 		END
		 	ELSE NULL
	  END as theatre_outcome_code 	
	, cast(SUBSTRING_INDEX(LatestAnaestheticRecord.RBOP_RowId,"TB",-1) as INT) as theatre_encounter_id												
	, Case when cds_movement.Acute_Or_Elective = 'EM' then 1 Else 0 End as Acute_flag						
	, cds_admission.Health_Specialty_Code as theatre_event_health_specialty									
	, LatestAnaestheticRecord.RBOP_Movement_Create_DateTime as booking_created_datetime						
	, LatestAnaestheticRecord.RBOP_Movement_Start_DateTime as booked_theatre_datetime 						
	, cds_procedure1.Total_Plan_Theatre_Time as booked_in_theatre_minutes										 
	, cds_procedure_ana.Start_DateTime as anaesthetic_start_datetime
	, LatestAnaestheticRecord.Movement_Start_DateTime as into_theatre_datetime
	, cds_procedure1.Start_DateTime as surgery_start_datetime
	, cds_procedure1.Start_DateTime as knife_to_skin_datetime
	, cds_procedure1.Finish_DateTime as surgery_end_datetime
	, cds_procedure1.Theatre_Out_DateTime as out_of_theatre_datetime
	, post_theatre.Movement_End_Datetime as out_of_recovery_datetime
	, cds_procedure_ana.ASA as asa																		
	, CASE WHEN cds_procedure_ana.theatre_module_procedure_Code like '%local%' THEN 1 ELSE 0 END as local_anaesthetic_flag
	, cds_procedure_ana.theatre_module_procedure_Code as anaesthetic_type_code			
	, cds_ref_procedure1.Procedure_Code as theatre_module_procedure_1 									
	, cds_ref_procedure2.Procedure_Code as theatre_module_procedure_2 									
	, cds_ref_procedure3.Procedure_Code as theatre_module_procedure_3 									
	, cds_ref_procedure4.Procedure_Code as theatre_module_procedure_4 									
	, cds_ref_procedure5.Procedure_Code as theatre_module_procedure_5 									
	, cds_ref_procedure6.Procedure_Code as theatre_module_procedure_6 									
	, cds_ref_procedure7.Procedure_Code as theatre_module_procedure_7 									
	, cds_ref_procedure8.Procedure_Code as theatre_module_procedure_8 									
	, cds_ref_procedure9.Procedure_Code as theatre_module_procedure_9 									
	, '1022' as district_of_service
	, now as extract_dtm
	, 0 as invalid_encounter_flag
	, 0 as BOOKED_IN_THEATRE_MINUTES_FLAG
FROM 	hive_metastore.silver_live.cds_movement cds_movement,  current_time -- SQLUser.OR_Anaesthesia OR_Anaesthesia
LEFT  JOIN hive_metastore.silver_live.cds_movement post_theatre			ON cds_movement.Admission_ID = post_theatre.Admission_ID and post_theatre.Movement_Type = 'Post Theatre Event'
INNER JOIN LatestAnaestheticRecord 										ON LatestAnaestheticRecord.ANA_RowId = cds_movement.UID and LatestAnaestheticRecord.rowNumber=1
LEFT  JOIN hive_metastore.silver_live.cds_location	cds_location		ON cds_location.Location_ID = cds_movement.Location_ID
LEFT  JOIN hive_metastore.silver_live.cds_ref_hospital cds_ref_hospital ON cds_ref_hospital.Hospital_ID = cds_location.Hospital_ID 
LEFT  JOIN hive_metastore.silver_live.cds_admission cds_admission		ON cds_movement.Admission_ID = cds_admission.Admission_ID
LEFT  JOIN hive_metastore.silver_live.cds_patient cds_patient			ON cds_admission.Patient_ID = cds_patient.Patient_ID 
LEFT  JOIN hive_metastore.silver_live.cds_procedure cds_procedure1			ON cds_movement.Admission_ID = cds_procedure1.Admission_ID and cds_procedure1.Is_Primary = 1
LEFT  JOIN hive_metastore.silver_live.cds_ref_procedure cds_ref_procedure1 	ON cds_procedure1.Procedure_ID = cds_ref_procedure1.Procedure_ID 
LEFT  JOIN hive_metastore.silver_live.cds_procedure cds_procedure2			ON cds_movement.Admission_ID = cds_procedure2.Admission_ID and cds_procedure2.Is_Primary = 0 and cast(SUBSTRING_INDEX(cds_procedure2.UID,"||",-1) as INT) = 1 
LEFT  JOIN hive_metastore.silver_live.cds_ref_procedure cds_ref_procedure2 	ON cds_procedure2.Procedure_ID = cds_ref_procedure2.Procedure_ID  
LEFT  JOIN hive_metastore.silver_live.cds_procedure cds_procedure3			ON cds_movement.Admission_ID = cds_procedure3.Admission_ID and cds_procedure3.Is_Primary = 0 and cast(SUBSTRING_INDEX(cds_procedure3.UID,"||",-1) as INT) = 2 
LEFT  JOIN hive_metastore.silver_live.cds_ref_procedure cds_ref_procedure3 	ON cds_procedure3.Procedure_ID = cds_ref_procedure3.Procedure_ID  
LEFT  JOIN hive_metastore.silver_live.cds_procedure cds_procedure4			ON cds_movement.Admission_ID = cds_procedure4.Admission_ID and cds_procedure4.Is_Primary = 0 and cast(SUBSTRING_INDEX(cds_procedure4.UID,"||",-1) as INT) = 3 
LEFT  JOIN hive_metastore.silver_live.cds_ref_procedure cds_ref_procedure4 	ON cds_procedure4.Procedure_ID = cds_ref_procedure4.Procedure_ID  
LEFT  JOIN hive_metastore.silver_live.cds_procedure cds_procedure5			ON cds_movement.Admission_ID = cds_procedure5.Admission_ID and cds_procedure5.Is_Primary = 0 and cast(SUBSTRING_INDEX(cds_procedure5.UID,"||",-1) as INT) = 4 
LEFT  JOIN hive_metastore.silver_live.cds_ref_procedure cds_ref_procedure5 	ON cds_procedure5.Procedure_ID = cds_ref_procedure5.Procedure_ID  
LEFT  JOIN hive_metastore.silver_live.cds_procedure cds_procedure6			ON cds_movement.Admission_ID = cds_procedure6.Admission_ID and cds_procedure6.Is_Primary = 0 and cast(SUBSTRING_INDEX(cds_procedure6.UID,"||",-1) as INT) = 5 
LEFT  JOIN hive_metastore.silver_live.cds_ref_procedure cds_ref_procedure6 	ON cds_procedure6.Procedure_ID = cds_ref_procedure6.Procedure_ID  
LEFT  JOIN hive_metastore.silver_live.cds_procedure cds_procedure7			ON cds_movement.Admission_ID = cds_procedure7.Admission_ID and cds_procedure7.Is_Primary = 0 and cast(SUBSTRING_INDEX(cds_procedure7.UID,"||",-1) as INT) = 6 
LEFT  JOIN hive_metastore.silver_live.cds_ref_procedure cds_ref_procedure7 	ON cds_procedure7.Procedure_ID = cds_ref_procedure7.Procedure_ID  
LEFT  JOIN hive_metastore.silver_live.cds_procedure cds_procedure8			ON cds_movement.Admission_ID = cds_procedure8.Admission_ID and cds_procedure8.Is_Primary = 0 and cast(SUBSTRING_INDEX(cds_procedure8.UID,"||",-1) as INT) = 7 
LEFT  JOIN hive_metastore.silver_live.cds_ref_procedure cds_ref_procedure8 	ON cds_procedure8.Procedure_ID = cds_ref_procedure8.Procedure_ID  
LEFT  JOIN hive_metastore.silver_live.cds_procedure cds_procedure9			ON cds_movement.Admission_ID = cds_procedure9.Admission_ID and cds_procedure9.Is_Primary = 0 and cast(SUBSTRING_INDEX(cds_procedure9.UID,"||",-1) as INT) = 8 
LEFT  JOIN hive_metastore.silver_live.cds_ref_procedure cds_ref_procedure9 	ON cds_procedure9.Procedure_ID = cds_ref_procedure9.Procedure_ID  
LEFT  JOIN hive_metastore.silver_live.cds_appointment cds_appointment	ON cds_movement.Admission_ID = cds_appointment.Admission_ID
LEFT  JOIN hive_metastore.silver_live.cds_procedure cds_procedure_ana	ON cds_movement.Admission_ID = cds_procedure_ana.Admission_ID and cds_procedure_ana.Procedure_ID = 99999
WHERE 1=1
	AND cds_movement.Movement_Type = 'Theatre Event'
--	
--GROUP BY 
--	  PA_PatMas.PAPMI_No
--	, OR_Anaesthesia.ANA_RowId
--	, RB_OperatingRoom.RBOP_RowId
--	, PA_Adm.PAADM_ADMNo 
--	, OR_Anaesthesia.ANA_RowId
--	, OR_Anaest_Operation.ANAOP_RowId
--	, OR_Anaest_Operation.ANAOP_Type_DR
--	, OR_Anaesthesia.ANA_No
--	, OR_Anaest_Operation.ANAOP_No
--	, OR_Anaesthesia.ANA_UpdateDate
----		, AnaestheticStatus.Description 
--	, primaryProcedureDetails.OPER_Code 
--	, OR_An_Oper_SecondaryProc1.SECPR_RowId
--	, secondaryProcedureDetails1.OPER_Code 
--	, secondaryProcedureDetails1.OPER_Desc
--	, OR_Anaesthesia.ANA_Date
--	, OR_Anaesthesia.ANA_AnaStartTime
--   	, OR_Anaesthesia.ANA_AnaFinishTime
--	, OR_Anaest_Operation.ANAOP_OpEndDate
--	, OR_Anaest_Operation.ANAOP_OpEndTime
--	, OR_Anaest_Operation.ANAOP_TheatreOutDate
--	, OR_Anaest_Operation.ANAOP_TheatreOutTime
--	, OR_Anaesthesia.ANA_PACU_FinishDate
--	, OR_Anaesthesia.ANA_PACU_FinishTime
--	, orc_asa_classphactiv.ORASA_Code
--	, orc_anaestmethod.ANMET_Desc
--	, OR_Anaesthesia.ANA_TheatreInDate
--	, OR_Anaesthesia.ANA_TheatreInTime
--	, OR_Anaest_Operation.ANAOP_OpStartDate
--	, OR_Anaest_Operation.ANAOP_OpStartTime
--	, secondaryProcedureDetails1.OPER_Code
--	, secondaryProcedureDetails2.OPER_Code
--	, secondaryProcedureDetails3.OPER_Code
--	, secondaryProcedureDetails4.OPER_Code
--	, secondaryProcedureDetails5.OPER_Code
--	, secondaryProcedureDetails6.OPER_Code
--	, secondaryProcedureDetails7.OPER_Code
--	, secondaryProcedureDetails8.OPER_Code
----	, rowNumber
--	, OR_Anaesthesia.ANA_Status
--	, OR_Anaest_Operation.ANAOP_Status
--    , CT_Loc.CTLOC_Code
--	, CT_Hospital.HOSP_Code
--	, RB_ApptSchedule.AS_RowId
--	, RBC_Equipment.EQ_Code
--	, RB_Resource.RES_Desc
--	, RB_Appointment.APPT_CancelDate
--	, RB_Appointment.APPT_CancelTime
--	, RB_Appointment.APPT_Status
--	, OR_Anaesthesia.ANA_Status
--	, OR_Anaest_Operation.ANAOP_Status
--	, RB_OperatingRoom.RBOP_BookingType
--	, CT_HealthSpecialtyCodes.HSC_code
--	, RB_OperatingRoom.RBOP_CreateDate
--	, RB_OperatingRoom.RBOP_CreateTime
--	, RB_OperatingRoom.RBOP_DateOper
--    , RB_OperatingRoom.RBOP_TimeOper
--	, RB_OperatingRoom.RBOP_TotalPlanTheatreTime
--	, ORC_ReasonForSuspend.SUSP_Desc
--	, CT_HealthSpecialtyCodes.HSC_Desc
--HAVING COUNT(OR_Anaesthesia.ANA_RowId) <= 1
--ORDER BY PA_PatMas.PAPMI_No, OR_Anaest_Operation.ANAOP_RowId

""")

# COMMAND ----------


