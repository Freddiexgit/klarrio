# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 28-Mar-2024 | 1       | Siddharth S    | Create first draft of presentation view for room to ward details (for rooms without beds) |
# MAGIC

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_ioc_bed_to_ward_details""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_ioc_bed_to_ward_details
AS

select 
rb.Bed_ID
, Bed_Number
, rb.Bed_Code
, Bed_Status_Start_DateTime
, Bed_Status_Finish_DateTime
, Bed_Reason_Not_Available
, Is_Bed_Restricted
, Is_Bed_Available
, rb.Room_ID
, Room_Code
, Room_Desc
, Room_Type_Code
, ROOM_Query
, Room_Description
, Case when w.Ward_Code = 'CDU' and Room_code in ('1P', '2P', '3P', '4P', '5P', '6P', '7P', '8P', '9P', '10P', '11P', '12P', '13P', '14P', '15P', '16P', '17P', '18P', '19P', '20P', '21P', '22P', '23P', '24P')
    then 'Blue'
    when w.Ward_Code = 'CDU' and Room_Code in ('25S', '26S', '27S', 'MR28', 'MR29', 'MR30', 'MR31', 'MR32', 'MR33') then 'Yellow' end as Blue_OR_Yellow_Room
, w.Ward_Code
, w.WARD_Desc
, w.IOC_Ward_Type as IOC_BedToWard_Type
, Case when rb.bed_id in ( '108||110', '108||119', '108||120', '108||123', '108||124', '109||47', '109||48', '11||133', '11||134', '11||135', '11||136', '11||138', '11||139', '11||140', '11||141', '11||148', '11||149', '11||150', '11||151', '11||152', '11||153', '11||154', '11||155', '11||160', '11||162', '11||163', '11||164', '11||165', '114||47', '114||48', '115||55', '115||56', '126||63', '126||64', '13||53', '13||54', '13||55', '13||56', '13||57', '13||58', '13||59', '13||60', '25||67', '33||21', '33||22', '33||23', '33||24', '33||25', '33||26', '33||27', '33||28', '33||29', '35||289', '35||384', '35||448', '35||450', '35||452', '35||455', '35||457', '35||459', '36||146', '36||147', '36||148', '36||149', '37||117', '37||118', '55||74', '58||50', '58||51', '58||52', '58||66', '68||69', '68||70', '7||111', '70||110', '9||100', '9||109', '9||110', '9||111', '9||112', '9||83', '9||84', '9||85', '9||86', '9||87', '9||88', '9||89', '9||90', '9||91', '9||92', '9||93', '9||94', '9||97', '9||98', '9||99') 
 then 'Y' else 'N' end Negative_Pressure_Room
, case when w.Ward_Code = 'AED'
       then
              case when rb.Bed_ID in ('35||289', '35||290', '35||291', '35||292', '35||293', '35||294', '35||295', '35||300', '35||301', '35||302', 
              '35||303', '35||304', '35||305', '35||306', '35||307', '35||308', '35||309', '35||310', '35||311', '35||312', '35||319', '35||320', '35||321', '35||322', '35||323', '35||324')
               then 'Acute'
                     when rb.Bed_ID in ('35||370', '35||371', '35||372', '35||373', '35||374', '35||375', '35||376', '35||377', '35||378', '35||379') then 'Monitoring'
                     when rb.Bed_ID in ('35||388', '35||389', '35||390', '35||391') then 'Resus'
                     when rb.Bed_ID in ('35||448', '35||450', '35||452') then 'RIso'
                     when rb.Bed_ID in ( '35||394', '35||395', '35||396', '35||397', '35||398', '35||399', '35||400', '35||401', '35||402', '35||403', '35||404') then 'SSED'
              else 'NA' end
       else case when w.Ward_code = 'CED' then 
	            case when r.Room_Code like 'RR%' then 'CED Resus'
                     when r.Room_Code in ('8P','9P','10P','11P','12P' ) then 'CED Central Monitored'
                     when r.Room_Code in ('1P','4P','5P','INT1') then 'CED Immunocompromised'
                     when r.Room_Code in ('14P','15P') then 'CED Isolation'
                     when r.Room_Code in ('2P','3P','6P','7P','13A','13B','13C','13D','13E','13F','13G','13H') then 'CED Acute' end 
                    
            else null end
       end as LevelTwoZone
, case when Is_Bed_Restricted = 'Y' then 1 else 0 end as Restricted_Bed_Row_Count
, w.Approved_Beds
, case when w.ward_code = 'CICU48' and r.Room_Code in ('1P', '1S', '2P', '2S', '3P', '3S', '4P', '4S', '5P', '5S', '6P', '6S', '7P', '7S') then 'CVICU'
when w.ward_code = 'CICU48' and r.Room_Code in ('8S', '8P') then 'CVHDU' 
when w.ward_code in ('CICU48', 'DCCM82', 'CCU34') then w.ward_code else 'Non-Critical' end Critical_Care_Ward_Category
from hive_metastore.silver_live.cds_ref_bed rb
LEFT JOIN hive_metastore.silver_live.cds_ref_room R on R.room_ID = RB.Room_ID
left join hive_metastore.gold_live.vw_pres_ref_ward w on w.Ward_ID = rb.Ward_ID
left join hive_metastore.silver_live.cds_bed_status bs on rb.bed_id = bs.Bed_ID

""")

# COMMAND ----------


