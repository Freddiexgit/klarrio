# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 23 May 2024 | 1       | Janesa R       | Initial Build                                                              |
# MAGIC | 20 Aug 2024 | 2       | Khalid J       | Exclude Ward YPE 96 For WH Inpatient                                       |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_ref_ward""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_ref_ward
AS

WITH Ward_Loc as (
select * from hive_metastore.silver_live.cds_location
where Location_Type in ("Emergency", "Ward")
)
select 
  Ward_ID
, case when Ward_Code = '27A' then 'ONCDSU' else Ward_Code end as Ward_Code
, WARD_Desc
, CASE WHEN w.Ward_Code in ('AED', 'CDU') THEN 'Adult Emergency'
    WHEN w.Ward_Code = 'CED' THEN 'Child Health Emergency'
    WHEN w.Ward_Code in ('AODS') THEN 'Adult Day Stay'
    WHEN w.Ward_Code in ('27A', 'DSU', '23BDSU', 'ONCDSU') Then 'Child Health Day Stay'
    WHEN w.Ward_Code in ('CICU48', 'CCU34', 'DCCM82') THEN 'Adult Critical Care'
    WHEN w.Ward_Code in ('NICU92', 'PICU') THEN 'Child Health Critical Care'
    WHEN w.Ward_Code in (
        'AWATEA', 'MARINO', 'MOTU', 'RANGI', 'REMURA', '10SURG', '31W'
        , '41', '42', '51', '61', '62', '63', '64', '65', '66', '67', '68',
        '7A', '72', '73', '74', '75', '76', '77', '78', '71',
        '81', '83', '97'
    ) THEN 'Adult Inpatient'
    WHEN  w.Ward_Code in (
        '23B', '24A', '24B', '25', '26A', '26B', '27B', '28A'
    ) THEN 'Child Health Inpatient'
    WHEN w.Ward_Code in (
        'BRC', 'CFUO', 'FMU', 'B', 'C', 'TWT', 'A', 'TUPU'
    ) THEN 'Mental Health Inpatient'
    WHEN  w.Ward_Code in (
        'TAMAKI', '98'
    ) THEN 'Womens Inpatient'
    WHEN  w.Ward_Code in (
        'WAU', '91'
    ) THEN 'Womens Acute Maternity'
    WHEN  w.Ward_Code in (
        'TOTARA'
    ) THEN 'Greenlane Inpatient'
    WHEN  w.Ward_Code = 'WOP' THEN 'Womens Health Other'
    ELSE 'Non-IOC Ward' END as IOC_Ward_Type
, Approved_Beds
from hive_metastore.silver_live.cds_ref_ward w
left outer join Ward_Loc loc on loc.Location_Code = w.Ward_Code

""")

# COMMAND ----------


