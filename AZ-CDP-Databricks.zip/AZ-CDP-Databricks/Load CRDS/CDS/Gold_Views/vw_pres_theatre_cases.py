# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 20 Aug 2024 | 1       | Janesa R   | Initial Draft      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_theatre_cases""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_theatre_cases
AS

WITH
Admit_Ward AS
(SELECT
    Admission_ID
    ,Location_ID
    ,Bed_ID
    ,Admission_ID 
	,Movement_Type
	,Movement_Start_Datetime 
	,Movement_End_Datetime 
FROM
    (
    SELECT
        Admission_ID
        ,ROW_NUMBER() OVER (PARTITION BY Admission_ID
    ORDER BY
        Movement_End_Datetime ASC) AS rownumber
        ,Location_ID
        ,Bed_ID
        ,Movement_Type
		,Movement_Start_Datetime 
		,Movement_End_Datetime 
    FROM
        hive_metastore.silver_live.cds_movement
    WHERE 1=1
        -- trans type
AND Movement_End_DateTime IS NULL
AND UPPER(Movement_Type) = 'WARD TRANSFER' ) WHERE rownumber = '1'),
Current_Ward AS 
(SELECT
    Admission_ID
    ,Location_ID
    ,Bed_ID
    ,Admission_ID 
	,Movement_Type
	,Movement_Start_Datetime 
	,Movement_End_Datetime 
FROM
    (
    SELECT
        Admission_ID
        ,ROW_NUMBER() OVER (PARTITION BY Admission_ID
    ORDER BY
        Movement_End_Datetime DESC) AS rownumber
        ,Location_ID
        ,Bed_ID
        ,Movement_Type
		,Movement_Start_Datetime 
		,Movement_End_Datetime 
    FROM
        hive_metastore.silver_live.cds_movement
    WHERE 1=1
        -- trans type
AND Movement_End_DateTime IS NULL
AND UPPER(Movement_Type) = 'WARD TRANSFER' ) WHERE rownumber = '1')
/* Theatre Case Rework */
select 
cts.Session_Id 
, ca2.Admission_ID 
, cts.Theatre_Code 
, cts.Session_Date 
, cts.Session_Start_Time 
, cts.Session_End_Time
, cm.Movement_Start_Datetime as SurgeryStartDateTime -- needs validation
, cm.Movement_End_Datetime as SurgeryEndDateTime -- needs validation
, DATE_FORMAT(cm.Movement_Start_Datetime , 'hh:mm') as CaseStartTime -- needs validation
, DATE_FORMAT(cm.Movement_End_Datetime, 'hh:mm') as CaseEndTime -- needs validation
, CONCAT(DATE_FORMAT(cm.Movement_Start_Datetime , 'hh:mm'), ' - ', DATE_FORMAT(cm.Movement_End_Datetime, 'hh:mm')) as TheatreTime -- needs validation
--, ca.Appointment_DateTime  -- needs validation
--, ca.Appointment_Start_Time as CaseStartTime -- needs validation
--, ca.Appointment_End_Time as CaseEndTime -- needs validation
--, CONCAT(ca.Appointment_Start_Time , ' - ' , ca.Appointment_End_Time) as CaseTimes -- needs validation
, ca.Appointment_Cancel_DateTime -- needs validation
--, DATEDIFF(MINUTE ,ca.Appointment_Start_Time , ca.Appointment_End_Time) AS TheatreTime -- needs validation
, cp.Patient_First_Name 
, cp.Patient_Last_Name 
, cm.Movement_Status 
, cp.Patient_NHI
, cp.Patient_ID
, currloc.Location_Code as NextWard
, admitloc.Location_Code as AdmitWard
, cl.Location_Desc as CaseSpecialtyDesc
, ca2.Estimated_Discharge_DateTime
, cm.Current_Clinician as CaseConsultant
, cm.Anaesthetist
, cts.Dependent_Resource 
, cts.Session_Type 
, cm.Acute_Or_Elective as OperatingType
, cm.Movement_Type
, crp.Procedure_ID 
, crp.Procedure_Desc as ProcedureDesc
, CASE WHEN cts.Theatre_Code LIKE '%V%' THEN 'Y' ELSE 'N' END AS Virtual_Theatre_Flag
, SUBSTRING(cm.UID, 3, length(cm.UID)) as Theatre_Event_Ref_No
from silver_live.cds_theatre_session cts 
left join silver_live.cds_appointment ca on ca.Session_ID = cts.Session_Id 
left join silver_live.cds_admission ca2 on ca2.Admission_ID = ca.Admission_ID 
left join silver_live.cds_patient cp on cp.Patient_ID = ca2.Patient_ID 
left join silver_live.cds_movement cm on cm.Admission_ID = ca.Admission_ID  and UPPER(cm.Movement_Type) = 'THEATRE BOOKING'
left join silver_live.cds_ref_procedure crp on crp.Procedure_ID = cm.Movement_Procedure_ID
left join silver_live.cds_location cl on cl.Location_ID = cm.Speciality_Location_ID 
left join Admit_Ward aw on aw.Admission_Id = ca.Admission_ID 
left join Current_Ward cw on cw.Admission_Id = ca.Admission_ID 
left join silver_live.cds_location admitloc on admitloc.Location_ID = aw.Location_Id
left join silver_live.cds_location currloc on currloc.Location_ID = cw.Location_Id
where 1=1
and cm.Movement_Status = 'P' 


""")

# COMMAND ----------


