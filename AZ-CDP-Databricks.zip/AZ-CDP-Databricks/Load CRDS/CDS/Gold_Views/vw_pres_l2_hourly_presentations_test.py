# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 28-Mar-2024 | 1       | Janesa R    | Create first draft of presentation view from vw_pres_l2_hourly_presentations      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_l2_hourly_presentations_test""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_l2_hourly_presentations_test
AS

WITH current_time AS (
  SELECT from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
),

-- Calculate the start of the next hour
next_hour AS (
  SELECT timestampadd(HOUR, 1, date_trunc('HOUR', now)) AS next_hour_start
  FROM current_time
),

-- Generate hourly intervals for the past 9 hours from the next hour start
hourly_intervals AS (
  SELECT 
    explode(
      sequence(
        next_hour_start - interval 9 hours,
        next_hour_start,
        interval 1 hour
      )
    ) AS hour_start
  FROM next_hour
),

--SELECT * FROM hourly_intervals

Ward_transfers as (
select Admission_ID, mv.Movement_Sequence, mv.Location_ID, Movement_Type, mv.Movement_Start_DateTime, mv.Movement_End_DateTime,
row_number() over (partition by mv.Admission_ID  order by mv.Movement_Sequence asc) as first_movement_flag,
row_number() over (partition by mv.Admission_ID  order by mv.Movement_Sequence desc) as last_movement_flag
from silver_live.cds_movement mv
where mv.Movement_Type = 'Ward Transfer'
order by mv.Movement_Sequence),

--select * from Ward_Transfers
--where Admission_ID = 70766

-- Extend patient data to handle null discharge dates and filter relevant data
extended_patient_data AS (
  SELECT 
    ca.Admission_ID,
    mv2.Location_ID as First_Location_ID,
    mv.Location_ID as Current_Location_ID, --current
    ca.Triage_Code as CED_Triage_Category, 
    case when mr.Discharge_Code in('EDIP', 'CDUIP', 'EDOT', 'CDUOT') then 'Admitted to IP Ward' 
		when mr.Discharge_Code is null and ca.Inpatient_Short_Stay_Intent is null then 'In CED'
		when mr.Discharge_Code is null and ca.Inpatient_Short_Stay_Intent is not null then 'SS in CED'
		else 'Discharged from CED' end as CED_Visit_Status,
    cast(ca.Admission_DateTime AS timestamp) AS admission_date,
    coalesce(cast(ca.Actual_Discharge_DateTime AS timestamp), now) AS discharge_date,
    cast(mv.Movement_Start_DateTime AS timestamp) AS movement_start_date,
    coalesce(cast(mv.Movement_End_DateTime AS timestamp), now) AS movement_end_date,
    ca.Admission_Number
from Ward_transfers mv, current_time
left outer join silver_live.cds_admission ca on mv.Admission_ID = ca.Admission_ID
left outer join silver_live.cds_medical_record mr on mr.Admission_ID = ca.Admission_ID
left outer join Ward_transfers mv2 on mv.Admission_ID = mv2.Admission_ID and mv2.first_movement_flag = 1
where ca.Admission_Type_Code in ('I', 'E')
and mv.Movement_Type = 'Ward Transfer'
and ca.Visit_Status_code in ('A', 'D')
and mv2.Location_ID in (225, 226, 227)
--and ca.Admission_Number = 'S001000064'
and mv.last_movement_flag = 1
),

--select * from extended_patient_data 
-- Join the hourly intervals with the patient data to determine the number of patients per interval
patient_hourly AS (
  SELECT
    i.hour_start,
    i.hour_start + interval 1 hour AS hour_end,
    p.Admission_ID,
    p.Admission_Number,
    p.First_Location_ID,
    p.Current_Location_ID,
    p.CED_Triage_Category,
    p.CED_Visit_Status,
    p.admission_date,
    p.discharge_date,
    p.movement_start_date,
    p.movement_end_date
  FROM 
    hourly_intervals i
  JOIN 
    extended_patient_data p
  ON 
    p.admission_date <= (i.hour_start + interval 1 hour) AND p.discharge_date > i.hour_start
),
 
--select * FROM patient_hourly /*

-- Count the number of patients per hour and format the hour bucket
patient_hourly_buckets AS (
SELECT
  hour_start,
  hour_end,
  First_Location_ID,
  Current_Location_ID,
  Admission_ID,
  Admission_Number,
  CASE WHEN Current_Location_ID = 227 then CED_Triage_Category else null end CED_Triage_Category,
  CASE WHEN Current_Location_ID = 227 then CED_Visit_Status else null end CED_Visit_Status,
 admission_date,
 discharge_date,
    movement_start_date,
    movement_end_date,
  CASE WHEN hour_start <= now - interval 7 hours THEN '6+'
  ELSE
      CONCAT(
        CAST((UNIX_TIMESTAMP(now) - UNIX_TIMESTAMP(hour_end)) / 3600 AS INT),
        ' - ',
        CAST((UNIX_TIMESTAMP(now) - UNIX_TIMESTAMP(hour_start)) / 3600 AS INT))
      END AS Six_Hour_Bucket,
  CASE WHEN hour_start <= now - interval 10 hours THEN '9+'
  ELSE
      CONCAT(
        CAST((UNIX_TIMESTAMP(now) - UNIX_TIMESTAMP(hour_end)) / 3600 AS INT),
        ' - ',
        CAST((UNIX_TIMESTAMP(now) - UNIX_TIMESTAMP(hour_start)) / 3600 AS INT))
        END AS Nine_Hour_Bucket,
  CASE WHEN Six_Hour_Bucket = '0 - 0' or Nine_Hour_Bucket = '0 - 0' then 0 -- remove double count
        WHEN (Current_Location_ID = 226 and First_Location_ID = 225) then 0 
        WHEN First_Location_ID = 225 then 1 else 0 end as AED_Occupancy,
  CASE WHEN Six_Hour_Bucket = '0 - 0' or Nine_Hour_Bucket = '0 - 0' then 0
        WHEN (Current_Location_ID = 226 and First_Location_ID = 225) then 1
        WHEN First_Location_ID = 226 then 1 else 0 end as CDU_Occupancy,
  CASE WHEN Six_Hour_Bucket = '0 - 0' or Nine_Hour_Bucket = '0 - 0' then 0
        WHEN First_Location_ID = 227 then 1 else 0 end as CED_Occupancy,
  CASE WHEN admission_date >= hour_start AND admission_date < hour_end THEN 1 ELSE 0 END AS ED_Arrivals
FROM 
  patient_hourly, current_time
)

--select * from patient_hourly_buckets 
--order by movement_start_date desc, movement_end_date  desc /*

select
  hour_start,
  hour_end, 
  First_Location_ID,
  Current_Location_ID,
  Admission_Number,
  admission_date,
 discharge_date,
    movement_start_date,
    movement_end_date,
  CED_Triage_Category,
  CED_Visit_Status,
  Case when Six_Hour_Bucket = '0 - 0' then '0 - 1' else Six_Hour_Bucket end as Six_Hour_Bucket,
  Case when Six_Hour_Bucket = '5 - 6' then 1
      when Six_Hour_Bucket = '4 - 5' then 2
      when Six_Hour_Bucket = '3 - 4' then 3
      when Six_Hour_Bucket = '2 - 3' then 4
      when Six_Hour_Bucket = '1 - 2' then 5
      when Six_Hour_Bucket = '0 - 1' then 6
      when Six_Hour_Bucket = '0 - 0' then 6
      else 0 end as Six_Hour_Bucket_Order,
  Case when Nine_Hour_Bucket = '0 - 0' then '0 - 1' else Nine_Hour_Bucket end as Nine_Hour_Bucket,
  Case when Nine_Hour_Bucket = '8 - 9' then 1
       when Nine_Hour_Bucket = '7 - 8' then 2
       when Nine_Hour_Bucket = '6 - 7' then 3
       when Nine_Hour_Bucket = '5 - 6' then 4
       when Nine_Hour_Bucket = '4 - 5' then 5
       when Nine_Hour_Bucket = '3 - 4' then 6
       when Nine_Hour_Bucket = '2 - 3' then 7
       when Nine_Hour_Bucket = '1 - 2' then 8
       when Nine_Hour_Bucket = '0 - 1' then 9
       when Nine_Hour_Bucket = '0 - 0' then 9
      else 0 end as Nine_Hour_Bucket_Order,
  SUM(AED_Occupancy) AS Hourly_AED_Occupancy,
  SUM(CDU_Occupancy) AS Hourly_CDU_Occupancy,
  SUM(CED_Occupancy) AS Hourly_CED_Occupancy,
  SUM(ED_Arrivals) AS Hourly_ED_Arrivals
from patient_hourly_buckets 
GROUP BY 
  First_Location_ID,  Current_Location_ID,   CED_Triage_Category, CED_Visit_Status,    six_hour_bucket, nine_hour_bucket
  ,Admission_Number,   hour_start,  hour_end,
  admission_date,
 discharge_date,
    movement_start_date,
    movement_end_date

  

""")

# COMMAND ----------


