# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 28-Mar-2024 | 1       | Siddharth S    | Create first draft of presentation view from cds_location delta table      |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_location""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_location
AS

WITH Bed_Details as (
select w.IOC_Ward_Type, case when w.Ward_Code = '27A' then 'ONCDSU' else w.Ward_Code end as Ward_Code,
count( distinct rb.Bed_ID) as Restricted_Bed_Count
from hive_metastore.silver_live.cds_ref_bed rb
LEFT JOIN hive_metastore.silver_live.cds_ref_room R on R.room_ID = RB.Room_ID
left join hive_metastore.gold_live.vw_pres_ref_ward w on w.Ward_ID = rb.Ward_ID
left join hive_metastore.silver_live.cds_bed_status bs on rb.bed_id = bs.Bed_ID
where Is_Bed_Restricted = "Y"
group by w.Ward_Code, w.IOC_Ward_Type
)

select 
 UID
, Hospital_ID
, Location_ID
, case when Location_Code = '27A' then 'ONCDSU' else Location_Code end as Location_Code
, Location_Desc
, Location_Type
, Is_Active
, Is_Emergency
, Inpatient_Type
, COALESCE(loc.Approved_Beds, 0) as Approved_Beds_Per_Location
, COALESCE(bd.Restricted_Bed_Count, 0) as Restricted_Beds_Per_Location
, case when loc.Approved_Beds <> 0 then loc.Approved_Beds - coalesce(bd.Restricted_Bed_Count, 0) else 0 end as Available_Beds_Per_Location
, COALESCE(w.IOC_Ward_Type, 'Non-IOC Ward') as IOC_Ward_Type
, case when Location_Code in ('1404152035', '1404152035A', '1404152035B', '1404152035C', '1404152035D', '1404152035E',
                            '1404152035F', '1404152035G',  '1404152035H', '1404153659', '1404353092D') then 'Gynae'
when Location_Code in ('1404152020A', '1404452028C', '1404153107A', '1404153664H', '1404153646A',
                        '1404153646B', '1404153646C', '1404153646', '1404152020', '1404153664', '1404153646D') then 'Maternity' else 'Non-WAU' end as WAU_Category
FROM silver_live.cds_location loc
left outer join Bed_Details bd on bd.Ward_Code = loc.Location_Code
left outer join  gold_live.vw_pres_ref_ward w on w.Ward_Code = (case when Location_Code = '27A' then 'ONCDSU' else Location_Code end)

""")

# COMMAND ----------


