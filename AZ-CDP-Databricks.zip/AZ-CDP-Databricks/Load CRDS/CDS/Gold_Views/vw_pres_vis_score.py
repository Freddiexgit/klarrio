# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 15 May-2024 | 1       | Janesa R    | Initial build of VRM VIS Score table |
# MAGIC
# MAGIC

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch test

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_vis_score""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_vis_score
AS

WITH current_time AS (
  SELECT date_format(from_utc_timestamp(now(), 'Pacific/Auckland'), 'yyyy-MM-dd HH:mm:ss') AS now
),

Temp as (
	select 
	rtrim(TBL_Tran_Scorecard.WardID) as WardCode
	,TBL_Tran_Scorecard.ScoreTotal
	--TBL_For_ScorecardWards.ScorecardKey
	,TBL_Tran_Scorecard.CreateDate
	, case	when (date_part('hour', TBL_Tran_Scorecard.CreateDate) >= 7 and date_part('hour', TBL_Tran_Scorecard.CreateDate) < 15)
		then '7am Shift'
		when (date_part('hour', TBL_Tran_Scorecard.CreateDate) >= 15 and date_part('hour', TBL_Tran_Scorecard.CreateDate) < 23)
		then '3pm Shift'
		when (date_part('hour', TBL_Tran_Scorecard.CreateDate) >= 23 or date_part('hour', TBL_Tran_Scorecard.CreateDate) < 7)
		then '11pm Shift'
		else 'Unknown'
		end as VISUpdatedInShift
	, trim(TBL_Detail_AlertRules.Color) as Color
	-- Get correct record for current shift - Create date AND current date need to both be within the correct shift
/*	, case	when	(TBL_Tran_Scorecard.CreateDate >= Date_Add(day, datediff(day, TIMESTAMP'1900-01-01', CAST(now AS DATE)),  TIMESTAMP'1900-01-01') and (date_part('hour', TBL_Tran_Scorecard.CreateDate) >= 7 and date_part('hour', TBL_Tran_Scorecard.CreateDate) < 15 and 
						date_part('hour', CAST(now AS DATE)) >= 7 and date_part('hour', CAST(now AS DATE)) < 15))

					or (TBL_Tran_Scorecard.CreateDate >= Date_Add(day, datediff(day, TIMESTAMP'1900-01-01', CAST(now AS DATE)),  TIMESTAMP'1900-01-01') and (date_part('hour', TBL_Tran_Scorecard.CreateDate) >= 15 and date_part('hour', TBL_Tran_Scorecard.CreateDate) < 23 and
						date_part('hour', CAST(now AS DATE)) >= 15 and date_part('hour', CAST(now AS DATE)) < 23))
				-- 11pm to 7am - need to check if query is being run on same day after 11pm also next day but CreateDate was after 11am "yesterday"
				-- check if yesterday or after 11pm, or before 7am today
					or (
						-- Check if create date was "today" AND being run at or after 11pm today
						( DATEDIFF(day, TBL_Tran_Scorecard.CreateDate, now) = 0 and date_part('hour', CAST(now AS DATE)) >= 23) and (date_part('hour', TBL_Tran_Scorecard.CreateDate) >= 23) 

					or
					-- Check if create date was "yesterday" AND at or after 11am AND before 7am
						DATEDIFF(day, TBL_Tran_Scorecard.CreateDate, now) = 1 and (date_part('hour', TBL_Tran_Scorecard.CreateDate) >= 23) and date_part('hour', CAST(now AS DATE)) < 7 )
					or
					-- Check if a score was entered after midnight but before 7am and the view is run after midnight and before 7am 
						DATEDIFF(day, TBL_Tran_Scorecard.CreateDate, now) = 0 and ((date_part('hour', TBL_Tran_Scorecard.CreateDate) between 0 and 6) and (date_part('hour', CAST(now AS DATE)) between 0 and 6)) 
				
					 then 1 end as VisUpdatedForCurrentShiftFlag
           */
,    CASE
        WHEN (
                (DATE(TBL_Tran_Scorecard.CreateDate) >= DATE_ADD(CAST(current_time.now AS DATE), 0) AND 
                 (HOUR(TBL_Tran_Scorecard.CreateDate) >= 7 AND HOUR(TBL_Tran_Scorecard.CreateDate) < 15 AND 
                  HOUR(current_time.now) >= 7 AND HOUR(current_time.now) < 15))
                
             OR (DATE(TBL_Tran_Scorecard.CreateDate) >= DATE_ADD(CAST(current_time.now AS DATE), 0) AND 
                 (HOUR(TBL_Tran_Scorecard.CreateDate) >= 15 AND HOUR(TBL_Tran_Scorecard.CreateDate) < 23 AND 
                  HOUR(current_time.now) >= 15 AND HOUR(current_time.now) < 23))
                
             OR ((DATEDIFF(TBL_Tran_Scorecard.CreateDate, current_time.now) = 0 AND HOUR(current_time.now) >= 23) AND 
                  HOUR(TBL_Tran_Scorecard.CreateDate) >= 23)
                
             OR (DATEDIFF(TBL_Tran_Scorecard.CreateDate, current_time.now) = 1 AND 
                 (HOUR(TBL_Tran_Scorecard.CreateDate) >= 23) AND HOUR(current_time.now) < 7)
                
             OR (DATEDIFF(TBL_Tran_Scorecard.CreateDate, current_time.now) = 0 AND 
                 ((HOUR(TBL_Tran_Scorecard.CreateDate) BETWEEN 0 AND 6) AND (HOUR(current_time.now) BETWEEN 0 AND 6)))
            )
        THEN 1 
        ELSE 0
    END AS VisUpdatedForCurrentShiftFlag
  , IOCAS_WardService.DirectorateDesc
	, ROW_NUMBER() over (partition by TBL_Tran_Scorecard.WardID order by TBL_Tran_Scorecard.CreateDate desc) as RowNumber
	FROM silver_live.vrm_tbl_tran_scorecard as TBL_Tran_Scorecard, current_time
    LEFT JOIN hive_metastore.silver_live.cds_dsu_service_mapping IOCAS_WardService
		on rtrim(TBL_Tran_Scorecard.WardID) = IOCAS_WardService.WardCode
	LEFT JOIN silver_live.vrm_tbl_for_scorecardwards as TBL_For_ScorecardWards 
		on trim(TBL_Tran_Scorecard.WardID) = trim(TBL_For_ScorecardWards.WardID)
	LEFT JOIN silver_live.vrm_tbl_detail_alertrules as TBL_Detail_AlertRules 
	    ON  (TBL_For_ScorecardWards.ScorecardKey = TBL_Detail_AlertRules.ScorecardKey 
		AND TBL_Tran_Scorecard.ScoreTotal BETWEEN TBL_Detail_AlertRules.From 
		AND TBL_Detail_AlertRules.To 
		AND TBL_Detail_AlertRules.Deleted = 0)
	WHERE TBL_Tran_Scorecard.CreateDate >= DATE_Add(day, (datediff(day, TIMESTAMP'1900-01-01', CAST(now AS DATE)) - 1), TIMESTAMP'1900-01-01')  -- Get VIS records for last few days (to bring in all that "should have" scored today
	  
) 

select 
--	CreateDate
--	, DATE_Add(day, (datediff(day, TIMESTAMP'1900-01-01', CAST(now AS DATE)) - 1), TIMESTAMP'1900-01-01') as Date_Filter
      temp.WardCode
      ,Temp.Color
	--,  Temp.scorecardkey
--    , DirectorateDesc
    , ScoreTotal as VisScore
--, VISUpdatedInShift
--	, VisUpdatedForCurrentShiftFlag
--	, RowNumber
--	, CASE WHEN VisUpdatedForCurrentShiftFlag = 1 then 'Vis'+Temp.Color else 'VisWhite' end as LastRecordedVisColour
	, case	when VisUpdatedForCurrentShiftFlag = 1 then 0 else 1 end as VISWhite  -- default for those that haven't scored
	, case	when VisUpdatedForCurrentShiftFlag = 1 and Temp.Color = 'Purple' then 1 else 0 end as VISPurple
	, case	when VisUpdatedForCurrentShiftFlag = 1 and Temp.Color = 'Green' then 1 else 0 end as VISGreen
	, case	when VisUpdatedForCurrentShiftFlag = 1 and Temp.Color = 'Yellow' then 1 else 0 end as VISYellow
	, case	when VisUpdatedForCurrentShiftFlag = 1 and Temp.Color = 'Orange' then 1 else 0 end as VISOrange
	, case	when VisUpdatedForCurrentShiftFlag = 1 and Temp.Color = 'Red' then 1 else 0 end as VISRed
	,Case 
	      When VisUpdatedForCurrentShiftFlag = 1 and Temp.Color = 'Purple' Then 'VisPurple'
		  when VisUpdatedForCurrentShiftFlag = 1 and Temp.Color = 'Green' Then 'VisGreen'
		  when VisUpdatedForCurrentShiftFlag = 1 and Temp.Color = 'Yellow' Then 'VisYellow'
		  when VisUpdatedForCurrentShiftFlag = 1 and Temp.Color = 'Orange' Then 'VisOrange'
		  when VisUpdatedForCurrentShiftFlag = 1 and Temp.Color = 'Red' Then 'VisRed'
		  When VisUpdatedForCurrentShiftFlag = 0 or VisUpdatedForCurrentShiftFlag is null Then 'VisWhite'
		  End as VisColour
	,Case 
	      When VisUpdatedForCurrentShiftFlag = 1 and Temp.Color = 'Purple' Then '#9999FF'
		  when VisUpdatedForCurrentShiftFlag = 1 and Temp.Color = 'Green' Then '#85D19C'
		  when VisUpdatedForCurrentShiftFlag = 1 and Temp.Color = 'Yellow' Then '#F5F000'
		  when VisUpdatedForCurrentShiftFlag = 1 and Temp.Color = 'Orange' Then '#FFA900'
		  when VisUpdatedForCurrentShiftFlag = 1 and Temp.Color = 'Red' Then '#FD625E'
		  When VisUpdatedForCurrentShiftFlag = 0 or VisUpdatedForCurrentShiftFlag is null Then '#FFFFFF'
		  End as VisHexColor
	from Temp, current_time
where RowNumber = 1 




""")

# COMMAND ----------


