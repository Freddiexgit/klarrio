# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 6 June 2024  | 1       | Janesa R     | Initial draft |
# MAGIC | 18 July 2024 | 1       | Khalid J     | Added column to the view as per reporting requirements|

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_theatre_session""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_theatre_session
AS

select 
Session_Id
, Location_ID
, Specialty_Location_ID
, Theatre_Code
, Theatre_Description
, Dependent_Resource
, Session_Date
, Session_Start_Time
, Session_End_Time
, Session_Consultant
, Session_Booking_Method_Code
, AMPM
, Session_DateTime
, Session_Type
, case when Theatre_Code like '%V%' then 'Y' else 'N' end as Virtual_Theatre_Flag
, CAST(date_format(Session_DateTime, 'yyyyMMdd') AS char(8)) as Session_Start_Date_Key
from silver_live.cds_theatre_session

""")

# COMMAND ----------


