# Databricks notebook source


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 02-Aug-2024 | 1       | Khalid Jameel    | Create first draft of presentation view for variance calculations        |
# MAGIC | 08-Aug-2024 | 2       | Khalid Jameel    | Added Variance Calculations for variance bed occupancies and ward        |

# COMMAND ----------



# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_ioc_variance_calculation""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_ioc_variance_calculation
AS
With current_time AS (
SELECT
    from_utc_timestamp(current_timestamp(), 'Pacific/Auckland') AS now
),
TrendCare_to_TrakCare_Ward_Mapping as (
select
    location_code as Ward_Code,
    location_id as TrakCare_Location_ID,
    case
        when UPPER(location_code) = '10SURG' then '197'
        when UPPER(location_code) = '23B' then '16'
        when UPPER(location_code) = '24A' then '26'
        when UPPER(location_code) = '24B' then '17'
        when UPPER(location_code) = '25' then '18'
        when UPPER(location_code) = '26A' then '2'
        when UPPER(location_code) = '26B' then '20'
        when UPPER(location_code) = '27A' then '13'
        when UPPER(location_code) = '27B' then '3'
        when UPPER(location_code) = '31W' then '30'
        when UPPER(location_code) = '41' then '38'
        when UPPER(location_code) = '42' then '5'
        when UPPER(location_code) = '51' then '203'
        when UPPER(location_code) = '61' then '40'
        when UPPER(location_code) = '62' then '157'
        when UPPER(location_code) = '63' then '43'
        when UPPER(location_code) = '64' then '46'
        when UPPER(location_code) = '65' then '7'
        when UPPER(location_code) = '66' then '59'
        when UPPER(location_code) = '67' then '62'
        when UPPER(location_code) = '68' then '63'
        when UPPER(location_code) = '71' then '67'
        when UPPER(location_code) = '72' then '69'
        when UPPER(location_code) = '73' then '71'
        when UPPER(location_code) = '74' then '74'
        when UPPER(location_code) = '75' then '75'
        when UPPER(location_code) = '76' then '1'
        when UPPER(location_code) = '77' then '77'
        when UPPER(location_code) = '78' then '4'
        when UPPER(location_code) = '7A' then '78'
        when UPPER(location_code) = '81' then '80'
        when UPPER(location_code) = '83' then '121'
        when UPPER(location_code) = '91' then '83'
        when UPPER(location_code) = '96' then '87'
        when UPPER(location_code) = '97' then '89'
        when UPPER(location_code) = '98' then '91'
        when UPPER(location_code) = 'AWATEA' then '113'
        when UPPER(location_code) = 'CCU34' then '119'
        when UPPER(location_code) = 'CICU48' then '115'
        when UPPER(location_code) = 'DCCM82' then '109'
        when UPPER(location_code) = 'DSU' then '104'
        when UPPER(location_code) = 'MARINO' then '6'
        when UPPER(location_code) = 'MOTU' then '128'
        when UPPER(location_code) = 'NICU92' then '72'
        when UPPER(location_code) = 'PICU' then '51'
        when UPPER(location_code) = 'RANGI' then '47'
        when UPPER(location_code) = 'REMURA' then '45'
        when UPPER(location_code) = 'TAMAKI' then '33'
        when UPPER(location_code) = 'TOTARA' then '29'
        when UPPER(location_code) = 'TUPU' then '184'
        when UPPER(location_code) = 'WAU' then '23'
        when UPPER(location_code) = 'A' then '92'
        when UPPER(location_code) = 'B' then '114'
        when UPPER(location_code) = 'C' then '116'
        when UPPER(location_code) = 'BRC' then '8'
        when UPPER(location_code) = 'FMU' then '94'
        when UPPER(location_code) = 'CFUO' then '117'
        when UPPER(location_code) = 'TUPU' then '184'
    end as TrendCare_Ward_Code
from
    hive_metastore.gold_live.vw_pres_location
where
    UPPER(IOC_Ward_Type) IN('ADULT CRITICAL CARE', 'ADULT EMERGENCY', 'ADULT INPATIENT', 'CHILD HEALTH CRITICAL CARE',
'CHILD HEALTH DAY STAY', 'CHILD HEALTH INPATIENT', 'MENTAL HEALTH INPATIENT', 'WOMENS ACUTE MATERNITY', 'WOMENS HEALTH OTHER', 'WOMENS INPATIENT', 'MENTAL HEALTH INPATIENT', 'GREENLANE INPATIENT', 'WOMENS ACUTE MATERNITY', 'WOMENS HEALTH OTHER')
),
TrendCare_Details as (
select
    Trend_care_mapping.TrakCare_Location_ID,
    Trend_care_mapping.TrendCare_Ward_Code
from
	TrendCare_to_TrakCare_Ward_Mapping Trend_care_mapping 
),
Total_Expected_Arrivals_Without_Beds as(
--today only would be considered on the tile
Select
    DISTINCT COUNT(Admission_id) as Total_Expected_Arrivals,
    mvmt.Location_ID
from
    hive_metastore.silver_live.cds_movement mvmt,
    current_time
where
    mvmt.Movement_End_Datetime is null
    and mvmt.Movement_Code IN('Move', 'Booking')
    and mvmt.Movement_Status IN('Transfer', 'Requested', 'Accepted')
    and mvmt.Movement_Type IN('Ward Transfer', 'Bed Request')
    and mvmt.Movement_End_Datetime IS NULL
    and mvmt.Location_ID IS NOT NULL
    and date(mvmt.Movement_Start_Datetime) = date(now)
    
    and mvmt.bed_id IS NULL
    and mvmt.Room_Id IS NULL
group by
    mvmt.Location_ID
),
Total_Reserved_Beds_Today as( -- the allocated beds today only 
Select
    DISTINCT COUNT(mvmt.Admission_id) as Total_Reserved_Beds,
    mvmt.Location_ID
from
    hive_metastore.silver_live.cds_movement mvmt,
    current_time
where
    mvmt.Movement_End_Datetime is null
    and mvmt.Movement_Code IN('Move', 'Booking')
    and mvmt.Movement_Status IN('Transfer', 'Requested', 'Accepted')
    and mvmt.Movement_Type IN('Ward Transfer', 'Bed Request')
    and mvmt.Movement_End_Datetime IS NULL
    and mvmt.Location_ID IS NOT NULL
    and date(mvmt.Movement_Start_Datetime) = date(now)
    and mvmt.bed_id IS NOT NULL
group by
    mvmt.Location_ID
),
Total_Expected_Discharges as(
Select
    DISTINCT COUNT(adm.Admission_id) as Total_Expected_Discharges,
    mvmt.Location_ID
from
    hive_metastore.silver_live.cds_movement mvmt,
    current_time
Left outer join hive_metastore.silver_live.cds_admission adm on
    adm.admission_id = mvmt.admission_id
where
    mvmt.Movement_End_Datetime is null
    and mvmt.Movement_Code = 'Move'
    and mvmt.Movement_Status = 'Transfer'
    and mvmt.Movement_Type = 'Ward Transfer'
    and mvmt.Movement_End_Datetime IS NULL
    and mvmt.Location_ID IS NOT NULL
    --and adm.Estimated_Discharge_DateTime IS NOT NULL
    and adm.Actual_Discharge_DateTime IS NULL
    and adm.Actual_Discharge_DateTime IS NULL
    and adm.Admission_Type_Code IN('I')
    and adm.Visit_Status_Code IN('A')
    and date(adm.Estimated_Discharge_DateTime) = date(now)
    --and now > DATEADD(hour, 1, adm.Estimated_Discharge_DateTime )
group by
	mvmt.Location_ID
),
Total_Occupied_Beds as( --Both allocated and not allocated beds will come from here 
Select
    DISTINCT COUNT(adm.Admission_id) as Total_Occupied_Beds,
    mvmt.Location_ID
from
    hive_metastore.silver_live.cds_movement mvmt
Left outer join hive_metastore.silver_live.cds_admission adm on
    adm.admission_id = mvmt.admission_id
Left outer join hive_metastore.silver_live.cds_medical_record mr on
     mvmt.admission_id = mr.Admission_ID 
where
    mvmt.Movement_Code = 'Move'
    and mvmt.Movement_Status = 'Transfer'
    and mvmt.Movement_Type = 'Ward Transfer'
    and mvmt.Movement_End_Datetime IS NULL
    --and adm.Estimated_Discharge_DateTime IS NOT NULL
    and adm.Actual_Discharge_DateTime IS NULL
    and adm.Admission_Type_Code IN('I')
    and adm.Visit_Status_Code IN('A')
    group by
        mvmt.Location_ID
),
Total_Birth_Events as( 
Select
    DISTINCT COUNT(adm.Admission_id) as Total_Birth_Events,
    mvmt.Location_ID
from
    hive_metastore.silver_live.cds_movement mvmt
Left outer join hive_metastore.silver_live.cds_admission adm on
    adm.admission_id = mvmt.admission_id
Left outer join hive_metastore.silver_live.cds_medical_record mr on
     mvmt.admission_id = mr.Admission_ID 
where
    mvmt.Movement_Code = 'Move'
    and mvmt.Movement_Status = 'Transfer'
    and mvmt.Movement_Type = 'Ward Transfer'
    and mvmt.Movement_End_Datetime IS NULL
    --and adm.Estimated_Discharge_DateTime IS NOT NULL
    and adm.Actual_Discharge_DateTime IS NULL
    and adm.Admission_Type_Code IN('I')
    and adm.Visit_Status_Code IN('A')
    and UPPER(mr.Care_Type_Desc) IN('BIRTH EVENT')
    group by
        mvmt.Location_ID
),
Variances_and_Unc_Numbers as (
SELECT
    td.TrakCare_Location_ID,
    SUM(Trend_Var.NumberUncategorised) as UNC,
    MAX(Trend_Var.VariancePerFTEHourMinute) as VAR_FTE,
    MAX(Trend_Var.VarianceHours) as Variance_Hours
FROM
    hive_metastore.gold_live.vw_pres_trendcare_variance Trend_Var
INNER JOIN TrendCare_Details td on
	td.TrendCare_Ward_Code = Trend_Var.TCWardCode
GROUP BY
    td.TrakCare_Location_ID
),
Total_Restricted_Beds as (
select
    w.IOC_Ward_Type,
    w.Ward_Code,
    count( distinct rb.Bed_ID) as Total_Restricted_Beds
from
    hive_metastore.silver_live.cds_ref_bed rb
LEFT JOIN hive_metastore.silver_live.cds_ref_room R on
    R.room_ID = RB.Room_ID
left join hive_metastore.gold_live.vw_pres_ref_ward w on
    w.Ward_ID = rb.Ward_ID
left join hive_metastore.silver_live.cds_bed_status bs on
    rb.bed_id = bs.Bed_ID
where
    Is_Bed_Restricted = 'Y'
group by
    w.Ward_Code,
    w.IOC_Ward_Type
),
Total_Ward_Leave as (
Select
    DISTINCT COUNT(adm.Admission_id) as Total_Ward_Leave,
    mvmt.Location_ID
from
    hive_metastore.silver_live.cds_movement mvmt
Left outer join hive_metastore.silver_live.cds_admission adm on
    adm.admission_id = mvmt.admission_id
where
    mvmt.Movement_End_Datetime is null
    and mvmt.Movement_Code = 'Move'
    and mvmt.Movement_Status = 'Transfer'
    and mvmt.Movement_Type = 'Ward Transfer'
    and mvmt.Movement_End_Datetime IS NULL
    and mvmt.Location_ID IS NOT NULL
    and adm.Actual_Discharge_DateTime IS NULL
    and adm.Admission_Type_Code IN('I')
    and adm.Visit_Status_Code IN('A')
    and adm.Leave_Type_Code in ('WL', 'S31WL')
    and adm.Leave_Actual_Return_DateTime is null
    and adm.Leave_Actual_Return_DateTime is null
    and adm.Leave_Going_Out_DateTime is not null
group by
	mvmt.Location_ID
)
SELECT
    Loc.Location_ID,
    Loc.Location_Code,
    Loc.Location_Desc,
    IFNULL(Loc.Approved_Beds,0) as Approved_Beds,   
    IFNULL(BE.Total_Birth_Events,0) as Total_Birth_Events,
    IFNULL(R.Total_Restricted_Beds,0) as Total_Restricted_Beds,
	IFNULL(RB.Total_Reserved_Beds,0) AS Total_Reserved_Beds, 
	IFNULL(Loc.Approved_Beds,0) - IFNULL(R.Total_Restricted_Beds,0) as Total_Resourced_Beds,
	--IFNULL(OCC.Total_Occupied_Beds,0) AS Total_Occupied_Beds,
	--IFNULL(Loc.Approved_Beds,0) - IFNULL(OCC.Total_Occupied_Beds,0) - IFNULL(R.Total_Restricted_Beds,0) as Total_Available_Beds,
   	--IFNULL(Loc.Approved_Beds,0) - IFNULL(OCC.Total_Occupied_Beds,0) - IFNULL(R.Total_Restricted_Beds,0) - IFNULL(RB.Total_Reserved_Beds,0) as Bed_Occupancy_Tile,
	--(IFNULL(OCC.Total_Occupied_Beds,0) / (IFNULL(Loc.Approved_Beds,0) - IFNULL(R.Total_Restricted_Beds,0) )*100) as Percent_Occupancy,
	
    CASE WHEN UPPER(Gld_Loc.IOC_Ward_Type) IN('WOMENS ACUTE MATERNITY','WOMENS INPATIENT') THEN 
    	 	IFNULL(OCC.Total_Occupied_Beds,0) - IFNULL(BE.Total_Birth_Events,0) ELSE
    	 	IFNULL(OCC.Total_Occupied_Beds,0)
    	 END AS Total_Occupied_Beds,
	
	CASE WHEN UPPER(Gld_Loc.IOC_Ward_Type) IN('WOMENS ACUTE MATERNITY','WOMENS INPATIENT') THEN 
    	 	IFNULL(Loc.Approved_Beds,0) - ( IFNULL(OCC.Total_Occupied_Beds,0) - IFNULL(BE.Total_Birth_Events,0) ) - IFNULL(R.Total_Restricted_Beds,0)  ELSE
    	 	IFNULL(Loc.Approved_Beds,0) - IFNULL(OCC.Total_Occupied_Beds,0) - IFNULL(R.Total_Restricted_Beds,0) 
    	 END AS Total_Available_Beds,

	CASE WHEN UPPER(Gld_Loc.IOC_Ward_Type) IN('WOMENS ACUTE MATERNITY','WOMENS INPATIENT') THEN 
    	 	IFNULL(Loc.Approved_Beds,0) - ( IFNULL(OCC.Total_Occupied_Beds,0) - IFNULL(BE.Total_Birth_Events,0) ) - IFNULL(R.Total_Restricted_Beds,0) - IFNULL(RB.Total_Reserved_Beds,0) ELSE
    	 	IFNULL(Loc.Approved_Beds,0) - IFNULL(OCC.Total_Occupied_Beds,0) - IFNULL(R.Total_Restricted_Beds,0) - IFNULL(RB.Total_Reserved_Beds,0)
    	 END AS Bed_Occupancy_Tile,
    	 
	CASE WHEN UPPER(Gld_Loc.IOC_Ward_Type) IN('WOMENS ACUTE MATERNITY','WOMENS INPATIENT') THEN 
    	 	( (IFNULL(OCC.Total_Occupied_Beds,0) - IFNULL(BE.Total_Birth_Events,0)) / (IFNULL(Loc.Approved_Beds,0) - IFNULL(R.Total_Restricted_Beds,0) )*100) ELSE
    	 	(IFNULL(OCC.Total_Occupied_Beds,0) / (IFNULL(Loc.Approved_Beds,0) - IFNULL(R.Total_Restricted_Beds,0) )*100)
    	 END AS Percent_Occupancy,    	 
   
    IFNULL(EA.Total_Expected_Arrivals,0) as Total_Expected_Arrivals_wo_beds,
    IFNULL(ED.Total_Expected_Discharges, 0) as Total_Expected_Discharges,
    IFNULL(VAR.UNC, 0) as UNC,
    IFNULL(VAR.VAR_FTE, 0) as VAR_FTE,
    IFNULL(WL.Total_Ward_Leave, 0) as Total_Ward_Leave,
    IFNULL(case when ROUND(VAR.Variance_Hours, 0) > 0 then '+'||ROUND(VAR.Variance_Hours, 0) 
   				when ROUND(VAR.Variance_Hours, 0) <= 0 then ROUND(VAR.Variance_Hours, 0) 
    end, 0) as Variance_Hours
FROM
    hive_metastore.silver_live.cds_location Loc
LEFT OUTER JOIN Total_Expected_Arrivals_Without_Beds EA ON
    Loc.Location_ID = EA.Location_ID
LEFT OUTER JOIN Total_Occupied_Beds OCC ON
    Loc.Location_ID = OCC.Location_ID
LEFT OUTER JOIN Variances_and_Unc_Numbers VAR ON
    Loc.Location_ID = VAR.TrakCare_Location_ID
LEFT OUTER JOIN Total_Expected_Discharges ED ON
    Loc.Location_ID = ED.Location_ID
LEFT OUTER JOIN Total_Reserved_Beds_Today RB ON
    Loc.Location_ID = RB.Location_ID
LEFT OUTER JOIN Total_Restricted_Beds R ON
    Loc.Location_Code = R.Ward_Code
LEFT OUTER JOIN Total_Ward_Leave WL ON 
	Loc.Location_ID = WL.Location_ID
LEFT OUTER JOIN Total_Birth_Events BE ON 
	Loc.Location_ID = BE.Location_ID
LEFT JOIN hive_metastore.gold_live.vw_pres_location Gld_Loc ON 
	Loc.Location_Code = Gld_Loc.Location_Code
WHERE
UPPER(Gld_Loc.IOC_Ward_Type) IN('ADULT CRITICAL CARE','ADULT EMERGENCY','ADULT INPATIENT','CHILD HEALTH CRITICAL CARE',
'CHILD HEALTH DAY STAY','CHILD HEALTH INPATIENT','MENTAL HEALTH INPATIENT','WOMENS ACUTE MATERNITY','WOMENS HEALTH OTHER','WOMENS INPATIENT', 'MENTAL HEALTH INPATIENT', 'GREENLANE INPATIENT', 'WOMENS ACUTE MATERNITY', 'WOMENS HEALTH OTHER');
""")

# COMMAND ----------


