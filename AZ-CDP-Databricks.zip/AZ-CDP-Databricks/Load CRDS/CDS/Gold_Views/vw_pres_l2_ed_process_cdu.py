# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 03-May-2024 | 1       | Janesa R       | Created vw_pres_l2_ed_process_cdu                         |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_l2_ed_process_cdu""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_l2_ed_process_cdu
AS

------ 20/08/2024 Added the speciality filter to IP decision
SELECT
    Ward,
    CASE CDUStage
        WHEN 'CDUAwaitingPlacement' THEN 'CDU Awaiting Placement'
        WHEN 'AwaitingAmbulatoryOffload' THEN 'Awaiting Ambulatory Offload'
        WHEN 'AwaitingIPSignon' THEN 'Awaiting IP Signon'
        WHEN 'AwaitingIPDecision' THEN 'Awaiting IP Decision'
        WHEN 'ShortStayPatient' THEN 'Short Stay Patients'
        WHEN 'BedRequestActive' THEN 'Bed Request Active'
        WHEN 'BedRequestAccepted' THEN 'Bed Request Accepted'
        WHEN 'BedReady' THEN 'Bed Ready'
    END AS CDUStage,
    SUM(PatientCount) AS PatientCount,
    CASE CDUStage
        WHEN 'CDUAwaitingPlacement' THEN 1
        WHEN 'AwaitingAmbulatoryOffload' THEN 2
        WHEN 'AwaitingIPSignon' THEN 3
        WHEN 'AwaitingIPDecision' THEN 4
        WHEN 'ShortStayPatient' THEN 5
        WHEN 'BedRequestActive' THEN 6
        WHEN 'BedRequestAccepted' THEN 7
        WHEN 'BedReady' THEN 8
    END AS CDUStageOrder,
    CASE 
        WHEN (CDUStage = 'AwaitingAmbulatoryOffload' AND SUM(PatientCount) >= 15) 
            OR (CDUStage = 'CDUAwaitingPlacement' AND SUM(PatientCount) >= 15) 
            OR (CDUStage = 'AwaitingEMSignon' AND SUM(PatientCount) >= 30) 
        THEN '#ED1010'
        ELSE '#4875AF'
    END AS RAGColour
FROM 
(
    SELECT 
        Ward,
        CDUStage,
        PatientCount
    FROM 
    (
        SELECT
            Ward,
            AdmissionNumber,
            BedRequestActive,
            BedRequestAccepted,
            BedReady,
            AwaitingAmbulatoryOffload,
            CDUAwaitingPlacement,
            ShortStayPatient,
            AwaitingIPSignon,
            CASE 
                WHEN AwaitingIPSignon = 0 AND BedRequestActive = 0 AND BedRequestAccepted = 0 AND SSFlag = 'N'
                     AND Specialty NOT IN ('Adult Emergency Department', 'Clinical Decision Unit') 
                     AND Movement_Status IS NULL AND Medical_Discharge_DateTime IS NULL 
                     AND Current_Clinician IS NOT NULL AND Movement_End_Datetime IS NULL  
                THEN 1 
                ELSE 0 
            END AS AwaitingIPDecision
        FROM
        (
           SELECT
                wt.CurrWard AS Ward,
                loc1.Location_Code AS ScheduledWard,
                ad.Admission_Number AS AdmissionNumber, 
                pat.Patient_NHI,
                mv1.CBU,
                mv1.Specialty,
                mv1.Current_Clinician,
                ad.Clinician_Seen_DateTime,
                mv1.Movement_Type,
                ad.Medical_Discharge_DateTime,
                mv1.Movement_End_Datetime,
                mv2.Movement_Status,
                CASE 
                    WHEN (wt.Room_Code IS NULL AND ad.Ambul_Handover_Comp_DateTime IS NULL AND mv1.Movement_Type = 'Ward Transfer' AND mv1.Movement_End_Datetime IS NULL AND mr.Transfer_Means_Desc LIKE '%Ambulance%')
                        OR (wt.Room_Code = 'STJ' AND ad.Ambul_Handover_Comp_DateTime IS NULL AND mv1.Movement_Type = 'Ward Transfer' AND mv1.Movement_End_Datetime IS NULL AND mr.Transfer_Means_Desc LIKE '%Ambulance%') 
                    THEN 1 
                    ELSE 0 
                END AS CDUAwaitingAmbulatoryOffload,
                CASE 
                    WHEN wt.Inpatient_Short_Stay_Intent = 'Y' OR wt.Room_Code IN ('SS1', 'SS2', 'SS3', 'SS4', 'SS5') 
                    THEN 'Y' 
                    ELSE 'N' 
                END AS SSFlag,
                ROUND((DATEDIFF(MINUTE, mv1.Movement_Start_Datetime, DATEADD(HOUR, 12, CURRENT_TIMESTAMP)) / 60.0), 0) AS BRwaiting,
                CASE 
                    WHEN (mv1.Movement_Type = 'Bed Request' AND mv1.Movement_Status = 'Requested' AND wt.CurrWard = 'CDU') 
                    THEN 1 
                    ELSE 0 
                END AS BedRequestActive,
                CASE 
                    WHEN (mv1.Movement_Type = 'Case Transfer' AND mv1.Current_Clinician IS NULL AND mv1.Emergency_Consultant is NULL AND mv1.RMC IS NULL AND mv1.CBU IN ('Emergency Medicine', 'Adult Emergency Department', 'Child Emergency Dept (CED)') AND mv1.Movement_End_Datetime IS NULL) 
                    THEN 1 
                    ELSE 0 
                END AS AwaitingEMSignon,
                CASE 
                    WHEN (mv1.Movement_Type = 'Bed Request' AND mv1.Movement_Status = 'Accepted' AND wt.CurrWard = 'CDU' AND mv1.Movement_End_Datetime IS NOT NULL) 
                    THEN 1 
                    ELSE 0 
                END AS BedRequestAccepted,
                CASE 
                    WHEN (mv1.Movement_Type = 'Bed Request' AND mv1.Movement_Status = 'Accepted' AND ((DATEDIFF(MINUTE, mv1.Movement_Start_Datetime, DATEADD(HOUR, 12, CURRENT_TIMESTAMP)) / 60.0 > 1) AND wt.CurrWard = 'CDU')) 
                    THEN 1 
                    ELSE 0 
                END AS BedReady,
                CASE 
                    WHEN (
                              ad.Actual_Arrival_DateTime IS NOT NULL
                          AND ad.Clinician_Seen_DateTime is null
                          AND ad.Ambul_Handover_Comp_DateTime IS NULL 
                          AND mv1.Movement_Type = 'Ward Transfer' 
                          AND mv1.Movement_End_Datetime IS NULL 
                          AND wt.Movement_End_Datetime IS NULL 
                          AND mr.Transfer_Means_Desc LIKE '%Ambulance%' 
                          AND wt.CurrWard = 'CDU'
                         ) 
                    THEN 1 
                    ELSE 0 
                END AS AwaitingAmbulatoryOffload,
                CASE 
                    WHEN (mv1.Movement_Type = 'Ward Transfer' AND r1.Room_Type_Code IS NULL AND wt.CurrWard = 'CDU' AND mv1.Movement_End_Datetime IS NULL) 
                    THEN 1 
                    ELSE 0 
                END AS CDUAwaitingPlacement,
                CASE 
                    WHEN (wt.Inpatient_Short_Stay_Intent = 'Y' AND mv1.Movement_End_Datetime IS NULL AND mv1.Movement_Type = 'Ward Transfer' AND wt.CurrWard = 'CDU') 
                        OR (r1.Room_Code IN ('SS1', 'SS2', 'SS3', 'SS4', 'SS5') AND wt.Inpatient_Short_Stay_Intent <> 'N' AND mv1.Movement_End_Datetime IS NULL AND mv1.Movement_Type = 'Ward Transfer' AND wt.CurrWard = 'CDU') 
                    THEN 1 
                    ELSE 0 
                END AS ShortStayPatient,
                CASE 
                    WHEN (mv1.Movement_Type = 'Case Transfer' AND mv1.cbu NOT IN ('Emergency Medicine', 'Adult Emergency Department') AND mv1.Current_Clinician = 'Awaiting IP clinician Sign on' AND mv1.Movement_End_Datetime IS NULL AND wt.CurrWard = 'CDU')
                        OR (mv1.Movement_Type = 'Case Transfer' AND mv1.Movement_End_Datetime IS NULL AND mv1.Specialty NOT IN ('Adult Emergency Department', 'Clinical Decision Unit') AND mv1.Current_Clinician IS NULL) 
                    THEN 1 
                    ELSE 0 
                END AS AwaitingIPSignon
            FROM 
                hive_metastore.silver_live.cds_admission ad
                LEFT JOIN hive_metastore.silver_live.cds_medical_record mr ON ad.Admission_ID = mr.Admission_ID
                LEFT JOIN hive_metastore.silver_live.cds_movement mv1 ON ad.Admission_ID = mv1.Admission_ID
                LEFT JOIN hive_metastore.silver_live.cds_location loc1 ON mv1.Location_ID = loc1.Location_ID
                LEFT JOIN hive_metastore.silver_live.cds_patient pat ON ad.Patient_ID = pat.Patient_ID
                LEFT JOIN hive_metastore.silver_live.cds_ref_room r1 ON mv1.Room_ID = r1.Room_ID
                LEFT JOIN hive_metastore.silver_live.cds_movement mv2 ON mv1.Admission_ID = mv2.Admission_ID AND mv2.Movement_Type = 'Bed Request' AND mv2.Movement_End_Datetime IS NULL
                LEFT JOIN 
                (
                    SELECT 
                        ad.Admission_ID AS AdmissionID,
                        ad.Admission_Number AS AdmissionNumber,
                        ad.Inpatient_Short_Stay_Intent,
                        loc.Location_Code AS CurrWard,
                        r.Room_Code,
                        ad.Actual_Arrival_DateTime,
                        ad.Ambul_Handover_Comp_DateTime,
                        mv2.Movement_End_Datetime
                    FROM 
                        hive_metastore.silver_live.cds_admission ad
                        LEFT JOIN hive_metastore.silver_live.cds_movement mv2 ON ad.Admission_ID = mv2.Admission_ID
                        LEFT JOIN hive_metastore.silver_live.cds_location loc ON mv2.Location_ID = loc.Location_ID
                        LEFT JOIN hive_metastore.silver_live.cds_ref_room r ON mv2.Room_ID = r.Room_ID
                    WHERE 
                        mv2.Movement_Type = 'Ward Transfer'
                        AND mv2.Movement_End_Datetime IS NULL
                ) wt ON wt.AdmissionID = mv1.Admission_ID
            WHERE 
                1 = 1
                AND wt.CurrWard IN ('CDU')
                AND ad.Visit_Status_Code = 'A'
        ) AS Q1
    ) AS Q2
    UNPIVOT 
    (
        PatientCount FOR CDUStage IN (
            CDUAwaitingPlacement, 
            AwaitingAmbulatoryOffload, 
            AwaitingIPSignon, 
            AwaitingIPDecision, 
            ShortStayPatient, 
            BedRequestActive, 
            BedRequestAccepted, 
            BedReady
        )
    ) AS UP
) AS Q3
GROUP BY
    Ward,
    CDUStage;

""")

# COMMAND ----------


