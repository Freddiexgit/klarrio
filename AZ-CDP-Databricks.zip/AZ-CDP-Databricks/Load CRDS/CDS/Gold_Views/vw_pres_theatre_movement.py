# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 28-Mar-2024 | 1       | Siddharth S    | Create first draft of presentation view from cds_movement delta table      |
# MAGIC | 01-May-2024 | 2       | Janesa R       | Added Movement_Sequence2
# MAGIC | 16-Aug-2024 | 3       | Khalid J       | Added Movemnt Procedure ID and Description columns
# MAGIC

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

#dbutils.widgets.remove("p_etlcontrolid")

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP VIEW gold_live.vw_pres_theatre_movement""")

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE VIEW gold_live.vw_pres_theatre_movement
AS


WITH PostTheatre_Movement as (
select
    distinct
    Admission_ID,
    Movement_ReadyToLeave_DateTime,
    Movement_Start_DateTime
from
    hive_metastore.silver_live.cds_movement
where
    Movement_Type = 'Post Theatre Event'
)
,
Procedure_Description as (
select 
	Procedure_ID,
	Procedure_Desc as Movement_Procedure_Description 
from
	hive_metastore.silver_live.cds_ref_procedure
)
SELECT
    mv1.UID,
    mv1.Movement_Sequence,
    mv1.Admission_ID,
    mv1.Movement_Type,
    mv1.Movement_Code,
    mv1.Movement_Status,
    mv1.Location_ID,
    mv1.Speciality_Location_ID,
    mv1.Bed_ID,
    mv1.Room_ID,
    mv1.Movement_Create_DateTime,
    mv1.Movement_Start_Datetime,
    mv1.Movement_End_Datetime,
    mv1.Movement_ReadyToLeave_DateTime,
    mv1.Current_Clinician,
    mv1.Emergency_Consultant,
    mv1.RMC,
    mv1.Directorate,
    mv1.CBU,
    mv1.Specialty,
    mv1.Movement_Is_Main,
    mv1.Override_Room_Type,
    mv1.Transfer_Remark,
    mv1.Acute_Or_Elective,
    mv1.Movement_Procedure_ID,
    PD.Movement_Procedure_Description,
    mv1.processing_time,
    CASE
        WHEN mv2.Movement_ReadyToLeave_DateTime is not NULL THEN 'Fit to leave'
        When mv2.Movement_ReadyToLeave_DateTime is NULL
        and mv2.movement_start_datetime is not NULL then 'In PACU'
        WHEN mv2.movement_start_datetime IS NULL
        AND mv1.movement_start_datetime IS NOT NULL THEN 'In Theatre'
        ELSE 'Not in Theatre'
    END AS Theatre_Progress
FROM
    hive_metastore.silver_live.cds_movement mv1
left outer join PostTheatre_Movement mv2 on
    mv2.Admission_ID = mv1.Admission_ID
left outer join Procedure_Description PD on
    mv1.Movement_Procedure_ID = PD.Procedure_ID
where
    mv1.Movement_Type in ('Theatre Event', 'Post Theatre Event', 'Theatre Booking');
 


 """)

# COMMAND ----------


