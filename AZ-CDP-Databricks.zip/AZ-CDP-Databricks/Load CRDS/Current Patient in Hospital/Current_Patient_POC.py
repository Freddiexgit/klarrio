# Databricks notebook source
# MAGIC %md
# MAGIC ###Notebook to execute CRDS process create current patient in hospital dashboard

# COMMAND ----------

# MAGIC %md
# MAGIC ####Importing libraries

# COMMAND ----------

import pandas as pd
import datetime
import pytz
from pyspark.sql.window import Window
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import SparkSession

# COMMAND ----------

# MAGIC %md
# MAGIC ####calling the notebook where common Utilities are stored

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

#%run "../../Utilities/utils"

# COMMAND ----------

spark.sql(f"""
CREATE Or Replace TABLE silver_live.CurrentEpisodes
COMMENT "The episodes of patients who are currently in hospital, ingested from RDS layer."
TBLPROPERTIES ("myCompanyPipeline.quality" = "CRDS")
LOCATION '{silver_folder_path}/trakcare_live/CRDS/CurrentPatients/Current_Episodes'
AS 
SELECT 
PAADM_RowID as EpisodeID,
PAADM_ADMNo AS EpisodeNo,
PAADM_PAPMI_DR AS PatientID,
PAADM_DepCode_DR AS EpisodeAdmitDepartment,
PAADM_AdmCateg_DR AS EpisodeAdmitCategory,
PAADM_AdmDate AS AdmitDate,
PAADM_AdmTime AS AdmitTime,
PAADM_Type AS AdmitType,
PAADM_AdmSrc_DR AS AdmitSource,
PAADM_VisitStatus AS EpisodeStatus,
PAADM_ExpLOS AS ExpectedLOS,
PAADM_EmergencyDate AS EDAdmitDate,
PAADM_EmergencyTime AS EDADmitTime,
PAADM_EstimDischargeDate AS ExpectedDischargeDate,
PAADM_CurrentWard_DR AS CurrentWardID,
PAADM_CurrentRoom_DR AS CurrentRoomID,
PAADM_CurrentBed_DR AS CurrentBedID,
PAADM_AdmReason_DR AS AdmitReason,
PAADM_Current AS CurrentFlag,
PAADM_UpdateDate AS EpisodeUpdateDate,
PAADM_UpdateTime AS EpisodeUpdateTime
FROM bronze_live.tc_lv_pa_adm where PAADM_Current = 'Y'
""")

# COMMAND ----------

targettable = 'tc.current_episodes'
Current_Episodes_DF = spark.read.format("delta").load(f"{silver_folder_path}/trakcare_live/CRDS/CurrentPatients/Current_Episodes")
write_to_mi_db(Current_Episodes_DF,'DA_PRES',targettable,'overwrite')

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE TABLE silver_live.CurrentPatients
COMMENT "The demographics of patients who are currently in hospital, ingested from RDS layer."
TBLPROPERTIES ("myCompanyPipeline.quality" = "CRDS")
Location '{silver_folder_path}/trakcare_live/CRDS/CurrentPatients/Current_Patients'
AS 
SELECT  
  patients.PAPER_PAPMI_DR AS PatientID,
  patients.PAPER_Name AS Name,
  patients.PAPER_Dob AS DateofBirth,
  patients.PAPER_AgeYr AS AgeYear,
  patients.PAPER_AgeMth AS AgeMonth,
  patients.PAPER_AgeDay AS AgeDay,
  patients.PAPER_Sex_DR AS SexID,
  gender.GENID_Desc AS GenderDesc
  --ethnicity.ETHNIC_Desc
FROM bronze_live.tc_lv_pa_person as patients
JOIN bronze_live.tc_lv_pa_adm as episodes on patients.PAPER_PAPMI_DR = episodes.PAADM_PAPMI_DR AND PAADM_Current = 'Y'
LEFT JOIN bronze_live.tc_lv_CT_GenderIdentity as gender on patients.PAPER_BirthGender_DR = gender.GENID_RowId
LEFT JOIN bronze_live.tc_lv_PA_PersonEthnicity as patEthnicity on patients.PAPER_PAPMI_DR = patEthnicity.ETHNIC_ParRef
--LEFT JOIN bronze_live.tc_lv_PAC_Ethnicity as ethnicity on patEthnicity.ETHNIC_Ethnicity_DR = ethnicity.ETHNIC_Rowid;
""")


# COMMAND ----------

targettable = 'tc.current_patients'
Current_Patients_DF = spark.read.format("delta").load(f"{silver_folder_path}/trakcare_live/CRDS/CurrentPatients/Current_Patients")
write_to_mi_db(Current_Patients_DF,'DA_PRES',targettable,'overwrite')

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE TABLE silver_live.Ward
COMMENT "List of all wards in hospital, ingested from RDS layer."
TBLPROPERTIES ("myCompanyPipeline.quality" = "CRDS")
Location '{silver_folder_path}/trakcare_live/CRDS/CurrentPatients/Ward'
AS 
SELECT 
WARD_RowID AS WardID,
WARD_Code AS WardCode,
Ward_Desc AS WardDesc,
Ward_RoomDR AS WardRoomID,
WARD_SingleRoom AS WardSingleRoom,
WARD_LocationDR AS WardLocationID
from
bronze_live.tc_lv_pac_ward
""")


# COMMAND ----------

targettable = 'tc.ward'
Ward_DF = spark.read.format("delta").load(f"{silver_folder_path}/trakcare_live/CRDS/CurrentPatients/Ward")
write_to_mi_db(Ward_DF,'DA_PRES',targettable,'overwrite')

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE TABLE silver_live.Room
COMMENT "List of all wards in hospital, ingested from RDS layer."
TBLPROPERTIES ("myCompanyPipeline.quality" = "CRDS")
Location '{silver_folder_path}/trakcare_live/CRDS/CurrentPatients/Room'
AS 
SELECT
ROOM_RowID AS RoomID,
ROOM_Code AS RoomCode,
ROOM_Desc AS RoomDesc,
ROOM_RoomType_DR AS RoomTypeID,
ROOM_UpdatedDate AS RoomUpdateDate,
ROOM_UpdatedTime AS RoomUpdateTime
FROM bronze_live.tc_lv_pac_room
""")

# COMMAND ----------

targettable = 'tc.room'
Room_DF = spark.read.format("delta").load(f"{silver_folder_path}/trakcare_live/CRDS/CurrentPatients/Room")
write_to_mi_db(Room_DF,'DA_PRES',targettable,'overwrite')

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE TABLE silver_live.Bed
COMMENT "List of all wards in hospital, ingested from RDS layer."
TBLPROPERTIES ("myCompanyPipeline.quality" = "CRDS")
Location '{silver_folder_path}/trakcare_live/CRDS/CurrentPatients/Bed'
AS 
SELECT 
 BED_WARD_ParRef AS BedWardID
,BED_RowID AS BedID
,BED_Room_DR AS BedRoomID
,BED_Code As BedCode
,BED_Status_DR AS BedStatusID
,BED_BedType_Dr AS BedTypeID
,BED_Childsub AS BedChildID
,BED_Available AS BedAvailableFlag
,BED_UpdatedDate AS BedUpdateDate
,BED_UpdateDTime AS BedUpdateTime
FROM bronze_live.tc_lv_pac_bed
""")

# COMMAND ----------

targettable = 'tc.bed'
Bed_DF = spark.read.format("delta").load(f"{silver_folder_path}/trakcare_live/CRDS/CurrentPatients/Bed")
write_to_mi_db(Bed_DF,'DA_PRES',targettable,'overwrite')

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE TABLE silver_live.WardRoom
COMMENT "List of all wards in hospital, ingested from RDS layer."
TBLPROPERTIES ("myCompanyPipeline.quality" = "CRDS")
Location '{silver_folder_path}/trakcare_live/CRDS/CurrentPatients/WardRoom'
AS 
SELECT 
 Room_ParRef AS WardID
,Room_RowID AS WardRoomID
,Room_childSub AS RoomChildID
,Room_Room_Dr As RoomID
FROM bronze_live.tc_lv_pac_wardroom
""")

# COMMAND ----------

targettable = 'tc.wardroom'
Bed_DF = spark.read.format("delta").load(f"{silver_folder_path}/trakcare_live/CRDS/CurrentPatients/WardRoom")
write_to_mi_db(Bed_DF,'DA_PRES',targettable,'overwrite')

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE TABLE silver_live.WardRoomBed
COMMENT "List of all wards in hospital, ingested from RDS layer."
TBLPROPERTIES ("myCompanyPipeline.quality" = "CRDS")
Location '{silver_folder_path}/trakcare_live/CRDS/CurrentPatients/WardRoomBed'
AS 
SELECT 
 Ward_RowID AS WardID
,Ward_Code AS WardCode
,Ward_Desc AS WardDesc
,R.Room_RowID AS WardRoomID
,Room_Code AS RoomCode
,Room_Desc AS RoomDesc
,ROOM_RoomType_DR AS RoomTypeID
,Bed_code AS BedCode
,Bed_BedType_DR AS BedTypeID
,Bed_Available As BedAvailableFlag
,CASE WHEN Bed_Code IS NULL THEN 'No Bed'
 ELSE Bed_Code 
 END as NewBedCode
,CASE WHEN Bed_Available = 'Y' Then 'Bedvacant'
      WHEN Bed_Available = 'N' THEN 'Bedoccuiped'
 ELSE 'No Bed in the Room'
 END as Bedoccupancy
FROM bronze_live.tc_lv_pac_ward AS W
JOIN bronze_live.tc_lv_pac_wardroom AS WR ON W.ward_rowid = WR.Room_ParRef
JOIN bronze_live.tc_lv_pac_room AS R ON WR.room_room_dr = R.room_rowid
LEFT JOIN bronze_live.tc_lv_pac_bed AS B ON WR.room_parref = B.bed_ward_Parref and R.room_rowid = B.bed_room_dr
""")

# COMMAND ----------

targettable = 'tc.wardroombed'
Bed_DF = spark.read.format("delta").load(f"{silver_folder_path}/trakcare_live/CRDS/CurrentPatients/WardRoomBed")
write_to_mi_db(Bed_DF,'DA_PRES',targettable,'overwrite')

# COMMAND ----------

# MAGIC %sql
# MAGIC select Count(distinct EpisodeID) as TotalPatients 
# MAGIC ,GenderDesc
# MAGIC ,avg(ExpectedLOS) as LOS
# MAGIC ,Concat(max(EpisodeUpdateDate),'  ',extract(H From max(EpisodeUpdateTime)),':',extract(mins From max(EpisodeUpdateTime)),':',extract(s From max(EpisodeUpdateTime))) as LatestUpdateDate
# MAGIC --,PAADM_AdmDate as AdmitDate
# MAGIC from silver_live.CurrentEpisodes as e
# MAGIC Join silver_live.CurrentPatients as p on e.PatientID = p.PatientID
# MAGIC Group by GenderDesc

# COMMAND ----------

# MAGIC %sql
# MAGIC select Count(EpisodeID) as TotalPatients 
# MAGIC ,month(AdmitDate) as AdmitMonth
# MAGIC from silver_live.CurrentEpisodes 
# MAGIC --Join silver.CurrentPatients as p on e.PAADM_PAPMI_DR = p.PAPER_PAPMI_DR
# MAGIC Where AdmitDate between '2023-01-01' and '2023-12-31'
# MAGIC Group by month(AdmitDate)
# MAGIC Order By month(AdmitDate)

# COMMAND ----------

# MAGIC %sql
# MAGIC select Count(EpisodeNo) as TotalPatients 
# MAGIC ,WardCode as Ward
# MAGIC from silver_live.CurrentEpisodes as e
# MAGIC Join silver_live.ward as w on e.CurrentWardID = w.WardID
# MAGIC Group by WardCode

# COMMAND ----------

# MAGIC %sql
# MAGIC select Count(EpisodeID) as TotalPatients 
# MAGIC --,PAADM_AdmDate as AdmitDate
# MAGIC ,WardCode as Ward
# MAGIC from silver_live.CurrentEpisodes as e
# MAGIC Join silver_live.ward as w on e.CurrentWardID = w.WardID
# MAGIC where
# MAGIC WardCode in ('AED')
# MAGIC Group by WardCode
