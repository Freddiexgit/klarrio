# Cache the table in memory
spark.catalog.cacheTable("adm_config.control_cds")