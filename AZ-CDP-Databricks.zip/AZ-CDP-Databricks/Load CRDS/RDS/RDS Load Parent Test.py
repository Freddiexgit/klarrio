# Databricks notebook source
# MAGIC %md
# MAGIC # Notebook to implement multi processing/parallel runs of RDS fast load 

# COMMAND ----------

dbutils.widgets.dropdown("BatchType", "RDS_Live", ["RDS_Live", "RDS_Full"])
v_BatchType = dbutils.widgets.get("BatchType")

dbutils.widgets.text("TrakCareSource","DM")
v_TrakCareSource= dbutils.widgets.get("TrakCareSource")

# COMMAND ----------

# MAGIC %md
# MAGIC ###Importing libraries

# COMMAND ----------

import pandas as pd
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor

# COMMAND ----------

# MAGIC %md
# MAGIC ###Function to call the RDS fast load notebook

# COMMAND ----------

def processRDSLoad(etlControlID):
    v_Message = dbutils.notebook.run(path = "./RDS Load Test",
                                        timeout_seconds = 1200, 
                                        arguments = {"etlControlID":etlControlID,"TrakCareSource":v_TrakCareSource})
    return(v_Message)


# COMMAND ----------

# MAGIC %md
# MAGIC ###Function to read data from SQL MI system

# COMMAND ----------

# Cache the table in memory
spark.catalog.cacheTable("adm_config.control_cds")

# COMMAND ----------

qry = f"""
        SELECT 
            ETLcontrolid 
        FROM 
            adm_config.control_cds
        where 
            Token = 'RDS'
            and IsActive = 1 
            and BatchType = '{v_BatchType}'
            """
EtlControl_df = spark.sql(qry)

# COMMAND ----------

display(EtlControl_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Executing the RDS fast loading notebooks

# COMMAND ----------

Table_Count = EtlControl_df.count()
print(f'Total no of tables processed:{Table_Count}')
listOfNumbers = list(EtlControl_df.select('ETLcontrolid').toPandas()['ETLcontrolid']) # => [1, 2, 3, 4]
max_workers = 20
with ThreadPoolExecutor(max_workers=max_workers) as executor:
  for result in executor.map(processRDSLoad, listOfNumbers):
    print(result)



# COMMAND ----------

# Don't forget to uncache the table when it's no longer needed
# spark.catalog.uncacheTable("adm_config.control_cds")
