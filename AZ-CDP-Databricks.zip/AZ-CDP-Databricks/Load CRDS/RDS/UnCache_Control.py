# Don't forget to uncache the table when it's no longer needed
spark.catalog.uncacheTable("adm_config.control_cds")