# Databricks notebook source
from pyspark.sql.types import *
from delta.tables import *
from pyspark.sql.functions import *
from pyspark.sql import SparkSession


# COMMAND ----------

def SchemaSet(tableName):
    TableName1 = "{'TabName':'PAC_TransferMeans','Value': 'bronze.tc_l_PAC_TransferMeans (TRANSM_RowId long,TRANSM_Code string,TRANSM_Desc string,TRANSM_IconName string,TRANSM_IconPriority string,TRANSM_DateFrom date,TRANSM_DateTo date,TRANSM_NationalCode string,TRANSM_Owner string,TRANSM_CodeTableTags string,TRANSM_Subregion_DR long,TRANSM_CreatedDate date,TRANSM_CreatedTime timestamp,TRANSM_CreatedUser_DR long,TRANSM_UpdatedDate date,TRANSM_UpdatedTime timestamp,TRANSM_UpdatedUser_DR long)','MergeC':'TRANSM_RowId','Source':'tc','Database':'trakcare','CDCFlag':'N'}"
    TableName2 = "{'TabName':'PAC_Ward','Value': 'bronze.tc_l_PAC_Ward (WARD_RowID long,WARD_Code string,WARD_Desc string,WARD_RoomDR long,WARD_SingleRoom string,WARD_LocationDR long,WARD_Active string,WARD_InactiveDateFrom date,WARD_InactiveTimeFrom timestamp,WARD_InactiveDateTo date,WARD_InactiveTimeTo timestamp,WARD_ViewLinkedRooms string,WARD_ViewNextMostUrgent string,WARD_IgnoreTempLoc string,WARD_CreatedDate date,WARD_CreatedTime timestamp,WARD_CreatedUser_DR long,WARD_UpdatedDate date,WARD_UpdatedTime timestamp,WARD_UpdatedUser_DR long,WARD_CodeTranslated string,WARD_DescTranslated string)','MergeC':'WARD_RowID','Source':'tc','Database':'trakcare','CDCFlag':'N'}"
    TableName3 = "{'TabName':'CT_Loc','Value': 'bronze.tc_l_CT_Loc (CTLOC_RowID long,CTLOC_Code string,CTLOC_Desc string,CTLOC_GLCCC_DR long,CTLOC_Password string,CTLOC_WardFlag string,CTLOC_Address string,CTLOC_ActiveFlag string,CTLOC_Cashier_DR long,CTLOC_OTC_DR long,CTLOC_StartTime timestamp,CTLOC_EndTime timestamp,CTLOC_OwnQueFlag string,CTLOC_RecQueFlag string,CTLOC_Type string,CTLOC_DispLoc_DR long,CTLOC_Floor string,CTLOC_NFMI_DR string,CTLOC_Laundry string,CTLOC_Dep_DR long,CTLOC_DifferentSexPatients string,CTLOC_Index string,CTLOC_Hospital_DR long,CTLOC_ExecuteConfirmation string,CTLOC_DateActiveFrom date,CTLOC_DateActiveTo date,CTLOC_RehabilitativeFlag string,CTLOC_MedicalRecordActive string,CTLOC_DefaultMRType_DR long,CTLOC_ResultDelivery string,CTLOC_RespUnit_DR long,CTLOC_PatientAgeSexMix_DR long,CTLOC_IntendClinCareIntensity_DR long,CTLOC_BroadPatientGroup_DR long,CTLOC_WeeklyAvailIndicator string,CTLOC_OpenOvernightIndicator string,CTLOC_SignifFacility_DR long,CTLOC_NotUsed string,CTLOC_ExtGroup_DR long,CTLOC_ExternalInfoSystem string,CTLOC_Telephone string,CTLOC_TelephoneExt string,CTLOC_HL7OrdersLink string,CTLOC_ContactName string,CTLOC_FloorplanQuery string,CTLOC_VisitHrFrom timestamp,CTLOC_VisitHrTo timestamp,CTLOC_RestPeriodFrom timestamp,CTLOC_RestPeriodTo timestamp,CTLOC_AgeFrom double,CTLOC_AgeTo double,CTLOC_NationCode string,CTLOC_OrdersToRecLoc string,CTLOC_SendHL7MessageOn string,CTLOC_DepartmentHeadUserDR long,CTLOC_PagerNo string,CTLOC_Email string,CTLOC_Fax string,CTLOC_DaysAutoGenerate double,CTLOC_MRRequestMoveValid string,CTLOC_SNAPFlag string,CTLOC_MultDateRangesVisitHrs string,CTLOC_MentalHealthUnit string,CTLOC_PreferedOutlierWard long,CTLOC_WardSingleSex long,CTLOC_PrintLabelsUrgMRRequest string,CTLOC_EnableDischargeAllHyperlink string,CTLOC_InPatientUnit string,CTLOC_OutPatientUnit string,CTLOC_TimeSinceLastAppt double,CTLOC_Period string,CTLOC_DischSumNotRequired string,CTLOC_NatCodeDateFrom date,CTLOC_NatCodeDateTo date,CTLOC_SignFacilDateFrom date,CTLOC_SignifFacilDateTo date,CTLOC_DischargeLounge string,CTLOC_ExternalViewerLink string,CTLOC_DaysToKeepRecord double,CTLOC_NATAHeadings string,CTLOC_WeeksSuspensionReview double,CTLOC_DaysForOPDOffer double,CTLOC_DaysForOPLetterResponse double,CTLOC_OffersBeforeIP_OPWaitReset double,CTLOC_DaysOfferOutcomeChange double,CTLOC_RadOrdAccessNoPrefix string,CTLOC_DoNotDisplayRoomDescForBed string,CTLOC_EBookerID string,CTLOC_EBookingID string,CTLOC_EBookerEnabled string,CTLOC_EBookingEnabled string,CTLOC_EBookerIURPEnabled string,CTLOC_EBookerSuspDate date,CTLOC_EBookerSuspReas string,CTLOC_DischSumOPRequired string,CTLOC_DischSumIPRequired string,CTLOC_DischSumEDRequired string,CTLOC_IPDischSummaryType string,CTLOC_OPDischSummaryType string,CTLOC_EDDischSummaryType string,CTLOC_ChargeAccomPatientOnLeave string,CTLOC_CommunityUnit string,CTLOC_DaysClinSummaryOP double,CTLOC_DaysClinSummaryIP double,CTLOC_DaysClinSummaryED double,CTLOC_AdmQuest_DR long,CTLOC_IntQuest_DR long,CTLOC_DisQuest_DR long,CTLOC_DefAdmTimLoc timestamp,CTLOC_Zip_DR long,CTLOC_DoctorsReportsType string,CTLOC_QuickPrint string,CTLOC_DocCourier_DR long,CTLOC_DocCourierCopies decimal(15,0),CTLOC_LocCourier_DR long,CTLOC_LocCourierCopies decimal(15,0),CTLOC_ReferringDoctorCourier_DR long,CTLOC_ReferringDoctorCourierCopies decimal(15,0),CTLOC_ThirdPartyCourier_DR long,CTLOC_ThirdPartyCourierCopies decimal(15,0),CTLOC_DoctorsReportsDeliverySort string,CTLOC_CumulativePreference string,CTLOC_CumulativeOrder string,CTLOC_CumulativeEpisodes integer,CTLOC_Language_DR long,CTLOC_Owner string,CTLOC_CodeTableTags string,CTLOC_CounterType_DR long,CTLOC_StartTimeFB24 timestamp,CTLOC_LabDefaultReceiveDateTime string,CTLOC_TimeZone string,CTLOC_MandatoryBeforePack string,CTLOC_UpdPharmStatus string,CTLOC_MandatoryBeforeAdmin string,CTLOC_InclDisOrders string,CTLOC_EnabledPharmRev string,CTLOC_ShortLabSiteCode string,CTLOC_ChildHealthOrganisation_DR long,CTLOC_FlowsheetName string,CTLOC_ManualPrint string,CTLOC_DefaultRapidRequestForm_DR long,CTLOC_POEnabled string,CTLOC_StockEnabled string,CTLOC_ExternalInterfaceQueue_DR long,CTLOC_ReportMode string,CTLOC_ExclHospAverPriceQty string,CTLOC_StorageBinStatus string,CTLOC_CreatedDate date,CTLOC_CreatedTime timestamp,CTLOC_CreatedUser_DR long,CTLOC_UpdatedDate date,CTLOC_UpdatedTime timestamp,CTLOC_UpdatedUser_DR long,CTLOC_BedReasonNotAvail_DR long,CTLOC_DoNotSetBedUnavail string,CTLOC_HighDependencyUnit string,CTLOC_DefDischTimeLoc timestamp,CTLOC_LabAutoReceive string,CTLOC_DefaultCollectionCentre_DR long,CTLOC_CollectionCentreLicenseNumber string,CTLOC_PBSPharmacyApprovalNumber string,CTLOC_ConfidentialFax string,CTLOC_City_DR long,CTLOC_Province_DR long,CTLOC_Region_DR long,CTLOC_PrefConMethod string,CTLOC_JBGroup_DR long,CTLoc_BPDisposalAllow string,CTLOC_ResetPharmStatus string,CTLOC_LabReportPage_DR long,CTLOC_HealthCentre string,CTLOC_EnableEDStreaming string,CTLOC_EDStreamingMethod string,CTLOC_AllowLabBulkReceive string,CTLOC_PatientType_DR long,CTLOC_DefReqByType string,CTLOC_TelehealthAppointment string,CTLOC_VetSubjectApplicable string,CTLOC_EnvSubjectApplicable string,CTLOC_PharmRevSTATNotReq string,CTLOC_ExtAvailable_DR long,CTLOC_CodeTranslated string,CTLOC_DescTranslated string)','MergeC':'CTLOC_RowID','Source':'tc','Database':'trakcare','CDCFlag':'N'}"
    TableName4 = "{'TabName':'CT_Hospital','Value': 'bronze.tc_l_CT_Hospital (HOSP_RowId long,HOSP_Code string,HOSP_Desc string,HOSP_BillAddress string,HOSP_BillNo_DR long,HOSP_CreditNoteNo_DR long,HOSP_UseSameCounter string,HOSP_Trust_DR long,HOSP_NationalCode string,HOSP_WarnSameServiceWnXDays double,HOSP_DateFrom date,HOSP_DateTo date,HOSP_Phone string,HOSP_Fax string,HOSP_Email string,HOSP_MedicalDirector string,HOSP_ZipDR long,HOSP_State long,HOSP_Address string,HOSP_City long,HOSP_MandatoryRefHospital string,HOSP_Logo string,HOSP_HospDRGCateg_DR long,HOSP_SHowAppWTimeViolation string,HOSP_Province_DR long,HOSP_Email1 string,HOSP_Island string,HOSP_ApplyVCFees string,HOSP_BankAccount string,HOSP_Tariff_DR long,HOSP_MHACT_DR long,HOSP_FaxServerEmail string,HOSP_WeeksSuspensionReview double,HOSP_DaysForOPDOffer double,HOSP_DaysForOPLetterResponse double,HOSP_OffersBeforeIP_OPWaitReset double,HOSP_NewWays string,HOSP_DaysOfferOutcomeChange double,HOSP_FacilityType_DR long,HOSP_InsuranceType_DR long,HOSP_FacilityId string,HOSP_ClaimTypeCode string,HOSP_Owner string,HOSP_CodeTableTags string,HOSP_SubRegion_DR long,HOSP_Country_DR long,HOSP_CountyParish_DR long,HOSP_DebtorControl string,HOSP_BankAccount1 string,HOSP_UnallocPayment string,HOSP_AccrualsControl string,HOSP_POSessionCounter_DR long,HOSP_CreatedDate date,HOSP_CreatedTime timestamp,HOSP_CreatedUser_DR long,HOSP_UpdatedDate date,HOSP_UpdatedTime timestamp,HOSP_UpdatedUser_DR long,HOSP_PayorApprovalReq string,HOSP_TimeZone string,HOSP_PBSFacilityNumber string,HOSP_PBSDispensingRuleList string,HOSP_OrganizationID string,HOSP_CPGroupAffiliations string,HOSP_PostOffice_DR long,HOSP_ProcAnaestheticOrders string,HOSP_CareTypes string,HOSP_Region_DR long,HOSP_EpTypeMedDisBeforeFinDis string,HOSP_AssignedGroupCategory string,HOSP_ApplyDRGOutlierCalc string,HOSP_GuarantorGroup_DR long,HOSP_CodeTranslated string,HOSP_DescTranslated string)','MergeC':'HOSP_RowId','Source':'tc','Database':'trakcare','CDCFlag':'N'}"
    TableName5 = "{'TabName':'CT_RefClin','Value': 'bronze.tc_l_CT_RefClin (CTRFC_RowId long,CTRFC_Code string,CTRFC_Desc string,CTRFC_ActiveFlag string,CTRFC_VEMD string,CTRFC_DateFrom date,CTRFC_DateTo date,CTRFC_Owner string,CTRFC_CodeTableTags string,CTRFC_CreatedDate date,CTRFC_CreatedTime timestamp,CTRFC_CreatedUser_DR long,CTRFC_UpdatedDate date,CTRFC_UpdatedTime timestamp,CTRFC_UpdatedUser_DR long)','MergeC':'CTRFC_RowId','Source':'tc','Database':'trakcare','CDCFlag':'N'}"
    TableName6 = "{'TabName':'CT_ResponsibleUnit','Value': 'bronze.tc_l_CT_ResponsibleUnit (RU_RowId long,RU_Code string,RU_Desc string,RU_DateFrom date,RU_DateTo date,RU_FirstApptValidation string,RU_Owner string,RU_CodeTableTags string,RU_CreatedDate date,RU_CreatedTime timestamp,RU_CreatedUser_DR long,RU_UpdatedDate date,RU_UpdatedTime timestamp,RU_UpdatedUser_DR long)','MergeC':'RU_RowId','Source':'tc','Database':'trakcare','CDCFlag':'N'}"
    TableName7 = "{'TabName':'PAC_AdmSource','Value': 'bronze.tc_l_PAC_AdmSource (ADSOU_RowId long,ADSOU_Code string,ADSOU_Desc string,ADSOU_RcFlag string,ADSOU_DateFrom date,ADSOU_DateTo date,ADSOU_NationalCode string,ADSOU_EpisodeType string,ADSOU_ReasonForCritCareTransfer string,ADSOU_InpatAdmType string,ADSOU_TransferSource string,ADSOU_AdmReason string,ADSOU_CareType string,ADSOU_AgeFrom double,ADSOU_AgeTo double,ADSOU_IntentReadmit string,ADSOU_AgeType string,ADSOU_QualificationStatus string,ADSOU_Owner string,ADSOU_CodeTableTags string,ADSOU_CreatedDate date,ADSOU_CreatedTime timestamp,ADSOU_CreatedUser_DR long,ADSOU_UpdatedDate date,ADSOU_UpdatedTime timestamp,ADSOU_UpdatedUser_DR long)','MergeC':'ADSOU_RowId','Source':'tc','Database':'trakcare','CDCFlag':'N'}"
    TableName8 = "{'TabName':'PAC_ReferralReason','Value': 'bronze.tc_l_PAC_ReferralReason (REFREA_RowId long,REFREA_Code string,REFREA_Desc string,REFREA_DateFrom date,REFREA_DateTo date,REFREA_Owner string,REFREA_CodeTableTags string,REFREA_CreatedDate date,REFREA_CreatedTime timestamp,REFREA_CreatedUser_DR long,REFREA_UpdatedDate date,REFREA_UpdatedTime timestamp,REFREA_UpdatedUser_DR long)','MergeC':'REFREA_RowId','Source':'tc','Database':'trakcare','CDCFlag':'N'}"
    TableName9 = "{'TabName':'attendance_location_extension','Value': 'bronze.ref_l_attendance_location_extension (lAttendanceLocationId integer,ICU_Ward_Flag string,ED_Ward_Flag string,Admit_Ward_Flag string,Discharge_Ward_Flag string,ED_Ward_PCM_Flag string,Eligible_Ward_Flag string,Offsite_Ward_Flag string,NWB_Ward_Flag string,Triage_Ward_Flag string,Post_Triage_Ward_Flag string,Inpatient_Ward_Flag string,APU_Ward_Flag string,MH_Ward_Flag string,MH_Ward_Historic_Flag string,MH_MoHTeam_Code string,ED_6Hr_Rule_Ward_Flag string,WardCode string)','MergeC':'lAttendanceLocationId','Source':'ref','Database':'DA_REF','CDCFlag':'N'}"
    TableName10 = "{'TabName':'age_group','Value': 'bronze.ref_l_age_group (Age integer, AgeBand5yr string, AgeBand10yr string, AgeBand10yr2 string, AgeBand20yr string,AgeGroupMOH string,AgeGroupMOHDesc string,AgeGroupMOH2 string,AgeGroupMOH3 string,AgeGroupMH string,AgeGroupMHDesc string)','MergeC':'Age','Source':'ref','Database':'DA_REF','CDCFlag':'N'}"
    TableName11 = "{'TabName':'admittance_category','Value': 'bronze.ref_l_admittance_category (Admittance_Category_ID integer,Admittance_Category string)','MergeC':'Admittance_Category_ID','Source':'ref','Database':'DA_REF','CDCFlag':'N'}"
    TableName12 = "{'TabName':'cbu_link','Value': 'bronze.ref_l_cbu_link (CBU_Id integer,cbu_desc string,Short_desc string,cbu_code string,Sub_Specialty_Id integer,Disch_CBU_For_Revenue_Flag string,Permit_Readmit_Flag string,PCM_Priority integer,ED_Flag string)','MergeC':'CBU_Id','Source':'ref','Database':'DA_REF','CDCFlag':'N'}"
    TableName13 = "{'TabName':'ccl_pccl','Value': 'bronze.ref_l_ccl_pccl (CCLCode integer,CCLDescription string)','MergeC':'CCLCode','Source':'ref','Database':'DA_REF','CDCFlag':'N'}"
    TableName14 = "{'TabName':'health_services_group','Value': 'bronze.ref_l_health_services_group (Health_Services_Group_ID integer,Health_Services_Group_Code string,Health_Services_Group_Desc string,Health_Services_Group_Order integer,Operational_Functional_Group_ID integer,Health_Services_Group_IsDirectorateReportable string)','MergeC':'Health_Services_Group_ID','Source':'ref','Database':'DA_REF','CDCFlag':'N'}"
    TableName15 = "{'TabName':'pvs_admittance_type','Value': 'bronze.ref_l_pvs_admittance_type (Admittance_Type_ID integer,Admittance_Type string,Admittance_Category string,Admittance_Category_ID integer,Contract_Admittance_Type_ID integer)','MergeC':'Admittance_Type_ID','Source':'ref','Database':'DA_REF','CDCFlag':'N'}"
    TableName16 = "{'TabName':'service_mapping','Value': 'bronze.ref_l_service_mapping (DirectorateCode string,ServiceCode string,ServiceName string,CBUCode string,ClinicCode string,WardCode string)','MergeC':'Composite','Source':'ref','Database':'DA_REF','CDCFlag':'N'}"
    TableName17 = "{'TabName':'specialty','Value': 'bronze.ref_l_specialty (Specialty_ID integer,Specialty_Code string,Specialty_Desc string,Portfolio_ID integer)','MergeC':'Specialty_ID','Source':'ref','Database':'DA_REF','CDCFlag':'N'}"
    TableName18 = "{'TabName':'sub_specialty','Value': 'bronze.ref_l_sub_specialty (Sub_Specialty_Id integer,Sub_Specialty_Code integer,Sub_Specialty_Desc string,Specialty_ID integer,Medical_Surgical_Ind string,Health_Specialty_ID integer)','MergeC':'Sub_Specialty_Id','Source':'ref','Database':'DA_REF','CDCFlag':'N'}"
    TableName19 = "{'TabName':'wardmappinginterface','Value': 'bronze.ref_l_wardmappinginterface (WardID decimal(38,0),WardCode string,WardDesc string,ServiceCode string,DirectorateCode string,TrendcareCode decimal(38,0),TrendcareDesc string,DatixCode string,DatixDesc string,RCCode decimal(38,0),WFCWard string)','MergeC':'WardID','Source':'ref','Database':'DA_REF','CDCFlag':'N'}"
    TableName20 = "{'TabName':'PA_Person','Value': '','MergeC':'PAPER_RowId','Source':'tc','Database':'trakcare','CDCFlag':'Y'}"
    TableName21 = "{'TabName':'PA_PersonEthnicity','Value': '','MergeC':'Composite','Source':'tc','Database':'trakcare','CDCFlag':'N'}"
    TableName22 = "{'TabName':'CT_GenderIdentity','Value': '','MergeC':'GENID_RowId','Source':'tc','Database':'trakcare','CDCFlag':'Y'}"
    TableName23 = "{'TabName':'PA_Adm','Value': '','MergeC':'PAADM_RowID','Source':'tc','Database':'trakcare','CDCFlag':'Y'}"
    TableName24 = "{'TabName':'PAC_Ethnicity','Value': '','MergeC':'ETHNIC_RowId','Source':'tc','Database':'trakcare','CDCFlag':'Y'}"
    TableName25 = "{'TabName':'operational_functional_group','Value': '','MergeC':'Composite','Source':'ref','Database':'DA_REF'}"
    TableName26 = "{'TabName':'portfolio','Value': '','MergeC':'Composite','Source':'ref','Database':'DA_REF','CDCFlag':'N'}"
    TableName27 = "{'TabName':'reporting_top_tier','Value': '','MergeC':'Composite','Source':'ref','Database':'DA_REF','CDCFlag':'N'}"
    TableName28 = "{'TabName':'npf_attendanceoutcome','Value': '','MergeC':'Composite','Source':'ref','Database':'DA_REF','CDCFlag':'N'}"
    TableName29 = "{'TabName':'npf_attout','Value': '','MergeC':'Composite','Source':'ref','Database':'DA_REF','CDCFlag':'N'}"
    TableName30 = "{'TabName':'nnpac_health_specialty','Value': '','MergeC':'Composite','Source':'ref','Database':'DA_REF','CDCFlag':'N'}"
    TableName31 = "{'TabName':'CT_CareProv','Value': '','MergeC':'Composite','Source':'tc','Database':'trakcare','CDCFlag':'N'}"
    TableName32 = "{'TabName':'PAC_AlcoholOrDrugInvolvement','Value': '','MergeC':'ALCDRGIN_RowId','Source':'tc','Database':'trakcare','CDCFlag':'Y'}"
    TableName33 = "{'TabName':'PAC_CareType','Value': '','MergeC':'CARETYP_RowId','Source':'tc','Database':'trakcare','CDCFlag':'Y'}"
    TableName34 = "{'TabName':'PAC_Room','Value': '','MergeC':'ROOM_RowID','Source':'tc','Database':'trakcare','CDCFlag':'Y'}"
    TableName35 = "{'TabName':'PAC_Bed','Value': '','MergeC':'Composite','Source':'tc','Database':'trakcare','CDCFlag':'Y'}"
    TableName36 = "{'TabName':'PAC_SourceOfAttendance','Value': '','MergeC':'ATTEND_RowId','Source':'tc','Database':'trakcare','CDCFlag':'Y'}"
    TableName37 = "{'TabName':'PAC_EpisodeSubType','Value': '','MergeC':'SUBT_RowId','Source':'tc','Database':'trakcare','CDCFlag':'Y'}"
    TableName38 = "{'TabName':'PAC_BedStatus','Value': '','MergeC':'BSTAT_RowId','Source':'tc','Database':'trakcare','CDCFlag':'Y'}"
    TableName39 = "{'TabName':'PA_WaitingList','Value': '','MergeC':'WL_RowId','Source':'tc','Database':'trakcare','CDCFlag':'Y'}"


    json_list = []
    json_list.append(TableName1)
    json_list.append(TableName2)
    json_list.append(TableName3)
    json_list.append(TableName4)
    json_list.append(TableName5)
    json_list.append(TableName6)
    json_list.append(TableName7)
    json_list.append(TableName8)
    json_list.append(TableName9)
    json_list.append(TableName10)
    json_list.append(TableName11)
    json_list.append(TableName12)
    json_list.append(TableName13)
    json_list.append(TableName14)
    json_list.append(TableName15)
    json_list.append(TableName16)
    json_list.append(TableName17)
    json_list.append(TableName18)
    json_list.append(TableName19)
    json_list.append(TableName20)
    json_list.append(TableName21)
    json_list.append(TableName22)
    json_list.append(TableName23)
    json_list.append(TableName24)
    json_list.append(TableName25)
    json_list.append(TableName26)
    json_list.append(TableName27)
    json_list.append(TableName28)
    json_list.append(TableName29)
    json_list.append(TableName30)
    json_list.append(TableName31)
    json_list.append(TableName32)
    json_list.append(TableName33)
    json_list.append(TableName34)
    json_list.append(TableName35)
    json_list.append(TableName36)
    json_list.append(TableName37)
    json_list.append(TableName38)
    json_list.append(TableName39)
    
    
    

    df = spark.read.json(sc.parallelize(json_list))
    df2 = df.select("TabName", "Value", "MergeC","Source","Database",'CDCFlag').filter(f"TabName=='{tableName}'")
    return df2

