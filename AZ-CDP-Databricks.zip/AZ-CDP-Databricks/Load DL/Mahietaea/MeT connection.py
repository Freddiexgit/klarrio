# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 23-Nov-2023 | 1       | Gery Smith     | Created - Authentication established                                                                   |
# MAGIC |                                                                                                                     |

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### Basic Logic
# MAGIC
# MAGIC 1. done - Get a token 
# MAGIC 2. done - Get endpoints from Control tbl
# MAGIC 3. done - process a request
# MAGIC 4. done - save response as a file in ADLS
# MAGIC ---
# MAGIC to be done
# MAGIC - log fileinfo in the LogFileOperations table
# MAGIC - create a batch
# MAGIC - update a batch
# MAGIC

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

import requests
import http
import json

# COMMAND ----------

# Authentication
auth_data = dbutils.secrets.get(scope = 'AzureSecretScope', key = 'MahieTaeaLoginBody')
appkey = dbutils.secrets.get(scope = 'AzureSecretScope', key = 'MahieTaeaAppKey')

headers = {
        "appkey" :f"{appkey}",
        "Content-Type": "application/x-www-form-urlencoded"
    }
base_url = 'https://northerndhbs-trn.npr.mykronos.com/api/'
url = base_url + 'authentication/access_token'
resp = requests.post(url, data=auth_data, headers=headers).json()
tkn = resp['access_token']
tkn

# COMMAND ----------

# POST request
payload = {
    "multiReadOptions":{
        "includeOrgPathDetails":True
    },
    "where": {
        "descendantsOf" : {
            "context": "ORG",
            "date": "2023-08-31",
            "locationRef":{
                "qualifier":"H/ADHB"
            }
        }
    }
}

headers = {
   "appkey":f"{appkey}",
   "Content-Type":"application/json",
   "Authorization":f"{tkn}"
}

url = f'{base_url}'+'v1/commons/locations/multi_read'
print(url)

# The code below works with json=payload, but it is not working with data=payload
resp = requests.post(url, json = payload, headers = headers)

if resp.status_code == 200:
    jsondata = resp.json()
    jsondata

# COMMAND ----------

# Create variable from etl.Control table
# WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
qry = f"""
       SELECT 
              ETLControlID
            , SourceSystem
            , SourceSystemType
            , SourceTableSchemaName
            , SourceTableName
            , CASE WHEN IncrementalLoad = 1 THEN WaterMarkValue ELSE '1900-01-01' END WaterMarkValue
            , TargetSystemType
            , TargetTableSchemaName
            , TargetTableName
            , IncrementalLoad
            , IsActive
            , TargetEntityPath
            , CustomConfig
        FROM ADM_CONFIG.etl.Control 
        WHERE SourceSystem = 'mahietaea'
        AND SourceSystemType = 'API'
        AND targettablename = 'locationsmultireadapi'
"""
# ETLControlID = {v_etlcontrolid}
df_control = read_from_mi_db('ADM_CONFIG', qry)

v_watermark_date = df_control.select("WaterMarkValue").collect()[0][0]
v_target_table_name = df_control.select("TargetTableName").collect()[0][0]
v_target_database = df_control.select("CustomConfig").collect()[0][0]
# don't use the sourcesystem from the query as it is lower case and will create a new folder for mahieatea
v_sourcesystem = 'MahieTaea'
v_target_entity_path = df_control.select("TargetEntityPath").collect()[0][0]

# COMMAND ----------

print('v_watermark_date:\t', v_watermark_date)
print('v_target_table_name:\t', v_target_table_name)
print('v_target_database:\t', v_target_database)
print('v_sourcesystem:\t\t', v_sourcesystem)
print('v_target_entity_path:\t', v_target_entity_path)
# print('v_new_watermark_value:\t', v_new_watermark_value)

# COMMAND ----------

from datetime import datetime, timedelta
import pytz
tz_info = pytz.timezone('Pacific/Auckland')
cur_date_path = datetime.now(tz=tz_info).strftime('%Y/%m/%d')
print(cur_date_path)
cur_datetime = datetime.now(tz=tz_info).strftime('%Y%m%d%H%M%S')
print(cur_datetime)
file_name = f"{v_sourcesystem}_{v_target_table_name}_{cur_datetime}_1.csv"
print(file_name)

# COMMAND ----------

save_path = bronze_folder_path + f"{v_sourcesystem}/{v_target_table_name}/{cur_date_path}/{file_name}"
print(save_path)
dbutils.fs.put(save_path,json.dumps(jsondata),True)
