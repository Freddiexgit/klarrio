# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 23-Nov-2023 | 1       | Gery Smith     | Created - Authentication established                                                                   |
# MAGIC |                                                                                                                     |

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### Basic Logic
# MAGIC
# MAGIC 1. done - Get a token 
# MAGIC 2. done - Get endpoints from Control tbl
# MAGIC 3. done - process a request
# MAGIC 4. done - save response as a file in ADLS
# MAGIC ---
# MAGIC to be done
# MAGIC - log fileinfo in the LogFileOperations table
# MAGIC - create a batch
# MAGIC - update a batch
# MAGIC

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# Create variable from etl.Control table
# WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
qry = f"""
       SELECT 
              ETLControlID
            , SourceSystem
            , SourceSystemType
            , SourceTableSchemaName
            , SourceTableName
            , SourceQuery
            , replace(SourceQuery, 'REPLACE_WITH_DATE_RANGE', WaterMarkValue) Payload
            , WaterMarkQuery
            , WaterMarkValue
       --     , CASE WHEN IncrementalLoad = 1 THEN WaterMarkValue ELSE '1900-01-01' END WaterMarkValue
            , TargetSystemType
            , TargetTableSchemaName
            , TargetTableName
            , IncrementalLoad
            , IsActive
            , TargetEntityPath
            , CustomConfig
        FROM ADM_CONFIG.etl.Control 
        WHERE SourceSystem = 'mahietaea_genmed'
        AND SourceSystemType = 'API'
        AND ETLControlID = 2020
"""
# ETLControlID = {v_etlcontrolid}
df_control = read_from_mi_db('ADM_CONFIG', qry)

v_watermark_date = df_control.select("WaterMarkValue").collect()[0][0]
v_target_table_name = df_control.select("TargetTableName").collect()[0][0]
v_target_database = df_control.select("CustomConfig").collect()[0][0]
# don't use the sourcesystem from the query as it is lower case and will create a new folder for mahieatea
v_sourcesystem = df_control.select("SourceSystem").collect()[0][0]
v_target_entity_path = df_control.select("TargetEntityPath").collect()[0][0]
v_payload = df_control.select("Payload").collect()[0][0]
v_source_query = df_control.select("SourceQuery").collect()[0][0]

# COMMAND ----------

print('v_watermark_date:\t', v_watermark_date)
print('v_target_table_name:\t', v_target_table_name)
print('v_target_database:\t', v_target_database)
print('v_sourcesystem:\t\t', v_sourcesystem)
print('v_target_entity_path:\t', v_target_entity_path)
# print('v_new_watermark_value:\t', v_new_watermark_value)
print('v_payload:\t', v_payload)
print('v_source_query:\t', v_source_query)

# COMMAND ----------

type(v_payload)

# COMMAND ----------

import requests
import http
import json

# COMMAND ----------

# v_payload = '''{
#     "multiReadOptions": {
#         "excludeOvernightShiftsOnStartDate": true
#     },
#     "select": [
#         "SCHEDULETAGS"
#     ],
#     "where": {
#         "hyperFind": {
#             "startDate" : "2023-12-13", "endDate":"2023-12-13",
#             "hyperFind": {
#                 "qualifier": "ADHB-ALL"
#             }
#         },
#         "excludeBreaks": "false"
#     }
# }'''

# COMMAND ----------



# COMMAND ----------

# Authentication
auth_data = dbutils.secrets.get(scope = 'AzureSecretScope', key = 'MahieTaeaLoginBody')
appkey = dbutils.secrets.get(scope = 'AzureSecretScope', key = 'MahieTaeaAppKey')

headers = {
        "appkey" :f"{appkey}",
        "Content-Type": "application/x-www-form-urlencoded"
    }
base_url = 'https://northerndhbs-trn.npr.mykronos.com/api/'
url = base_url + 'authentication/access_token'
resp = requests.post(url, data=auth_data, headers=headers).json()
tkn = resp['access_token']
tkn

# COMMAND ----------

# POST request
# payload = {}

headers = {
   "appkey":f"{appkey}",
   "Content-Type":"application/json",
   "Authorization":f"{tkn}"
}

url = f'{base_url}'+'v1/scheduling/schedule/multi_read'
print(url)

# The code below works with json=payload, but it is not working with data=payload
# if the payload is in json (not string), then use json =
# if the payload is a string then use data =

# resp = requests.post(url, json = v_payload.json(), headers = headers)
# resp = requests.post(url, data = v_payload, headers = headers)
resp = requests.post(url, json = json.loads(v_payload), headers = headers)
print(resp.status_code)

if resp.status_code == 200:
    jsondata = resp.json()
    jsondata

# COMMAND ----------

jsondata

# COMMAND ----------

pd.set_option('display.max_colwidth',None)
pd.set_option('display.max_rows', 10)

# COMMAND ----------

pd_df_shifts = pd.json_normalize(jsondata, record_path = ['shifts'])
pd_df_shifts

# COMMAND ----------

pd_df_shift = pd.json_normalize(jsondata, record_path =['shifts', 'segments'],
                                meta=[['shifts','employee','qualifier'],
                                      ['shifts','id']])[['shifts.employee.qualifier','shifts.id','id', 'startDateTime', 'endDateTime', 'transferLaborCategories',
       'userEnteredOrgJob', 'transferOrgJob', 'userEnteredCostCenter',
       'transferCostCenter', 'userEnteredWorkrule', 'transferWorkrule',
       'skillCertProfileRefs', 'type', 'segmentTypeRef.id',
       'segmentTypeRef.qualifier', 'orgJobRef.id', 'orgJobRef.qualifier',
       'primaryOrgJobRef.id', 'primaryOrgJobRef.qualifier',
       'costCenter.referenceId', 'costCenter.costCenter.id',
       'costCenter.costCenter.qualifier', 'primaryCostCenter.referenceId',
       'primaryCostCenter.costCenter.id',
       'primaryCostCenter.costCenter.qualifier', 'workruleRef.id',
       'workruleRef.qualifier', 'primaryWorkruleRef.id',
       'primaryWorkruleRef.qualifier', 'transferString', 'segmentTags']]
pd_df_shift

# COMMAND ----------

import pandas as pd

# COMMAND ----------

pd_df_schedules = pd.json_normalize(jsondata, record_path = ['scheduleTags','segments']
                  ,meta=[['scheduleTags','id'],['scheduleTags','startDateTime'],['scheduleTags','endDateTime'],['scheduleTags','employee','qualifier']])[['scheduleTags.id','scheduleTagColor','tagDefinitionRef.qualifier','scheduleTags.startDateTime', 'scheduleTags.endDateTime', 'scheduleTags.employee.qualifier','orgJobRef.qualifier']]
pd_df_schedules

# COMMAND ----------

pd_df_schedules.columns = ['scheduleTagId', 'scheduleTagColor','scheduleTagName', 'startDateTime', 'endDateTime', 'employeeid','orgJobPath']
pd_df_schedules

# COMMAND ----------

sp_df = spark.createDataFrame(pd_df)

# COMMAND ----------

jsn = sp_df.toJSON()
jsn

# COMMAND ----------

from datetime import datetime, timedelta
import pytz
tz_info = pytz.timezone('Pacific/Auckland')
cur_date_path = datetime.now(tz=tz_info).strftime('%Y/%m/%d')
print(cur_date_path)
cur_datetime = datetime.now(tz=tz_info).strftime('%Y%m%d_%H%M%S')
print(cur_datetime)
file_name = f"{v_sourcesystem}_{v_target_table_name}_{cur_datetime}.json"
print(file_name)

# COMMAND ----------

save_path = landing_folder_path + f"{v_sourcesystem}/{v_target_table_name}/{cur_date_path}/{file_name}"
print(save_path)
dbutils.fs.put(save_path,json.dumps(jsondata),True)

# COMMAND ----------

type(jsondata.toJSON())

# COMMAND ----------

SourceDirectory =f"{landing_folder_path}mahietaea_genmed/shift/"
p_TableName = f"met_genmed_shift"
checkpointpath = f"{bronze_folder_path}mahietaea_genmed/checkpoint/{p_TableName}/"
target_path = f"{bronze_folder_path}mahietaea_genmed"
# merge_condition = "ActivityEvents.Id = updates.Id"

# COMMAND ----------

print('SourceDirectory:\t', SourceDirectory)
print('p_TableName:\t\t', p_TableName)
print('checkpointpath:\t\t', checkpointpath)
print('target_path:\t\t',target_path)

# COMMAND ----------

spark.sql(f"""
          DROP TABLE bronze.{p_TableName} -- Location '{target_path}/{p_TableName}'
          """)

# COMMAND ----------

# from pyspark.sql import functions as fn
# import json

# COMMAND ----------

# SelectExpr
spark.sql(f"""
          DROP TABLE IF EXISTS bronze.{p_TableName} -- Location '{target_path}/{p_TableName}'
          """)
if not spark.catalog.tableExists(f"bronze.{p_TableName}"):
    print('New Load Table')
    spark.sql(f"CREATE table if not exists bronze.{p_TableName} Location '{target_path}/{p_TableName}'")    
    df_data = (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "json")
        .option("cloudFiles.schemaLocation", checkpointpath)        
        .option("cloudFiles.inferColumnTypes", "true")
        .option("cloudFiles.schemaEvolutionMode", "rescue")
        .option("multiline", "true")
        .load(SourceDirectory)
        # .filter("scheduleTags IS NOT NULL")
        .drop("leaveEdits","availabilities","holidays","dayLocks","employees","openShifts","scheduleDayList","expandedJobs")
        #.drop("Datasets")
        # the select below converted every column in a list
        .selectExpr(
            "scheduleTags.id::int as schedule_tag_id",
            "scheduleTags.employee.qualifier::string as employee_id",
            "scheduleTags.startDateTime::timestamp as tag_startdatetime",
            "scheduleTags.endDateTime::timestamp as tag_enddatetime",
            input_file_name().alias("source_file"),
            current_timestamp().alias("processing_time"),
        )
        # .dropDuplicates(["id"])
        .writeStream.format("delta")
        .option("mergeSchema", "true")
        .option("checkpointLocation", checkpointpath)
        .trigger(once=True)
        .start(f"{target_path}/{p_TableName}")
    )
    df_data.awaitTermination()
    #spark.sql(f"CREATE OR REPLACE Table bronze.temp_{p_TableName} AS SELECT * FROM bronze.{p_TableName}")
    print('the end')
else: 
    print('Table exists.')

# COMMAND ----------

# Select
spark.sql(f"""
          DROP TABLE IF EXISTS bronze.{p_TableName} -- Location '{target_path}/{p_TableName}'
          """)
print(f"bronze.{p_TableName} dropped")
if not spark.catalog.tableExists(f"bronze.{p_TableName}"):
    spark.sql(f"CREATE table if not exists bronze.{p_TableName} Location '{target_path}/{p_TableName}'")    
    print(f'bronze.{p_TableName} created pointing to {target_path}/{p_TableName}')
    df_data = (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "json")
        .option("cloudFiles.schemaLocation", checkpointpath)        
        .option("cloudFiles.inferColumnTypes", "true")
        .option("cloudFiles.schemaEvolutionMode", "rescue")
        .option("multiline", "true")
        .load(SourceDirectory)
        # .filter("scheduleTags IS NOT NULL")
        .drop("leaveEdits","availabilities","holidays","dayLocks","employees","openShifts","scheduleDayList","expandedJobs",)
        #.drop("Datasets")
        # the select below converted every column in a list
        .select(
            "scheduleTags.id",
            "scheduleTags.employee.qualifier",
            "scheduleTags.startDateTime",
            "scheduleTags.endDateTime",
            "scheduleTags.segments.tagDefinitionRef.qualifier",
            input_file_name().alias("source_file"),
            current_timestamp().alias("processing_time"),
        )
        # .dropDuplicates(["id"])
        .writeStream.format("delta")
        .option("mergeSchema", "true")
        .option("checkpointLocation", checkpointpath)
        .trigger(once=True)
        .start(f"{target_path}/{p_TableName}")
    )
    df_data.awaitTermination()
    #spark.sql(f"SELECT * FROM bronze.{p_TableName}")
    print(f"{target_path}/{p_TableName}")
else: 
    print('Table exists.')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from  bronze.met_genmed_shift

# COMMAND ----------

import pandas as pd


# COMMAND ----------

df_schedule_tags = (spark.sql("select * from bronze.met_genmed_shift")).toPandas()
import json
df2 = df_schedule_tags.explode(['id','qualifier', 'startDateTime','endDateTime','tagDefinitionRef'])
df2[['id','tagDefinitionRef','scheduleTag']]


# COMMAND ----------

# df2 = df2.assign(scheduleTag=None)
df2['tagDefinitionRef']

# COMMAND ----------

type(df_schedule_tags)

# COMMAND ----------

jsondata.keys()

# COMMAND ----------

jsondata['shifts'][1]['id']  

# COMMAND ----------

pd.json_normalize(jsondata, record_path = ['shifts'] )[['id','startDateTime','endDateTime','label','employee.qualifier']].query("label == 'GM SMO Black W67 T1 8Dt'")

# COMMAND ----------

import pandas as pd
import json

# COMMAND ----------

jsn = jsondata.toJSON()

# COMMAND ----------

type(jsn)

# COMMAND ----------

pd.json_normalize(jsondata, record_path = ['scheduleTags'])

# COMMAND ----------

pd.json_normalize(jsondata, record_path = ['scheduleTags'] )[['employee.qualifier','id', 'startDateTime','endDateTime','segments']]

# COMMAND ----------



# COMMAND ----------

import pandas as pd
df1 = pd.json_normalize(jsn)
df1

# COMMAND ----------

import pandas as pd
df1 = pd.json_normalize(jsondata, record_path = ['scheduleTags'] )[['employee.qualifier','id', 'startDateTime','endDateTime','segments']]
# Or rename the existing DataFrame (rather than creating a copy) 
df1.rename(columns={'employee.qualifier': 'employee_id'}, inplace=True)
# df1 = pd.json_normalize(jsondata, record_path = ['scheduleTags'] )[['employee.qualifier','id', 'startDateTime','endDateTime','segments']].query("employee.qualifier == '03013234-06'")
# df2 = df1[(df1.id == 71878856)]
df2 = df1.assign(scheduleTag=None, scheduleTagColor=None)
len(df2)
df2

# COMMAND ----------

df2[df2['employee_id']=='03013234-06']

# COMMAND ----------

df2['segments']

# COMMAND ----------

df2[df2['employee_id'] == '03013234-06']['scheduleTag']

# COMMAND ----------

# index is a MUST with the iterrows()
for index, row in df2.iterrows():
    print(index, '\t' ,row['id']) #, '\n', row['segments']['tagDefinitionRef']['qualifier'])
    for segment in row['segments']:
        print(segment['tagDefinitionRef']['qualifier'])

        # MUST use .loc this way, otherwise you will get a warning
        # NOTICE, that the column you are UPDATING is after the , in the .loc
        df2.loc[df2['id'] == row['id'],'scheduleTag'] = segment['tagDefinitionRef']['qualifier']
        df2.loc[df2['id'] == row['id'],'scheduleTagColor'] = segment['scheduleTagColor']
        
        print(df2.loc[[index],['employee_id', 'id','scheduleTag']])

# COMMAND ----------

df2

# COMMAND ----------

for index, row in df2.iterrows():
    print(index, '\t' ,row['employee_id']) #, '\n', row['segments'])
    for segment in row['segments']:
        print(segment['tagDefinitionRef']['qualifier'])
        for el in segment['tagDefinitionRef']:
            print(type(el), '\t', el)
            if isinstance(el, dict):
                print(el.keys())
                for key in el.keys():
                    if key == 'tagDefinitionRef':
                        if isinstance(el[key], dict):
                            for key2 in el[key]:
                                if key2 == 'qualifier':
                                    print(key2, ' ', el[key][key2])
                                    df2['scheduleTag'].loc[df['employee_id'] == row['employee_id']] = el[key][key2]

# COMMAND ----------

df2

# COMMAND ----------

segments = []
for segment in df2.segments:
    print(f'\n{segment}')

# COMMAND ----------

df1 = pd.json_normalize(jsondata, record_path = ['scheduleTags'] )[['employee.qualifier','id', 'startDateTime','endDateTime','segments']]
# .query("employee.qualifier == '03013234-06'")
df1

# COMMAND ----------

df1.explode('segments')

# COMMAND ----------

pd.json_normalize(jsondata, record_path = ['scheduleTags','segments'])

# COMMAND ----------

pd.json_normalize(jsondata, record_path = ['shifts'])['label'].unique()

# COMMAND ----------

import pandas as pd
# pd.json_normalize(jsondata, record_path = ['shifts'])
pd.json_normalize(jsondata, record_path = ['shifts','segments'])
# .query('id = 68555792')

# COMMAND ----------

# df = spark.read.parquet(f"{silver_folder_path}{trakcare_export_parquet}{v_target_table_name}")
# display(df.count())

# COMMAND ----------

df = spark.read.json('/mnt/devcdpadlsae1/landing/mahietaea_genmed/shift/2023/11/29/mahietaea_genmed_shift_20231129_205113.json')

# COMMAND ----------



# COMMAND ----------

df.printSchema

# COMMAND ----------


