# Databricks notebook source
source_directory:	 /mnt/devcdpadlsae1/landing/mahietaea_genmed/shift/
p_tablename:		 met_gm_shift
checkpointpath:		 /mnt/devcdpadlsae1/bronze/mahietaea_genmed/checkpoint/met_gm_shift/
target_path:		 /mnt/devcdpadlsae1/bronze/mahietaea_genmed
merge_condition:	 source.shiftId = updates.shiftId

# COMMAND ----------

spark.sql(f"CREATE table if not exists bronze.shift_txt Location '{bronze_write_path}'")   
%sql desc bronze.shift_txt

# COMMAND ----------

	
df = spark.read.format("delta").load('/mnt/devcdpadlsae1/bronze/mahietaea_genmed/shift_txt').show()

# COMMAND ----------

df_shifts =spark.sql("select value from bronze.shift_txt where  len(value) < 10000")
display(df_shifts)

# COMMAND ----------

# MAGIC %sql desc bronze.shift_txt

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import col

raw_files =              "/mnt/devcdpadlsae1/landing/mahietaea_genmed/shift/2024/01/05/"
bronze_checkpoint_path = "/mnt/devcdpadlsae1/bronze/mahietaea_genmed/checkpoint/shift_txt/"
bronze_write_path = "/mnt/devcdpadlsae1/bronze/mahietaea_genmed/shift_txt"


#Start autoloader to read the files and add two columns, one for the JSON payload and a timestamp column
idf = spark.readStream.format("cloudFiles")\
    .option("cloudFiles.format", "text")\
    .option("mergeSchema", "true")\
    .load(raw_files)\
    .withColumn("value", col("value")).withColumn("time_stamp", F.current_timestamp())\
    .writeStream\
    .format("delta")\
    .option("checkpointLocation", bronze_checkpoint_path)\
    .start(bronze_write_path)

# COMMAND ----------

idf = spark.readStream.format("cloudFiles")\
    .option("cloudFiles.format", "text")\
    .option("mergeSchema", "true")\
    .load(raw_files)\
    .withColumn("value", col("value")).withColumn("time_stamp", F.current_timestamp())

# COMMAND ----------

display(idf)

# COMMAND ----------

odf = idf.writeStream.format("delta")\
.option("checkpointLocation", bronze_checkpoint_path)\
.outputMode("append")\
.trigger(once=True)\
.start(bronze_write_path)
display(odf)

# COMMAND ----------

# MAGIC %sql 
# MAGIC select * from JSON_PARSE.shift_txt where len(value)<10000

# COMMAND ----------

# MAGIC %sql
# MAGIC insert i

# COMMAND ----------

# MAGIC %sql 
# MAGIC select value.shifts.id from JSON_PARSE.shift_txt where len(value)<10000 
# MAGIC

# COMMAND ----------

import json
import pandas
df_shifts.describe()

# COMMAND ----------

print(type(df_shifts.select(df_shifts['value'])))

# COMMAND ----------

pd_df_shifts = pd.json_normalize(jsondata, record_path = ['shifts','segments']
                  ,meta=[['shifts','id'],['shifts','startDateTime'],['shifts','endDateTime'],['shifts','label'],['shifts','employee','qualifier']]
                  ,errors='ignore')[['shifts.id','shifts.startDateTime', 'shifts.endDateTime', 'shifts.employee.qualifier','orgJobRef.qualifier','shifts.label','segmentTypeRef.qualifier','transferOrgJob','primaryOrgJobRef.qualifier']]
pd_df_shifts.columns = ['shiftId','shiftStartDateTime','shiftEndDateTime','employeeId','orgJobPath','shiftLabel','shiftSegmentType','transferOrgJob','primaryOrgJobPath']
pd_df_shifts.head(5)

# COMMAND ----------

df_file = spark.read.text('/mnt/devcdpadlsae1/landing/mahietaea_genmed/shift/2024/01/05/*.json')
df_file.printSchema()

# COMMAND ----------

df_json = spark.read.option("multiline","true").json('/mnt/devcdpadlsae1/landing/mahietaea_genmed/shift/2024/01/05/*.json')
df_json.printSchema()

# COMMAND ----------

'orgJobRef.qualifier','shifts.label','segmentTypeRef.qualifier','transferOrgJob','primaryOrgJobRef.qualifier'

# COMMAND ----------

df_shiftid = df_json.select(["shifts.id"])

# COMMAND ----------

from pyspark.sql.functions import col, concat, lit
df_shiftid = df_json.select(col("shifts.id").alias("shift_id"),\
    col("shifts.startDateTime").alias("shiftStartDateTime"),\
    col("shifts.endDateTime").alias("shiftEndDateTime"),\
    col("shifts.employee.qualifier").alias("employee_id"),\
    col('shifts.label').alias("shift_label"),\
    col('shifts.segments.segmentTypeRef.qualifier').alias("shiftSegmentType"),\
    col('shifts.segments.transferOrgJob').alias("transferOrgJob"),\
    col('shifts.segments.orgJobRef.qualifier').alias("orgJobPath"),\
    col('shifts.segments.primaryOrgJobRef.qualifier').alias("primaryOrgJobPath")\
    )
# df_shiftid.withColumnRenamed("id","shift_id")
df_shiftid.display()

# COMMAND ----------

explode(df_shiftid.id)

# COMMAND ----------

display(df_shiftid.select([explode_outer(df_shiftid.id),explode_outer(df_shiftid.startDateTime) ]
                          ))

# COMMAND ----------

# MAGIC %md
# MAGIC ###PySpark: Dataframe Multiple Explode
# MAGIC Source: https://dbmstutorials.com/pyspark/spark-dataframe-multiple-explode.html
# MAGIC
# MAGIC Main Takeaway: Pyspark does not allow 2 or more explode to be present in a single select statement.
# MAGIC
# MAGIC Explode function can be used to flatten array in a column in Pyspark in conjunction with **arrays_zip** function (Preferred way)

# COMMAND ----------

from pyspark.sql.functions import arrays_zip, explode

# arrays_zip("id","startDateTime","endDateTime", "qualifier","label")  concatanates all columns specified in 1 column called "col"
exp_step1_df = df_shiftid.select(explode(arrays_zip("shift_id","shiftStartDateTime","shiftEndDateTime", "employee_id","shift_label","shiftSegmentType","transferOrgJob","primaryOrgJobPath")))

exp_step1_df.display()

# COMMAND ----------

exp_step2_df = exp_step1_df.select("col.shift_id","col.shiftStartDateTime","col.shiftEndDateTime","col.employee_id","col.shift_label","col.shiftSegmentType", "col.transferOrgJob","col.primaryOrgJobPath")

display(exp_step2_df)

# COMMAND ----------

display(exp_step2_df.select("*").where("transferOrgJob[0]=='true'"))

# COMMAND ----------

exp_step3_df = exp_step2_df.select("shift_id","shiftStartDateTime","shiftEndDateTime", "employee_id","shift_label",explode(arrays_zip("shiftSegmentType","transferOrgJob","primaryOrgJobPath")))

# COMMAND ----------

display(exp_step3_df)

# COMMAND ----------

exp_step4_df = exp_step3_df.select("shift_id","shiftStartDateTime","shiftEndDateTime", "employee_id","shift_label","col.shiftSegmentType", "col.transferOrgJob", "col.primaryOrgJobPath")
display(exp_step4_df)

# COMMAND ----------

df_json2 = df = spark.read.load(
    '/mnt/devcdpadlsae1/landing/mahietaea_genmed/shift/2024/01/05/*.json', 
    format='json',
    multiLine=True, 
    schema=None)

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

display(df_json2.select(df_json2['shifts'][0]))

# COMMAND ----------



# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType
schema = StructType([
    StructField("")
])
