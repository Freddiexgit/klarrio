# Databricks notebook source
import requests
import json
from datetime import datetime
import pytz

##############################
# Set widget and default value for this.
dbutils.widgets.text("mount_point", "/mnt/devcdpadlsae1/")
##############################

##############################
# Global variables. Define variables used across this notebook

# Set local date Pacific/Auckland for ADLS folder path settings
tz_info = pytz.timezone('Pacific/Auckland')
cur_date_path = datetime.now(tz=tz_info).strftime('%Y/%m/%d')
cur_file_time = datetime.now(tz=tz_info).strftime('%H%M')
graph_folder_path = dbutils.widgets.get("mount_point") + "landing/Auditing/MSGraph/{folder}/" + cur_date_path + "/{file}"
pbi_folder_path = dbutils.widgets.get("mount_point") + "landing/Auditing/MSPowerBI/{folder}/" + cur_date_path + "/{file}"

tenant_id = "494a2d87-24b5-42d8-8a3d-77448be1d46f"

# Power BI API Endpoint URLs:
pbi_workspaces_url = "https://api.powerbi.com/v1.0/myorg/groups"
pbi_wsUsers_url = "https://api.powerbi.com/v1.0/myorg/groups/{workspaceID}/users"
pbi_wsDatasets_url = "https://api.powerbi.com/v1.0/myorg/groups/{workspaceID}/datasets"
pbi_wsReports_url = "https://api.powerbi.com/v1.0/myorg/groups/{workspaceID}/reports"

pbi_dsUsers_url = "https://api.powerbi.com/v1.0/myorg/groups/{workspaceID}/datasets/{datasetId}/users"
pbi_dsDatasources_url = "https://api.powerbi.com/v1.0/myorg/groups/{workspaceID}/datasets/{datasetId}/datasources"
pbi_dsRefreshes_url = "https://api.powerbi.com/v1.0/myorg/groups/{workspaceID}/datasets/{datasetId}/refreshes"
pbi_dsSchedule_url = "https://api.powerbi.com/v1.0/myorg/groups/{workspaceID}/datasets/{datasetId}/refreshSchedule"

pbi_rpUsers_url = "https://api.powerbi.com/v1.0/myorg/admin/reports/{reportId}/users"

pbi_apps_url = "https://api.powerbi.com/v1.0/myorg/admin/apps?$top=5000"
pbi_appUsers_url = "https://api.powerbi.com/v1.0/myorg/admin/apps/{app}/users"

# COMMAND ----------

###################################
# Define functions used in notebook
###################################

def authServicePrincipal(tenant_id, api):
    # Headers passed to API
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer ",
        "ConsistencyLevel": "eventual"
    }
    if api == "graph":
        scope = "&scope=https://graph.microsoft.com/.default"
    elif api == "pbi":
        scope = "&scope=https://analysis.windows.net/powerbi/api/.default"
    
    url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
    auth_data = dbutils.secrets.get(scope = 'AzureSecretScope', key = 'AutomationServicePrincipal') + scope + "&grant_type=client_credentials"
    response = requests.post(url, data = auth_data)
    response_json = response.json()
    access_token = response_json["access_token"]
    headers["Authorization"] += access_token
    return headers

def getResponse(url, headers):
    response = requests.get(url, headers=headers)
    return response.json()

def writeToADLS(folder_path,folder,file_name,data):
    save_path = folder_path.replace("{folder}",folder).replace("{file}",file_name)
    dbutils.fs.put(save_path,data,True)


# COMMAND ----------

#######################################
# Define function to call Power BI APIs
#######################################

def getPBIObjects(end_point, url, headers):
    final_data = []
    response = getResponse(url,headers)
    final_data = response["value"]
    return final_data

def getWorkspaceObjects(end_point, url, headers, workspace_data):
    final_data = []
    for workspace in workspace_data:
        target_url = url.replace("{workspaceID}",workspace["id"])
        response = getResponse(target_url,headers)
        target_list = response["value"]
        for record in target_list:
            record["workspaceID"] = workspace["id"]
        final_data.extend(target_list)
    return final_data
        

# COMMAND ----------

def getDatasetObjects(end_point, url, headers, dataset_data):
    final_data = []
    if end_point != "DatasetRefreshSchedule":
        for dataset in dataset_data:
            try:
                target_url = url.replace("{workspaceID}",dataset["workspaceID"]).replace("{datasetId}",dataset["id"])
                response = getResponse(target_url,headers)
                target_list = response["value"]
                for record in target_list:
                    record["workspaceID"] = dataset["workspaceID"]
                    record["datasetID"] = dataset["id"]
                final_data.extend(target_list)
            except:
                pass
    elif end_point == "DatasetRefreshSchedule":
        for dataset in dataset_data:
            try:
                target_url = url.replace("{workspaceID}",dataset["workspaceID"]).replace("{datasetId}",dataset["id"])
                target_list = getResponse(target_url,headers)
                target_list["workspaceID"] = dataset["workspaceID"]
                target_list["datasetID"] = dataset["id"]
                final_data.append(target_list)
            except:
                pass
    return final_data

# COMMAND ----------

def getReportObjects(end_point, url, headers, report_data):
    final_data = []
    for report in report_data:
        try:
            target_url = url.replace("{reportId}", report["id"])
            response = getResponse(target_url, headers)
            target_list = response["value"]
            for record in target_list:
                record["reportID"] = report["id"]
            final_data.extend(target_list)
        except:
            pass
    return final_data
  
def getAppObjects(end_point, url, headers, app_data):
    final_data = []
    for app in app_data:
        try:
            target_url = url.replace("{app}", app["id"])
            response = getResponse(target_url, headers)
            target_list = response["value"]
            for record in target_list:
                record["appID"] = app["id"]
            final_data.extend(target_list)
        except:
            pass
    return final_data

# COMMAND ----------

if __name__ == "__main__":
    
    ###########################
    # Authorize MS PowerBI APIs
    ###########################
    headers = authServicePrincipal(tenant_id, "pbi")

    # 4. Workspaces
    pbi_workspaces_data = getPBIObjects("Workspaces", pbi_workspaces_url, headers)
    writeToADLS(pbi_folder_path,"Workspaces", "01_Workspaces_{time}_SourceData.json".replace("{time}",cur_file_time), json.dumps(pbi_workspaces_data))

# COMMAND ----------

if __name__ == "__main__":
    
    
    # 5. Workspace users
    pbi_wsusers_data = getWorkspaceObjects("WorkspaceUsers", pbi_wsUsers_url, headers, pbi_workspaces_data)
    writeToADLS(pbi_folder_path,"WorkspaceUsers", "01_WorkspaceUsers_{time}_SourceData.json".replace("{time}",cur_file_time), json.dumps(pbi_wsusers_data))
    
    # 6. Workspace datasets
    pbi_wsdatasets_data = getWorkspaceObjects("WorkspaceDatasets", pbi_wsDatasets_url, headers, pbi_workspaces_data)
    writeToADLS(pbi_folder_path,"WorkspaceDatasets", "01_WorkspaceDatasets_{time}_SourceData.json".replace("{time}",cur_file_time), json.dumps(pbi_wsdatasets_data))
    
    # 7. Workspace reports
    pbi_wsreports_data = getWorkspaceObjects("WorkspaceReports", pbi_wsReports_url, headers, pbi_workspaces_data)
    writeToADLS(pbi_folder_path,"WorkspaceReports", "01_WorkspaceReports_{time}_SourceData.json".replace("{time}",cur_file_time), json.dumps(pbi_wsreports_data))

# COMMAND ----------

if __name__ == "__main__":

    ###########################
    # Authorize MS PowerBI APIs
    ###########################
    headers = authServicePrincipal(tenant_id, "pbi")

    # 8. Dataset users
    pbi_dsusers_data = getDatasetObjects("DatasetUsers",pbi_dsUsers_url,headers,pbi_wsdatasets_data)
    writeToADLS(pbi_folder_path,"DatasetUsers", "01_DatasetUsers_{time}_SourceData.json".replace("{time}",cur_file_time), json.dumps(pbi_dsusers_data))
    
    # 9. Dataset datasources
    pbi_dsdatasources_data = getDatasetObjects("DatasetDatasources",pbi_dsDatasources_url,headers,pbi_wsdatasets_data)
    writeToADLS(pbi_folder_path,"DatasetDatasources", "01_DatasetDatasources_{time}_SourceData.json".replace("{time}",cur_file_time), json.dumps(pbi_dsdatasources_data))
    
    # 10. Dataset refresh history
    pbi_dsrefreshes_data = getDatasetObjects("DatasetRefreshHistory",pbi_dsRefreshes_url,headers,pbi_wsdatasets_data)
    writeToADLS(pbi_folder_path,"DatasetRefreshHistory", "01_DatasetRefreshHistory_{time}_SourceData.json".replace("{time}",cur_file_time), json.dumps(pbi_dsrefreshes_data))
    
    # 11. Dataset refresh schedules
    pbi_dsschedule_data = getDatasetObjects("DatasetRefreshSchedule",pbi_dsSchedule_url,headers,pbi_wsdatasets_data)
    writeToADLS(pbi_folder_path,"DatasetRefreshSchedule", "01_DatasetRefreshSchedule_{time}_SourceData.json".replace("{time}",cur_file_time), json.dumps(pbi_dsschedule_data))


# COMMAND ----------

if __name__ == "__main__":
    
    #12. Report users
    pbi_reportusers_data = getReportObjects("ReportUsers",pbi_rpUsers_url,headers,pbi_wsreports_data)
    writeToADLS(pbi_folder_path,"ReportUsers", "01_ReportUsers_{time}_SourceData.json".replace("{time}",cur_file_time), json.dumps(pbi_reportusers_data))

# COMMAND ----------

if __name__ == "__main__":
    
    ###########################
    # Authorize MS PowerBI APIs
    ###########################
    headers = authServicePrincipal(tenant_id, "pbi")
    
    # 13. Applications
    pbi_apps_data = getPBIObjects("Applications", pbi_apps_url, headers)
    writeToADLS(pbi_folder_path,"Applications", "01_Applications_{time}_SourceData.json".replace("{time}",cur_file_time), json.dumps(pbi_apps_data))
    
    # 14. App Users
    pbi_appusers_data = getAppObjects("ApplicationUsers", pbi_appUsers_url, headers, pbi_apps_data)
    writeToADLS(pbi_folder_path, "ApplicationUsers", "01_ApplicationUsers_{time}_SourceData.json".replace("{time}",cur_file_time), json.dumps(pbi_appusers_data))

# COMMAND ----------

# import multiprocessing
# from multiprocessing import Pool

# def processDatasetsParallel(dataset_object, pbi_ds_url, headers, pbi_wsdatasets_data, pbi_folder_path, file_name):
#     pbi_api_data = getDatasetObjects(dataset_object, pbi_ds_url, headers, pbi_wsdatasets_data)
#     writeToADLS(pbi_folder_path, dataset_object, file_name, json.dumps(pbi_api_data))

# if __name__ == "__main__":
#     headers = authServicePrincipal(tenant_id, "pbi")

#     param_list = [("DatasetUsers", pbi_dsUsers_url, headers, pbi_wsdatasets_data, pbi_folder_path, "01_DatasetUsers_SourceData.json")
#                  ,("DatasetDatasources", pbi_dsDatasources_url, headers, pbi_wsdatasets_data, pbi_folder_path, "01_DatasetDatasources_SourceData.json")
#                  ,("DatasetRefreshHistory", pbi_dsRefreshes_url, headers, pbi_wsdatasets_data, pbi_folder_path, "01_DatasetRefreshHistory_SourceData.json")
#                  ,("DatasetRefreshSchedule", pbi_dsSchedule_url, headers, pbi_wsdatasets_data, pbi_folder_path, "01_DatasetRefreshSchedule_SourceData.json")
#                  ]

#     with Pool(multiprocessing.cpu_count()-1) as p:
#         p.starmap(processDatasetsParallel,param_list)
#         p.close()
#         p.join()
