# Databricks notebook source
import requests
import json
from datetime import datetime
import pytz

##############################
# Set widget and default value for this.
dbutils.widgets.text("mount_point", "/mnt/devcdpadlsae1/")
##############################

##############################
# Global variables. Define variables used across this notebook

# Set local date Pacific/Auckland for ADLS folder path settings
tz_info = pytz.timezone('Pacific/Auckland')
cur_date_path = datetime.now(tz=tz_info).strftime('%Y/%m/%d')
cur_file_time = datetime.now(tz=tz_info).strftime('%H%M')
graph_folder_path = dbutils.widgets.get("mount_point") + "landing/Auditing/MSGraph/{folder}/" + cur_date_path + "/{file}"
pbi_folder_path = dbutils.widgets.get("mount_point") + "landing/Auditing/MSPowerBI/{folder}/" + cur_date_path + "/{file}"

tenant_id = "494a2d87-24b5-42d8-8a3d-77448be1d46f"

# Graph API Endpoint URLs:
ad_groups_url = "https://graph.microsoft.com/v1.0/groups?%24filter=startswith(displayName,'SEC_DL_APP_')"
ad_users_url = "https://graph.microsoft.com/v1.0/users?%24count=true&%24filter=endsWith(mail,'@adhb.govt.nz')"
ad_members_base_url = "https://graph.microsoft.com/v1.0/groups/{groupID}/members"


# COMMAND ----------

###################################
# Define functions used in notebook
###################################

def authServicePrincipal(tenant_id, api):
    # Headers passed to API
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer ",
        "ConsistencyLevel": "eventual"
    }
    if api == "graph":
        scope = "&scope=https://graph.microsoft.com/.default"
    elif api == "pbi":
        scope = "&scope=https://analysis.windows.net/powerbi/api/.default"
    
    url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
    auth_data = dbutils.secrets.get(scope = 'AzureSecretScope', key = 'AutomationServicePrincipal') + scope + "&grant_type=client_credentials"
    response = requests.post(url, data = auth_data)
    response_json = response.json()
    access_token = response_json["access_token"]
    headers["Authorization"] += access_token
    return headers

def getResponse(url, headers):
    response = requests.get(url, headers=headers)
    return response.json()

def writeToADLS(folder_path,folder,file_name,data):
    save_path = folder_path.replace("{folder}",folder).replace("{file}",file_name)
    dbutils.fs.put(save_path,data,True)


# COMMAND ----------

####################################
# Define function to call Graph APIs
####################################

def callGraphEP(end_point, url, headers):
    if (end_point == "ADGroups" or end_point == "ADUsers"):
        final_data = []
        response = getResponse(url,headers)
        final_data = response["value"]
        while "@odata.nextLink" in response:
            nextLink = response["@odata.nextLink"]
            response = getResponse(nextLink, headers)
            final_data.extend(response["value"])
    elif end_point == "ADGroupMembers":
        final_data = []
        group_list = callGraphEP("ADGroups", ad_groups_url, headers)
        for group in group_list:
            ad_members_url = ad_members_base_url.replace("{groupID}",group["id"])
            response = getResponse(ad_members_url, headers)
            member_list = response["value"]
            while "@odata.nextLink" in response:
                nextLink = response["@odata.nextLink"]
                response = getResponse(nextLink, headers)
                member_list.extend(response["value"])
            for record in member_list:
                record["groupID"] = group["id"]
            final_data.extend(member_list)
    return final_data

# COMMAND ----------

if __name__ == "__main__":
    
    #########################
    # Authorize MS Graph APIs
    #########################
    headers = authServicePrincipal(tenant_id, "graph")
    
    # 1. ADGroups
    ad_groups_data = callGraphEP("ADGroups", ad_groups_url, headers)
    writeToADLS(graph_folder_path,"ADGroups", "01_ADGroups_{time}_SourceData.json".replace("{time}",cur_file_time), json.dumps(ad_groups_data))
    
    # 2. AD Users
    ad_users_data = callGraphEP("ADUsers", ad_users_url, headers)
    writeToADLS(graph_folder_path,"ADUsers", "01_ADUsers_{time}_SourceData.json".replace("{time}",cur_file_time), json.dumps(ad_users_data))

    # 3. AD Members
    ad_members_data = callGraphEP("ADGroupMembers", ad_members_base_url, headers)
    writeToADLS(graph_folder_path,"ADGroupMembers", "01_ADGroupMembers_{time}_SourceData.json".replace("{time}",cur_file_time), json.dumps(ad_members_data))

