# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 17-Apr-2023 | 1       | Abhilash       | Created                                                                    |
# MAGIC |                                                                                                                     |

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

#%run "../../Utilities/common_variables"

# COMMAND ----------

import requests
import json
from datetime import datetime, timedelta
import pytz
import pyodbc
import itertools

##############################\
# Global variables. Define variables used across this notebook

# Set local date Pacific/Auckland for ADLS folder path settings
tz_info = pytz.timezone('Pacific/Auckland')
cur_date_path = datetime.now(tz=tz_info).strftime('%Y/%m/%d')
cur_datetime = datetime.now(tz=tz_info).strftime('%Y%m%d_%H%M')
pbi_folder_path = landing_folder_path+"Auditing/MSPowerBI/{folder}/" + cur_date_path + "/{file}"
tenant_id = "494a2d87-24b5-42d8-8a3d-77448be1d46f"

# Power Activity Events API Endpoint URL:
pbi_activityevents_url = "https://api.powerbi.com/v1.0/myorg/admin/activityevents?startDateTime='{StartDate}'&endDateTime='{EndDate}'"

# COMMAND ----------

###################################
# Define functions used in notebook
###################################

def authServicePrincipal(tenant_id, api):
    # Headers passed to API
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer ",
        "ConsistencyLevel": "eventual"
    }

    scope = "&scope=https://analysis.windows.net/powerbi/api/.default"
    
    url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
    auth_data = dbutils.secrets.get(scope = 'AzureSecretScope', key = 'AutomationServicePrincipal') + scope + "&grant_type=client_credentials"
    response = requests.post(url, data = auth_data)
    response_json = response.json()
    access_token = response_json["access_token"]
    headers["Authorization"] += access_token
    return headers

def getResponse(url, headers):
    response = requests.get(url, headers=headers)
    return response.json()

def writeToADLS(folder_path,folder,file_name,data):
    save_path = folder_path.replace("{folder}",folder).replace("{file}",file_name)
    dbutils.fs.put(save_path,data,True)

def getActivityEvents(end_point, url, startDatetime, endDatetime, headers):
    final_data = []
    target_url = url.replace("{StartDate}",startDatetime).replace("{EndDate}",endDatetime)
    response = getResponse(target_url,headers)
    final_data = response["activityEventEntities"]
    return final_data

# COMMAND ----------

###################################
# Execute Stored Proc to fetch Last Run Times
# into Py dictionary
###################################

try:
    #connectAZSQLMI('dev-cdp-sqlmi-ae-1.792150d6ca9e.database.windows.net', 'ADM_CONFIG', 'adhbsqladmin')
    connectAZSQLMI('ADM_CONFIG')
    cursor = conn.cursor()
    sqlCommand = """
            EXEC etl.PowerBI_Activity_BatchLoad
            """
 # Call Stored Procedure
    cursor.execute(sqlCommand)
    
# Fetch all rows and load into dictionary
 
    rows = cursor.fetchall()
    desc = cursor.description
    column_names = [col[0] for col in desc]
    data = [dict(zip(column_names, row))  
           for row in rows]
    print(data)
 # Close the cursor and delete it
    cursor.close()
    del cursor
 
 # Close the database connection
    conn.close()
    
except pyodbc.Error as err:
    print("Printing Error: ", err)
    cursor.close()
    conn.close()

# COMMAND ----------

###################################
# Loop through last Runtimes, call PBI API 
# and write to ADLS
###################################

headers = authServicePrincipal(tenant_id, "graph")
itr = 0

for record in data:
    itr += 1
    outFile = str(itr).zfill(2) + "_ActivityEvents-"+cur_datetime+"_SourceData.json"
    #print(outFile)
    try:
        pbi_activity_events = getActivityEvents("Activity Events", pbi_activityevents_url, record["StartDate"], record["EndDate"], headers)
        writeToADLS(pbi_folder_path,"ActivityEvents",outFile,json.dumps(pbi_activity_events))
        print(outFile)
    
    except:
        pass


# COMMAND ----------

###################################
# Record Successful run
###################################

try:
    #connectAZSQLMI('dev-cdp-sqlmi-ae-1.792150d6ca9e.database.windows.net', 'ADM_CONFIG', 'adhbsqladmin')
    connectAZSQLMI('ADM_CONFIG')
    cursor = conn.cursor()
    sqlCommand = """
            EXEC etl.CreateBatch @ParentBatchID=?, @ProcessName=?
            """
 # Call Stored Procedure
    cursor.execute(sqlCommand, 0, 'Power BI Activity Events')
    conn.commit()
 # Close the cursor and delete it
    cursor.close()
    del cursor
 
 # Close the database connection
    conn.close()
    
except pyodbc.Error as err:
    print("Printing Error: ", err)
    cursor.close()
    conn.close()
