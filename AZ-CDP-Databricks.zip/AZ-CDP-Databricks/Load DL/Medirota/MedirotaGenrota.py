# Databricks notebook source
import http
import requests
import json
import os

#The data factory will need to supply the variables below.
#We create the text box so that we can enter values to test before we call the notebook from Azure Data Factory

dbutils.widgets.text("paramsFromADF", "","")
FilePathNameAndToken = dbutils.widgets.get("paramsFromADF")
FilePathNameAndToken_jsonObject = json.loads(FilePathNameAndToken)

FileName = FilePathNameAndToken_jsonObject["FileName"]
FilePath = FilePathNameAndToken_jsonObject["FilePath"]
ApiUrlAndToken =FilePathNameAndToken_jsonObject["ApiUrlAndToken"]

#need to extract the storage account name wihtout the http bit
StorageAccount =FilePathNameAndToken_jsonObject["StorageAccount"][8:21]

response = requests.get(ApiUrlAndToken)                      
print(response.status_code)
#print(response.content)

#Need to make sure the folder exists
os.makedirs('/dbfs/mnt/'+StorageAccount+'/bronze/'+FilePath, exist_ok=True)

with open('/dbfs/mnt/'+StorageAccount+'/bronze/'+FilePath+'/'+FileName, 'wb') as f:
    f.write(response.content)
#file1=open('/dbfs/mnt/devcdpadlsae1/bronze/medirota/'+FileName)
#print(file1.read())
#print()

#Now return a value to the Azure Data Factory Pipeline and exit the Notebook
dbutils.notebook.exit('The Notebook ran succesfuly. The filename is:'+FileName)


# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE books
# MAGIC USING xml
# MAGIC OPTIONS (path "/dbfs/mnt/devcdpadlsae1/bronze/medirota/MedirotaGenRota.xml", rowTag "stream")

# COMMAND ----------

# MAGIC %scala
# MAGIC import com.databricks.spark.xml._ // Add the DataFrame.read.xml() method
# MAGIC
# MAGIC val df = spark.read
# MAGIC   .option("rowTag", "stream")
# MAGIC   .xml("/mnt/devcdpadlsae1/bronze/medirota/MedirotaGenRota.xml")
# MAGIC
# MAGIC print(df)

# COMMAND ----------

display(spark.read.option("rootTag", "stream").option("rowTag","summary").format("xml").load('/dbfs/mnt/devcdpadlsae1/bronze/medirota/MedirotaGenRota.xml'))

# COMMAND ----------

import xml.etree.ElementTree as ET
#with open(''/dbfs/mnt/devcdpadlsae1/bronze/medirota/MedirotaGenRota.xml',)

tree = ET.parse('/dbfs/mnt/devcdpadlsae1/bronze/medirota/MedirotaGenRota.xml')
root =  tree.getroot()

for node in tree["streaam"]["node"]:
    [node["session"]]

# COMMAND ----------

import xmltodict

with open('/dbfs/mnt/devcdpadlsae1/bronze/medirota/MedirotaGenRota.xml') as xmlfile:
    xml =  xmltodict.parse(xmlfile.read())
 

#for nd in xml["stream"]["node"]:
#    nd
    #type  = [nd["type"]]

# COMMAND ----------

from xml.etree import ElementTree
xml = ElementTree.parse('/dbfs/mnt/devcdpadlsae1/bronze/medirota/MedirotaGenRota.xml')
root =  tree.getroot()

for nd in xml.findall("node"):
    session = nd.find("session")
print(session)

# COMMAND ----------

Test
