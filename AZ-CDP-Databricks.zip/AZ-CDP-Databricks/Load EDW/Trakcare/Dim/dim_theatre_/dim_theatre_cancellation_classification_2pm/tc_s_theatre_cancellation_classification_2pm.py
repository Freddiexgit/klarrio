# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 10-May-2024 | 1       | Eric Yang      | Init `tc_s_theatre_cancellation_classification_2pm` table                  |
# MAGIC | 17-May-2024 | 2       | Eric Yang      | Add Updte control tables part                                              |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# Use the function below if you need to reset the development and start from scratch.
# reset_table('silver_db', 'trakcare', 'tc_s_theatre_cancellation_classification_2pm', 1777, 'Control_TRAK')

# COMMAND ----------

# DBTITLE 1,Variables
# p_etlcontrolid is passed as a parameter from ADF
dbutils.widgets.text("p_batchid","0")
v_batchid = int(dbutils.widgets.get("p_batchid"))
dbutils.widgets.text("p_etlcontrolid","1777")
v_etlcontrolid = dbutils.widgets.get("p_etlcontrolid")

# COMMAND ----------

# Create variable from etl.Control table
# WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
qry = f"""
       SELECT 
              ETLControlID
            , SourceSystem
            , SourceSystemType
            , SourceTableSchemaName
            , SourceTableName
            , CASE WHEN IncrementalLoad = 1 THEN WaterMarkValue ELSE '1900-01-01' END WaterMarkValue
            , TargetSystemType
            , TargetTableSchemaName
            , TargetTableName
            , IncrementalLoad
            , IsActive
            , TargetEntityPath
            , CustomConfig
        FROM ADM_CONFIG.etl.Control_TRAK
        WHERE ETLControlID = {v_etlcontrolid}"""

df_control = read_from_mi_db('ADM_CONFIG', qry)

v_watermark_date = df_control.select("WaterMarkValue").collect()[0][0]
v_target_table_name = df_control.select("TargetTableName").collect()[0][0]
v_target_database = df_control.select("CustomConfig").collect()[0][0]
v_sourcesystem = 'trakcare'
v_target_entity_path = df_control.select("TargetEntityPath").collect()[0][0]


# COMMAND ----------

# DBTITLE 1,Set new WaterMarkValue
# New WaterMarkValue is the latest processing date across all RDS joining tables
v_new_watermark_value = spark.sql(f"""
select date(max(watermark)) v_new_watermark_value
from 
    (
    select max(processing_time) watermark from bronze.tc_l_rb_apptschedule
    union
    select max(processing_time) watermark from bronze.tc_l_rb_appointment
    ) qry
""").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,Create Table
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {v_target_database}.{v_target_table_name}
(
  watermarkvalue timestamp
  , hashid string
  , cancelclassification2pm string
  , sourcecode string )
USING DELTA
LOCATION '{silver_folder_path}trakcare/{v_target_table_name}'
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Processing

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Create Temp View with Changes only

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE TEMP VIEW vw_s_theatre_cancellation_classification_2pm
AS
SELECT DISTINCT
  '{v_new_watermark_value}' AS watermarkvalue
  , '' AS HashID
  , case
    when rbapt.APPT_CancelTime <= timestampadd(HOUR, 14, date(date_add(DAY, -1, rbats.AS_SessStartTime))) THEN 'Early Cancellation' -- prior 2pm of the day before theatre session
    when rbapt.APPT_CancelTime > timestampadd(HOUR, 14, date(date_add(DAY, -1, rbats.AS_SessStartTime))) then 'Late Cancellation' -- after 2pm of the day before theatre session
    else 'Case Completed'
  end as CancelClassification2pm
  , 'TRAK' AS SourceCode
FROM hive_metastore.bronze.tc_l_rb_apptschedule rbats
LEFT JOIN hive_metastore.bronze.tc_l_rb_appointment rbapt ON rbapt.APPT_AS_ParRef = rbats.AS_RowId
WHERE 1=1
""")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Update the target table

# COMMAND ----------

# this dataframe is required for the merge function
df_view = spark.sql("SELECT * FROM vw_s_theatre_cancellation_classification_2pm")

# obtain the list of column to be used to generate the hashid column: it should include all columns except the watermark
lst_cols = df_view.columns
lst_cols.remove('watermarkvalue')

# add hashid column to the view dataframe
df_hashed = df_view.withColumn("hashid", sha2(concat_ws('|', *lst_cols),256))

# COMMAND ----------

# set the merge condition required for the merge functions
merge_condition = "TARGET.CancelClassification2pm = SOURCE.CancelClassification2pm"

# to update the true delta records
match_additional_condition = f""" TARGET.hashid <> SOURCE.hashid """

# call merge function
merge_delta_tables(df_hashed, v_target_database, v_target_table_name, merge_condition, match_additional_condition )

# COMMAND ----------

# write to the ADM_LOG.etl.LogOverview table on MI the output from the merge 
insert_into_log_overview(v_target_database, v_target_table_name, v_etlcontrolid, v_sourcesystem, v_target_database[0])

# COMMAND ----------

# MAGIC %md
# MAGIC ####Validation Checks

# COMMAND ----------

# DBTITLE 1,No Duplicates and NULL values
v_grain = 'CancelClassification2pm'
v_columns_exclude = ''

check_for_duplicates (v_target_database, v_target_table_name, v_grain, v_columns_exclude)
check_for_null_values(v_target_database, v_target_table_name, v_grain, v_columns_exclude)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Post-processing

# COMMAND ----------

# DBTITLE 1,Export deltas to parquet file
# Saving the changes in the target table as a parquet file to be consumed by Titan (via ADF).
if v_watermark_date == v_new_watermark_value.strftime("%Y-%m-%d") : 
    wmrk = '9999-01-01' 
else: 
    wmrk = v_new_watermark_value

# produce an empty dataframe if old and new watermark have the same value
df_s_parquet = get_df_titan(v_target_database,v_target_table_name, wmrk)
write_parquet_for_export(df_s_parquet, silver_folder_path, trakcare_export_parquet, v_target_table_name, 'overwrite')

# COMMAND ----------

# DBTITLE 1,Update WaterMarkValue
# update the etl.Control table WaterMarkValue with the latest processing date from the RDS joining tables
# if the old and the new watermark dates have different values
if v_watermark_date != v_new_watermark_value.strftime("%Y-%m-%d") : 
    update_mi_water_mark_value (v_new_watermark_value, v_etlcontrolid)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Update Control Tables

# COMMAND ----------

def update_sqlmi_control_tables(db_name:str, query:str) -> None:
    """
    This function is to execute query against SQLMI Instances.

    This function can be used for following scenarios
      - Update Control_Trak table
      - Update BatchControl Table
    
    Usage:
    >>> qry = 'INSERT INTO [ADM_CONFIG].[etl].BatchControl(ETLCOntrolID,BatchType,IsActive,ControlTableName,SortOrder) VALUES()'
    >>> exec_sqlmi_query('ADM_CONFIG', qry)

    """

    import pyodbc 
    
    try:
        #pwd=dbutils.secrets.get(scope='AzureSecretScope',key='az-sql-mi-admin-password')
        connectAZSQLMI(db_name)

        cursor = conn.cursor()
        cursor.execute(query)

        conn.commit()
        cursor.close()
        conn.close()
    
    except pyodbc.Error as err:
        print("Printing Error: ", err)
        cursor.close()
        conn.close()
        exit()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1: Update Control_Trak Table

# COMMAND ----------

SourceTableName = "tc_l_rb_apptschedule,tc_l_rb_appointment"
WaterMarkQuery = 'embedded in Databricks notebook'
WaterMarkValue = v_new_watermark_value
TargetEntityPath = "trakcare/export/"
IsActive = 1
Token = "eric"
DatabricksNotebook = '/Shared/Load EDW/Trakcare/Dim/dim_theatre_/dim_theatre_cancellation_classification_2pm/tc_s_theatre_cancellation_classification_2pm'
CustomConfig = "silver_db"
StatusDesc = "Released_V01_20240517"

update_control_trak_query = f"""
BEGIN TRANSACTION;
UPDATE [ADM_CONFIG].[etl].Control_trak
SET
  SourceTableName = '{SourceTableName}'
  , WaterMarkQuery  = '{WaterMarkQuery}'
  , WaterMarkValue = '{WaterMarkValue}'
  , TargetEntityPath = '{TargetEntityPath}'
  , IsActive = {IsActive}
  , Token = '{Token}'
  , DatabricksNotebook = '{DatabricksNotebook}'
  , CustomConfig = '{CustomConfig}'
  , StatusDesc = '{StatusDesc}'
WHERE 1=1
  and ETLControlID = {v_etlcontrolid}
;
COMMIT TRANSACTION;
"""
print(update_control_trak_query)

# COMMAND ----------



# COMMAND ----------

## Uncomment this code to update the `[ADM_CONFIG].[etl].Control_trak` table when necessary
#

# update_sqlmi_control_tables('ADM_CONFIG', update_control_trak_query)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 2: Update BatchControl Table

# COMMAND ----------

ETLCOntrolID = v_etlcontrolid
BatchType = "Load_tc_s_"
IsActive = 1
ControlTableName = "Control_TRAK"
SortOrder = 2015

update_batch_control_query = f"""
BEGIN TRANSACTION;
INSERT INTO [ADM_CONFIG].[etl].BatchControl(ETLCOntrolID,BatchType,IsActive,ControlTableName,SortOrder)
VALUES ({ETLCOntrolID}, '{BatchType}', {IsActive}, '{ControlTableName}', {SortOrder});
COMMIT TRANSACTION;
"""
print(update_batch_control_query)

# COMMAND ----------

## Uncomment this code to update the `[ADM_CONFIG].[etl].BatchControl` table when necessary
#

# update_sqlmi_control_tables('ADM_CONFIG', update_batch_control_query)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 3: Check Control Tables

# COMMAND ----------

# MAGIC %md
# MAGIC Check Control_Trak table, make sure all fields are valid

# COMMAND ----------

check_control_trak_query = f""" 
SELECT * FROM [ADM_CONFIG].[etl].Control_trak WHERE ETLControlID IN ( 1615, {v_etlcontrolid} )
"""
control_trak_df = read_from_mi_db('ADM_CONFIG', check_control_trak_query)
display(control_trak_df)

# COMMAND ----------

# MAGIC %md
# MAGIC Check BatchControl table, make sure all fields are valid

# COMMAND ----------

check_batch_control_query = f"""
SELECT * FROM [ADM_CONFIG].[etl].BatchControl WHERE ETLControlID IN ( 1615, {v_etlcontrolid} )
"""
batch_control_df = read_from_mi_db('ADM_CONFIG', check_batch_control_query)
display(batch_control_df)
