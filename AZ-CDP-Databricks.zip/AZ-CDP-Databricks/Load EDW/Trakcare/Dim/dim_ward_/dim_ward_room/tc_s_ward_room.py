# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 01-May-2023 | 1       | Donne Medley | Create first draft of tc_s_ward_room                                     |
# MAGIC | 01-May-2023 | 2       | Donne Medley | QuarantineComment, QuarantineFlag, RestrictedComment, TotalBedSpaces not mapped                                                               |
# MAGIC |09-05-2023|3|Donne Medley| changed column order for zorder|
# MAGIC |10-05-2023|3|Donne Medley| NOTE: based on view vw_tc_s_ward|
# MAGIC |16-08-2023|4|Mahi Ethiraj| Changing the Wardid,roomid and tcroomid mapping to accordate titan (it is a int field in DW) and add locationid field|
# MAGIC |15-12-2023|5|Gery Smith | Amend roomid and tcroomid field to use the function sql_format_field|
# MAGIC |26-03-2024|6|Gery Smith | Depricated fields: RoomAgeGroupCode, RoomAgeGroupDesc, RoomgenderTypeCode, RoomGenderTypeDesc|
# MAGIC | 27-Mar-2024 | 7       | Gery Smith     | Switch to Control_TRAK |
# MAGIC | 03-Apr-2024 | 8       | Gery Smith     | Added RestrictedComment. This probably will need to change once we have actual data. |
# MAGIC | 15-08-2024 | 9       | Daniel Menary  | Mapping Revised |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# reset_table(v_target_database , v_sourcesystem , v_target_table_name , v_etlcontrolid )
# reset_table('silver_db', 'trakcare', 'tc_s_ward_room', 1854, 'Control_TRAK')

# COMMAND ----------

# DBTITLE 1,Variables
# p_etlcontrolid is passed as a parameter from ADF
dbutils.widgets.text("p_batchid","0")
v_batchid = int(dbutils.widgets.get("p_batchid"))

dbutils.widgets.text("p_etlcontrolid","1854")
v_etlcontrolid = dbutils.widgets.get("p_etlcontrolid")

# COMMAND ----------

# Create variable from etl.Control table
# WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
qry = f"""
       SELECT 
              ETLControlID
            , SourceSystem
            , SourceSystemType
            , SourceTableSchemaName
            , SourceTableName
            , CASE WHEN IncrementalLoad = 1 THEN WaterMarkValue ELSE '1900-01-01' END WaterMarkValue
            , TargetSystemType
            , TargetTableSchemaName
            , TargetTableName
            , IncrementalLoad
            , IsActive
            , TargetEntityPath
            , CustomConfig
        FROM ADM_CONFIG.etl.Control_TRAK
        WHERE ETLControlID = {v_etlcontrolid}"""

df_control = read_from_mi_db('ADM_CONFIG', qry)

v_watermark_date = df_control.select("WaterMarkValue").collect()[0][0]
v_target_table_name = df_control.select("TargetTableName").collect()[0][0]
v_target_database = df_control.select("CustomConfig").collect()[0][0]
v_sourcesystem = 'trakcare'
v_target_entity_path = df_control.select("TargetEntityPath").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,Set new WaterMarkValue
# New WaterMarkValue is the latest processing date across all RDS joining tables
v_new_watermark_value = spark.sql("""
SELECT DATE(MAX(watermark)) v_new_watermark_value
FROM 
    (
    SELECT MAX(watermarkvalue) watermark from silver_db.vw_tc_s_ward
    UNION
    SELECT MAX(processing_time) watermark FROM bronze.tc_l_pac_ward
    UNION
    SELECT MAX(processing_time) watermark FROM bronze.tc_l_pac_wardroom
    UNION
    SELECT MAX(processing_time) watermark FROM bronze.tc_l_pac_room
    UNION 
    SELECT MAX(processing_time) watermark FROM bronze.tc_l_pac_bed
    UNION
    SELECT MAX(processing_time) watermark from bronze.tc_l_pac_bedstatuschange
    ) qry
""").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,Create Table
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {v_target_database}.{v_target_table_name}
(
 watermarkvalue timestamp
 ,hashid string
 ,locationid int
 ,locationcode string
 ,wardcode string
 ,roomcode string
 ,wardid int
 ,roomid int
 ,tcroomid int
 ,locationdesc string
 ,warddesc string
 ,roomdesc string
 , roomgendertypecode string --depricated
 , roomgendertypedesc string -- depricated
 , roomagegroupcode string -- depricated
 , roomagegroupdesc string -- depricated
 ,totalbedspaces int
 ,roomstatus string
 ,quarantinecomment string
 ,restrictedcomment string
 ,offsite string
 ,admitwardflag string
 ,dischwardflag string
 ,emergencywardflag string
 ,emergencywardpcmflag string
 ,icuwardflag string
 ,quarantineflag string
 ,sourcecode string
)
USING DELTA
LOCATION '{silver_folder_path}trakcare/{v_target_table_name}'
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Processing

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Create Temp View with Changes only

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE TEMP VIEW vw_s_ward_room
AS
SELECT 
'{v_new_watermark_value}' AS watermarkvalue
 , vw.locationid
 ,vw.locationcode 
 ,vw.wardcode 
 ,r.ROOM_Code roomcode 
 --,vw.wardid 
 ,w.ward_rowid as wardid -- V4 Change
 ,r.room_rowid as roomid
 ,Cast(sql_format_field(r.ROOM_ROWID,'|','0', 3) as integer) tcroomid -- V5 Change
 ,vw.locationdesc 
 ,vw.warddesc 
 ,r.ROOM_Desc roomdesc 
 , null roomgendertypecode  -- depricated
 , null roomgendertypedesc  -- depricated
 , null roomagegroupcode    -- depricated
 , null roomagegroupdesc    -- depricated
 , COALESCE(bd.totalbedspaces, 0) AS totalbedspaces
 , CASE
    WHEN r.ROOM_DateTo IS NULL THEN 'Active'
    WHEN to_date(from_utc_timestamp(now() ,'Pacific/Auckland')) <= r.ROOM_DateTo THEN 'Active'
    ELSE 'Inactive'
   END as roomstatus
 ,NULL quarantinecomment -- depricated DataEDO
 ,ifnull(qry.stat_comment,'') restrictedcomment   
 ,vw.offsite 
 ,vw.admitwardflag 
 ,vw.dischwardflag 
 ,vw.emergencywardflag 
 ,vw.emergencywardpcmflag 
 ,vw.icuwardflag 
 ,NULL quarantineflag -- depricated DataEDO
 ,'TRAK' as sourcecode
FROM 
silver_db.vw_tc_s_ward vw
LEFT JOIN bronze.tc_l_pac_ward w ON vw.wardid = w.ward_locationdr
LEFT JOIN (
  SELECT ROOM_ParRef, ROOM_Room_DR, MIN(processing_time) AS processing_time FROM bronze.tc_l_pac_wardroom GROUP BY ROOM_ParRef, ROOM_Room_DR
) wr ON w.ward_rowid = wr.ROOM_ParRef
LEFT JOIN bronze.tc_l_pac_room r ON wr.ROOM_Room_DR = r.room_rowid
LEFT JOIN (
     select bd.BED_WARD_ParRef ,bd.BED_Room_DR, ch.STAT_Date , ch.STAT_Time , ch.STAT_DateTo , ch.STAT_Comment
 from bronze.tc_l_pac_bedstatuschange ch
 join bronze.tc_l_pac_bedstatus st
 on ch.STAT_Status_DR = st.BSTAT_RowId 
 join bronze.tc_l_pac_bed bd on ch.STAT_ParRef = bd.BED_RowID 
 and   bd.BED_DateTo is null
) qry
    ON qry.BED_WARD_ParRef = w.WARD_RowId
    AND qry.BED_Room_DR = r.ROOM_RowId
LEFT JOIN (
  select
    BED_WARD_ParRef,
    BED_Room_DR,
    count(bd.BED_RowId) totalbedspaces
  from bronze.tc_l_pac_bed bd 
  where 
    (
      bd.BED_DateTo is null or
      to_date(from_utc_timestamp(now() ,'Pacific/Auckland')) <= bd.BED_DateTo
    )
  group by
    BED_WARD_ParRef,
    BED_Room_DR
) bd
on bd.BED_WARD_ParRef = wr.ROOM_ParRef 
AND bd.BED_Room_DR = wr.ROOM_Room_DR
WHERE
r.ROOM_Code IS NOT NULL
AND (
    date(vw.watermarkvalue) >= '{v_watermark_date}'
    OR date(w.processing_time) >= '{v_watermark_date}' 
    OR date(wr.processing_time) >= '{v_watermark_date}' 
    OR date(r.processing_time) >= '{v_watermark_date}' 
    )
""")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Update the target table

# COMMAND ----------

# this dataframe is required for the merge function
df_view = spark.sql("SELECT * FROM vw_s_ward_room")

from pyspark.sql.functions import sha2, concat_ws

# obtain the list of column to be used to generate the hashid column: it should include all columns except the watermark
lst_cols = df_view.columns
lst_cols.remove('watermarkvalue')

# add hashid column to the view dataframe
df_hashed = df_view.withColumn("hashid",sha2(concat_ws('|', *lst_cols),256))

# COMMAND ----------

# set the merge condition required for the merge functions
merge_condition = 'TARGET.locationcode=SOURCE.locationcode AND TARGET.wardcode=SOURCE.wardcode AND TARGET.roomid=SOURCE.roomid'

# to update the true delta records
match_additional_condition = 'TARGET.hashid <> SOURCE.hashid'

# call merge function
merge_delta_tables(df_hashed, v_target_database, v_target_table_name, merge_condition, match_additional_condition )

# COMMAND ----------

# write to the ADM_LOG.etl.LogOverview table on MI the output from the merge 
insert_into_log_overview(v_target_database, v_target_table_name, v_etlcontrolid, v_sourcesystem, v_target_database[0], v_batchid)

# COMMAND ----------

# MAGIC %md
# MAGIC ####Validation Checks

# COMMAND ----------

# DBTITLE 1,No Duplicates and NULL values
#v_grain = 'locationcode,wardcode,roomid'
#v_columns_exclude = ''

#check_for_duplicates (v_target_database, v_target_table_name, v_grain, v_columns_exclude)
#check_for_null_values(v_target_database, v_target_table_name, v_grain, v_columns_exclude)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Post-processing

# COMMAND ----------

# DBTITLE 1,Export deltas to parquet file
# Saving the changes in the target table as a parquet file to be consumed by Titan (via ADF).
if v_watermark_date == v_new_watermark_value.strftime("%Y-%m-%d") : 
    wmrk = '9999-01-01' 
else: 
    wmrk = v_new_watermark_value

# produce an empty dataframe if old and new watermark have the same value
df_s_parquet = get_df_titan(v_target_database,v_target_table_name, wmrk)
write_parquet_for_export(df_s_parquet, silver_folder_path, trakcare_export_parquet, v_target_table_name, 'overwrite')

# COMMAND ----------

# DBTITLE 1,Update WaterMarkValue
# update the etl.Control table WaterMarkValue with the latest processing date from the RDS joining tables
# if the old and the new watermark dates have different values
if v_watermark_date != v_new_watermark_value.strftime("%Y-%m-%d") : 
    update_mi_water_mark_value (v_new_watermark_value, v_etlcontrolid, 'Control_TRAK')
