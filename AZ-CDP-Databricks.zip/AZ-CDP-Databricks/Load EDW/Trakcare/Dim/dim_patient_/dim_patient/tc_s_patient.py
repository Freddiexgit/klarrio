# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 23/05/2023 | 1        | Donne Medley   | Create first draft of tc_s_patient                                         |
# MAGIC | 24/05/2023 | 2        | Mahi Ethiraj   | Second draft                                                               |
# MAGIC | 30/05/2023 | 3        | Mahi Ethiraj   | Added few more mapped columns from drop V4                                 |
# MAGIC | 06/06/2023 | 3a       | Gery Smith     | Included Ethnicity fields in the vw_tc_s_patient from drop V4              |
# MAGIC | 06/06/2023 | 4        | Janesa Ramirez | Added mapped columns from drop v5                                          |    
# MAGIC | 24/07/2023 | 5        | Gopesh         | Added mapped columns from drop v9 and v10                                          |
# MAGIC | 09/08/2023 | 6        | Mahi Ethiraj   | Added placeholders for all columns to tc_s_patient as per dim_patient for WSR build|
# MAGIC | 18/08/2023 | 7        | Gery Smith     | Added sourcecode column |
# MAGIC | 18/12/2023 | 8        | Gery Smith     | Replace domiciledesc, dhbcode and dhbdesc to use a function instead of going back to the beginning of the tables |
# MAGIC | 27/02/2024 | 9        | Gery Smith     | Amend column currentflag. |
# MAGIC | 25/03/2024 | 10       | Daniel Menary  | add missing columns|
# MAGIC | 13/05/2024 | 10       | Donne Medley  | Reverted to subquery for domiciledesc, dhbcode and dhbdesc to avoid UDF calls for every row |
# MAGIC | 21/05/2024 | 11       | Daniel Menary  | correct values failing reconcilation|
# MAGIC | 21/05/2024 | 12       | Daniel Menary  | correct values failing reconcilation v2|
# MAGIC | 27/08/2024 | 13       | Arvin Chand    | amended logic to pick relationship name and surname from PA_Person if not available in PA_nok |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# MAGIC %run "/Shared/Load RDS/Trakcare/Data Masking Views"

# COMMAND ----------

# Use the function below if you need to reset the development and start from scratch.
# 1726 is the ETLControlID required to reset the watermark
# reset_table('silver_db', 'trakcare', 'tc_s_patient', 1726, 'Control_TRAK')

# COMMAND ----------

# DBTITLE 1,Variables
# p_etlcontrolid is passed as a parameter from ADF
dbutils.widgets.text("p_batchid","0")
v_batchid = int(dbutils.widgets.get("p_batchid"))
dbutils.widgets.text("p_etlcontrolid","1726")
v_etlcontrolid = dbutils.widgets.get("p_etlcontrolid")

# COMMAND ----------

# Create variable from etl.Control table
# WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
qry = f"""
       SELECT 
              ETLControlID
            , SourceSystem
            , SourceSystemType
            , SourceTableSchemaName
            , SourceTableName
            , CASE WHEN IncrementalLoad = 1 THEN WaterMarkValue ELSE '1900-01-01' END WaterMarkValue
            , TargetSystemType
            , TargetTableSchemaName
            , TargetTableName
            , IncrementalLoad
            , IsActive
            , TargetEntityPath
            , CustomConfig
        FROM ADM_CONFIG.etl.Control_TRAK 
        WHERE ETLControlID = {v_etlcontrolid}"""

df_control = read_from_mi_db('ADM_CONFIG', qry)

v_watermark_date = df_control.select("WaterMarkValue").collect()[0][0]
v_target_table_name = df_control.select("TargetTableName").collect()[0][0]
v_target_database = df_control.select("CustomConfig").collect()[0][0]
v_sourcesystem = 'trakcare'
v_target_entity_path = df_control.select("TargetEntityPath").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,Set new WaterMarkValue
# New WaterMarkValue is the latest processing date across all RDS joining tables
v_new_watermark_value = spark.sql("""
select   date(max(watermark)) v_new_watermark_value
from 
    (
    select max(watermarkvalue) watermark from  silver_db.vw_tc_s_patient
    union
    select max(processing_time) watermark from bronze.tc_l_pac_preferredlanguage
    union
    select max(processing_time) watermark from bronze.tc_l_pac_refdoctor
    union
    select max(processing_time) watermark from bronze.tc_l_pac_refdoctorclinic
    union
    select max(processing_time) watermark from bronze.tc_l_pac_clinic
    ) qry
""").collect()[0][0]

# COMMAND ----------

print('v_watermark_date:\t', v_watermark_date)
print('v_target_table_name:\t', v_target_table_name)
print('v_target_database:\t', v_target_database)
print('v_sourcesystem:\t\t', v_sourcesystem)
print('v_target_entity_path:\t', v_target_entity_path)
print('v_new_watermark_value:\t', v_new_watermark_value)

# COMMAND ----------

# DBTITLE 1,Create Table
# this will be replaced with a function<START>
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {v_target_database}.{v_target_table_name}
(
  watermarkvalue timestamp
, hashid string
, tcpatientid int
, patientbk string
, oldpatientbk string
, bkchangedate timestamp
, nhi string
, secondarynhi string
, primarynhiflag string
, secondarynhiflag string
, nhiterminalDigit string
, currentFlag string
, patientid int
, primaryid int
, firstname string
, secondname string
, thirdname string
, surname string
, fullname string
, title string
, dateofbirth timestamp
, gendercode string
, genderdesc string
, addressLine1 string
, addressLine2 string
, suburb string
, city string
, postcode string
, domicilecode STRING
, domiciledesc string
, dhbcode string
, dhbdesc string
, country string
, phonehome string
, mobilephone string
, phoneother string
, emailaddress string
, emailvalidationflag STRING
, dateofdeath timestamp
, asianflag string
, pacificflag string
, ethnicitycode string
, ethnicitydesc string
, ethnicity2code string
, ethnicity2desc string
, ethnicity3code string
, ethnicity3desc string
, ethnicity4code string
, ethnicity4desc string
, ethnicity5code string
, ethnicity5desc string
, ethnicity6code string
, ethnicity6desc string
, ethnicitymohcode string
, ethnicitymoh2code string 
, ethnicitymoh3code string 
, ethnicitymoh4code string 
, ethnicitymoh5code string 
, ethnicitymoh6code string 
, ethnicityprioritisedcode string 
, ethnicityprioritiseddesc string
, residentstatusid string
, nzresidentflag string
, foreignpatientflag string
, residentcountry string
, birthcountrycode string 
, birthcountrydesc string
, countryentrydate timestamp
, countrycomment string
, noktype string
, nokname string
, noksurname string
, nokphonehome string
, nokphoneother string
, gpcode string
, gpname string
, gpaddress string
, gppracticeAddress string
, gppracticecode string
, gppracticeName string
, language string
, interpreterflag string
, religion string
, occupation string
, patientcomments string
, maritalstatuscode string
, maritalstatusdesc string
, eligibilitycategory string
, eligibilitystatus string
, eligiblefromdate string
, eligibleuntildate string
, eligibleallservicesflag string
, eligibleacutecareflag string
, eligiblealcoholanddrugflag string
, eligiblematernityflag string
, eligiblementalhealthflag string
, eligibletuberculosisflag string
, eligiblefundedidtreatflag string
, alleligibleservices string
, passportno string
, visaexpirydate timestamp
, nzisclientno string
, legalstatuscode string
, legalstatusdesc string
, covid19dosenumber int
, covid19dayssincedose int
, sexcode string
, sexdesc string
, sourcecode string
)
LOCATION '{silver_folder_path}{v_sourcesystem}/{v_target_table_name}'
""")
# this will be replaced with a function<END>

# COMMAND ----------

# MAGIC %md
# MAGIC ### Processing

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Create Temp View with Changes only

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE TEMP VIEW vw_s_patient
AS
SELECT 
    '{v_new_watermark_value}' AS watermarkvalue
    , patient.PAPMI_RowId as tcpatientid
    , patient.papmi_no as patientbk
    , '' as oldpatientbk
    , '9999-12-31' as bkchangedate
    , patient.papmi_no as nhi
    , pa_patmas_from.papmi_no   as secondarynhi 
    , COALESCE(patient.PAPMI_Active,'Y') as primarynhiflag
    , CASE WHEN COALESCE(patient.PAPMI_Active,'Y')='Y' THEN 'N' ELSE 'Y' END as secondarynhiflag
    , RIGHT(RTRIM(patient.papmi_no), 2) as nhiterminaldigit
    , CASE WHEN COALESCE(patient.PAPMI_Active,'Y')='Y' THEN 'Y' ELSE 'N' END as currentflag
    , patient.PAPMI_RowId as patientid
    , patient.PAPMI_ID as primaryid
    , patient.PAPER_Name2 as firstname
    , COALESCE(patient.Paper_Name3, '') as secondname
    , '' as thirdname -- thirdname is not available in trak and this was not migrated
    , patient.PAPER_Name as surname
    , CASE WHEN patient.PAPER_Name2 IS NOT NULL THEN CONCAT(patient.PAPER_Name2,' ',patient.PAPER_Name)
           ELSE patient.PAPER_Name
           END as fullname
    , CASE   
       WHEN patient.TTL_Desc IS NULL AND patient.GENID_Code = 'female' THEN 'Ms'  
       WHEN patient.TTL_Desc IS NULL AND patient.GENID_Code = 'male' THEN 'Mr'  
       ELSE IFNULL(patient.TTL_Desc, 'Unknown') END as title
    , patient.PAPER_Dob as dateofbirth
    , upper(ifNull(left(patient.GENID_Code,1),'U')) as gendercode
    , patient.GENID_Desc as genderdesc
    , patient.PAPER_StName as addressline1
    , COALESCE(patient.PAPER_ForeignAddress, '') as addressline2
    , CASE WHEN patient.CTCIT_Desc is NULL THEN 'Unknown'
           ELSE patient.CTCIT_Desc
           END as suburb
    , CASE WHEN patient.prov_desc is NULL THEN 'Unknown'
           ELSE patient.prov_desc
           END as city
    , CASE WHEN patient.CTZIP_Code IS NULL THEN 'Unknown' ELSE patient.CTZIP_Code END as postcode
    , patient.PAPER_DomicileCode as domicilecode
    , COALESCE(patient.domiciledesc, 'Unknown') AS domiciledesc
    --, sql_get_current_domicile_desc(PAPER_DomicileCode) as domiciledesc
    , patient.dhbcode
    --,sql_get_current_dhb_code(PAPER_DomicileCode) as dhbcode
    , patient.dhbdesc
    --, sql_get_current_dhb_desc(PAPER_DomicileCode) as dhbdesc
    , CASE WHEN patient.CTCOU_Desc is NULL THEN 'Unknown'
           ELSE patient.CTCOU_Desc 
           END as country
    , patient.PAPER_TelH as phonehome
    , patient.PAPER_MobPhone as mobilephone
    , patient.PAPER_TelO as phoneother
    , COALESCE(patient.PAPER_Email, '') as emailaddress
    , COALESCE(emailval.EMVST_Code, 'N') as emailvalidationflag
    , patient.PAPER_Deceased_Date as dateofdeath
    , patient.asianflag
    , patient.pacificflag
    , patient.ethnicitycode 
    , patient.ethnicitydesc 
    , patient.ethnicity2code 
    , patient.ethnicity2desc 
    , patient.ethnicity3code
    , patient.ethnicity3desc
    , patient.ethnicity4code
    , patient.ethnicity4desc
    , patient.ethnicity5code
    , patient.ethnicity5desc 
    , patient.ethnicity6code
    , patient.ethnicity6desc
    , patient.ethnicitycode as ethnicitymohcode
    , patient.ethnicity2code as ethnicitymoh2code 
    , patient.ethnicity3code as ethnicitymoh3code 
    , patient.ethnicity4code as ethnicitymoh4code 
    , patient.ethnicity5code as ethnicitymoh5code 
    , patient.ethnicity6code as ethnicitymoh6code
    , patient.ethnicityprioritisedcode as ethnicityprioritisedcode 
    , patient.ethnicityprioritiseddesc as ethnicityprioritiseddesc
    , patient.PAPMI_EmailValidationStatus_DR as residentstatusid
    , COALESCE( patient.PAPER_NationalResident, 'U')  as nzresidentflag
    , CASE 
       WHEN patient.PAPER_NationalResident = 'N' THEN 'Y'
       ELSE 'N'
      END AS foreignpatientflag
    , '' as residentcountry               -- Not Required
    , COALESCE(patient.birthcountrycode, 'UNK') as birthcountrycode 
    , COALESCE(patient.birthcountrydesc, 'Unknown') as birthcountrydesc 
    , '9999-12-31' as countryentrydate              -- Not Required
    , patient.PAPPREQ_Remarks as countrycomment                 
    , ifnull(nextofkin.noktype,'') noktype
    , ifnull(nextofkin.nokname,'') nokname
    , ifnull(nextofkin.noksurname,'') noksurname
    , ifnull(nextofkin.nokphonehome,'') nokphonehome
    , ifnull(nextofkin.nokphoneother,'') nokphoneother
    , refdoctor.REFD_Code as gpcode
    , case 
       when refdoctor.REFD_Desc = 'Unknown' then refdoctor.REFD_Desc
       else CONCAT(ifnull(refdoctor.REFD_ForeName,'') ,' ' ,ifnull(refdoctor.REFD_Desc,'')) 
      end as gpname
    , refdoctor.REFD_Address as gpaddress
    , CONCAT ( ifnull(clinic.CLN_Desc,'') , ' , '  
             , ifnull(clinic.CLN_Address2,'') , ' , ' 
             , ifnull(clinic.CLN_Address1,'')) as gppracticeaddress
    , clinic.CLN_Code as gppracticecode
    , clinic.CLN_Desc as gppracticename
    , ifnull(preferredlanguage.PREFL_Desc,'') as language
    , CASE WHEN patient.PAPER_InterpreterRequired = 'Y' THEN 'Y'
           WHEN patient.PAPER_InterpreterRequired = 'N' THEN 'N'
           ELSE 'U'
           END AS interpreterflag    
    , coalesce(religion.CTRLG_Desc,'') as religion
    , CASE WHEN occupation.CTOCC_Desc is NULL THEN 'Unknown'
           ELSE occupation.CTOCC_Desc 
           END as occupation
    , COALESCE(patient.PAPER_Remark, '') as patientcomments
    , ifnull(marital.CTMAR_Code,'') as maritalstatuscode
    , COALESCE(
       CASE 
           WHEN  marital.CTMAR_CODE = 'S' THEN 'Single'
           WHEN marital.CTMAR_CODE = 'F' THEN 'De Facto'
           WHEN marital.CTMAR_CODE = 'U' THEN 'Unspecified'
           ELSE marital.CTMAR_Desc 
       END,'') AS maritalstatusdesc
    , CASE 
       WHEN patient.APPREQST_Desc IS NULL THEN 'Unknown'
       WHEN patient.APPREQST_Desc = 'Default Initial' THEN 'Unknown'
       ELSE patient.APPREQST_Desc
      END as eligibilitycategory
    , patient.APPREQST_Code as eligibilitystatus -- Not Required
    , patient.PAPPREQ_Date2 as eligiblefromdate  
    , CASE
       WHEN patient.PAPPREQ_ApprovValidUntilDate >= '2099-01-01' THEN '2050-05-05' 
       ELSE patient.PAPPREQ_ApprovValidUntilDate
      END  as eligibleuntildate
    , CASE WHEN patient.APPREQST_Code IN ('AUC','CE','MFAT','NZC','NZR','PR','WV1','EL') THEN 'Y' else "N" END  as eligibleallservicesflag       
    , Case when patient.APPREQST_Code IN ('AUC1','UK') THEN 'Y' else "N" END  as eligibleacutecareflag          
    , null as eligiblealcoholanddrugflag    -- Not Required
    , Case when patient.APPREQST_Code IN ('MC') THEN 'Y' else "N"  END   as eligiblematernityflag          
    , Case when patient.APPREQST_Code IN ('MH') THEN 'Y' else "N" END    as eligiblementalhealthflag      
    , null as eligibletuberculosisflag       -- Not Required
    , Case when patient.APPREQST_Code IN ('ID') THEN 'Y' else "N" END  as eligiblefundedidtreatflag    
    , CASE
       WHEN patient.APPREQST_Code IN ('AUC','CE','MFAT','NZC','NZR','PR','WV1','EL') THEN 'All Services'
       WHEN patient.APPREQST_Code IN ('AUC1','UK') THEN 'Acute Care'
       WHEN patient.APPREQST_Code = 'ID'	 THEN 'Infectious Disease'
       WHEN patient.APPREQST_Code = 'MC'	 THEN 'Maternity'
       WHEN patient.APPREQST_Code = 'MH'	 THEN 'Mental Health'
       ELSE 'Not Applicable' END   as alleligibleservices         
    , coalesce(patient.PAPER_PassportNumber,'') as passportno
    , patient.PAPER_TravelVisaEndDate    as visaexpirydate
    , patient.PAPER_TravelVisaNumber as nzisclientno
    , ifnull(patient.mhcdt_code,'') as legalstatuscode                 
    , ifnull(patient.mhcdt_desc,'') as legalstatusdesc                
    , null as covid19dosenumber             -- Not Required
    , null as covid19dayssincedose          -- Not Required
    , patient.CTSEX_Code as sexcode
    , patient.CTSEX_Desc as sexdesc 
    , 'TRAK'  as sourcecode   
FROM silver_db.vw_tc_s_patient as patient
LEFT JOIN bronze.tc_l_ct_religion as religion on patient.PAPER_Religion_DR = religion.CTRLG_RowId
LEFT JOIN bronze.tc_l_pac_refdoctor as refdoctor on patient.PAPER_FamilyDoctor_DR = refdoctor.REFD_RowId
LEFT JOIN bronze.tc_l_pac_refdoctorclinic as refdoctorclinic on patient.PAPER_FamilyDoctorClinic_DR = refdoctorclinic.CLN_RowId
LEFT JOIN bronze.tc_l_pac_clinic as clinic on refdoctorclinic.CLN_Clinic_DR = clinic.CLN_RowId
LEFT JOIN bronze.tc_l_pac_preferredlanguage as preferredlanguage on patient.PAPER_PrefLanguage_DR = preferredlanguage.PREFL_RowId
LEFT JOIN bronze.tc_l_ct_occupation as occupation on patient.PAPER_Occupation_DR = occupation.CTOCC_RowId
LEFT JOIN bronze.tc_l_ct_marital as marital on patient.PAPER_Marital_DR = marital.CTMAR_RowID
LEFT JOIN bronze.tc_l_pa_mergepatient on tc_l_pa_mergepatient.MRG_PAPMI_to_DR = patient.PAPMI_RowId
LEFT JOIN bronze.tc_l_pa_patmas_main pa_patmas_from on pa_patmas_from.PAPMI_RowId = tc_l_pa_mergepatient.MRG_PAPMI_From_DR 
LEFT JOIN (
            SELECT 
                  ROW_NUMBER() OVER (PARTITION BY nok.NOK_PAPMI_ParRef  order by NOK_Rank asc ) as NokRowNumber
                , greatest(nok.processing_time,re.processing_time) processing_time 
                , nok.NOK_PAPMI_ParRef
                , coalesce(nok.NOK_Name2, person.PAPER_Name2) as nokname
                , nok.NOK_TelH as nokphonehome
                , nok.NOK_TelO as nokphoneother
                , coalesce(nok.NOK_Name, person.PAPER_Name) as noksurname
                , CASE WHEN re.CTRLT_Desc IS null THEN 'Unknown'
                       ELSE re.CTRLT_Desc
                       END as noktype
            FROM bronze.tc_l_PA_Nok nok 
            LEFT JOIN bronze.tc_l_CT_Relation re on nok.NOK_Relation_DR = re.CTRLT_RowId
            LEFT JOIN bronze.tc_l_pa_person person ON nok.NOK_PAPER_DR = person.PAPER_RowId
            --WHERE NOK_Inactive = 'N' 
            ) nextofkin 
            on patient.PAPMI_RowId = nextofkin.NOK_PAPMI_ParRef and nextofkin.NokRowNumber = 1
LEFT JOIN  bronze.tc_l_pac_emailvalidationstatus as  emailval   on patient.PAPMI_EmailValidationStatus_DR = EMVST_RowId 

where     (date(patient.watermarkvalue)    >= '{v_watermark_date}'
           or
           date(religion.processing_time)    >= '{v_watermark_date}'
           or
           date(refdoctor.processing_time)    >= '{v_watermark_date}'
           or
           date(refdoctorclinic.processing_time)    >= '{v_watermark_date}'
           or
           date(clinic.processing_time)    >= '{v_watermark_date}'
           or
           date(preferredlanguage.processing_time)    >= '{v_watermark_date}'
           or
           date(occupation.processing_time)    >= '{v_watermark_date}'
           or
           date(nextofkin.processing_time)    >= '{v_watermark_date}'
        )   
""")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Update the target table

# COMMAND ----------

# this dataframe is required for the merge function
df_view = spark.sql("SELECT * FROM vw_s_patient")

from pyspark.sql.functions import sha2, concat_ws

# obtain the list of column to be used to generate the hashid column: it should include all columns except the watermark
lst_cols = df_view.columns
lst_cols.remove('watermarkvalue')

# add hashid column to the view dataframe
df_hashed = df_view.withColumn("hashid",sha2(concat_ws('|', *lst_cols),256))

# COMMAND ----------

# set the merge condition required for the merge functions
merge_condition = 'TARGET.patientid = SOURCE.patientid'

# to update the true delta records
match_additional_condition = 'TARGET.hashid <> SOURCE.hashid'

# call merge function
merge_delta_tables(df_hashed, v_target_database, v_target_table_name, merge_condition, match_additional_condition )

# COMMAND ----------

# write to the ADM_LOG.etl.LogOverview table on MI the output from the merge 
insert_into_log_overview(v_target_database, v_target_table_name, v_etlcontrolid, v_sourcesystem, v_target_database[0], v_batchid)

# COMMAND ----------

# MAGIC %md
# MAGIC ####Validation Checks

# COMMAND ----------

# DBTITLE 1,No Duplicates and NULL values
# v_grain = 'tcpatientid'
# v_columns_exclude = ''

# check_for_duplicates (v_target_database, v_target_table_name, v_grain, v_columns_exclude)
# check_for_null_values(v_target_database, v_target_table_name, v_grain, v_columns_exclude)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Post-processing

# COMMAND ----------

# DBTITLE 1,Export deltas to parquet file
# Saving the changes in the target table as a parquet file to be consumed by Titan (via ADF).
if v_watermark_date == v_new_watermark_value.strftime("%Y-%m-%d") : 
    wmrk = '9999-01-01' 
else: 
    wmrk = v_new_watermark_value

# produce an empty dataframe if old and new watermark have the same value
df_s_parquet = get_df_titan(v_target_database,v_target_table_name, wmrk)
write_parquet_for_export(df_s_parquet, silver_folder_path, trakcare_export_parquet, v_target_table_name, 'overwrite')

# COMMAND ----------

# DBTITLE 1,Update WaterMarkValue
# update the etl.Control table WaterMarkValue with the latest processing date from the RDS joining tables
# if the old and the new watermark dates have different values
if v_watermark_date != v_new_watermark_value.strftime("%Y-%m-%d") : 
    update_mi_water_mark_value (v_new_watermark_value, v_etlcontrolid , 'Control_TRAK')
