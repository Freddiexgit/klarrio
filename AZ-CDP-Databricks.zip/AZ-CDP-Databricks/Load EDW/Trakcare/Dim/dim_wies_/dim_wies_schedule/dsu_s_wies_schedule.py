# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 27-Feb-2024 | 1       | Donne | Create first draft of tc_s_wies_schedule using dummy data    |
# MAGIC | 27-Mar-2024 | 2       | Gery Smith     | Switch to Control_TRAK |
# MAGIC |03-Apr-2024| 3 |Daniel Menary| update SQL |
# MAGIC |08-Apr-2024| 4 |Daniel Menary| change to dsu naming convention  |
# MAGIC |24-Apr-2024| 4 |Daniel Menary| update merge condition  |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# Use the function below if you need to reset the development and start from scratch.
# reset_table('silver_db', 'trakcare', 'dsu_s_wies_schedule', 1823, 'Control_TRAK')

# COMMAND ----------

# DBTITLE 1,Variables
# p_etlcontrolid is passed as a parameter from ADF
dbutils.widgets.text("p_batchid","0")
v_batchid = int(dbutils.widgets.get("p_batchid"))
dbutils.widgets.text("p_etlcontrolid","1823")
v_etlcontrolid = dbutils.widgets.get("p_etlcontrolid")

# COMMAND ----------

# Create variable from etl.Control table
# WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
qry = f"""
       SELECT 
              ETLControlID
            , SourceSystem
            , SourceSystemType
            , SourceTableSchemaName
            , SourceTableName
            , CASE WHEN IncrementalLoad = 1 THEN WaterMarkValue ELSE '1900-01-01' END WaterMarkValue
            , TargetSystemType
            , TargetTableSchemaName
            , TargetTableName
            , IncrementalLoad
            , IsActive
            , TargetEntityPath
            , CustomConfig
        FROM ADM_CONFIG.etl.Control_TRAK
        WHERE ETLControlID = {v_etlcontrolid}"""

df_control = read_from_mi_db('ADM_CONFIG', qry)

v_watermark_date = df_control.select("WaterMarkValue").collect()[0][0]
v_target_table_name = df_control.select("TargetTableName").collect()[0][0]
v_target_database = df_control.select("CustomConfig").collect()[0][0]
v_sourcesystem = 'trakcare'
v_target_entity_path = df_control.select("TargetEntityPath").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,Set new WaterMarkValue
# New WaterMarkValue is the latest processing date across all RDS joining tables
v_new_watermark_value = spark.sql("""
select   date(max(watermark)) v_new_watermark_value
from 
    (
    select max(processing_time) watermark from bronze.dsu_l_map_version_discharge_date 
    union
    select max(processing_time) watermark from bronze.dsu_l_map_victorian_weights 
    union
    select max(processing_time) watermark from bronze.dsu_l_drg 
    ) qry
""").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,Create Table
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {v_target_database}.{v_target_table_name}
(
watermarkvalue timestamp 
,hashid string
,wiesversion string
,drgcode string
,drgdesc string
,wiesstartdate timestamp
,wiesenddate timestamp
,drgversion string
,financialyear string
,lowboundarylos float
,highboundarylos float
,avginlierlos float
,mechventcopayment string
,samedayoneday string
,coelig string
,samedayweight float
,onedayweight float
,lowoutlierperdiem float
,inlierweight float
,highoutlierperdiem float
,medsurgindicator string
,clustercode string
,severitycode string
,sourcecode string
)
USING DELTA
LOCATION '{silver_folder_path}trakcare/{v_target_table_name}'
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Processing

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Create Temp View with Changes only

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE TEMP VIEW vw_s_wies_schedule
AS
SELECT
'{v_new_watermark_value}' as watermarkvalue,
'' hashid ,
s_wies_schedule_v.WIESVersion,
s_wies_schedule_v.DRGCode,
s_wies_schedule_v.DRGDesc,
s_wies_schedule_v.WIESStartDate,
s_wies_schedule_v.WIESEndDate,
s_wies_schedule_v.DRGVersion,
s_wies_schedule_v.FinancialYear,
s_wies_schedule_v.LowBoundaryLOS,
s_wies_schedule_v.HighBoundaryLOS,
s_wies_schedule_v.AvgInlierLOS,
s_wies_schedule_v.MechVentCopayment,
s_wies_schedule_v.SameDayOneDay,
s_wies_schedule_v.Coelig,
s_wies_schedule_v.SameDayWeight,
s_wies_schedule_v.OneDayWeight,
s_wies_schedule_v.LowOutlierPerDiem,
s_wies_schedule_v.InlierWeight,
s_wies_schedule_v.HighOutlierPerDiem,
CASE WHEN Prior_To_V4 = 1 THEN Partition_Code
WHEN s_wies_schedule_v.DRGCode = '999' THEN 'U'
WHEN cast( SUBSTRING(s_wies_schedule_v.DRGCode,2,2) as INT) BETWEEN 40 AND 59 and s_wies_schedule_v.WIESStartDate < '2023-07-01' THEN 'O'
WHEN cast( SUBSTRING(s_wies_schedule_v.DRGCode,2,2) as INT) BETWEEN 60 AND 99 and s_wies_schedule_v.WIESStartDate < '2023-07-01' THEN 'M'
WHEN cast( SUBSTRING(s_wies_schedule_v.DRGCode,2,2) as INT) BETWEEN 00 AND 39 and s_wies_schedule_v.WIESStartDate < '2023-07-01' THEN 'S'
WHEN cast( SUBSTRING(s_wies_schedule_v.DRGCode,2,2) as INT) BETWEEN 00 AND 59 and s_wies_schedule_v.WIESStartDate >= '2023-07-01' THEN 'I'
WHEN cast( SUBSTRING(s_wies_schedule_v.DRGCode,2,2) as INT) BETWEEN 60 AND 99 and s_wies_schedule_v.WIESStartDate >= '2023-07-01' THEN 'M'
ELSE 'U'
END MedSurgIndicator,
CASE WHEN Prior_To_V4 = 1 THEN Cluster_Code
ELSE LEFT(s_wies_schedule_v.DRGCode,3)
END ClusterCode,
CASE WHEN Prior_To_V4 = 1 THEN Severity
WHEN LEN(RTRIM(s_wies_schedule_v.DRGCode)) = 4 THEN RIGHT(RTRIM(s_wies_schedule_v.DRGCode),1)
ELSE 'N/A'
END SeverityCode,
'TRAK' SourceCode 
FROM  
(SELECT
w.version as wiesversion ,
v.WIESStartDate,
v.WIESEndDate,
w.code drgcode,
w.drg_description  as drgdesc,
v.DRGVersion,
v.FinancialYear,
w.lowboundary  as lowboundarylos,
w.highboundary  as highboundarylos,
w.avginlierlos,
w.mechvent_copayment  as MechVentCopayment,
w.same_day_one_day  as SameDayOneDay,
w.coelig,
w.same_day_weight  as SameDayWeight,
w.one_day_weight  as OneDayWeight,
w.low_outlier_per_diem as LowOutlierPerDiem,
w.weights_inlier  as InlierWeight,
w.high_outlier_per_diem  as HighOutlierPerDiem
FROM
	(SELECT
	wies_version_desc WIESVersion,
	cast(    MIN(date_from)  as date ) WiesStartDate,
	cast(    MAX(date_to)    as date ) WiesEndDate,
	MIN(drg_version_desc) DRGVersion, 
	concat(cast( YEAR(MIN(date_from)) as varchar(12) ) ,'/',  cast( YEAR(MAX(date_from)) as varchar(12) ) ) FinancialYear
	FROM  bronze.dsu_l_map_version_discharge_date
	WHERE date_from >= '1999-07-01'
	GROUP BY wies_version_desc ) v
LEFT OUTER JOIN   bronze.dsu_l_map_victorian_weights w
ON v.WIESVersion = w.version
WHERE w.version IS NOT NULL) s_wies_schedule_v
LEFT OUTER JOIN bronze.dsu_l_drg 
ON s_wies_schedule_v.DRGCode = dsu_l_drg.DRG_Code
""")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Update the target table

# COMMAND ----------

# this dataframe is required for the merge function
df_view = spark.sql("SELECT * FROM vw_s_wies_schedule")

from pyspark.sql.functions import sha2, concat_ws

# obtain the list of column to be used to generate the hashid column: it should include all columns except the watermark
lst_cols = df_view.columns
lst_cols.remove('watermarkvalue')

# add hashid column to the view dataframe
df_hashed = df_view.withColumn("hashid",sha2(concat_ws('|', *lst_cols),256))

# COMMAND ----------

# set the merge condition required for the merge functions
merge_condition = 'TARGET.drgcode = SOURCE.drgcode AND  TARGET.wiesversion = SOURCE.wiesversion  and  TARGET.WIESStartDate = SOURCE.WIESStartDate and  TARGET.WIESEndDate = SOURCE.WIESEndDate' 

# to update the true delta records
match_additional_condition = 'TARGET.hashid <> SOURCE.hashid'

# call merge function
merge_delta_tables(df_hashed, v_target_database, v_target_table_name, merge_condition, match_additional_condition )

# COMMAND ----------

# write to the ADM_LOG.etl.LogOverview table on MI the output from the merge 
insert_into_log_overview(v_target_database, v_target_table_name, v_etlcontrolid, v_sourcesystem, v_target_database[0])

# COMMAND ----------

# MAGIC %md
# MAGIC ####Validation Checks

# COMMAND ----------

# DBTITLE 1,No Duplicates and NULL values
# v_grain = 'drgcode'
# v_columns_exclude = ''

# check_for_duplicates (v_target_database, v_target_table_name, v_grain, v_columns_exclude)
# check_for_null_values(v_target_database, v_target_table_name, v_grain, v_columns_exclude)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Post-processing

# COMMAND ----------

# DBTITLE 1,Export deltas to parquet file
# Saving the changes in the target table as a parquet file to be consumed by Titan (via ADF).
if v_watermark_date == v_new_watermark_value.strftime("%Y-%m-%d") : 
    wmrk = '9999-01-01' 
else: 
    wmrk = v_new_watermark_value

# produce an empty dataframe if old and new watermark have the same value
df_s_parquet = get_df_titan(v_target_database,v_target_table_name, wmrk)
write_parquet_for_export(df_s_parquet, silver_folder_path, trakcare_export_parquet, v_target_table_name, 'overwrite')

# COMMAND ----------

# DBTITLE 1,Update WaterMarkValue
# update the etl.Control table WaterMarkValue with the latest processing date from the RDS joining tables
# if the old and the new watermark dates have different values
if v_watermark_date != v_new_watermark_value.strftime("%Y-%m-%d") : 
    update_mi_water_mark_value (v_new_watermark_value, v_etlcontrolid, 'Control_TRAK')
