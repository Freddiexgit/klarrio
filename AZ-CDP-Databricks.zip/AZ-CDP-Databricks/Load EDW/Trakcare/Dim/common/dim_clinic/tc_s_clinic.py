# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 03-May-2023 | 1       | Janesa Ramirez | Create first draft of tc_s_clinic                                          |
# MAGIC | 13-Jun-2023 | 2       | Mahi Ethiraj   | Entire table has been re-mapped. Making changes accordingly                |
# MAGIC | 30-Jun-2023 | 3       | Mahi Ethira    | Added new column from drop 7       
# MAGIC | 19-Jul-2023 | 4       | Gopesh    | Added new column from drop 9                                         |
# MAGIC | 19-Jul-2023 | 5       | Janesa    | Added new column from drop 10                                         |
# MAGIC | 02-Aug-2023 | 6      | Donne    | Changed clinicid from loc.CTLOC_RowID to equipment.EQ_RowId                                         |
# MAGIC |  |   |    | Created temp version of tc_l_rb_resource to get rid of duplicates                                        |
# MAGIC | 25-Jan-2024 | 7   | Donne   | Recoded based on remodelling to CT_Loc as main source table. Previous version saved as tc_s_clinic_OLD                                        |
# MAGIC | 09-Feb-2024 | 8   | Donne   | Changed ref_ to dsu_                                        |
# MAGIC | 13-Feb-2024 | 9   | Donne   | Added clinicgroupingdesc                                      |
# MAGIC | 27-Mar-2024 | 10   | Gery   | Switch to Control_TRAK |
# MAGIC | 20-06-2024 | 11   | Dan Menary   | recon fixes |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
#%run "../../../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# Use the function below if you need to reset the development and start from scratch.
# reset_table('silver_db', 'trakcare', 'tc_s_clinic', 1539, 'Control_TRAK')

# COMMAND ----------

# DBTITLE 1,Variables
# p_etlcontrolid is passed as a parameter from ADF
dbutils.widgets.text("p_batchid","0")
v_batchid = int(dbutils.widgets.get("p_batchid"))
dbutils.widgets.text("p_etlcontrolid","1539")
v_etlcontrolid = dbutils.widgets.get("p_etlcontrolid")

# COMMAND ----------

# Create variable from etl.Control table
# WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
qry = f"""
       SELECT 
              ETLControlID
            , SourceSystem
            , SourceSystemType
            , SourceTableSchemaName
            , SourceTableName
            , CASE WHEN IncrementalLoad = 1 THEN WaterMarkValue ELSE '1900-01-01' END WaterMarkValue
            , TargetSystemType
            , TargetTableSchemaName
            , TargetTableName
            , IncrementalLoad
            , IsActive
            , TargetEntityPath
            , CustomConfig
        FROM ADM_CONFIG.etl.Control_TRAK 
        WHERE ETLControlID = {v_etlcontrolid}"""

df_control = read_from_mi_db('ADM_CONFIG', qry)

v_watermark_date = df_control.select("WaterMarkValue").collect()[0][0]
v_target_table_name = df_control.select("TargetTableName").collect()[0][0]
v_target_database = df_control.select("CustomConfig").collect()[0][0]
v_sourcesystem = 'trakcare'
v_target_entity_path = df_control.select("TargetEntityPath").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,Set new WaterMarkValue
# New WaterMarkValue is the latest processing date across all RDS joining tables
v_new_watermark_value = spark.sql("""
SELECT DATE(MAX(watermark)) v_new_watermark_value
from 
    (
    SELECT max(processing_time) watermark FROM  bronze.tc_l_ct_loc 
    UNION
    SELECT max(processing_time) watermark FROM bronze.tc_l_ct_hospital 
    UNION
    SELECT max(processing_time) watermark FROM bronze.tc_l_rbc_equipment 
    UNION
    SELECT max(processing_time) watermark FROM bronze.tc_l_ct_significantfacility
    ) qry
""").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,Create Table
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {v_target_database}.{v_target_table_name}
( 
  watermarkvalue timestamp
 ,hashid string
 ,cbucode string
 ,cbudesc string
 ,clinicid int
 ,cliniccode string
 ,clinicdesc string
 ,cliniclocation string
 ,clinicsecureflag string
 ,clinicactiveflag string
 ,clinichl7code string
 ,clinicgroupingdesc string
 ,espi2flag string
 ,directoratecode string
 ,directoratedesc string
 ,facilityactiveflag string
 ,facilityhl7code string
 ,siteabbr string
 ,sitename string
 ,ResourceUnitRCCode string
 ,CostingRCCode	string
, sourcecode string
 )
USING DELTA
LOCATION '{silver_folder_path}trakcare/{v_target_table_name}'
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Processing

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Create Temp View with Changes only

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE TEMP VIEW vw_s_clinic
AS

SELECT 
'{v_new_watermark_value}' AS watermarkvalue
,cbu.cbu_code as cbucode
,cbu.cbu_desc as cbudesc
,clinic.CTLOC_RowId as clinicid 
,clinic.CTLOC_Code as cliniccode         
,clinic.CTLOC_Desc as clinicdesc 
,clinic.CTLOC_Address cliniclocation 
,'N' as clinicsecureflag
,CASE
    WHEN clinic.CTLOC_DateActiveTo IS NULL THEN 'Y'
    WHEN to_date(from_utc_timestamp(now() ,'Pacific/Auckland')) <= clinic.CTLOC_DateActiveTo THEN 'Y'
    ELSE 'N'
 END as clinicactiveflag
,clinic.CTLOC_NationCode as clinichl7code
,COALESCE(cg.ClinicGroupingDesc,clinic.CTLOC_Desc) AS clinicgroupingdesc  
,NULL AS espi2flag -- ESPI2 Flags will not be linked to Clinics in TrakCare
--,directorate.SIGNF_Code directoratecode 
--,directorate.SIGNF_Desc directoratedesc 
, rtrim(sp.directoratecode) as directoratecode 
, sp.directoratedesc as directoratedesc 
, case when clinic.CTLOC_ActiveFlag = 1 then 'Y' else 'N' end as facilityactiveflag 
,directorate.SIGNF_Code as facilityhl7code  -- not in Trak yet
, CASE
    WHEN hospital.HOSP_Code = 'MH1' THEN 'AKCH'
    WHEN hospital.HOSP_Code = '3260B' THEN 'SSH'
    WHEN hospital.HOSP_Code = '3260' THEN 'AKCH'
    WHEN hospital.HOSP_Code = '3260A' THEN 'GLCC'
    WHEN hospital.HOSP_Code = '3245' THEN 'CMH'
    ELSE NULL
    END	as siteabbr
,hospital.Hosp_desc as sitename 
,respunit.RU_Code as ResourceUnitRCCode
,dsu_resource_unit.PCM_RC_Code  as CostingRCCode	
,'TRAK' as sourcecode
FROM 
bronze.tc_l_ct_loc AS clinic
LEFT JOIN bronze.tc_l_ct_significantfacility as directorate on clinic.CTLOC_SignifFacility_DR = directorate.SIGNF_RowId
LEFT JOIN bronze.tc_l_ct_hospital hospital on clinic.ctloc_hospital_dr = hospital.hosp_rowid
LEFT JOIN bronze.tc_l_ct_responsibleunit respunit ON clinic.CTLOC_RespUnit_DR = respunit.RU_RowId
LEFT JOIN bronze.dsu_l_cbu_link cbu ON respunit.RU_RowId=cbu.cbu_id
LEFT JOIN bronze.dsu_l_clinicgroupingmapping cg ON clinic.CTLOC_RowId=cg.clinicid
LEFT JOIN silver_db.vw_tc_s_specialty sp ON cbu.Sub_Specialty_Id = sp.subspecialtyid
--left outer join bronze.tc_l_ct_responsibleunit as ru on clinic.CTLOC_RowID = ru.resource_unit_id
LEFT OUTER JOIN bronze.dsu_l_resource_unit dsu_resource_unit   ON clinic.CTLOC_RowID = dsu_resource_unit.resource_unit_id

WHERE 
clinic.CTLOC_Type = 'CL'
AND 
(
DATE(clinic.processing_time) >= '{v_watermark_date}'
OR DATE(directorate.processing_time) >= '{v_watermark_date}'
OR DATE(hospital.processing_time) >= '{v_watermark_date}'
OR DATE(respunit.processing_time) >= '{v_watermark_date}'
)
""")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Update the target table

# COMMAND ----------

# this dataframe is required for the merge function
df_view = spark.sql("SELECT * FROM vw_s_clinic")

from pyspark.sql.functions import sha2, concat_ws

# obtain the list of column to be used to generate the hashid column: it should include all columns except the watermark
lst_cols = df_view.columns
lst_cols.remove('watermarkvalue')

# add hashid column to the view dataframe
df_hashed = df_view.withColumn("hashid",sha2(concat_ws('|', *lst_cols),256))

# COMMAND ----------

# set the merge condition required for the merge functions
merge_condition = 'TARGET.clinicid = SOURCE.clinicid'
match_additional_condition = 'TARGET.hashid <> SOURCE.hashid'
merge_delta_tables(df_hashed, v_target_database, v_target_table_name, merge_condition, match_additional_condition )

# COMMAND ----------

# write to the ADM_LOG.etl.LogOverview table on MI the output from the merge 
insert_into_log_overview(v_target_database, v_target_table_name, v_etlcontrolid, v_sourcesystem, v_target_database[0], v_batchid)

# COMMAND ----------

# MAGIC %md
# MAGIC ####Validation Checks

# COMMAND ----------

# DBTITLE 1,No Duplicates and NULL values
# v_grain = 'tcclinicid'
# v_columns_exclude = ''

# check_for_duplicates (v_target_database, v_target_table_name, v_grain, v_columns_exclude)
# check_for_null_values(v_target_database, v_target_table_name, v_grain, v_columns_exclude)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Post-processing

# COMMAND ----------

# DBTITLE 1,Export deltas to parquet file
# Saving the changes in the target table as a parquet file to be consumed by Titan (via ADF).
if v_watermark_date == v_new_watermark_value.strftime("%Y-%m-%d") : 
    wmrk = '9999-01-01' 
else: 
    wmrk = v_new_watermark_value

# produce an empty dataframe if old and new watermark have the same value
df_s_parquet = get_df_titan(v_target_database,v_target_table_name, wmrk)
write_parquet_for_export(df_s_parquet, silver_folder_path, trakcare_export_parquet, v_target_table_name, 'overwrite')

# COMMAND ----------

# DBTITLE 1,Update WaterMarkValue
# update the etl.Control table WaterMarkValue with the latest processing date from the RDS joining tables
# if the old and the new watermark dates have different values
if v_watermark_date != v_new_watermark_value.strftime("%Y-%m-%d") : 
    update_mi_water_mark_value (v_new_watermark_value, v_etlcontrolid, 'Control_TRAK')

# COMMAND ----------

df = spark.read.parquet(f"{silver_folder_path}{trakcare_export_parquet}{v_target_table_name}")
display(df.count())
