# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 30-Mar-2023 | 1       | Mahi Ethiraj   | Create first draft of stc_s_event_typetage_table_name                      |
# MAGIC | 01-May-2023 | 2       | Mahi Ethiraj   | Add a new BK tceventtypeid and amend the merge condition                   |
# MAGIC | 16-Aug-2023 | 3       | Gery Smith  | Add sourcecode                  |
# MAGIC | 07-Feb-2024 | 4       | Gery Smith  | Replace ref_l_ with dsu_l_                  |
# MAGIC | 27-Mar-2024 | 5       | Gery Smith  | Switch to Control_TRAK  |
# MAGIC | 24-Jul-2024 | 6       | ArvinC      | changed filters as per mapping |
# MAGIC | 24-Jul-2024 | 7       | Daniel Menary     | updae to cct.Item_Desc as eventtypedesc |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
#%run "../../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# Use the function below if you need to reset the development and start from scratch.  
# reset_table('silver_db', 'trakcare', 'tc_s_event_type', 1621, 'Control_TRAK')

# COMMAND ----------

# DBTITLE 1,Variables
# p_etlcontrolid is passed as a parameter from ADF
dbutils.widgets.text("p_batchid","0")
v_batchid = int(dbutils.widgets.get("p_batchid"))

dbutils.widgets.text("p_etlcontrolid","1621")
v_etlcontrolid = dbutils.widgets.get("p_etlcontrolid")

# COMMAND ----------

# Create variable from etl.Control table
# WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
qry = f"""
       SELECT 
              ETLControlID
            , SourceSystem
            , SourceSystemType
            , SourceTableSchemaName
            , SourceTableName
            , CASE WHEN IncrementalLoad = 1 THEN WaterMarkValue ELSE '1900-01-01' END WaterMarkValue
            , TargetSystemType
            , TargetTableSchemaName
            , TargetTableName
            , IncrementalLoad
            , IsActive
            , TargetEntityPath
            , CustomConfig
        FROM ADM_CONFIG.etl.Control_TRAK
        WHERE ETLControlID = {v_etlcontrolid}"""

df_control = read_from_mi_db('ADM_CONFIG', qry)

v_watermark_date = df_control.select("WaterMarkValue").collect()[0][0]
v_target_table_name = df_control.select("TargetTableName").collect()[0][0]
v_target_database = df_control.select("CustomConfig").collect()[0][0]
v_sourcesystem = 'trakcare'
v_target_entity_path = df_control.select("TargetEntityPath").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,Set new WaterMarkValue
# New WaterMarkValue is the latest processing date across all RDS joining tables
v_new_watermark_value = spark.sql("""
select   date(max(watermark)) v_new_watermark_value
from 
    (
    select max(processing_time) watermark from  bronze.tc_l_pac_caretype 
    union
    select max(processing_time) watermark from bronze.dsu_l_cct
    ) qry
""").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,Create Table
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {v_target_database}.{v_target_table_name}
(
  eventtypeid Integer
 ,eventtypecode string
 ,eventtypedesc string
 ,inout string
 ,tceventtypeid Integer
 ,watermarkvalue timestamp
 ,hashid string 
 , sourcecode string
 )
USING DELTA
LOCATION '{silver_folder_path}trakcare/{v_target_table_name}'
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Processing

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Create Temp View with Changes only

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE TEMP VIEW vw_s_event_type
AS
SELECT 
      ct.CARETYP_RowId as eventtypeid
     ,ct.CARETYP_Code as eventtypecode
     ,cct.Item_Desc as eventtypedesc
     ,CASE WHEN   ct.CARETYP_Code = 'RES' THEN 'C' 
          WHEN  cct.CCT_Name = 'Trak Event Type Outpatient' THEN 'O'
          ELSE 'I'
          END   as inout        
    ,ct.CARETYP_RowId as tceventtypeid
    ,'{v_new_watermark_value}' AS Watermarkvalue
    , 'TRAK' as sourcecode
FROM bronze.tc_l_pac_caretype as ct 
LEFT JOIN bronze.dsu_l_cct as cct on ct.CARETYP_Code = cct.item_code and cct.CCT_Name LIKE 'Trak Event Type %'
WHERE (date(ct.CARETYP_DateTo) >= getdate() OR date(ct.CARETYP_DateTo) IS NULL);
""")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Update the target table

# COMMAND ----------

# this dataframe is required for the merge function
df_view = spark.sql("SELECT * FROM vw_s_event_type")

from pyspark.sql.functions import sha2, concat_ws
# obtain the list of column to be used to generate the hashid column: it should include all columns
lst_cols = df_view.columns
lst_cols.remove('Watermarkvalue')
df_hashed = df_view.withColumn("hashid",sha2(concat_ws('|', *lst_cols),256))

# COMMAND ----------

# set the merge condition required for the merge functions
merge_condition = 'TARGET.eventtypeid = SOURCE.eventtypeid'
matched_additional_condition = 'TARGET.hashid <> SOURCE.hashid'
merge_delta_tables(df_hashed, v_target_database, v_target_table_name, merge_condition)

# COMMAND ----------

# write to the ADM_LOG.etl.LogOverview table on MI the output from the merge 
v_loadtype = 's'
insert_into_log_overview(v_target_database, v_target_table_name, v_etlcontrolid, v_sourcesystem,v_loadtype,v_batchid)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Validation Checks

# COMMAND ----------

# DBTITLE 1,No Duplicates and NULL values
 #v_grain = 'tceventtypeid'
 #v_columns_exclude = ''

 #check_for_duplicates (v_target_database, v_target_table_name, v_grain, v_columns_exclude)
 #check_for_null_values(v_target_database, v_target_table_name, v_grain, v_columns_exclude)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Post-processing

# COMMAND ----------

# DBTITLE 1,Export deltas to parquet file
# Saving the changes in the target table as a parquet file to be consumed by Titan (via ADF).
if v_watermark_date == v_new_watermark_value.strftime("%Y-%m-%d") : 
    wmrk = '9999-01-01' 
else: 
    wmrk = v_new_watermark_value

# produce an empty dataframe if old and new watermark have the same value
df_s_parquet = get_df_titan(v_target_database,v_target_table_name, wmrk)
write_parquet_for_export(df_s_parquet, silver_folder_path, v_target_entity_path, v_target_table_name, 'overwrite')

# COMMAND ----------

# DBTITLE 1,Update WaterMarkValue
# update the etl.Control table WaterMarkValue with the latest processing date from the RDS joining tables
# if the old and the new watermark dates have different values
if v_watermark_date != v_new_watermark_value.strftime("%Y-%m-%d") : 
    update_mi_water_mark_value (v_new_watermark_value, v_etlcontrolid, 'Control_TRAK')
