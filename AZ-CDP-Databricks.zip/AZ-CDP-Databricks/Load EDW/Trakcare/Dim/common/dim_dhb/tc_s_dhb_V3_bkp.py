# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 29-May-2023 | 1       | Mahi Ethiraj   | Create first draft of tc_s_dhb. More columns to be mapped                  |
# MAGIC | 13-Jun-2023 | 2       | Mahi Ethiraj   | Adding newly mapped columns to tc_s_dhb - ref TTTENG 823                   |
# MAGIC | 16-Aug-2023 | 3       | Gery Smith    | Adding sourcecode                 |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from silver_db.vw_tc_s_dhb

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# DBTITLE 1,Variables
# p_etlcontrolid is passed as a parameter from ADF
dbutils.widgets.text("p_batchid","0")
v_batchid = int(dbutils.widgets.get("p_batchid"))
dbutils.widgets.text("p_etlcontrolid","1592")
v_etlcontrolid = dbutils.widgets.get("p_etlcontrolid")

# COMMAND ----------

# Use the function below if you need to reset the development and start from scratch.  
# reset_table('silver_db', 'trakcare', 'tc_s_dhb', 1592)

# COMMAND ----------

# Create variable from etl.Control table
# WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
qry = f"""
       SELECT 
              ETLControlID
            , SourceSystem
            , SourceSystemType
            , SourceTableSchemaName
            , SourceTableName
            , CASE WHEN IncrementalLoad = 1 THEN WaterMarkValue ELSE '1900-01-01' END WaterMarkValue
            , TargetSystemType
            , TargetTableSchemaName
            , TargetTableName
            , IncrementalLoad
            , IsActive
            , TargetEntityPath
            , CustomConfig
        FROM ADM_CONFIG.etl.Control 
        WHERE ETLControlID = {v_etlcontrolid}"""

df_control = read_from_mi_db('ADM_CONFIG', qry)

v_watermark_date = df_control.select("WaterMarkValue").collect()[0][0]
v_target_table_name = df_control.select("TargetTableName").collect()[0][0]
v_target_database = df_control.select("CustomConfig").collect()[0][0]
v_sourcesystem = 'trakcare'
v_target_entity_path = df_control.select("TargetEntityPath").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,Set new WaterMarkValue
# New WaterMarkValue is the latest processing date across all RDS joining tables
v_new_watermark_value = spark.sql("""
select   date(max(watermark)) v_new_watermark_value
from 
    (
    select max(processing_time) watermark from  bronze.tc_l_pac_trust
    union
    select max(processing_time) watermark from  bronze.ref_l_dhb
    ) qry
""").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,Create Table
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {v_target_database}.{v_target_table_name}
(
  watermarkvalue timestamp 
 ,hashid string
 ,tcdhbid int
 ,dhbcode string
 ,dhbdesc string
 ,dhbmohdesc string
 ,dhbgroup string
 ,dhbsplit string
 ,dhbnorthernregion string
 ,dhbnorthern string
 ,dhbregion string
 ,dhbregionak string
 ,dhbcar string
 ,dhbtrim string
 ,dhbabbr string
 ,dhblongdesc string
 ,dhbcmsid int
 ,dhbcmsdesc string
 ,localdhbflag string
 ,fundingdhbcode string
 ,fundingdhbdesc string
 ,fundingdhbmohdesc string
 ,fundingdhbgroup string
 ,fundingdhbsplit string
 ,fundingdhbnorthernregion string
 ,fundingdhbnorthern string
 ,fundingdhbregion string
 ,fundingdhbregionak string
 ,fundingdhbcar string
 ,fundingdhbtrim string
 ,fundingdhbabbr string
 ,fundingdhblongdesc string
 ,fundingdhbcmsid int
 ,fundingdhbcmsdesc string
 ,fundinglocaldhbflag string
 , sourcecode string
 )
USING DELTA
LOCATION '{silver_folder_path}trakcare/{v_target_table_name}'
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Processing

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Create Temp View with Changes only

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE TEMP VIEW vw_s_dhb
AS
SELECT 
    '{v_new_watermark_value}' AS watermarkvalue
 ,trust.TRUST_RowId as tcdhbid  
 ,trust.Trust_Code as dhbcode 
 ,trust.TRUST_Desc as dhbdesc 
 ,Null as dhbmohdesc 
 ,CASE WHEN trust.Trust_Code = '1022' THEN 'Auckand'
	   WHEN trust.Trust_Code = '1021' THEN 'Waitemata'
       WHEN trust.Trust_Code = '1023' THEN 'Counties Manukau'
       WHEN trust.Trust_Code = '1011' THEN 'Northland'
	   ELSE 'Other'
       END as dhbgroup 
 ,CASE WHEN trust.Trust_Code = '1022' THEN 'Auckland'
       ELSE 'Other'
       END as dhbsplit 
 ,CASE WHEN trust.Trust_Code = 'Unknown' THEN 'Unknown'
	   WHEN trust.Trust_Code in ('1021', '1011', '1023', '1022') THEN 'North'
       ELSE 'Other'
       END as dhbnorthernregion 
 ,CASE WHEN trust.Trust_Code = 'Unknown' THEN 'Unknown'
	   WHEN trust.Trust_Code in ('1021'	, '1011', '1023') THEN 'Rest Of Region'
	   WHEN trust.Trust_Code in ('1022')  THEN 'Auckland'
       ELSE 'Other'
       END as dhbnorthern 
 ,CASE WHEN trust.Trust_Code in('1021', '1011', '1023', '1022') THEN 'Northern'
	   WHEN trust.Trust_Code in ('2031', '2042', '2047', '2051') THEN 'Midland'
	   WHEN trust.Trust_Code in ('3061', '2071', '3081', '3082', '3091', '3092', '3093') THEN 'Central'
	   WHEN trust.Trust_Code in ('3101', '4111', '4121', '4122', '4123', '4131', '4141', '4160') THEN 'Southern'
       ELSE 'Other'
       END as dhbregion 
 ,CASE WHEN trust.Trust_Code = '1022' THEN 'Auckland'
	   WHEN trust.Trust_Code = '1021' THEN 'Waitemata'
       WHEN trust.Trust_Code = '1023' THEN 'Counties Manukau'
       ELSE 'Other'
       END as dhbregionak 
 ,CASE WHEN trust.Trust_Code in( '4141', '4131') THEN 'Southern'
	   ELSE trust.Trust_Desc
       END as dhbcar 
 ,CASE WHEN LEFT(RIGHT(trust.TRUST_Code,3),1) =0 THEN RIGHT(trust.TRUST_Code,2)
       ELSE RIGHT(trust.TRUST_Code,3)
       END  as dhbtrim 
 ,CASE WHEN trust.Trust_Code= '1022' THEN 'ADHB'
       WHEN trust.Trust_Code= '2047' THEN 'BOPDHB'
       WHEN trust.Trust_Code = '3091' THEN 'C&CDHB'
       WHEN trust.Trust_Code in('4121', '4122') THEN 'CDHB'
       WHEN trust.Trust_Code = '1023' THEN 'CMDHB'
       WHEN trust.Trust_Code= '3061' THEN 'HBDHB'
       WHEN trust.Trust_Code = '3092' THEN 'HVDHB'
       WHEN trust.Trust_Code = '2042' THEN 'LDHB'
       WHEN trust.Trust_Code = '3081' THEN 'MCDHB'
       WHEN trust.Trust_Code = '1011' THEN 'NDHB'
       WHEN trust.Trust_Code = '3101' THEN 'NMDHB'
       WHEN trust.Trust_Code= '4123' THEN 'SCDHB'
       WHEN trust.Trust_Code = '4141' THEN 'SDHB'
       WHEN trust.Trust_Code = '2071' THEN 'TADHB'
       WHEN trust.Trust_Code = '2051' THEN 'TDHB'
       WHEN trust.Trust_Code = '4111' THEN 'WCDHB'
       WHEN trust.Trust_Code = '1021' THEN 'WDHB'
       WHEN trust.Trust_Code = '3082' THEN 'WHDHB'
       WHEN trust.Trust_Code = '2031' THEN 'WKDHB'
       WHEN trust.Trust_Code = '3093' THEN 'WRPDHB'
       WHEN trust.Trust_Code = '4131' THEN 'ODHB'
       ELSE 'Other'
       END as dhbabbr 
 ,IFNULL(concat(DHB_Desc,' DHB'),'Unknown') as dhblongdesc 
 ,trust.TRUST_RowId as dhbcmsid 
 ,CASE
	WHEN trust.Trust_Code = '3092'	THEN 'Hutt Valley'
	ELSE trust.Trust_Desc
    END as dhbcmsdesc 
 ,dhb.local_dhb_flag as localdhbflag 
 ,IFNULL(trust.Trust_code,'Unk')as fundingdhbcode 
 ,IFNULL(trust.Trust_desc,'Unknown') as fundingdhbdesc 
 ,IFNULL(dhb.dhb_moh_desc,'') as fundingdhbmohdesc 
 ,dhbfund.fundingdhbgroup 
 ,dhbfund.fundingdhbsplit 
 ,dhbfund.fundingdhbnorthernregion 
 ,dhbfund.fundingdhbnorthern 
 ,dhbfund.fundingdhbregion 
 ,dhbfund.fundingdhbregionak 
 ,dhbfund.fundingdhbcar 
 ,CASE WHEN LEFT(RIGHT(trust.TRUST_Code,3),1) =0 THEN RIGHT(trust.TRUST_Code,2)
       ELSE RIGHT(trust.TRUST_Code,3)
       END as fundingdhbtrim 
 , CASE WHEN dhb.dhb_desc = 'Auckland' THEN 'ADHB'
	    WHEN dhb.dhb_desc = 'Bay Of Plenty'	THEN 'BOPDHB'
	    WHEN dhb.dhb_desc = 'Capital and Coast'	THEN 'C&CDHB'
	    WHEN dhb.dhb_desc = 'Canterbury' THEN 'CDHB'
	    WHEN dhb.dhb_desc = 'Counties Manukau' THEN 'CMDHB'
	    WHEN dhb.dhb_desc = 'Hawke''s Bay' THEN 'HBDHB'
	    WHEN dhb.dhb_desc = 'Hutt' THEN 'HVDHB'
	    WHEN dhb.dhb_desc = 'Lakes'	THEN 'LDHB'
	    WHEN dhb.dhb_desc = 'MidCentral' THEN 'MCDHB'
	    WHEN dhb.dhb_desc = 'Northland'	THEN 'NDHB'
	    WHEN dhb.dhb_desc = 'Nelson Marlborough' THEN 'NMDHB'
	    WHEN dhb.dhb_desc = 'National' THEN 'NAT'
	    WHEN dhb.dhb_desc = 'Otago'	THEN 'ODHB'
	    WHEN dhb.dhb_desc = 'South Canterbury' THEN 'SCDHB'
	    WHEN dhb.dhb_desc = 'Southland'	THEN 'SDHB'
	    WHEN dhb.dhb_desc = 'Taranaki'	THEN 'TADHB'
	    WHEN dhb.dhb_desc = 'Tairawhiti' THEN 'TDHB'
	    WHEN dhb.dhb_desc = 'West Coast' THEN 'WCDHB'
	    WHEN dhb.dhb_desc = 'Waitemata'	THEN 'WDHB'
	    WHEN dhb.dhb_desc = 'Whanganui'	THEN 'WHDHB'
	    WHEN dhb.dhb_desc = 'Waikato'	THEN 'WKDHB'
	    WHEN dhb.dhb_desc = 'Wairarapa'	THEN 'WRPDHB'
	    ELSE 'Other' 
        END as fundingdhbabbr 
 ,IFNULL(concat(DHB_Desc,' DHB'),'Unknown') as fundingdhblongdesc 
 ,IFNULL(trust.TRUST_RowId,'Unk')  as fundingdhbcmsid 
 ,IFNULL(trust.TRUST_Desc,'Unknown') as fundingdhbcmsdesc 
 ,dhb.local_dhb_flag as fundinglocaldhbflag 
 , 'TRAK' sourcecode
FROM bronze.tc_l_pac_trust as trust
LEFT JOIN bronze.ref_l_dhb as dhb on trust.TRUST_code = dhb.DHB_MOH_Code
LEFT JOIN (
            SELECT * 
            FROM
            (
                SELECT 
                d.dhb_id, 
                g.DHB_Group_Desc,
                h.DHB_Group_Number 
                FROM
                    bronze.ref_l_dhb as d
                    LEFT JOIN bronze.ref_l_dhb_group_hierarchy as h on d.dhb_id = h.DHB_ID 
                    LEFT JOIN bronze.ref_l_dhb_group as g on h.DHB_Group_ID = g.DHB_Group_ID
                WHERE
                    h.DHB_Group_Number between '1' and '7'
            ) as source
            PIVOT
            (       
                Max(Dhb_group_desc) as desc
                for dhb_group_number in (1 as fundingdhbgroup, 2 as fundingdhbsplit , 3 as fundingdhbnorthernregion, 4 as fundingdhbnorthern, 5 as fundingdhbregion, 6 as fundingdhbregionak , 7 as fundingdhbcar)
            )
    ) as dhbfund on dhb.dhb_id = dhbfund.dhb_id
where     
    date(trust.processing_time)    >= '{v_watermark_date}'
    or
    date(dhb.processing_time)    >= '{v_watermark_date}'
""")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Update the target table

# COMMAND ----------

# this dataframe is required for the merge function
df_view = spark.sql("SELECT * FROM vw_s_dhb")

from pyspark.sql.functions import sha2, concat_ws

# obtain the list of column to be used to generate the hashid column: it should include all columns except the watermark
lst_cols = df_view.columns
lst_cols.remove('watermarkvalue')

# add hashid column to the view dataframe
df_hashed = df_view.withColumn("hashid",sha2(concat_ws('|', *lst_cols),256))

# COMMAND ----------

# set the merge condition required for the merge functions
merge_condition = 'TARGET.tcdhbid = SOURCE.tcdhbid'
match_additional_condition = 'TARGET.hashid <> SOURCE.hashid'
merge_delta_tables(df_hashed, v_target_database, v_target_table_name, merge_condition, match_additional_condition )

# COMMAND ----------

# write to the ADM_LOG.etl.LogOverview table on MI the output from the merge 
insert_into_log_overview(v_target_database, v_target_table_name, v_etlcontrolid, v_sourcesystem, v_target_database[0])

# COMMAND ----------

# MAGIC %md
# MAGIC ####Validation Checks

# COMMAND ----------

# DBTITLE 1,No Duplicates and NULL values
#v_grain = 'tcdhbid'
#v_columns_exclude = ''

#check_for_duplicates (v_target_database, v_target_table_name, v_grain, v_columns_exclude)
#check_for_null_values(v_target_database, v_target_table_name, v_grain, v_columns_exclude)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Post-processing

# COMMAND ----------

# DBTITLE 1,Export deltas to parquet file
# Saving the changes in the target table as a parquet file to be consumed by Titan (via ADF).
if v_watermark_date == v_new_watermark_value.strftime("%Y-%m-%d") : 
    wmrk = '9999-01-01' 
else: 
    wmrk = v_new_watermark_value

# produce an empty dataframe if old and new watermark have the same value
df_s_parquet = get_df_titan(v_target_database,v_target_table_name, wmrk)
write_parquet_for_export(df_s_parquet, silver_folder_path, trakcare_export_parquet, v_target_table_name, 'overwrite')

# COMMAND ----------

# DBTITLE 1,Update WaterMarkValue
# update the etl.Control table WaterMarkValue with the latest processing date from the RDS joining tables
# if the old and the new watermark dates have different values
if v_watermark_date != v_new_watermark_value.strftime("%Y-%m-%d") : 
    update_mi_water_mark_value (v_new_watermark_value, v_etlcontrolid)
