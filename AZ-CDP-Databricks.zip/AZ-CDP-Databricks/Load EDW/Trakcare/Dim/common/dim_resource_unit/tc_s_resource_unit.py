# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 01-Aug-2023 | 1       | Abhilash Kumar | Create first draft of tc_s_resource_unit                                   |
# MAGIC | 17-Aug-2023 | 2       | Gery Smith     | Add sourcecode                                |
# MAGIC | 09-Feb-2024 | 2       | Donne     | Changed REF_ to DSU_                                |
# MAGIC | 15-Feb-2024 | 2       | Donne     | Pointed to vw_tc_s_specialty for specialty data                             |
# MAGIC | 26-Mar-2024 | 3       | Gery      | added a comment for the depricated fields.
# MAGIC | 27-Mar-2024 | 3       | Gery      | Switch to Control_TRAK

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
#%run "../../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# Use the function below if you need to reset the development and start from scratch.  
# reset_table('silver_db', 'trakcare', 'tc_s_resource_unit', 1767, 'Control_TRAK')

# COMMAND ----------

# DBTITLE 1,Variables
# p_etlcontrolid is passed as a parameter from ADF
dbutils.widgets.text("p_batchid","0")
v_batchid = int(dbutils.widgets.get("p_batchid"))
dbutils.widgets.text("p_etlcontrolid","1767")
v_etlcontrolid = dbutils.widgets.get("p_etlcontrolid")

# COMMAND ----------

# Create variable from etl.Control table
# WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
qry = f"""
       SELECT 
              ETLControlID
            , SourceSystem
            , SourceSystemType
            , SourceTableSchemaName
            , SourceTableName
            , CASE WHEN IncrementalLoad = 1 THEN WaterMarkValue ELSE '1900-01-01' END WaterMarkValue
            , TargetSystemType
            , TargetTableSchemaName
            , TargetTableName
            , IncrementalLoad
            , IsActive
            , TargetEntityPath
            , CustomConfig
        FROM ADM_CONFIG.etl.Control_TRAK
        WHERE ETLControlID = {v_etlcontrolid}"""

df_control = read_from_mi_db("ADM_CONFIG", qry)

v_watermark_date = df_control.select("WaterMarkValue").collect()[0][0]
v_target_table_name = df_control.select("TargetTableName").collect()[0][0]
v_target_database = df_control.select("CustomConfig").collect()[0][0]
v_sourcesystem = "trakcare"
v_target_entity_path = df_control.select("TargetEntityPath").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,Set new WaterMarkValue
# New WaterMarkValue is the latest processing date across all RDS joining tables
v_new_watermark_value = spark.sql("""
select   date(max(watermark)) v_new_watermark_value
from 
    (
    SELECT MAX(processing_time) watermark FROM bronze.tc_l_ct_loc
    UNION
    SELECT MAX(processing_time) watermark FROM bronze.tc_l_ct_responsibleunit
    UNION
    SELECT MAX(processing_time) watermark FROM bronze.tc_l_ct_significantfacility
    UNION
    SELECT MAX(processing_time) watermark FROM bronze.dsu_l_cbu_link
    UNION
    SELECT MAX(processing_time) watermark FROM bronze.dsu_l_sub_specialty
    UNION
    SELECT MAX(processing_time) watermark FROM bronze.dsu_l_specialty
    ) qry
""").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,Create Table
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {v_target_database}.{v_target_table_name}
(
  watermarkvalue timestamp
 ,hashid string 
 ,tcresourceunitid string
 ,resourceunitid int
 ,resourceunitabbr string
 ,resourceunitname string
 ,subspecialtycode int
 ,subspecialtydesc string
 ,specialtycode string
 ,specialtydesc string
 ,portfoliocode string
 ,portfoliodesc string
 ,directoratecode string
 ,directoratedesc string
 ,resunitinactive int
 ,resourceunitrccode string
 ,resourceunitrcdesc string
 ,facilityid int
 ,facilityabbr string
 ,hl7resourceunitcode string
 ,securenhi string
 ,orgunitid int
 ,parentorgunitid int
 ,grandparentorgunitid int
 ,parentrccode string
 ,parentrcdesc string
 ,grandparentrccode string
 ,grandparentrcdesc string
 ,cbuid1 int
 ,cbuid2 int
 ,cbuid3 int
 ,cbuid int
 ,cbudesc string
 ,subspecialtyid int
 ,costingrccode string
 ,resunitgrpid int
 ,resourceunitgroupabbr string
 ,resourceunitgroupname string
 ,facilityactiveflag string
 ,facilityhl7code string
 ,espi2flag string
 ,sourcecode string
 )
USING DELTA
LOCATION '{silver_folder_path}trakcare/{v_target_table_name}'
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Processing

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Create Temp View with Changes only

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE TEMP VIEW vw_s_resource_unit
AS
SELECT 
'{v_new_watermark_value}' AS watermarkvalue
,clinic.CTLOC_RowID AS tcresourceunitid 
,clinic.CTLOC_RowID AS resourceunitid 
,clinic.CTLOC_Code AS resourceunitabbr 
,clinic.CTLOC_Desc AS resourceunitname 
,cl.cbu_code AS resourceunitrccode 
,cl.cbu_desc AS resourceunitrcdesc 
,clinic.CTLOC_NationCode AS hl7resourceunitcode
,0 AS resunitinactive       -- depricated DataEDO
,NULL AS resunitgrpid       -- depricated DataEDO
,NULL AS resourceunitgroupabbr -- depricated DataEDO
,NULL AS resourceunitgroupname  -- depricated DataEDO
,dir.SIGNF_Code AS directoratecode 
,dir.SIGNF_Desc AS directoratedesc 
,hosp.HOSP_RowId AS facilityid 
,hosp.HOSP_Code AS facilityabbr 
,CASE
    WHEN hosp.HOSP_DateTo IS NULL THEN 'Y'
    WHEN to_date(from_utc_timestamp(now() ,'Pacific/Auckland')) <= hosp.HOSP_DateTo THEN 'Y'
    ELSE 'N'
    END AS facilityactiveflag 
,NULL as facilityhl7code -- depricated DataEDO
,sp.portfoliocode   as portfoliocode 
,sp.portfoliodesc   as portfoliodesc 
,cbu.RU_RowId       as cbuid 
,NULL as cbuid1  -- depricated DataEDO
,NULL as cbuid2  -- depricated DataEDO
,NULL as cbuid3  -- depricated DataEDO
,cbu.RU_Desc        as cbudesc 
,cbu.RU_Code        as costingrccode 
,sp.specialtyid     as specialtyid
,sp.specialtycode   as specialtycode 
,sp.specialtydesc   as specialtydesc
,sp.subspecialtyid  as subspecialtyid
,sp.subspecialtycode as subspecialtycode 
,sp.subspecialtydesc as subspecialtydesc 
,NULL as securenhi             -- depricated DataEDO
,NULL as orgunitid             -- depricated DataEDO
,NULL as parentorgunitid       -- depricated DataEDO
,NULL as grandparentorgunitid  -- depricated DataEDO
,NULL as parentrccode       -- depricated DataEDO
,NULL as parentrcdesc       -- depricated DataEDO
,NULL AS grandparentrccode  -- depricated DataEDO
,NULL AS grandparentrcdesc  -- depricated DataEDO
,NULL AS espi2flag          -- depricated DataEDO
,'TRAK' AS sourcecode
FROM 
bronze.tc_l_ct_responsibleunit cbu
LEFT JOIN bronze.tc_l_ct_loc team ON cbu.RU_Code = team.CTLOC_Code 
    AND team.ctloc_type = 'E'
LEFT JOIN bronze.tc_l_ct_loc clinic ON clinic.CTLOC_RespUnit_DR = cbu.RU_RowID
    AND clinic.CTLOC_Type = 'CL'
LEFT JOIN bronze.tc_l_ct_significantfacility dir ON team.CTLOC_SignifFacility_DR = dir.SIGNF_RowId
LEFT JOIN bronze.dsu_l_cbu_link cl ON cl.CBU_Id = CBU.RU_RowId 
LEFT JOIN silver_db.vw_tc_s_specialty sp ON cl.Sub_Specialty_Id = sp.subspecialtyid  
LEFT JOIN bronze.tc_l_ct_hospital hosp ON clinic.CTLOC_Hospital_DR = hosp.HOSP_RowId
WHERE
clinic.CTLOC_Type = 'CL'
AND
    (
        DATE(clinic.processing_time)  >= '{v_watermark_date}'
        OR DATE(cbu.processing_time)  >= '{v_watermark_date}'
        OR DATE(dir.processing_time)  >= '{v_watermark_date}'
        OR DATE(cl.processing_time) >= '{v_watermark_date}'
        --OR DATE(subsp.processing_time) >= '{v_watermark_date}'
        OR DATE(sp.watermarkvalue) >= '{v_watermark_date}'
    )
""")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Update the target table

# COMMAND ----------

# this dataframe is required for the merge function
df_view = spark.sql("SELECT * FROM vw_s_resource_unit")

from pyspark.sql.functions import sha2, concat_ws

# obtain the list of column to be used to generate the hashid column: it should include all columns except the watermark
lst_cols = df_view.columns
lst_cols.remove('watermarkvalue')

# add hashid column to the view dataframe
df_hashed = df_view.withColumn("hashid",sha2(concat_ws('|', *lst_cols),256))

# COMMAND ----------

# set the merge condition required for the merge functions
merge_condition = 'TARGET.resourceunitid = SOURCE.resourceunitid'

# to update the true delta records
match_additional_condition = 'TARGET.hashid <> SOURCE.hashid'

# call merge function
merge_delta_tables(df_hashed, v_target_database, v_target_table_name, merge_condition, match_additional_condition )

# COMMAND ----------

# write to the ADM_LOG.etl.LogOverview table on MI the output from the merge 
insert_into_log_overview(v_target_database, v_target_table_name, v_etlcontrolid, v_sourcesystem, v_target_database[0])

# COMMAND ----------

# MAGIC %md
# MAGIC ####Validation Checks

# COMMAND ----------

# DBTITLE 1,No Duplicates and NULL values
#v_grain = 'resourceunitid'
#v_columns_exclude = ''

#check_for_duplicates (v_target_database, v_target_table_name, v_grain, v_columns_exclude)
#check_for_null_values(v_target_database, v_target_table_name, v_grain, v_columns_exclude)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Post-processing

# COMMAND ----------

# DBTITLE 1,Export deltas to parquet file
# Saving the changes in the target table as a parquet file to be consumed by Titan (via ADF).
if v_watermark_date == v_new_watermark_value.strftime("%Y-%m-%d") : 
    wmrk = '9999-01-01' 
else: 
    wmrk = v_new_watermark_value

# produce an empty dataframe if old and new watermark have the same value
df_s_parquet = get_df_titan(v_target_database,v_target_table_name, wmrk)
write_parquet_for_export(df_s_parquet, silver_folder_path, v_target_entity_path, v_target_table_name, 'overwrite')

# COMMAND ----------

# DBTITLE 1,Update WaterMarkValue
# update the etl.Control table WaterMarkValue with the latest processing date from the RDS joining tables
# if the old and the new watermark dates have different values
if v_watermark_date != v_new_watermark_value.strftime("%Y-%m-%d") : 
    update_mi_water_mark_value (v_new_watermark_value, v_etlcontrolid, 'Control_TRAK')
