# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 17-Apr-2023 | 1       | Mahi Ethiraj   | Create first draft of tc_s_alcohol_involved                                |
# MAGIC | 01-May-2023 | 2       | Mahi Ethiraj   | Add a new BK tcalcoholinvolvedid and amend the merge condition             |
# MAGIC | 16-Aug-2023 | 3       | Gery Smith     | Add SourceCode column             |
# MAGIC | 30-Nov-2023 | 4       | Gery Smith     | TTTENG-2837: DataEDO Review 1 ; no changes; outstanding issue: AlcoholInvolvedDesc = ALCDRGIN_Desc, but not available yet in Trak            |
# MAGIC | 20-Feb-2024 | 5       | Gery Smith     | TTTENG-3862: DataEDO Review 2 ; AlcoholInvolvedDesc new mapping          |
# MAGIC | 27-Mar-2024 | 6       | Gery Smith     | Switch to Control_TRAK             |
# MAGIC | 15-Aug-2024 | 7       | Kiruba         | TTTENG-6295   Adding CASE statement to the column- AlcoholInvolvedShortDesc            |        

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
#%run "../../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# Use the function below if you need to reset the development and start from scratch.
# reset_table('silver_db', 'trakcare', 'tc_s_alcohol_involved', 1517, 'Control_TRAK')

# COMMAND ----------

# DBTITLE 1,Variables
# p_etlcontrolid is passed as a parameter from ADF
dbutils.widgets.text("p_batchid","0")
v_batchid = int(dbutils.widgets.get("p_batchid"))

dbutils.widgets.text("p_etlcontrolid","1517")
v_etlcontrolid = dbutils.widgets.get("p_etlcontrolid")

# COMMAND ----------

# Create variable from etl.Control table
# WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
qry = f"""
       SELECT 
              ETLControlID
            , SourceSystem
            , SourceSystemType
            , SourceTableSchemaName
            , SourceTableName
            , CASE WHEN IncrementalLoad = 1 THEN WaterMarkValue ELSE '1900-01-01' END WaterMarkValue
            , TargetSystemType
            , TargetTableSchemaName
            , TargetTableName
            , IncrementalLoad
            , IsActive
            , TargetEntityPath
            , CustomConfig
        FROM ADM_CONFIG.etl.Control_TRAK
        WHERE ETLControlID = {v_etlcontrolid}"""

df_control = read_from_mi_db('ADM_CONFIG', qry)

v_watermark_date = df_control.select("WaterMarkValue").collect()[0][0]
v_target_table_name = df_control.select("TargetTableName").collect()[0][0]
v_target_database = df_control.select("CustomConfig").collect()[0][0]
v_sourcesystem = 'trakcare'
v_target_entity_path = df_control.select("TargetEntityPath").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,Set new WaterMarkValue
# New WaterMarkValue is the latest processing date across all RDS joining tables
v_new_watermark_value = spark.sql("""
select   date(max(watermark)) v_new_watermark_value
from 
    (
    select max(processing_time) watermark from  bronze.tc_l_pac_alcoholordruginvolvement
    ) qry
""").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,Create Table
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {v_target_database}.{v_target_table_name}
(
-- alcoholinvolvedid INTEGER
  alcoholinvolvedcode string
 ,alcoholinvolvedshortdesc string
 ,alcoholinvolveddesc string
 ,startdate timestamp
 ,enddate timestamp
 ,tcalcoholinvolvedid INTEGER
 ,watermarkvalue timestamp
 ,hashid string 
 ,sourcecode string )
USING DELTA
LOCATION '{silver_folder_path}trakcare/{v_target_table_name}'
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Processing

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE TEMP VIEW vw_s_alcohol_involved
AS
SELECT 
--     ALCDRGIN_RowId as alcoholinvolvedid  
    ALCDRGIN_Code as  alcoholinvolvedcode 
--    ,ALCDRGIN_Desc as alcoholinvolveddesc 
    , cct.item_desc as alcoholinvolveddesc
    ,CASE WHEN ALCDRGIN_Code = 'U' THEN 'Not Known'
        ELSE ALCDRGIN_Desc
        END as alcoholinvolvedshortdesc 
    ,ALCDRGIN_DateFrom as startdate 
    ,ALCDRGIN_DateTo as enddate
    ,ALCDRGIN_RowId as tcalcoholinvolvedid
    ,'{v_new_watermark_value}' AS watermarkvalue
    , 'TRAK' as sourcecode
FROM bronze.tc_l_pac_alcoholordruginvolvement a
join bronze.dsu_l_cct cct
    on a.ALCDRGIN_Code = cct.item_code
    and cct.cct_name = 'Alcohol Involved'
where     date(a.processing_time)    >= '{v_watermark_date}' 
    or    date(cct.processing_time) >= '{v_watermark_date}'
""")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Update the target table

# COMMAND ----------

# this dataframe is required for the merge function
df_view = spark.sql("SELECT * FROM vw_s_alcohol_involved")

from pyspark.sql.functions import sha2, concat_ws

# obtain the list of column to be used to generate the hashid column: it should include all columns
lst_cols = df_view.columns
lst_cols.remove('watermarkvalue')
df_hashed = df_view.withColumn("hashid",sha2(concat_ws('|', *lst_cols),256))

# COMMAND ----------

# set the merge condition required for the merge functions
merge_condition = 'TARGET.alcoholinvolvedcode = SOURCE.alcoholinvolvedcode'

match_additional_condition = 'TARGET.hashid <> SOURCE.hashid'

merge_delta_tables(df_hashed, v_target_database, v_target_table_name, merge_condition,match_additional_condition )

# COMMAND ----------

# write to the ADM_LOG.etl.LogOverview table on MI the output from the merge 
v_loadtype = 's'
insert_into_log_overview(v_target_database, v_target_table_name, v_etlcontrolid, v_sourcesystem,v_loadtype,v_batchid)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Validation Checks

# COMMAND ----------

# DBTITLE 1,No Duplicates and NULL values
#v_grain = 'tcalcoholinvolvedid'
#v_columns_exclude = ''

#check_for_duplicates (v_target_database, v_target_table_name, v_grain, v_columns_exclude)
#check_for_null_values(v_target_database, v_target_table_name, v_grain, v_columns_exclude)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Post-processing

# COMMAND ----------

# DBTITLE 1,Export deltas to parquet file
# Saving the changes in the target table as a parquet file to be consumed by Titan (via ADF).
if v_watermark_date == v_new_watermark_value.strftime("%Y-%m-%d") : 
    wmrk = '9999-01-01' 
else: 
    wmrk = v_new_watermark_value

# produce an empty dataframe if old and new watermark have the same value
df_s_parquet = get_df_titan(v_target_database,v_target_table_name, wmrk)
write_parquet_for_export(df_s_parquet, silver_folder_path, trakcare_export_parquet, v_target_table_name, 'overwrite')

# COMMAND ----------

# DBTITLE 1,Update WaterMarkValue
# update the etl.Control table WaterMarkValue with the latest processing date from the RDS joining tables
# if the old and the new watermark dates have different values
if v_watermark_date != v_new_watermark_value.strftime("%Y-%m-%d") : 
    update_mi_water_mark_value (v_new_watermark_value, v_etlcontrolid, 'Control_TRAK')
