# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 18-May-2023 | 1       | Abhilash Kumar | Create first draft of tc_s_ethnicity_group                                 |
# MAGIC | 30-Nov-2023 | 2       | Gery Smith | TTTENG-2827; DataEDO revision no changes; using MoHEthnicGroupCode instead of MoHEthnicityGroupCode                           |
# MAGIC | 24-Jan-2024 | 3       | Donne | Add sourcecode                                 |
# MAGIC | 0-Feb-2024 | 4      | Donne | Replace ref_l_ with dsu_l_                                |
# MAGIC | 27-Mar-2024 | 5      | Gery | Switch to Control_TRAK        |
# MAGIC | 24-Jul-2024 | 6       | Arvinc  | Added "CASE statement" for ethnicitycode  |
# MAGIC | 01-Aug-2024 | 7       | Arvinc  | Added new EthnicGroupCodeDesc of 'Other ethnicity' as 'OT'  |
# MAGIC | 12-Aug-2024 | 8       | Kiruba  | Added new EthnicGroupCodeDesc of 'Don't Know','Refused to Answer','Repeated Value','Response Outside Scope' as 'DK', 'RA', 'RV', 'RO'  |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
#%run "../../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# spark.sql(f"""DROP TABLE silver_db.dsu_s_ethnicity_group""")
# reset_table(v_target_database , v_sourcesystem , v_target_table_name , v_etlcontrolid )
# reset_table('silver_db', 'trakcare', 'dsu_s_ethnicity_group', 1616, 'Control_TRAK')

# COMMAND ----------

# DBTITLE 1,Variables
# p_etlcontrolid is passed as a parameter from ADF
dbutils.widgets.text("p_batchid","0")
v_batchid = int(dbutils.widgets.get("p_batchid"))
dbutils.widgets.text("p_etlcontrolid","1616")
v_etlcontrolid = dbutils.widgets.get("p_etlcontrolid")

# COMMAND ----------

# Create variable from etl.Control table
# WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
qry = f"""
       SELECT 
              ETLControlID
            , SourceSystem
            , SourceSystemType
            , SourceTableSchemaName
            , SourceTableName
            , CASE WHEN IncrementalLoad = 1 THEN WaterMarkValue ELSE '1900-01-01' END WaterMarkValue
            , TargetSystemType
            , TargetTableSchemaName
            , TargetTableName
            , IncrementalLoad
            , IsActive
            , TargetEntityPath
            , CustomConfig
        FROM ADM_CONFIG.etl.Control_TRAK 
        WHERE ETLControlID = {v_etlcontrolid}"""

df_control = read_from_mi_db('ADM_CONFIG', qry)

v_watermark_date = df_control.select("WaterMarkValue").collect()[0][0]
v_target_table_name = df_control.select("TargetTableName").collect()[0][0]
v_target_database = df_control.select("CustomConfig").collect()[0][0]
v_sourcesystem = 'trakcare'
v_target_entity_path = df_control.select("TargetEntityPath").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,Set new WaterMarkValue
# New WaterMarkValue is the latest processing date across all RDS joining tables
v_new_watermark_value = spark.sql("""
select   date(max(watermark)) v_new_watermark_value
from 
    (
    select max(processing_time) watermark from  bronze.dsu_l_mohethnicgroupcode 
    union
    select max(processing_time) watermark from bronze.dsu_l_ethnicity
    ) qry
""").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,Create Table
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {v_target_database}.{v_target_table_name}
(
  watermarkvalue timestamp 
 ,hashid string
 ,ethnicitycode string
 ,ethnicitydesc string
 ,ethnicitymohcode string
 ,mohethnicitypriority int
 ,ethnicityl1code int
 ,ethnicityl1desc string
 ,ethnicityl03catdesc string
 ,ethnicityl04catdesc string
 ,asianflag string
 ,pacificflag string
 ,sourcecode string
 )
USING DELTA
LOCATION '{silver_folder_path}trakcare/{v_target_table_name}'
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Processing

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Create Temp View with Changes only

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE TEMP VIEW vw_s_ethnicity_group
AS
SELECT 
'{v_new_watermark_value}' watermarkvalue
,CASE
    WHEN MoHgc.EthnicGroupCodeDesc = 'African' THEN 'AF'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Asian NFD' THEN 	'AS'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Chinese'	THEN  'OC'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Cook Island Maori' THEN 	'PR'
    WHEN MoHgc.EthnicGroupCodeDesc = "Don't Know" THEN 	'DK'
    WHEN MoHgc.EthnicGroupCodeDesc = 'European NFD'	THEN 'EN'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Fijian'	THEN 'PF'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Indian'	THEN 'OI'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Latin American' THEN 'LA'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Maori' THEN 	'M'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Middle Eastern' THEN 	'ME'
    WHEN MoHgc.EthnicGroupCodeDesc = 'New Zealand European'	THEN 'OE'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Niuean' THEN 	'PN'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Not Stated' THEN 	'NS'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Other' THEN 	'O'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Other Asian' THEN 	'OA'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Other European' THEN 'E'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Other Pacific Peoples' THEN 	'P'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Other ethnicity' THEN 	'OT'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Pacific Peoples NFD'	THEN 'PI'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Refused to Answer'	THEN 'RA'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Repeated Value'	THEN 'RV'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Response Outside Scope'	THEN 'RO'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Response Unidentifiable' THEN 'RU'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Samoan' THEN 	'PS'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Southeast Asian' THEN 'SE'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Tokelauan' THEN 	'PK'
    WHEN MoHgc.EthnicGroupCodeDesc = 'Tongan' THEN 	'PT'
    ELSE NULL 
 END  AS ethnicitycode
,MoHgc.EthnicGroupCodeDesc AS ethnicitydesc
,MoHgc.EthnicGroupCode AS ethnicitymohcode
,MoHgc.EthnicGroupPriority AS mohethnicitypriority
,ethL1.Level_Rollup_Code AS ethnicityl1code
,CASE WHEN ethL1.Level_Rollup_Desc = 'Pacific Island' THEN 'Pacific Peoples'
      WHEN MoHgc.EthnicGroupCode LIKE '5%' AND MoHgc.EthnicGroupCode <> '54' THEN 'Middle Eastern/Latin American/African' 
      WHEN MoHgc.EthnicGroupCode LIKE '6%' AND MoHgc.EthnicGroupCode <> '54' THEN 'Other Ethnicity' 
      WHEN MoHgc.EthnicGroupCode LIKE '9%' AND MoHgc.EthnicGroupCode <> '54' THEN 'Residual Categories'
      ELSE ethL1.Level_Rollup_Desc END AS ethnicityl1desc
,ethL3.Level_Rollup_Desc AS ethnicityl03catdesc
,ethL4.Level_Rollup_Desc AS ethnicityl04catdesc
,CASE WHEN MoHgc.EthnicGroupCode >=40 AND MoHgc.EthnicGroupCode < 50 THEN 'Y' ELSE 'N' END AS asianflag
,CASE WHEN MoHgc.EthnicGroupCode >=30 AND MoHgc.EthnicGroupCode < 40 THEN 'Y' ELSE 'N' END AS pacificflag
,'TRAK' AS sourcecode
FROM
bronze.dsu_l_mohethnicgroupcode MoHgc
LEFT JOIN bronze.dsu_l_ethnicity ethL1
    ON LEFT(Trim(MoHgc.EthnicGroupCode),1) = ethL1.Level_Code
    AND ethL1.Class_Level = 'Level1'
LEFT JOIN bronze.dsu_l_ethnicity ethL3
    ON ethL3.Level_Code = LEFT(Trim(ethL1.Level_Rollup_Code),1)
    AND ethL3.Class_Level = 'Level0_3Category'
LEFT JOIN bronze.dsu_l_ethnicity ethL4
    ON ethL4.Level_Code = LEFT(Trim(ethL1.Level_Rollup_Code),1)
    AND ethL4.Class_Level = 'Level0_4Category'
WHERE
MoHgc.EthnicGroupLevel = 2
AND
(
    date(MoHgc.processing_time)    >= '{v_watermark_date}'
    OR  date(ethL1.processing_time)    >= '{v_watermark_date}'
)
""")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Update the target table

# COMMAND ----------

# this dataframe is required for the merge function
df_view = spark.sql("SELECT * FROM vw_s_ethnicity_group")

from pyspark.sql.functions import sha2, concat_ws

# obtain the list of column to be used to generate the hashid column: it should include all columns except the watermark
lst_cols = df_view.columns
lst_cols.remove('watermarkvalue')

# add hashid column to the view dataframe
df_hashed = df_view.withColumn("hashid",sha2(concat_ws('|', *lst_cols),256))

# COMMAND ----------

# set the merge condition required for the merge functions
merge_condition = 'TARGET.ethnicitymohcode = SOURCE.ethnicitymohcode'

# to update the true delta records
match_additional_condition = 'TARGET.hashid <> SOURCE.hashid'

# call merge function
merge_delta_tables(df_hashed, v_target_database, v_target_table_name, merge_condition, match_additional_condition )

# COMMAND ----------

# write to the ADM_LOG.etl.LogOverview table on MI the output from the merge 
insert_into_log_overview(v_target_database, v_target_table_name, v_etlcontrolid, v_sourcesystem, v_target_database[0], v_batchid)

# COMMAND ----------

# MAGIC %md
# MAGIC ####Validation Checks

# COMMAND ----------

# DBTITLE 1,No Duplicates and NULL values
v_grain = 'ethnicitymohcode'
v_columns_exclude = ''

check_for_duplicates (v_target_database, v_target_table_name, v_grain, v_columns_exclude)
check_for_null_values(v_target_database, v_target_table_name, v_grain, v_columns_exclude)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Post-processing

# COMMAND ----------

# DBTITLE 1,Export deltas to parquet file
# Saving the changes in the target table as a parquet file to be consumed by Titan (via ADF).
if v_watermark_date == v_new_watermark_value.strftime("%Y-%m-%d") : 
    wmrk = '9999-01-01' 
else: 
    wmrk = v_new_watermark_value

# produce an empty dataframe if old and new watermark have the same value
df_s_parquet = get_df_titan(v_target_database,v_target_table_name, wmrk)
write_parquet_for_export(df_s_parquet, silver_folder_path, v_target_entity_path, v_target_table_name, 'overwrite')

# COMMAND ----------

# DBTITLE 1,Update WaterMarkValue
# update the etl.Control table WaterMarkValue with the latest processing date from the RDS joining tables
# if the old and the new watermark dates have different values
if v_watermark_date != v_new_watermark_value.strftime("%Y-%m-%d") : 
    update_mi_water_mark_value (v_new_watermark_value, v_etlcontrolid, 'Control_TRAK')
