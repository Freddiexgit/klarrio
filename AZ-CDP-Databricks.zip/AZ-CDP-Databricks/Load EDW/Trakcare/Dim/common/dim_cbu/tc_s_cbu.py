# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 03-Jul-2023 | 1       | Gery Smith     | Create first draft of tc_s_cbu                                     |
# MAGIC | 07-Feb-2024| 2       | Gery Smith | Replace ref_l_ with dsu_l_   |
# MAGIC | 27-Mar-2024| 3       | Gery Smith | Switch to Control_TRAK |
# MAGIC | 19-Jun-2024| 4       | Daniel Menary | trim DirectorateCode |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
# %run "../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# Use the function below if you need to reset the development and start from scratch.
# reset_table('silver_db', 'trakcare', 'tc_s_cbu', 502, 'Control_TRAK')

# COMMAND ----------

# DBTITLE 1,Variables
# p_etlcontrolid is passed as a parameter from ADF
dbutils.widgets.text("p_etlcontrolid","502")
v_etlcontrolid = dbutils.widgets.get("p_etlcontrolid")

dbutils.widgets.text("p_batchid","0")
v_batchid = int(dbutils.widgets.get("p_batchid"))

# COMMAND ----------

# Create variable from etl.Control table
# WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
qry = f"""
       SELECT 
              ETLControlID
            , SourceSystem
            , SourceSystemType
            , SourceTableSchemaName
            , SourceTableName
            , CASE WHEN IncrementalLoad = 1 THEN WaterMarkValue ELSE '1900-01-01' END WaterMarkValue
            , TargetSystemType
            , TargetTableSchemaName
            , TargetTableName
            , IncrementalLoad
            , IsActive
            , TargetEntityPath
            , CustomConfig
        FROM ADM_CONFIG.etl.Control_TRAK
        WHERE ETLControlID = {v_etlcontrolid}"""

df_control = read_from_mi_db('ADM_CONFIG', qry)

v_watermark_date = df_control.select("WaterMarkValue").collect()[0][0]
v_target_table_name = df_control.select("TargetTableName").collect()[0][0]
v_target_database = df_control.select("CustomConfig").collect()[0][0]
v_sourcesystem = 'trakcare'
v_target_entity_path = df_control.select("TargetEntityPath").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,Set new WaterMarkValue
# New WaterMarkValue is the latest processing date across all RDS joining tables
v_new_watermark_value = spark.sql("""
select   date(max(watermark)) v_new_watermark_value
from 
    (
    select max(watermarkvalue) watermark from  silver_db.vw_tc_s_specialty
    union
    select max(processing_time) watermark from bronze.dsu_l_cbu_link 
    ) qry
""").collect()[0][0]

# COMMAND ----------

print('v_watermark_date:\t', v_watermark_date)
print('v_target_table_name:\t', v_target_table_name)
print('v_target_database:\t', v_target_database)
print('v_sourcesystem:\t\t', v_sourcesystem)
print('v_target_entity_path:\t', v_target_entity_path)
print('v_new_watermark_value:\t', v_new_watermark_value)

# COMMAND ----------

# DBTITLE 1,Create Table
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {v_target_database}.{v_target_table_name}
(
    hashid string
 , watermarkvalue timestamp
 , cbucode string
 ,orgunitid int
 ,cbuid int
 ,cbudesc string
 ,rccode string
 ,rcdesc string
 ,rcactivestartdate timestamp
 ,rcactiveenddate timestamp
 ,subspecialtycode int
 ,subspecialtydesc string
 ,specialtycode string
 ,specialtydesc string
 ,portfoliocode string
 ,portfoliodesc string
 ,directoratecode string
 ,directoratedesc string
 ,dischcburevenueflag string
 ,emergencycbuflag string
 ,currentflag string
 ,tccbuid int
 ,sourcecode string
 )
USING DELTA
LOCATION '{silver_folder_path}{v_sourcesystem}/{v_target_table_name}'
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Processing

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Create Temp View with Changes only

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE TEMP VIEW vw_s_cbu
AS
SELECT 
  ''  hashid 
 , watermarkvalue 
 , cbucode 
 , orgunitid 
 , cbuid 
 , cbudesc 
 , rccode  
 , rcdesc 
 , rcactivestartdate 
 , rcactiveenddate 
 , subspecialtycode 
 , subspecialtydesc 
 , specialtycode 
 , specialtydesc 
 , portfoliocode 
 , portfoliodesc 
 , rtrim(directoratecode) directoratecode
 , directoratedesc 
 , dischcburevenueflag 
 , emergencycbuflag 
 , currentflag 
 , tccbuid
 , sourcecode
FROM silver_db.vw_tc_s_cbu
where     watermarkvalue    >= '{v_watermark_date}'
""")

# COMMAND ----------

# spark.sql(f"""
# CREATE OR REPLACE TEMP VIEW vw_s_cbu
# AS
# SELECT 
#   ''  hashid 
#  , greatest(sp.watermarkvalue, date(cbu.processing_time)) watermarkvalue 
#  , ru.RU_Code as cbucode 
#  , ru.RU_RowId as orgunitid 
#  , ru.RU_RowId as cbuid 
#  , ru.RU_Desc as cbudesc 
#  , null as rccode  -- concept hasn't been identified in TRAK yet
#  , null as rcdesc 
#  , null as rcactivestartdate 
#  , null as rcactiveenddate 
#  , sp.subspecialtycode as subspecialtycode 
#  , sp.subspecialtydesc subspecialtydesc 
#  , sp.specialtycode as specialtycode 
#  , sp.specialtydesc as specialtydesc 
#  , sp.portfoliocode as portfoliocode 
#  , sp.portfoliodesc as portfoliodesc 
#  , sp.directoratecode as directoratecode 
#  , sp.directoratedesc as directoratedesc 
#  , cbu.Disch_CBU_For_Revenue_Flag as dischcburevenueflag 
#  , cbu.ED_Flag as emergencycbuflag 
#  , CASE WHEN ru.RU_DateTo IS NULL THEN 'Y' ELSE 'N' END as currentflag 
#  , ru.RU_RowId as tccbuid
#  , 'TRAK' as sourcecode
# FROM bronze.ref_l_cbu_link cbu
# join bronze.tc_l_ct_responsibleunit ru
#     on cbu.tc_ru_rowid = ru.RU_RowId
# left join silver_db.vw_tc_s_specialty sp
#     on cbu.Sub_Specialty_Id = sp.subspecialtyid
# where     date(sp.watermarkvalue)    >= '{v_watermark_date}'
# or date(cbu.processing_time) >= '{v_watermark_date}'
# or date(ru.processing_time) >= '{v_watermark_date}'
# """)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Update the target table

# COMMAND ----------

# this dataframe is required for the merge function
df_view = spark.sql("SELECT * FROM vw_s_cbu")

from pyspark.sql.functions import sha2, concat_ws
lst_cols = df_view.columns
#print(lst_cols)
lst_cols.remove('watermarkvalue')
#print(lst_cols)

df_hashed = df_view.withColumn("hashid",sha2(concat_ws('|', *lst_cols),256))

# COMMAND ----------

# set the merge condition required for the merge functions
merge_condition = 'TARGET.tccbuid = SOURCE.tccbuid'

match_additional_condition = """
TARGET.hashid <> SOURCE.hashid
"""

merge_delta_tables(df_hashed, v_target_database, v_target_table_name, merge_condition, match_additional_condition )

# COMMAND ----------

# write to the ADM_LOG.etl.LogOverview table on MI the output from the merge 
insert_into_log_overview(v_target_database, v_target_table_name, v_etlcontrolid, v_sourcesystem,  v_target_database[0], v_batchid)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Post-processing

# COMMAND ----------

# DBTITLE 1,Export deltas to parquet file
# Saving the changes in the target table as a parquet file to be consumed by Titan (via ADF).
if v_watermark_date == v_new_watermark_value.strftime("%Y-%m-%d") : 
    wmrk = '9999-01-01' 
else: 
    wmrk = v_new_watermark_value

# produce an empty dataframe if old and new watermark have the same value
df_s_parquet = get_df_titan(v_target_database,v_target_table_name, wmrk)
write_parquet_for_export(df_s_parquet, silver_folder_path, trakcare_export_parquet, v_target_table_name, 'overwrite')

# COMMAND ----------

# DBTITLE 1,Update WaterMarkValue
# update the etl.Control table WaterMarkValue with the latest processing date from the RDS joining tables
# if the old and the new watermark dates have different values
if v_watermark_date != v_new_watermark_value.strftime("%Y-%m-%d") : 
    update_mi_water_mark_value (v_new_watermark_value, v_etlcontrolid, 'Control_TRAK')

# COMMAND ----------

# df = spark.read.parquet(f"{silver_folder_path}{trakcare_export_parquet}{v_target_table_name}")
# display(df.count())
