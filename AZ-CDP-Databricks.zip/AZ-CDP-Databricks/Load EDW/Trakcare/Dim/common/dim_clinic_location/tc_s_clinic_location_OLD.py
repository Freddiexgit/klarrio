# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 26-Jan-2024 | 1       | Donne | Create first draft of tc_s_clinic_location with dummy data to enable RED development                                          |

# COMMAND ----------

# IMPORTANT! Comment out the cell with relative path to utils notebook before deployment to development branch
# IMPORTANT! Uncomment the cell with absolute path to utile notebook before deployment to development branch

# COMMAND ----------

# DBTITLE 1,Common Notebooks
#%run "../../../../../Utilities/utils"

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# Use the function below if you need to reset the development and start from scratch.
# reset_table('silver_db', 'trakcare', 'tc_s_clinic_location', 1540)

# COMMAND ----------

# DBTITLE 1,Variables
# p_etlcontrolid is passed as a parameter from ADF
dbutils.widgets.text("p_batchid","0")
v_batchid = int(dbutils.widgets.get("p_batchid"))
dbutils.widgets.text("p_etlcontrolid","1540")
v_etlcontrolid = dbutils.widgets.get("p_etlcontrolid")

# COMMAND ----------

# Create variable from etl.Control table
# WaterMarkValue is set to 1900-01-01 to allow full table loads when IncrementalLoad = 0
qry = f"""
       SELECT 
              ETLControlID
            , SourceSystem
            , SourceSystemType
            , SourceTableSchemaName
            , SourceTableName
            , CASE WHEN IncrementalLoad = 1 THEN WaterMarkValue ELSE '1900-01-01' END WaterMarkValue
            , TargetSystemType
            , TargetTableSchemaName
            , TargetTableName
            , IncrementalLoad
            , IsActive
            , TargetEntityPath
            , CustomConfig
        FROM ADM_CONFIG.etl.Control 
        WHERE ETLControlID = {v_etlcontrolid}"""

df_control = read_from_mi_db('ADM_CONFIG', qry)

v_watermark_date = df_control.select("WaterMarkValue").collect()[0][0]
v_target_table_name = df_control.select("TargetTableName").collect()[0][0]
v_target_database = df_control.select("CustomConfig").collect()[0][0]
v_sourcesystem = 'trakcare'
v_target_entity_path = df_control.select("TargetEntityPath").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,Set new WaterMarkValue
# New WaterMarkValue is the latest processing date across all RDS joining tables
v_new_watermark_value = spark.sql("""
select   date(max(watermark)) v_new_watermark_value
from 
    (
    SELECT max(processing_time) watermark FROM bronze.tc_l_ct_loc 
    UNION
    SELECT max(processing_time) watermark FROM bronze.tc_l_rbc_equipment 
    UNION
    SELECT max(processing_time) watermark FROM bronze.tc_l_rbc_equipmentgroup
    UNION
    SELECT max(processing_time) watermark FROM bronze.tc_l_rb_resource
    UNION
    SELECT max(processing_time) watermark FROM bronze.tc_l_ct_hospital
    UNION
    SELECT max(processing_time) watermark FROM bronze.tc_l_ct_significantfacility
    ) qry
""").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,Create Table
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {v_target_database}.{v_target_table_name}
( 
watermarkvalue timestamp
,hashid string
,clinicid int
,cliniccode string
,appointmentcode string
,appointmentdesc string
,location string
,sourcecode string
 )
USING DELTA
LOCATION '{silver_folder_path}trakcare/{v_target_table_name}'
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Processing

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Create Temp View with Changes only

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE TEMP VIEW vw_s_clinic_location
AS

SELECT 
'{v_new_watermark_value}' AS watermarkvalue
,1 AS clinicid 
,'dummy data' AS cliniccode 
,'dummy data' AS appointmentcode 
,'dummy data' AS appointmentdesc 
,'dummy data' AS location
,'TRAK' AS sourcecode 
FROM 
bronze.tc_l_rbc_equipment as equipment 
INNER JOIN bronze.tc_l_rbc_equipmentgroup as equipgroup on equipment.EQ_Group_DR =equipgroup.GRP_RowId
--INNER JOIN bronze.tc_l_rb_resource as resource on equipment.EQ_RowId = resource.RES_EQ_DR
INNER JOIN 
    ( --use this until duplicates in bronze.tc_l_rb_resource are removed, e.g. RES_EQ_DR=248
    SELECT MAX(RES_CTLOC_DR) AS RES_CTLOC_DR, RES_EQ_DR, RES_CODE, processing_time
    FROM bronze.tc_l_rb_resource 
    WHERE RES_EQ_DR IS NOT NULL
    GROUP BY RES_EQ_DR, RES_CODE, processing_time  
    ) resource ON equipment.EQ_RowId = resource.RES_EQ_DR
LEFT JOIN bronze.tc_l_ct_loc loc ON resource.RES_CTLOC_DR = loc.CTLOC_RowID --another join condition is required, see equipment.EQ_RowId = 248
LEFT JOIN bronze.tc_l_ct_hospital hosp ON loc.ctloc_hospital_dr = hosp.hosp_rowid
LEFT JOIN bronze.tc_l_ct_significantfacility AS directorate ON loc.CTLOC_SignifFacility_DR = directorate.SIGNF_RowId
WHERE 
equipgroup.GRP_Code = 'OP'
AND 
    (
    DATE(loc.processing_time) >= '{v_watermark_date}'
    OR DATE(hosp.processing_time) >= '{v_watermark_date}'
    OR DATE(resource.processing_time) >= '{v_watermark_date}'
    OR DATE(equipment.processing_time) >= '{v_watermark_date}'
    OR DATE(equipgroup.processing_time) >= '{v_watermark_date}'
    OR DATE(directorate.processing_time) >= '{v_watermark_date}'
    )

LIMIT 1
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC --%sql
# MAGIC --SELECT 
# MAGIC --'{v_new_watermark_value}' AS watermarkvalue
# MAGIC --,equipment.EQ_RowId as tcclinicid
# MAGIC --,'TRAK' as sourcecode
# MAGIC --,equipment.EQ_RowId as clinicid 
# MAGIC --,equipment.EQ_Code as cliniccode         
# MAGIC --,equipment.EQ_Desc as clinicdesc 
# MAGIC --,loc.CTLOC_Address cliniclocation 
# MAGIC --,'N' as clinicsecureflag
# MAGIC --,CASE 	
# MAGIC --    WHEN equipment.EQ_DateTo IS NULL AND equipgroup.GRP_DateTo IS NULL THEN '1'
# MAGIC --    ELSE '0'
# MAGIC --    END as clinicactiveflag 
# MAGIC --,loc.CTLOC_NationCode as clinichl7code
# MAGIC --,loc.CTLOC_RowID check1
# MAGIC --,' ' as clinicgroupingdesc --isnull(l_dsu_clinicgroupingmapping.clinicgroupingdesc, loc.ctloc_desc) - where is l_dsu_clinicgroupingmapping
# MAGIC --,' ' as espi2flag -- not in Trak yet
# MAGIC --,directorate.SIGNF_Code directoratecode 
# MAGIC --,directorate.SIGNF_Desc directoratedesc 
# MAGIC --,' ' as facilityactiveflag 
# MAGIC --,' ' as facilityhl7code  -- not in Trak yet
# MAGIC --, CASE
# MAGIC --    WHEN hosp.HOSP_Code = 'MH1' THEN 'AKCH'
# MAGIC --    WHEN hosp.HOSP_Code = '3260B' THEN 'SSH'
# MAGIC --    WHEN hosp.HOSP_Code = '3260' THEN 'AKCH'
# MAGIC --    WHEN hosp.HOSP_Code = '3260A' THEN 'GLCC'
# MAGIC --    WHEN hosp.HOSP_Code = '3245' THEN 'CMH'
# MAGIC --    ELSE NULL
# MAGIC --    END	as siteabbr
# MAGIC --,hosp.Hosp_desc as sitename 
# MAGIC --,
# MAGIC
# MAGIC --FROM 
# MAGIC --bronze.tc_l_rbc_equipment as equipment 
# MAGIC --INNER JOIN bronze.tc_l_rbc_equipmentgroup as equipgroup on equipment.EQ_Group_DR =equipgroup.GRP_RowId
# MAGIC --INNER JOIN bronze.tc_l_rb_resource as resource on equipment.EQ_RowId = resource.RES_EQ_DR
# MAGIC --INNER JOIN 
# MAGIC --    ( --use this until duplicates in bronze.tc_l_rb_resource are removed, e.g. RES_EQ_DR=248
# MAGIC --    SELECT MAX(RES_CTLOC_DR) AS RES_CTLOC_DR, RES_EQ_DR, RES_CODE, processing_time
# MAGIC --    FROM bronze.tc_l_rb_resource 
# MAGIC --    WHERE RES_EQ_DR IS NOT NULL
# MAGIC --    GROUP BY RES_EQ_DR, RES_CODE, processing_time  
# MAGIC --    ) resource ON equipment.EQ_RowId = resource.RES_EQ_DR
# MAGIC --LEFT JOIN bronze.tc_l_ct_loc loc on resource.RES_CTLOC_DR = loc.CTLOC_RowID --another join condition is required, see equipment.EQ_RowId = 248
# MAGIC --LEFT JOIN bronze.tc_l_ct_hospital hosp on loc.ctloc_hospital_dr = hosp.hosp_rowid
# MAGIC --LEFT JOIN bronze.tc_l_ct_significantfacility as directorate on loc.CTLOC_SignifFacility_DR = directorate.SIGNF_RowId
# MAGIC
# MAGIC --WHERE 
# MAGIC --equipgroup.GRP_Code = 'O

# COMMAND ----------

# MAGIC %md
# MAGIC #### Update the target table

# COMMAND ----------

# this dataframe is required for the merge function
df_view = spark.sql("SELECT * FROM vw_s_clinic_location")

from pyspark.sql.functions import sha2, concat_ws

# obtain the list of column to be used to generate the hashid column: it should include all columns except the watermark
lst_cols = df_view.columns
lst_cols.remove('watermarkvalue')

# add hashid column to the view dataframe
df_hashed = df_view.withColumn("hashid",sha2(concat_ws('|', *lst_cols),256))

# COMMAND ----------

# set the merge condition required for the merge functions
merge_condition = 'TARGET.cliniccode = SOURCE.cliniccode AND TARGET.appointmentcode = SOURCE.appointmentcode'
match_additional_condition = 'TARGET.hashid <> SOURCE.hashid'
merge_delta_tables(df_hashed, v_target_database, v_target_table_name, merge_condition, match_additional_condition )

# COMMAND ----------

# write to the ADM_LOG.etl.LogOverview table on MI the output from the merge 
insert_into_log_overview(v_target_database, v_target_table_name, v_etlcontrolid, v_sourcesystem, v_target_database[0], v_batchid)

# COMMAND ----------

# MAGIC %md
# MAGIC ####Validation Checks

# COMMAND ----------

# DBTITLE 1,No Duplicates and NULL values
# v_grain = 'cliniccode,'
# v_columns_exclude = ''

# check_for_duplicates (v_target_database, v_target_table_name, v_grain, v_columns_exclude)
# check_for_null_values(v_target_database, v_target_table_name, v_grain, v_columns_exclude)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Post-processing

# COMMAND ----------

# DBTITLE 1,Export deltas to parquet file
# Saving the changes in the target table as a parquet file to be consumed by Titan (via ADF).
if v_watermark_date == v_new_watermark_value.strftime("%Y-%m-%d") : 
    wmrk = '9999-01-01' 
else: 
    wmrk = v_new_watermark_value

# produce an empty dataframe if old and new watermark have the same value
df_s_parquet = get_df_titan(v_target_database,v_target_table_name, wmrk)
write_parquet_for_export(df_s_parquet, silver_folder_path, trakcare_export_parquet, v_target_table_name, 'overwrite')

# COMMAND ----------

# DBTITLE 1,Update WaterMarkValue
# update the etl.Control table WaterMarkValue with the latest processing date from the RDS joining tables
# if the old and the new watermark dates have different values
if v_watermark_date != v_new_watermark_value.strftime("%Y-%m-%d") : 
    update_mi_water_mark_value (v_new_watermark_value, v_etlcontrolid)

# COMMAND ----------

df = spark.read.parquet(f"{silver_folder_path}{trakcare_export_parquet}{v_target_table_name}")
display(df.count())
