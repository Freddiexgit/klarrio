-- Databricks notebook source
Select count(*) from silver_db.tc_s_patient;

-- COMMAND ----------

select * from silver_db.tc_s_ward 
--where mhwardhistoricflag = 'Y'

-- COMMAND ----------

select * from bronze.dsu_l_domicile

-- COMMAND ----------

select * from  silver_db.vw_tc_f_diagnosis where eventid='6650318'

-- COMMAND ----------

desc columns in silver_db.tc_s_diagnosis

-- COMMAND ----------

-- MAGIC %python
-- MAGIC import requests
-- MAGIC import json
-- MAGIC import datetime
-- MAGIC # Define the endpoint URL for the Databricks Jobs API
-- MAGIC endpoint = "https://adb-1296242858425512.12.azuredatabricks.net/api/2.1/jobs/list"
-- MAGIC # Define the API token for authentication
-- MAGIC headers = {
-- MAGIC     "Authorization": "Bearer dapie7ee1698f3cd5eed998c398a05d0efcd"
-- MAGIC }
-- MAGIC # Get the current time and subtract 12 hours to find the start time for the search
-- MAGIC current_time = datetime.datetime.utcnow()
-- MAGIC start_time = current_time - datetime.timedelta(hours=12)
-- MAGIC # Define the parameters for the API call to list all jobs in the past 12 hours
-- MAGIC params = {
-- MAGIC     "status": "FAILED",
-- MAGIC     "from_time": int(start_time.timestamp() * 1000)
-- MAGIC }
-- MAGIC # Call the Databricks Jobs API
-- MAGIC response = requests.get(endpoint, headers=headers, params=params)

-- COMMAND ----------

-- MAGIC %python
-- MAGIC json.loads(response.text)

-- COMMAND ----------

-- MAGIC %python
-- MAGIC # Parse the response from the API
-- MAGIC jobs = json.loads(response.text)["jobs"]
-- MAGIC # Print all job failures in the past 12 hours
-- MAGIC for job in jobs:
-- MAGIC     print("Job ID:", job["job_id"], "Start Time:", datetime.datetime.fromtimestamp(job["start_time"]/1000), "Status:", job["state"]["life_cycle_state"])

-- COMMAND ----------

-- MAGIC %python
-- MAGIC dbutils.secrets.listScopes()

-- COMMAND ----------

-- MAGIC %python
-- MAGIC dbutils.secrets.list('AzureSecretScope')

-- COMMAND ----------

-- MAGIC %python
-- MAGIC dbutils.secrets.list('StorageAccountSecretScope')

-- COMMAND ----------

-- MAGIC %python
-- MAGIC import json, pprint
-- MAGIC
-- MAGIC dict_job_run_metadata = json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson())
-- MAGIC
-- MAGIC print(f'''      
-- MAGIC       currentRunId: {dict_job_run_metadata['currentRunId']}
-- MAGIC       jobGroup: {dict_job_run_metadata['jobGroup']}
-- MAGIC       ''')
-- MAGIC
-- MAGIC # Pretty print the dictionary
-- MAGIC pprint.pprint(dict_job_run_metadata)

-- COMMAND ----------

select * 
from bronze.tc_l_rbc_apptoutcome
