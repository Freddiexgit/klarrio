# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 12-Apr-2023 | 1       | Ranga          | Created dim_ad_groups                                   |
# MAGIC |                                                                 |

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# %run "../../../../Utilities/utils"

# COMMAND ----------

##############################
# Set widget and default value for this.
dbutils.widgets.text("mount_point", "/mnt/devcdpadlsae1/")
path = dbutils.widgets.get("mount_point")
spark.conf.set("table.path",path)
##############################

# COMMAND ----------

# MAGIC %sql
# MAGIC SET TIME ZONE 'Pacific/Auckland';

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS gold.dim_AD_groups(
# MAGIC 	id string,
# MAGIC 	deletedDateTime timestamp,
# MAGIC 	classification string,
# MAGIC 	createdDateTime timestamp,
# MAGIC 	description string,
# MAGIC 	displayName string,
# MAGIC 	expirationDateTime timestamp,
# MAGIC 	isAssignableToRole boolean,
# MAGIC 	mail string,
# MAGIC 	mailEnabled boolean,
# MAGIC 	mailNickname string,
# MAGIC 	membershipRule string,
# MAGIC 	membershipRuleProcessingState string,
# MAGIC 	onPremisesDomainName string,
# MAGIC 	onPremisesLastSyncDateTime timestamp,
# MAGIC 	onPremisesNetBiosName string,
# MAGIC 	onPremisesSamAccountName string,
# MAGIC 	onPremisesSecurityIdentifier string,
# MAGIC 	onPremisesSyncEnabled boolean,
# MAGIC 	preferredDataLocation string,
# MAGIC 	preferredLanguage string,
# MAGIC 	renewedDateTime timestamp,
# MAGIC 	securityEnabled boolean,
# MAGIC 	securityIdentifier string,
# MAGIC 	theme string,
# MAGIC 	visibility string,
# MAGIC     hashField string,
# MAGIC 	dss_version int,
# MAGIC 	dss_activeFlag boolean,
# MAGIC 	dss_activeStartDateTime timestamp,
# MAGIC 	dss_activeEndDateTime timestamp
# MAGIC )
# MAGIC LOCATION '${table.path}gold/Audit/dim_ad_groups'

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE silver_db.msad_s_ad_groups
# MAGIC LOCATION '${table.path}silver_db/Audit/msad_s_ad_groups'
# MAGIC AS
# MAGIC SELECT 
# MAGIC   id
# MAGIC   , cast(deletedDateTime as timestamp) as deletedDateTime
# MAGIC   , classification
# MAGIC   , cast(createdDateTime as timestamp) as createdDateTime
# MAGIC   , description
# MAGIC   , displayName
# MAGIC   , cast(expirationDateTime as timestamp) as expirationDateTime
# MAGIC   , cast(isAssignableToRole as boolean)
# MAGIC   , mail
# MAGIC   , cast(mailEnabled as boolean)
# MAGIC   , mailNickname
# MAGIC   , membershipRule
# MAGIC   , membershipRuleProcessingState
# MAGIC   , onPremisesDomainName
# MAGIC   , cast(onPremisesLastSyncDateTime as timestamp) as onPremisesLastSyncDateTime
# MAGIC   , onPremisesNetBiosName
# MAGIC   , onPremisesSamAccountName
# MAGIC   , onPremisesSecurityIdentifier
# MAGIC   , cast(onPremisesSyncEnabled as timestamp) as  onPremisesSyncEnabled
# MAGIC   , preferredDataLocation
# MAGIC   , preferredLanguage
# MAGIC   , cast(renewedDateTime as timestamp) as renewedDateTime
# MAGIC   , cast(securityEnabled as boolean)
# MAGIC   , securityIdentifier
# MAGIC   , theme
# MAGIC   , visibility 
# MAGIC   , md5(concat(
# MAGIC         ifnull(id,'')
# MAGIC         , ifnull(deletedDateTime,'')
# MAGIC         , ifnull(classification,'')
# MAGIC         , ifnull(createdDateTime,'')
# MAGIC         , ifnull(description,'')
# MAGIC         , ifnull(displayName,'')
# MAGIC         , ifnull(expirationDateTime,'')
# MAGIC         , ifnull(cast(isAssignableToRole as string),'')
# MAGIC         , ifnull(mail,'')
# MAGIC         , ifnull(cast(mailEnabled as string),'')
# MAGIC         , ifnull(mailNickname,'')
# MAGIC         , ifnull(membershipRule,'')
# MAGIC         , ifnull(membershipRuleProcessingState,'')
# MAGIC         , ifnull(onPremisesDomainName,'')
# MAGIC         , ifnull(onPremisesNetBiosName,'')
# MAGIC         , ifnull(onPremisesSamAccountName,'')
# MAGIC         , ifnull(onPremisesSecurityIdentifier,'')
# MAGIC         , ifnull(cast(onPremisesSyncEnabled as string),'')
# MAGIC         , ifnull(preferredDataLocation,'')
# MAGIC         , ifnull(preferredLanguage,'')
# MAGIC         , ifnull(renewedDateTime,'')
# MAGIC         , ifnull(cast(securityEnabled as string),'')
# MAGIC         , ifnull(securityIdentifier,'')
# MAGIC         , ifnull(theme,'')
# MAGIC         , ifnull(visibility,'')
# MAGIC        )) as hashField
# MAGIC   , ROW_NUMBER() OVER (PARTITION BY id ORDER BY createdDateTime desc) AS RN
# MAGIC FROM bronze.msad_l_groups
# MAGIC QUALIFY RN = 1
# MAGIC
# MAGIC     

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO gold.dim_ad_groups AS target USING (
# MAGIC   SELECT 
# MAGIC     id, 
# MAGIC     deletedDateTime, 
# MAGIC     classification, 
# MAGIC     createdDateTime, 
# MAGIC     description, 
# MAGIC     displayName, 
# MAGIC     expirationDateTime, 
# MAGIC     isAssignableToRole, 
# MAGIC     mail, 
# MAGIC     mailEnabled, 
# MAGIC     mailNickname, 
# MAGIC     membershipRule, 
# MAGIC     membershipRuleProcessingState, 
# MAGIC     onPremisesDomainName, 
# MAGIC     onPremisesLastSyncDateTime, 
# MAGIC     onPremisesNetBiosName, 
# MAGIC     onPremisesSamAccountName, 
# MAGIC     onPremisesSecurityIdentifier, 
# MAGIC     onPremisesSyncEnabled, 
# MAGIC     preferredDataLocation, 
# MAGIC     preferredLanguage, 
# MAGIC     renewedDateTime, 
# MAGIC     securityEnabled, 
# MAGIC     securityIdentifier, 
# MAGIC     theme, 
# MAGIC     visibility, 
# MAGIC     hashField, 
# MAGIC     1 dss_version, 
# MAGIC     'update' update_action 
# MAGIC   FROM 
# MAGIC     silver_db.msad_s_ad_groups 
# MAGIC   UNION ALL 
# MAGIC   SELECT 
# MAGIC     src.id, 
# MAGIC     src.deletedDateTime, 
# MAGIC     src.classification, 
# MAGIC     src.createdDateTime, 
# MAGIC     src.description, 
# MAGIC     src.displayName, 
# MAGIC     src.expirationDateTime, 
# MAGIC     src.isAssignableToRole, 
# MAGIC     src.mail, 
# MAGIC     src.mailEnabled, 
# MAGIC     src.mailNickname, 
# MAGIC     src.membershipRule, 
# MAGIC     src.membershipRuleProcessingState, 
# MAGIC     src.onPremisesDomainName, 
# MAGIC     src.onPremisesLastSyncDateTime, 
# MAGIC     src.onPremisesNetBiosName, 
# MAGIC     src.onPremisesSamAccountName, 
# MAGIC     src.onPremisesSecurityIdentifier, 
# MAGIC     src.onPremisesSyncEnabled, 
# MAGIC     src.preferredDataLocation, 
# MAGIC     src.preferredLanguage, 
# MAGIC     src.renewedDateTime, 
# MAGIC     src.securityEnabled, 
# MAGIC     src.securityIdentifier, 
# MAGIC     src.theme, 
# MAGIC     src.visibility, 
# MAGIC     src.hashField, 
# MAGIC     IFNULL(MAX(tgt.dss_version),0) + 1 dss_version, 
# MAGIC     'insert' update_action 
# MAGIC   FROM 
# MAGIC     silver_db.msad_s_ad_groups src 
# MAGIC     INNER JOIN gold.dim_ad_groups tgt ON tgt.id = src.id 
# MAGIC     AND src.hashField <> tgt.hashField 
# MAGIC     AND tgt.dss_activeFlag = TRUE 
# MAGIC   GROUP BY 
# MAGIC     src.id, 
# MAGIC     src.deletedDateTime, 
# MAGIC     src.classification, 
# MAGIC     src.createdDateTime, 
# MAGIC     src.description, 
# MAGIC     src.displayName, 
# MAGIC     src.expirationDateTime, 
# MAGIC     src.isAssignableToRole, 
# MAGIC     src.mail, 
# MAGIC     src.mailEnabled, 
# MAGIC     src.mailNickname, 
# MAGIC     src.membershipRule, 
# MAGIC     src.membershipRuleProcessingState, 
# MAGIC     src.onPremisesDomainName, 
# MAGIC     src.onPremisesLastSyncDateTime, 
# MAGIC     src.onPremisesNetBiosName, 
# MAGIC     src.onPremisesSamAccountName, 
# MAGIC     src.onPremisesSecurityIdentifier, 
# MAGIC     src.onPremisesSyncEnabled, 
# MAGIC     src.preferredDataLocation, 
# MAGIC     src.preferredLanguage, 
# MAGIC     src.renewedDateTime, 
# MAGIC     src.securityEnabled, 
# MAGIC     src.securityIdentifier, 
# MAGIC     src.theme, 
# MAGIC     src.visibility, 
# MAGIC     src.hashField
# MAGIC ) AS source ON source.id = target.id 
# MAGIC AND source.update_action = 'update' WHEN MATCHED 
# MAGIC AND source.hashField <> target.hashField 
# MAGIC AND target.dss_activeFlag = TRUE THEN 
# MAGIC UPDATE 
# MAGIC SET 
# MAGIC   dss_activeFlag = FALSE, 
# MAGIC   dss_activeEndDateTime = CURRENT_TIMESTAMP() 
# MAGIC WHEN NOT MATCHED THEN INSERT (
# MAGIC     id, deletedDateTime, classification, 
# MAGIC     createdDateTime, description, displayName, 
# MAGIC     expirationDateTime, isAssignableToRole, 
# MAGIC     mail, mailEnabled, mailNickname, 
# MAGIC     membershipRule, membershipRuleProcessingState, 
# MAGIC     onPremisesDomainName, onPremisesLastSyncDateTime, 
# MAGIC     onPremisesNetBiosName, onPremisesSamAccountName, 
# MAGIC     onPremisesSecurityIdentifier, onPremisesSyncEnabled, 
# MAGIC     preferredDataLocation, preferredLanguage, 
# MAGIC     renewedDateTime, securityEnabled, 
# MAGIC     securityIdentifier, theme, visibility, 
# MAGIC     hashField, dss_version, dss_activeFlag, 
# MAGIC     dss_activeStartDateTime, dss_activeEndDateTime
# MAGIC   ) 
# MAGIC VALUES 
# MAGIC   (
# MAGIC     source.id, 
# MAGIC     source.deletedDateTime, 
# MAGIC     source.classification, 
# MAGIC     source.createdDateTime, 
# MAGIC     source.description, 
# MAGIC     source.displayName, 
# MAGIC     source.expirationDateTime, 
# MAGIC     source.isAssignableToRole, 
# MAGIC     source.mail, 
# MAGIC     source.mailEnabled, 
# MAGIC     source.mailNickname, 
# MAGIC     source.membershipRule, 
# MAGIC     source.membershipRuleProcessingState, 
# MAGIC     source.onPremisesDomainName, 
# MAGIC     source.onPremisesLastSyncDateTime, 
# MAGIC     source.onPremisesNetBiosName, 
# MAGIC     source.onPremisesSamAccountName, 
# MAGIC     source.onPremisesSecurityIdentifier, 
# MAGIC     source.onPremisesSyncEnabled, 
# MAGIC     source.preferredDataLocation, 
# MAGIC     source.preferredLanguage, 
# MAGIC     source.renewedDateTime, 
# MAGIC     source.securityEnabled, 
# MAGIC     source.securityIdentifier, 
# MAGIC     source.theme, 
# MAGIC     source.visibility, 
# MAGIC     source.hashField, 
# MAGIC     source.dss_version, 
# MAGIC     TRUE, 
# MAGIC     current_timestamp(), 
# MAGIC     CAST('2999-12-31T23:59:59.997' as timestamp)
# MAGIC   )

# COMMAND ----------

data_df = spark.read.table("gold.dim_ad_groups")
write_to_mi_db(data_df, "DA_AUDIT", "dbo.dim_ad_groups", "overwrite")
