# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 12-Apr-2023 | 1       | Ranga          | Created dim_ad_users                                   |
# MAGIC |                                                                 |

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# %run "../../../../Utilities/utils"

# COMMAND ----------

##############################
# Set widget and default value for this.
dbutils.widgets.text("mount_point", "/mnt/devcdpadlsae1/")
path = dbutils.widgets.get("mount_point")
spark.conf.set("table.path",path)
##############################

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SET TIME ZONE 'Pacific/Auckland';

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS gold.dim_AD_users(
# MAGIC 	displayName string
# MAGIC 	, givenName string
# MAGIC 	, jobTitle string
# MAGIC 	, mail string
# MAGIC 	, mobilePhone string
# MAGIC 	, officeLocation string
# MAGIC 	, preferredLanguage string
# MAGIC 	, surname string
# MAGIC 	, userPrincipalName string
# MAGIC 	, id string
# MAGIC     , hashField string
# MAGIC 	, dss_version int
# MAGIC 	, dss_activeFlag boolean
# MAGIC 	, dss_activeStartDateTime timestamp
# MAGIC 	, dss_activeEndDateTime timestamp
# MAGIC )
# MAGIC LOCATION '${table.path}gold/Audit/dim_ad_users'

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE silver_db.msad_s_ad_users
# MAGIC LOCATION '${table.path}silver_db/Audit/msad_s_ad_users'
# MAGIC AS
# MAGIC SELECT 
# MAGIC   displayName
# MAGIC   , givenName
# MAGIC   , jobTitle
# MAGIC   , mail
# MAGIC   , mobilePhone
# MAGIC   , officeLocation
# MAGIC   , preferredLanguage
# MAGIC   , surname
# MAGIC   , userPrincipalName
# MAGIC   , id
# MAGIC   , md5(concat(
# MAGIC         ifnull(id,'')
# MAGIC         , ifnull(displayName,'')
# MAGIC         , ifnull(givenName,'')
# MAGIC         , ifnull(jobTitle,'')
# MAGIC         , ifnull(mail,'')
# MAGIC         , ifnull(mobilePhone,'')
# MAGIC         , ifnull(officeLocation,'')
# MAGIC         , ifnull(preferredLanguage,'')
# MAGIC         , ifnull(surname,'')
# MAGIC         , ifnull(userPrincipalName,'')
# MAGIC        )) as hashField
# MAGIC   , ROW_NUMBER() OVER (PARTITION BY id ORDER BY id desc) AS RN
# MAGIC FROM bronze.msad_l_users
# MAGIC QUALIFY RN = 1
# MAGIC
# MAGIC     

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO gold.dim_ad_users AS target USING (
# MAGIC   SELECT 
# MAGIC     displayName
# MAGIC     , givenName
# MAGIC     , jobTitle
# MAGIC     , mail
# MAGIC     , mobilePhone
# MAGIC     , officeLocation
# MAGIC     , preferredLanguage
# MAGIC     , surname
# MAGIC     , userPrincipalName
# MAGIC     , id 
# MAGIC     , hashField
# MAGIC     , 1 dss_version
# MAGIC     , 'update' update_action 
# MAGIC   FROM 
# MAGIC     silver_db.msad_s_ad_users 
# MAGIC   UNION ALL 
# MAGIC   SELECT 
# MAGIC     src.displayName
# MAGIC     , src.givenName
# MAGIC     , src.jobTitle
# MAGIC     , src.mail
# MAGIC     , src.mobilePhone
# MAGIC     , src.officeLocation
# MAGIC     , src.preferredLanguage
# MAGIC     , src.surname
# MAGIC     , src.userPrincipalName
# MAGIC     , src.id 
# MAGIC     , src.hashField
# MAGIC     , IFNULL(MAX(tgt.dss_version),0) + 1 dss_version
# MAGIC     , 'insert' update_action 
# MAGIC   FROM 
# MAGIC     silver_db.msad_s_ad_users src 
# MAGIC     INNER JOIN gold.dim_ad_users tgt ON tgt.id = src.id 
# MAGIC     AND src.hashField <> tgt.hashField 
# MAGIC     AND tgt.dss_activeFlag = TRUE
# MAGIC   GROUP BY 
# MAGIC     src.displayName
# MAGIC     , src.givenName
# MAGIC     , src.jobTitle
# MAGIC     , src.mail
# MAGIC     , src.mobilePhone
# MAGIC     , src.officeLocation
# MAGIC     , src.preferredLanguage
# MAGIC     , src.surname
# MAGIC     , src.userPrincipalName
# MAGIC     , src.id 
# MAGIC     , src.hashField
# MAGIC ) AS source ON source.id = target.id AND source.update_action = 'update' 
# MAGIC
# MAGIC WHEN MATCHED AND source.hashField <> target.hashField AND target.dss_activeFlag = TRUE 
# MAGIC THEN UPDATE 
# MAGIC   SET 
# MAGIC     dss_activeFlag = FALSE, 
# MAGIC     dss_activeEndDateTime = CURRENT_TIMESTAMP()
# MAGIC
# MAGIC WHEN NOT MATCHED THEN INSERT (
# MAGIC     displayName
# MAGIC     , givenName
# MAGIC     , jobTitle
# MAGIC     , mail
# MAGIC     , mobilePhone
# MAGIC     , officeLocation
# MAGIC     , preferredLanguage
# MAGIC     , surname
# MAGIC     , userPrincipalName
# MAGIC     , id 
# MAGIC     , hashField
# MAGIC     , dss_version
# MAGIC     , dss_activeFlag
# MAGIC     , dss_activeStartDateTime
# MAGIC     , dss_activeEndDateTime
# MAGIC   ) 
# MAGIC VALUES 
# MAGIC   (
# MAGIC     source.displayName
# MAGIC     , source.givenName
# MAGIC     , source.jobTitle
# MAGIC     , source.mail
# MAGIC     , source.mobilePhone
# MAGIC     , source.officeLocation
# MAGIC     , source.preferredLanguage
# MAGIC     , source.surname
# MAGIC     , source.userPrincipalName
# MAGIC     , source.id 
# MAGIC     , source.hashField 
# MAGIC     , source.dss_version 
# MAGIC     , TRUE
# MAGIC     , current_timestamp()
# MAGIC     , CAST('2999-12-31T23:59:59.997' as timestamp)
# MAGIC   )

# COMMAND ----------

data_df = spark.read.table("gold.dim_ad_users")
write_to_mi_db(data_df, "DA_AUDIT", "dbo.dim_ad_users", "overwrite")
