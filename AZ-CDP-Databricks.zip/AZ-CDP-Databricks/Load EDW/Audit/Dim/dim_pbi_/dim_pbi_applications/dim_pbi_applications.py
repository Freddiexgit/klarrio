# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 12-Apr-2023 | 1       | Ranga          | Created dim_pbi_applications                                   |
# MAGIC |                                                                 |

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# %run "../../../../Utilities/utils"

# COMMAND ----------

##############################
# Set widget and default value for this.
dbutils.widgets.text("mount_point", "/mnt/devcdpadlsae1/")
path = dbutils.widgets.get("mount_point")
spark.conf.set("table.path",path)
##############################

# COMMAND ----------

# MAGIC %sql
# MAGIC SET TIME ZONE 'Pacific/Auckland';

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS gold.dim_pbi_applications(
# MAGIC 	id string
# MAGIC 	, name string
# MAGIC     , description string
# MAGIC 	, lastUpdate timestamp
# MAGIC 	, publishedBy string
# MAGIC 	, workspaceID string
# MAGIC     , hashField string
# MAGIC 	, dss_version int
# MAGIC 	, dss_activeFlag boolean
# MAGIC 	, dss_activeStartDateTime timestamp
# MAGIC 	, dss_activeEndDateTime timestamp
# MAGIC )
# MAGIC LOCATION '${table.path}gold/Audit/dim_pbi_applications'

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE silver_db.mspbi_s_pbi_applications
# MAGIC LOCATION '${table.path}silver_db/Audit/mspbi_s_pbi_applications'
# MAGIC AS
# MAGIC SELECT
# MAGIC   id
# MAGIC   , name
# MAGIC   , description
# MAGIC   , lastUpdate
# MAGIC   , publishedBy
# MAGIC   , workspaceID
# MAGIC   , md5(concat(
# MAGIC         ifnull(id,'')
# MAGIC         , ifnull(name,'')
# MAGIC         , ifnull(description,'')
# MAGIC         , ifnull(cast(lastUpdate as string),'')
# MAGIC         , ifnull(publishedBy,'')
# MAGIC         , ifnull(workspaceID,'')
# MAGIC        )) as hashField
# MAGIC   , ROW_NUMBER() OVER (PARTITION BY id ORDER BY lastUpdate desc) AS RN
# MAGIC FROM bronze.mspbi_l_applications
# MAGIC QUALIFY RN = 1
# MAGIC
# MAGIC     

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO gold.dim_pbi_applications AS target USING (
# MAGIC   SELECT 
# MAGIC    id
# MAGIC    , name
# MAGIC    , description
# MAGIC    , lastUpdate
# MAGIC    , publishedBy
# MAGIC    , workspaceID
# MAGIC    , hashField
# MAGIC    , 1 dss_version
# MAGIC    , 'update' update_action 
# MAGIC   FROM 
# MAGIC     silver_db.mspbi_s_pbi_applications 
# MAGIC   UNION ALL 
# MAGIC   SELECT
# MAGIC     src.id
# MAGIC    , src.name
# MAGIC    , src.description
# MAGIC    , src.lastUpdate
# MAGIC    , src.publishedBy
# MAGIC    , src.workspaceID
# MAGIC    , src.hashField
# MAGIC     , IFNULL(MAX(tgt.dss_version),0) + 1 dss_version
# MAGIC     , 'insert' update_action 
# MAGIC   FROM 
# MAGIC     silver_db.mspbi_s_pbi_applications src 
# MAGIC     INNER JOIN gold.dim_pbi_applications tgt ON tgt.id = src.id 
# MAGIC     AND src.hashField <> tgt.hashField 
# MAGIC     AND tgt.dss_activeFlag = TRUE
# MAGIC   GROUP BY 
# MAGIC      src.id
# MAGIC    , src.name
# MAGIC    , src.description
# MAGIC    , src.lastUpdate
# MAGIC    , src.publishedBy
# MAGIC    , src.workspaceID
# MAGIC    , src.hashField
# MAGIC ) AS source ON source.id = target.id AND source.update_action = 'update' 
# MAGIC
# MAGIC WHEN MATCHED AND source.hashField <> target.hashField AND target.dss_activeFlag = TRUE 
# MAGIC THEN UPDATE 
# MAGIC   SET 
# MAGIC     dss_activeFlag = FALSE, 
# MAGIC     dss_activeEndDateTime = CURRENT_TIMESTAMP()
# MAGIC
# MAGIC WHEN NOT MATCHED THEN INSERT (
# MAGIC     id
# MAGIC     , name
# MAGIC     , description
# MAGIC     , lastUpdate
# MAGIC     , publishedBy
# MAGIC     , workspaceID
# MAGIC     , hashField
# MAGIC 	, dss_version
# MAGIC 	, dss_activeFlag
# MAGIC 	, dss_activeStartDateTime
# MAGIC 	, dss_activeEndDateTime
# MAGIC   ) 
# MAGIC VALUES 
# MAGIC   (
# MAGIC     source.id
# MAGIC     , source.name
# MAGIC     , source.description
# MAGIC     , source.lastUpdate
# MAGIC     , source.publishedBy
# MAGIC     , source.workspaceID
# MAGIC     , source.hashField
# MAGIC 	, source.dss_version 
# MAGIC     , TRUE
# MAGIC     , current_timestamp()
# MAGIC     , CAST('2999-12-31T23:59:59.997' as timestamp)
# MAGIC   )

# COMMAND ----------

data_df = spark.read.table("gold.dim_pbi_applications")
write_to_mi_db(data_df, "DA_AUDIT", "dbo.dim_pbi_applications", "overwrite")
