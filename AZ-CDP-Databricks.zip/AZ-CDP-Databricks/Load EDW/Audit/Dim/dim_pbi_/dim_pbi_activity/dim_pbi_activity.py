# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 17-Apr-2023 | 1       | Abhilash       | Created dim_pbi_activity                                                   |
# MAGIC |                                                                                                                     |

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

#%run "../../../../Utilities/utils"

# COMMAND ----------

dbutils.widgets.text("mount_point", "/mnt/devcdpadlsae1/")
path = dbutils.widgets.get("mount_point")
spark.conf.set("table.path",path)

# COMMAND ----------

# MAGIC %sql
# MAGIC SET TIME ZONE 'Pacific/Auckland';

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS gold.dim_PBI_Activity(
# MAGIC 	  dim_key string
# MAGIC 	, activity string
# MAGIC 	, dss_activeStartDateTime timestamp
# MAGIC )
# MAGIC LOCATION '${table.path}gold/Audit/dim_PBI_Activity'

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE silver_db.mspbi_s_pbi_activity
# MAGIC LOCATION '${table.path}silver_db/Audit/mspbi_s_pbi_activity'
# MAGIC AS
# MAGIC SELECT DISTINCT
# MAGIC md5(ifnull(activity,'')) as dim_key
# MAGIC ,activity 
# MAGIC FROM bronze.mspbi_l_activityevents  

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO gold.dim_PBI_Activity AS target USING (
# MAGIC   SELECT DISTINCT
# MAGIC     md5(ifnull(activity,'')) as dim_key
# MAGIC     , activity    
# MAGIC   FROM 
# MAGIC     silver_db.mspbi_s_pbi_activity  
# MAGIC ) AS source ON source.dim_key = target.dim_key
# MAGIC
# MAGIC WHEN NOT MATCHED THEN INSERT (
# MAGIC     dim_key
# MAGIC     , activity
# MAGIC     , dss_activeStartDateTime
# MAGIC   ) 
# MAGIC VALUES 
# MAGIC   (
# MAGIC     source.dim_key
# MAGIC     , source.activity
# MAGIC     , current_timestamp()
# MAGIC   )

# COMMAND ----------

data_df = spark.read.table("gold.dim_pbi_activity")
write_to_mi_db(data_df, "DA_AUDIT", "dbo.dim_pbi_activity", "overwrite")
