# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 17-Apr-2023 | 1       | Abhilash       | Created dim_pbi_consumption                                                   |
# MAGIC |                                                                                                                     |

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

#%run "../../../../Utilities/utils"

# COMMAND ----------

dbutils.widgets.text("mount_point", "/mnt/devcdpadlsae1/")
path = dbutils.widgets.get("mount_point")
spark.conf.set("table.path",path)

# COMMAND ----------

# MAGIC %sql
# MAGIC SET TIME ZONE 'Pacific/Auckland';

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS gold.dim_PBI_consumption(
# MAGIC 	  dim_key string
# MAGIC 	, consumptionMethod string
# MAGIC 	, dss_activeStartDateTime timestamp
# MAGIC )
# MAGIC LOCATION '${table.path}gold/Audit/dim_PBI_consumption'

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE silver_db.mspbi_s_pbi_consumption
# MAGIC LOCATION '${table.path}silver_db/Audit/mspbi_s_pbi_consumption'
# MAGIC AS
# MAGIC SELECT DISTINCT
# MAGIC md5(ifnull(consumptionMethod,'')) as dim_key
# MAGIC ,consumptionMethod 
# MAGIC FROM bronze.mspbi_l_activityevents  

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO gold.dim_PBI_consumption AS target USING (
# MAGIC   SELECT DISTINCT
# MAGIC     md5(ifnull(consumptionMethod,'')) as dim_key
# MAGIC     , consumptionMethod    
# MAGIC   FROM 
# MAGIC     silver_db.mspbi_s_pbi_consumption 
# MAGIC ) AS source ON source.dim_key = target.dim_key
# MAGIC
# MAGIC WHEN NOT MATCHED THEN INSERT (
# MAGIC     dim_key
# MAGIC     , consumptionMethod
# MAGIC     , dss_activeStartDateTime
# MAGIC   ) 
# MAGIC VALUES 
# MAGIC   (
# MAGIC     source.dim_key
# MAGIC     , source.consumptionMethod
# MAGIC     , current_timestamp()
# MAGIC   )

# COMMAND ----------

data_df = spark.read.table("gold.dim_pbi_consumption")
write_to_mi_db(data_df, "DA_AUDIT", "dbo.dim_pbi_consumption", "overwrite")
