# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 17-Apr-2023 | 1       | Abhilash       | Created dim_pbi_activityEvents                                             |
# MAGIC |                                                                                                                     |

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

#%run "../../../../Utilities/utils"

# COMMAND ----------

dbutils.widgets.text("mount_point", "/mnt/devcdpadlsae1/")
path = dbutils.widgets.get("mount_point")

# COMMAND ----------

# MAGIC %sql
# MAGIC SET TIME ZONE 'Pacific/Auckland';

# COMMAND ----------

def check_if_table_exists(database_name, target_table, key_columns):
    username = 'adhbsqladmin'
        #pwd = dbutils.secrets.get(scope = azure_secret_scope, key = azure_sql_pwd_key)
        #pwd = "dzqUn%sT&#D0M6V#"
    pwd=dbutils.secrets.get(scope='AzureSecretScope',key='az-sql-mi-admin-password')

    try:
        keys_df = spark.read.format("jdbc") \
            .option("url", f"{url_mi}{database_name};") \
            .option("dbtable", target_table) \
            .option("user", username) \
            .option("password", pwd) \
            .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
            .load().select(key_columns)        
        return True
    
    except Exception as ValueError:        
        return False

# COMMAND ----------

def insert_to_mi_db(input_df, database_name, target_table, mode_name, key_columns):
    # specify input_df
    # url_mi is a common variable
    # specify database name
    # specify target_table
    # specify mode_name: overwrite or append
    # specify key_columns: ["Id", "Name"]
    try:
        #print("start writing to sql")

        username = 'adhbsqladmin'
        #pwd = dbutils.secrets.get(scope = azure_secret_scope, key = azure_sql_pwd_key)
        #pwd = "dzqUn%sT&#D0M6V#"
        pwd=dbutils.secrets.get(scope='AzureSecretScope',key='az-sql-mi-admin-password')        

        # Read existing Keys from MI
        existing_keys_df = spark.read.format("jdbc") \
            .option("url", f"{url_mi}{database_name};") \
            .option("dbtable", target_table) \
            .option("user", username) \
            .option("password", pwd) \
            .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
            .load().select(key_columns)

        # Get new keys from input dataframe
        new_keys_df = input_df.select(key_columns)

        # Determine rows to insert
        rows_to_insert = new_keys_df.join(
            existing_keys_df, key_columns, "left_anti"
        ).join(input_df, key_columns)

        # Insert rows into MI
        if rows_to_insert.count() > 0:
            rows_to_insert.write.mode(f"{mode_name}") \
            .format("jdbc") \
            .option("url", f"{url_mi}{database_name};") \
            .option("dbtable", target_table) \
            .option("user", username) \
            .option("password", pwd) \
            .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
            .save()
    except ValueError as err:
        print(err)
        exit()

# COMMAND ----------

data_df = spark.read.table("bronze.mspbi_l_activityevents")
ct = check_if_table_exists("DA_AUDIT", "dbo.ActivityEvents", "Id")
if ct:
    insert_to_mi_db(data_df, "DA_AUDIT", "dbo.ActivityEvents", "append", "Id")
else:
    write_to_mi_db(data_df, "DA_AUDIT", "dbo.ActivityEvents", "overwrite")
