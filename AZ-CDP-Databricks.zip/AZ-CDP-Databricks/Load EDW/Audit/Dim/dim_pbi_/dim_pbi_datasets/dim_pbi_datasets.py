# Databricks notebook source
# MAGIC %md
# MAGIC ##### Pre-processing
# MAGIC
# MAGIC ###### History
# MAGIC
# MAGIC | Date        | Version | Author         | Changes                                                                    |
# MAGIC |-------------|---------|----------------|--------------------------------------------------------------------------- |
# MAGIC | 12-Apr-2023 | 1       | Ranga          | Created dim_pbi_datasets                                   |
# MAGIC |                                                                 |

# COMMAND ----------

# MAGIC %run /Shared/Utilities/utils

# COMMAND ----------

# %run "../../../../Utilities/utils"

# COMMAND ----------

##############################
# Set widget and default value for this.
dbutils.widgets.text("mount_point", "/mnt/devcdpadlsae1/")
path = dbutils.widgets.get("mount_point")
spark.conf.set("table.path",path)
##############################

# COMMAND ----------

# MAGIC %sql
# MAGIC SET TIME ZONE 'Pacific/Auckland';

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS gold.dim_pbi_datasets(
# MAGIC 	id string
# MAGIC 	, name string
# MAGIC     , description string
# MAGIC 	, webUrl string
# MAGIC 	, addRowsAPIEnabled boolean
# MAGIC 	, configuredBy string
# MAGIC 	, isRefreshable boolean
# MAGIC 	, isEffectiveIdentityRequired boolean
# MAGIC 	, isEffectiveIdentityRolesRequired boolean
# MAGIC 	, isOnPremGatewayRequired boolean
# MAGIC 	, targetStorageMode string
# MAGIC 	, createdDate timestamp
# MAGIC 	, createReportEmbedURL string
# MAGIC 	, qnaEmbedURL string
# MAGIC 	, workspaceID string
# MAGIC     , hashField string
# MAGIC 	, dss_version int
# MAGIC 	, dss_activeFlag boolean
# MAGIC 	, dss_activeStartDateTime timestamp
# MAGIC 	, dss_activeEndDateTime timestamp
# MAGIC )
# MAGIC LOCATION '${table.path}gold/Audit/dim_pbi_datasets'

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE silver_db.mspbi_s_pbi_datasets
# MAGIC LOCATION '${table.path}silver_db/Audit/mspbi_s_pbi_datasets'
# MAGIC AS
# MAGIC SELECT 
# MAGIC   id
# MAGIC   , name
# MAGIC   , description
# MAGIC   , webUrl
# MAGIC   , addRowsAPIEnabled
# MAGIC   , configuredBy
# MAGIC   , isRefreshable
# MAGIC   , isEffectiveIdentityRequired
# MAGIC   , isEffectiveIdentityRolesRequired
# MAGIC   , isOnPremGatewayRequired
# MAGIC   , targetStorageMode
# MAGIC   , createdDate
# MAGIC   , createReportEmbedURL
# MAGIC   , qnaEmbedURL
# MAGIC   , workspaceID
# MAGIC   , md5(concat(
# MAGIC         ifnull(id,'')
# MAGIC         , ifnull(name,'')
# MAGIC         , ifnull(description,'')
# MAGIC         , ifnull(webUrl,'')
# MAGIC         , ifnull(cast(addRowsAPIEnabled as string),'')
# MAGIC         , ifnull(configuredBy,'')
# MAGIC         , ifnull(cast(isRefreshable as string),'')
# MAGIC         , ifnull(cast(isEffectiveIdentityRequired as string),'')
# MAGIC         , ifnull(cast(isEffectiveIdentityRolesRequired as string),'')
# MAGIC         , ifnull(cast(isOnPremGatewayRequired as string),'')
# MAGIC         , ifnull(targetStorageMode,'')
# MAGIC         , ifnull(cast(createdDate as string),'')
# MAGIC         , ifnull(createReportEmbedURL,'')
# MAGIC         , ifnull(qnaEmbedURL,'')
# MAGIC         , ifnull(workspaceID,'')
# MAGIC        )) as hashField
# MAGIC   , ROW_NUMBER() OVER (PARTITION BY id ORDER BY createdDate desc) AS RN
# MAGIC FROM bronze.mspbi_l_workspacedatasets
# MAGIC QUALIFY RN = 1
# MAGIC
# MAGIC     

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO gold.dim_pbi_datasets AS target USING (
# MAGIC   SELECT 
# MAGIC    id
# MAGIC    , name
# MAGIC    , description
# MAGIC    , webUrl
# MAGIC    , addRowsAPIEnabled
# MAGIC    , configuredBy
# MAGIC    , isRefreshable
# MAGIC    , isEffectiveIdentityRequired
# MAGIC    , isEffectiveIdentityRolesRequired
# MAGIC    , isOnPremGatewayRequired
# MAGIC    , targetStorageMode
# MAGIC    , createdDate
# MAGIC    , createReportEmbedURL
# MAGIC    , qnaEmbedURL
# MAGIC    , workspaceID
# MAGIC    , hashField
# MAGIC    , 1 dss_version
# MAGIC    , 'update' update_action 
# MAGIC   FROM 
# MAGIC     silver_db.mspbi_s_pbi_datasets 
# MAGIC   UNION ALL 
# MAGIC   SELECT
# MAGIC     src.id
# MAGIC     , src.name
# MAGIC     , src.description
# MAGIC     , src.webUrl
# MAGIC     , src.addRowsAPIEnabled
# MAGIC     , src.configuredBy
# MAGIC     , src.isRefreshable
# MAGIC     , src.isEffectiveIdentityRequired
# MAGIC     , src.isEffectiveIdentityRolesRequired
# MAGIC     , src.isOnPremGatewayRequired
# MAGIC     , src.targetStorageMode
# MAGIC     , src.createdDate
# MAGIC     , src.createReportEmbedURL
# MAGIC     , src.qnaEmbedURL
# MAGIC     , src.workspaceID
# MAGIC     , src.hashField
# MAGIC     , IFNULL(MAX(tgt.dss_version),0) + 1 dss_version
# MAGIC     , 'insert' update_action 
# MAGIC   FROM 
# MAGIC     silver_db.mspbi_s_pbi_datasets src 
# MAGIC     INNER JOIN gold.dim_pbi_datasets tgt ON tgt.id = src.id 
# MAGIC     AND src.hashField <> tgt.hashField 
# MAGIC     AND tgt.dss_activeFlag = TRUE
# MAGIC   GROUP BY 
# MAGIC      src.id
# MAGIC     , src.name
# MAGIC     , src.description
# MAGIC     , src.webUrl
# MAGIC     , src.addRowsAPIEnabled
# MAGIC     , src.configuredBy
# MAGIC     , src.isRefreshable
# MAGIC     , src.isEffectiveIdentityRequired
# MAGIC     , src.isEffectiveIdentityRolesRequired
# MAGIC     , src.isOnPremGatewayRequired
# MAGIC     , src.targetStorageMode
# MAGIC     , src.createdDate
# MAGIC     , src.createReportEmbedURL
# MAGIC     , src.qnaEmbedURL
# MAGIC     , src.workspaceID
# MAGIC     , src.hashField
# MAGIC ) AS source ON source.id = target.id AND source.update_action = 'update' 
# MAGIC
# MAGIC WHEN MATCHED AND source.hashField <> target.hashField AND target.dss_activeFlag = TRUE 
# MAGIC THEN UPDATE 
# MAGIC   SET 
# MAGIC     dss_activeFlag = FALSE, 
# MAGIC     dss_activeEndDateTime = CURRENT_TIMESTAMP()
# MAGIC
# MAGIC WHEN NOT MATCHED THEN INSERT (
# MAGIC     id
# MAGIC     , name
# MAGIC     , description
# MAGIC     , webUrl
# MAGIC     , addRowsAPIEnabled
# MAGIC     , configuredBy
# MAGIC     , isRefreshable
# MAGIC     , isEffectiveIdentityRequired
# MAGIC     , isEffectiveIdentityRolesRequired
# MAGIC     , isOnPremGatewayRequired
# MAGIC     , targetStorageMode
# MAGIC     , createdDate
# MAGIC     , createReportEmbedURL
# MAGIC     , qnaEmbedURL
# MAGIC     , workspaceID
# MAGIC     , hashField
# MAGIC 	, dss_version
# MAGIC 	, dss_activeFlag
# MAGIC 	, dss_activeStartDateTime
# MAGIC 	, dss_activeEndDateTime
# MAGIC   ) 
# MAGIC VALUES 
# MAGIC   (
# MAGIC     source.id
# MAGIC     , source.name
# MAGIC     , source.description
# MAGIC     , source.webUrl
# MAGIC     , source.addRowsAPIEnabled
# MAGIC     , source.configuredBy
# MAGIC     , source.isRefreshable
# MAGIC     , source.isEffectiveIdentityRequired
# MAGIC     , source.isEffectiveIdentityRolesRequired
# MAGIC     , source.isOnPremGatewayRequired
# MAGIC     , source.targetStorageMode
# MAGIC     , source.createdDate
# MAGIC     , source.createReportEmbedURL
# MAGIC     , source.qnaEmbedURL
# MAGIC     , source.workspaceID
# MAGIC     , source.hashField
# MAGIC 	, source.dss_version 
# MAGIC     , TRUE
# MAGIC     , current_timestamp()
# MAGIC     , CAST('2999-12-31T23:59:59.997' as timestamp)
# MAGIC   )

# COMMAND ----------

data_df = spark.read.table("gold.dim_pbi_datasets")
write_to_mi_db(data_df, "DA_AUDIT", "dbo.dim_pbi_datasets", "overwrite")
