/*
 *  Power BI Visualizations
 *
 *  Copyright (c) Elastcloud Ltd
 *  All rights reserved.
 *  MIT License
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the ""Software""), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED *AS IS*, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 *  THE SOFTWARE.
 *
 *  Acknowledgements
 *  Layout inspired by Rick Wicklin and Robert Allison http://stat-computing.org/dataexpo/2009/posters/
 *  Original code by mbostock http://bl.ocks.org/mbostock/4063318
 *  Modified and integrated with love by Andy.
 */
var powerbi;
(function (powerbi) {
    var visuals;
    (function (visuals) {
        var CalendarVisual1442774095659;
        (function (CalendarVisual1442774095659) {
            var SelectionManager = visuals.utility.SelectionManager;
            ;
            ;
            CalendarVisual1442774095659.CalendarChartProps = {
                general: {
                    formatString: { objectName: 'general', propertyName: 'formatString' },
                },
                dataPoint: {
                    defaultColor: { objectName: 'dataPoint', propertyName: 'defaultColor' },
                    fill: { objectName: 'dataPoint', propertyName: 'fill' },
                },
            };
            var CalendarVisual = (function () {
                function CalendarVisual(cellSizeOpt) {
                    var _this = this;
                    this.drawMonthPath = false;
                    this.drawLegend = false;
                    this.drawLabels = true;
                    this.width = 1016;
                    this.height = 144;
                    this.cellSize = 18; // cell size
                    this.getDaysOfYear = function (year) {
                        return d3.time.days(new Date(year, 0, 1), new Date(year + 1, 0, 1));
                    };
                    this.getXPosition = function (date) {
                        return (d3.time.weekOfYear(date.date) * _this.cellSize);
                    };
                    this.getYPosition = function (date) {
                        return (date.date.getDay() * _this.cellSize);
                    };
                    this.monthPath = function (t0) {
                        var t1 = new Date(t0.getFullYear(), t0.getMonth() + 1, 0), d0 = t0.getDay(), w0 = d3.time.weekOfYear(t0), d1 = t1.getDay(), w1 = d3.time.weekOfYear(t1);
                        return "M" + (w0 + 1) * _this.cellSize + "," + d0 * _this.cellSize + "H" + w0 * _this.cellSize + "V" + 7 * _this.cellSize + "H" + w1 * _this.cellSize + "V" + (d1 + 1) * _this.cellSize + "H" + (w1 + 1) * _this.cellSize + "V" + 0 + "H" + (w0 + 1) * _this.cellSize + "Z";
                    };
                    if (cellSizeOpt) {
                        this.cellSize = cellSizeOpt;
                    }
                }
                CalendarVisual.prototype.init = function (options) {
                    this.colors = options.style.colorPalette.dataColors;
                    this.element = options.element.get(0);
                    this.selectionManager = new SelectionManager({ hostServices: options.host });
                    this.hostService = options.host;
                    this.defaultDataPointColorTop = '#01B8AA';
                    this.defaultDataPointColorBottom = '#01B8AA';
                };
                CalendarVisual.prototype.update = function (options) {
                    d3.select(this.element).selectAll("*").remove();
                    var viewModel = this.convert(options.dataViews[0], this.colors);
                    if (viewModel == null)
                        return;
                    var dataView = options.dataViews[0];
                    if (dataView.metadata && dataView.metadata.objects) {
                        var defaultColor = powerbi.DataViewObjects.getFillColor(dataView.metadata.objects, CalendarVisual1442774095659.CalendarChartProps.dataPoint.defaultColor);
                        if (defaultColor)
                            this.defaultDataPointColorTop = defaultColor;
                    }
                    this.maxDomain = viewModel.yearsList.map(function (year) {
                        return viewModel.values[year].map(function (dv) {
                            return dv.value ? dv.value : 0;
                        }).reduce(function (p, c) {
                            if (c > p) {
                                return c;
                            }
                            else {
                                return p;
                            }
                        }, 0);
                    }).reduce(function (p, c) {
                        if (c > p) {
                            return c;
                        }
                        else {
                            return p;
                        }
                    }, 0);
                    var dataViews = options.dataViews;
                    var currentViewport = options.viewport;
                    var dataView = undefined;
                    if (dataViews && dataViews.length > 0) {
                        dataView = dataViews[0];
                    }
                    this.draw(dataView, this.element, options.viewport.width, options.viewport.height, viewModel, this.colors);
                };
                CalendarVisual.prototype.renderTooltip = function (selection) {
                    visuals.TooltipManager.addTooltip(selection, function (tooltipEvent) {
                        return tooltipEvent.data.tooltipInfo;
                    });
                };
                CalendarVisual.prototype.createChangeForFilterProperty = function (selectedId, filterPropertyIdentifier) {
                    var properties = {};
                    var selectors = [];
                    if (selectedId) {
                        selectors = [selectedId.selector];
                    }
                    var instance = {
                        objectName: filterPropertyIdentifier.objectName,
                        selector: undefined,
                        properties: properties
                    };
                    var filter = powerbi.data.Selector.filterFromSelector(selectors, false);
                    if (filter == null) {
                        properties[filterPropertyIdentifier.propertyName] = {};
                        return {
                            remove: [instance]
                        };
                    }
                    else {
                        properties[filterPropertyIdentifier.propertyName] = filter;
                        return {
                            merge: [instance]
                        };
                    }
                };
                CalendarVisual.prototype.enumerateObjectInstances = function (options) {
                    var instances = [];
                    var enumeration = new visuals.ObjectEnumerationBuilder();
                    switch (options.objectName) {
                        case 'cellColor':
                            var cellColor = {
                                objectName: 'cellColor',
                                displayName: 'Cells color',
                                selector: null,
                                properties: {
                                    fill: this.defaultDataPointColorTop
                                }
                            };
                            instances.push(cellColor);
                            break;
                    }
                    return instances;
                };
                CalendarVisual.getTooltipData = function (displayName, value) {
                    return [{
                        displayName: displayName,
                        value: value < 0 ? "" : value.toString()
                    }];
                };
                CalendarVisual.prototype.draw = function (dataView, element, itemWidth, itemHeight, calendarViewModel, colors) {
                    var _this = this;
                    var colorScale = colors.getNewColorScale();
                    var yearslist = calendarViewModel.yearsList;
                    var format = d3.time.format("%Y-%m-%d");
                    var svg = d3.select(element).selectAll("svg").data(yearslist).enter().append("svg");
                    svg.attr("width", itemWidth).attr("height", itemWidth / 7).attr("viewBox", "-20 -20 " + (this.width - 20) + " " + (this.height + 4)).append("g").attr("transform", "translate(" + (20 + (this.width - this.cellSize * 52) / 2) + "," + (20 + this.height - this.cellSize * 7 - 1) + ")");
                    if (this.drawLabels) {
                        var textGroup = svg.append("g").attr("fill", "#cccccc");
                        textGroup.append("text").attr("transform", "translate(" + this.cellSize * -1.5 + "," + this.cellSize * 3.5 + ")rotate(-90)").style("text-anchor", "middle").text(function (d) {
                            return d;
                        });
                        textGroup.append("text").style("text-anchor", "middle").text("M").attr("transform", "translate(" + this.cellSize * -0.75 + ")").attr("x", 0).attr("y", 2 * this.cellSize);
                        textGroup.append("text").style("text-anchor", "middle").text("W").attr("transform", "translate(" + this.cellSize * -0.75 + ")").attr("x", 0).attr("y", 4 * this.cellSize);
                        textGroup.append("text").style("text-anchor", "middle").text("F").attr("transform", "translate(" + this.cellSize * -0.75 + ")").attr("x", 0).attr("y", 6 * this.cellSize);
                        textGroup.append("text").attr("transform", "translate(" + (this.width - (3 * this.cellSize)) + "," + this.cellSize * 3.5 + ")rotate(90)").style("text-anchor", "middle").text(function (d) {
                            return d;
                        });
                        textGroup.selectAll(".month").data(function (d) {
                            return d3.time.months(new Date(d, 0, 1), new Date(d + 1, 0, 1));
                        }).enter().append("text").attr("transform", function (d) {
                            return "translate(" + d3.time.weekOfYear(d) * _this.cellSize + ", -5)";
                        }).text(function (d) {
                            return d3.time.format("%b")(d);
                        });
                    }
                    var pad = function (n) {
                        if (n.toString().length === 1) {
                            return "0" + n;
                        }
                        return n.toString();
                    };
                    this.rect = svg.selectAll(".day").data(function (d, i) {
                        return calendarViewModel.values[d];
                    }).enter().append("rect").attr("width", this.cellSize - 1).attr("height", this.cellSize - 1).attr("class", "day").style({
                        "fill": function (d) { return d.color; },
                        "stroke": function (d) { return d.selector && d.selector.getKey() === _this.selectedKey ? '#333' : null; },
                        "stroke-width": '1px',
                    }).attr("x", this.getXPosition).attr("y", this.getYPosition).on("mousedown", function (d) {
                        _this.selectedKey = d.selector && d.selector.getKey();
                        if (d.selector) {
                            _this.selectionManager.select(d.selector);
                        }
                        else {
                            _this.selectionManager.clear();
                        }
                        _this.hostService.persistProperties(_this.createChangeForFilterProperty(d.selector, visuals.slicerProps.filterPropertyIdentifier));
                        if (_this.prevSelection) {
                            var oldStyle = _this.prevSelection.attr("oldStyle");
                            _this.prevSelection.attr("style", oldStyle);
                        }
                        var rect = d3.select(d3.event.target);
                        if (d.selector) {
                            var oldFill = rect.attr("style");
                            rect.attr("style", "stroke:#000000;stroke-width: 1px;" + oldFill);
                            rect.attr("oldStyle", oldFill);
                        }
                        _this.prevSelection = rect;
                        event.stopPropagation();
                    });
                    this.renderTooltip(this.rect);
                    svg.selectAll(".month").data(function (d) {
                        return d3.time.months(new Date(d, 0, 1), new Date(d + 1, 0, 1));
                    }).enter().append("path").attr("class", "month").attr("d", this.monthPath).attr("stroke", "#bbbbbb");
                    if (this.drawLegend) {
                        var legendGroup = d3.select(this.element).insert("svg", ":first-child").attr("width", itemWidth).attr("height", itemWidth / 17.5).attr("viewBox", "0 0 " + this.width + " " + this.height / 7).attr("preserveAspectRatio", "xMinYMin").append("g");
                        legendGroup.append("rect").attr("width", this.cellSize).attr("height", this.cellSize).attr("x", 0).attr("y", 0).attr("fill", "#000000");
                        legendGroup.append("rect").attr("width", this.cellSize).attr("height", this.cellSize).attr("x", 0).attr("y", this.cellSize * 1.5).attr("fill", "#00ff00");
                        legendGroup.append("text").text(0).attr("x", this.cellSize * 2).attr("y", this.cellSize);
                        legendGroup.append("text").text(d3.format(".4r")(this.maxDomain)).attr("x", this.cellSize * 2).attr("y", this.cellSize * 2.5);
                    }
                    svg.on('mousedown', function (d) {
                        _this.selectionManager.clear();
                        _this.selectedKey = null;
                    });
                };
                CalendarVisual.prototype.rgb2hex = function (red, green, blue) {
                    var rgb = blue | (green << 8) | (red << 16);
                    return '#' + (0x1000000 + rgb).toString(16).slice(1);
                };
                CalendarVisual.prototype.setUpColors = function (minValue, maxValue, returnSet) {
                    var r2 = parseInt(this.defaultDataPointColorTop.substr(1, 2), 16);
                    var g2 = parseInt(this.defaultDataPointColorTop.substr(3, 2), 16);
                    var b2 = parseInt(this.defaultDataPointColorTop.substr(5, 2), 16);
                    var bottomColor = '#dddddd';
                    var r1 = parseInt(bottomColor.substr(1, 2), 16);
                    var g1 = parseInt(bottomColor.substr(3, 2), 16);
                    var b1 = parseInt(bottomColor.substr(5, 2), 16);
                    var ratio = 1 / (maxValue - minValue);
                    for (var i = 0; i < returnSet.length; i++)
                        if (returnSet[i]) {
                            var percent = (returnSet[i].value - minValue) * ratio;
                            var resultRed = Math.abs(r1 + percent * (r2 - r1));
                            var resultGreen = Math.abs(g1 + percent * (g2 - g1));
                            var resultBlue = Math.abs(b1 + percent * (b2 - b1));
                            returnSet[i].color = this.rgb2hex(resultRed, resultGreen, resultBlue);
                        }
                };
                CalendarVisual.prototype.convert = function (dataView, colors) {
                    if (dataView && dataView.metadata.objects) {
                        var cellColorObj = dataView.metadata.objects['cellColor'];
                        if (cellColorObj && cellColorObj['fill']) {
                            this.defaultDataPointColorTop = cellColorObj['fill'].solid.color;
                        }
                    }
                    if (dataView == undefined || dataView.categorical == undefined || dataView.categorical.categories == null) {
                        window.console.log("no categoricals");
                        return;
                    }
                    else if (dataView.categorical.categories[0].values == undefined || dataView.categorical.categories[0].values == null) {
                        window.console.log("no categoricals");
                        return;
                    }
                    window.console.log(dataView.categorical.categories);
                    var minValue = 0;
                    var maxValue = 0;
                    var returnSet = dataView.categorical.categories[0].values.map(function (v, i) {
                        if (dataView.categorical.values) {
                            window.console.log("err somewhere here");
                            var retVal = {
                                date: v,
                                color: '',
                                value: dataView.categorical.values.map(function (val) {
                                    return val.values[i];
                                }).reduce(function (prev, curr) {
                                    return prev + curr;
                                }),
                                selector: visuals.SelectionIdBuilder.builder().withCategory(dataView.categorical.categories[0], i).withMeasure(dataView.categorical.values[0].source.queryName).createSelectionId(),
                                dateStr: v.getFullYear() + "-" + CalendarVisual.pad(v.getMonth() + 1) + "-" + CalendarVisual.pad(v.getDate())
                            };
                            //                        retVal.color = this.getDataPointColor(retVal.value);
                            if (i == 0 || minValue > retVal.value)
                                minValue = retVal.value;
                            if (i == 0 || maxValue < retVal.value)
                                maxValue = retVal.value;
                            retVal.tooltipInfo = CalendarVisual.getTooltipData(retVal.dateStr, retVal.value);
                            return retVal;
                        }
                        else
                            return null;
                    });
                    this.setUpColors(minValue, maxValue, returnSet);
                    var yearsList = this.getYears(returnSet);
                    var daysList = new Array();
                    for (var i = 0; i < yearsList.length; i++) {
                        var daysofY = this.getDaysOfYear(yearsList[i]).map(function (d) {
                            var activeDays = returnSet.filter(function (val) {
                                if (val) {
                                    return val.date.getTime() == d.getTime();
                                }
                                return false;
                            });
                            if (activeDays.length > 0) {
                                return activeDays[0];
                            }
                            return {
                                date: d,
                                dateStr: "",
                                value: 0
                            };
                        });
                        daysList[yearsList[i]] = daysofY;
                    }
                    ;
                    return {
                        values: daysList,
                        yearsList: yearsList
                    };
                };
                CalendarVisual.prototype.getYears = function (values) {
                    var allYears = values.map(function (value) {
                        if (value == null || value.date == null || value.date == undefined || isNaN(Date.parse(value.date.toString()))) {
                            return 1900;
                        }
                        ;
                        return value.date.getFullYear ? value.date.getFullYear() : null;
                    });
                    var uniqueYears = {}, a = [];
                    for (var i = 0, l = allYears.length; i < l; ++i) {
                        if (allYears[i] == null || uniqueYears.hasOwnProperty(allYears[i].toString())) {
                            continue;
                        }
                        a.push(allYears[i]);
                        uniqueYears[allYears[i].toString()] = 1;
                    }
                    return a.sort();
                };
                CalendarVisual.capabilities = {
                    dataRoles: [
                        {
                            name: 'Category',
                            kind: powerbi.VisualDataRoleKind.Grouping,
                            displayName: 'Category',
                        },
                        {
                            name: 'Y',
                            kind: powerbi.VisualDataRoleKind.Measure,
                            displayName: 'Y',
                        }
                    ],
                    dataViewMappings: [{
                        conditions: [
                            { 'Category': { max: 1 }, 'Y': { max: 1 } },
                        ],
                        categorical: {
                            categories: {
                                for: { in: 'Category' },
                            },
                            values: {
                                group: {
                                    by: 'Series',
                                    select: [{ bind: { to: 'Y' } }],
                                    dataReductionAlgorithm: { top: {} }
                                }
                            },
                            rowCount: { preferred: { max: 2 } }
                        },
                    }],
                    objects: {
                        cellColor: {
                            displayName: 'Cells color',
                            properties: {
                                fill: {
                                    displayName: 'Cell fill',
                                    type: { fill: { solid: { color: true } } }
                                }
                            }
                        },
                        general: {
                            displayName: powerbi.data.createDisplayNameGetter('Visual_General'),
                            properties: {
                                formatString: {
                                    type: { formatting: { formatString: true } },
                                },
                                filter: {
                                    type: { filter: {} },
                                    rule: {
                                        output: {
                                            property: 'selected',
                                            selector: ['Values'],
                                        }
                                    }
                                },
                            },
                        },
                        dataPoint: {
                            displayName: powerbi.data.createDisplayNameGetter('Visual_DataPoint'),
                            properties: {
                                defaultColor: {
                                    displayName: powerbi.data.createDisplayNameGetter('Visual_DefaultColor'),
                                    type: { fill: { solid: { color: true } } }
                                },
                                fill: {
                                    displayName: powerbi.data.createDisplayNameGetter('Visual_Fill'),
                                    type: { fill: { solid: { color: true } } }
                                },
                            }
                        },
                        labels: {
                            displayName: powerbi.data.createDisplayNameGetter('Visual_DataPointsLabels'),
                            properties: {
                                show: {
                                    displayName: powerbi.data.createDisplayNameGetter('Visual_Show'),
                                    type: { bool: true },
                                },
                                color: {
                                    displayName: powerbi.data.createDisplayNameGetter('Visual_LabelsFill'),
                                    type: { fill: { solid: { color: true } } }
                                },
                                labelDisplayUnits: {
                                    displayName: powerbi.data.createDisplayNameGetter('Visual_DisplayUnits'),
                                    type: { formatting: { labelDisplayUnits: true } }
                                }
                            }
                        }
                    }
                };
                CalendarVisual.pad = function (n) {
                    if (n.toString().length === 1) {
                        return "0" + n;
                    }
                    return n.toString();
                };
                return CalendarVisual;
            })();
            CalendarVisual1442774095659.CalendarVisual = CalendarVisual;
        })(CalendarVisual1442774095659 = visuals.CalendarVisual1442774095659 || (visuals.CalendarVisual1442774095659 = {}));
    })(visuals = powerbi.visuals || (powerbi.visuals = {}));
})(powerbi || (powerbi = {}));
var powerbi;
(function (powerbi) {
    var visuals;
    (function (visuals) {
        var plugins;
        (function (plugins) {
            plugins.CalendarVisual1442774095659 = {
                name: 'CalendarVisual1442774095659',
                class: 'CalendarVisual1442774095659',
                capabilities: powerbi.visuals.CalendarVisual1442774095659.CalendarVisual.capabilities,
                custom: true,
                create: function () { return new powerbi.visuals.CalendarVisual1442774095659.CalendarVisual(); }
            };
        })(plugins = visuals.plugins || (visuals.plugins = {}));
    })(visuals = powerbi.visuals || (powerbi.visuals = {}));
})(powerbi || (powerbi = {}));
//# sourceMappingURL=CalendarVisual1442774095659.js.map